package com.rehman.ahmedreactionstudio;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: R.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001:\u0003\u0003\u0004\u0005B\u0007\b\u0002¢\u0006\u0002\u0010\u0002"}, d2 = {"Lcom/rehman/ahmedreactionstudio/R;", "", "()V", "drawable", "mipmap", "style"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class R {

    @NotNull
    public static final R INSTANCE = new R();

    /* JADX INFO: compiled from: R.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b3\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00100\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00101\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00102\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00103\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00104\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00105\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00106\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u00107\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/R$drawable;", "", "()V", "ic_add", "", "ic_aspect", "ic_back", "ic_camera", "ic_center", "ic_check", "ic_close", "ic_copy", "ic_corner_bl", "ic_corner_br", "ic_corner_tl", "ic_corner_tr", "ic_delete", "ic_down", "ic_drag", "ic_edit", "ic_export", "ic_eye", "ic_eye_off", "ic_fill", "ic_fit", "ic_flash", "ic_fullscreen", "ic_image", "ic_info", "ic_launcher_background", "ic_layers", "ic_lock", "ic_lock_open", "ic_loop", "ic_more", "ic_palette", "ic_pause", "ic_play", "ic_redo", "ic_reset", "ic_screen", "ic_settings", "ic_star", "ic_stop", "ic_switch", "ic_text", "ic_undo", "ic_up", "ic_video", "ic_volume", "ic_volume_off", "ic_warning", "ic_wheel", "mixer_panel", "sources_panel", "splash_bg"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class drawable {

        @NotNull
        public static final drawable INSTANCE = new drawable();
        public static final int ic_add = 0x7f010000;
        public static final int ic_aspect = 0x7f010001;
        public static final int ic_back = 0x7f010002;
        public static final int ic_camera = 0x7f010003;
        public static final int ic_center = 0x7f010004;
        public static final int ic_check = 0x7f010005;
        public static final int ic_close = 0x7f010006;
        public static final int ic_copy = 0x7f010007;
        public static final int ic_corner_bl = 0x7f010008;
        public static final int ic_corner_br = 0x7f010009;
        public static final int ic_corner_tl = 0x7f01000a;
        public static final int ic_corner_tr = 0x7f01000b;
        public static final int ic_delete = 0x7f01000c;
        public static final int ic_down = 0x7f01000d;
        public static final int ic_drag = 0x7f01000e;
        public static final int ic_edit = 0x7f01000f;
        public static final int ic_export = 0x7f010010;
        public static final int ic_eye = 0x7f010011;
        public static final int ic_eye_off = 0x7f010012;
        public static final int ic_fill = 0x7f010013;
        public static final int ic_fit = 0x7f010014;
        public static final int ic_flash = 0x7f010015;
        public static final int ic_fullscreen = 0x7f010016;
        public static final int ic_image = 0x7f010017;
        public static final int ic_info = 0x7f010018;
        public static final int ic_launcher_background = 0x7f010019;
        public static final int ic_layers = 0x7f01001a;
        public static final int ic_lock = 0x7f01001b;
        public static final int ic_lock_open = 0x7f01001c;
        public static final int ic_loop = 0x7f01001d;
        public static final int ic_more = 0x7f01001e;
        public static final int ic_palette = 0x7f01001f;
        public static final int ic_pause = 0x7f010020;
        public static final int ic_play = 0x7f010021;
        public static final int ic_redo = 0x7f010022;
        public static final int ic_reset = 0x7f010023;
        public static final int ic_screen = 0x7f010024;
        public static final int ic_settings = 0x7f010025;
        public static final int ic_star = 0x7f010026;
        public static final int ic_stop = 0x7f010027;
        public static final int ic_switch = 0x7f010028;
        public static final int ic_text = 0x7f010029;
        public static final int ic_undo = 0x7f01002a;
        public static final int ic_up = 0x7f01002b;
        public static final int ic_video = 0x7f01002c;
        public static final int ic_volume = 0x7f01002d;
        public static final int ic_volume_off = 0x7f01002e;
        public static final int ic_warning = 0x7f01002f;
        public static final int ic_wheel = 0x7f010030;
        public static final int mixer_panel = 0x7f010031;
        public static final int sources_panel = 0x7f010032;
        public static final int splash_bg = 0x7f010033;

        private drawable() {
        }
    }

    private R() {
    }

    /* JADX INFO: compiled from: R.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/R$mipmap;", "", "()V", "ic_launcher", "", "ic_launcher_foreground", "ic_launcher_round"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class mipmap {

        @NotNull
        public static final mipmap INSTANCE = new mipmap();
        public static final int ic_launcher = 0x7f020000;
        public static final int ic_launcher_foreground = 0x7f020001;
        public static final int ic_launcher_round = 0x7f020002;

        private mipmap() {
        }
    }

    /* JADX INFO: compiled from: R.kt */
    @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/R$style;", "", "()V", "Theme_AhmedSplash", ""}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class style {

        @NotNull
        public static final style INSTANCE = new style();
        public static final int Theme_AhmedSplash = 0x7f030000;

        private style() {
        }
    }
}
