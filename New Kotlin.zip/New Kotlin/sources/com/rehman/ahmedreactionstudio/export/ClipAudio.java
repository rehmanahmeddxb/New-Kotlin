package com.rehman.ahmedreactionstudio.export;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: CompositionRecorder.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0002\b\r\u0018\u00002\u00020\u0001B9\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\b\b\u0002\u0010\n\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0005¢\u0006\u0002\u0010\fR\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\n\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0010R\u0011\u0010\u000b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0015"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/ClipAudio;", "", "path", "", "volume", "", "loop", "", "durMs", "", "layerId", "speed", "(Ljava/lang/String;FZJLjava/lang/String;F)V", "getDurMs", "()J", "getLayerId", "()Ljava/lang/String;", "getLoop", "()Z", "getPath", "getSpeed", "()F", "getVolume"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class ClipAudio {
    private final long durMs;

    @NotNull
    private final String layerId;
    private final boolean loop;

    @NotNull
    private final String path;
    private final float speed;
    private final float volume;

    public ClipAudio(@NotNull String path, float f, boolean z, long j, @NotNull String layerId, float f2) {
        Intrinsics.checkNotNullParameter(path, "path");
        Intrinsics.checkNotNullParameter(layerId, "layerId");
        this.path = path;
        this.volume = f;
        this.loop = z;
        this.durMs = j;
        this.layerId = layerId;
        this.speed = f2;
    }

    public /* synthetic */ ClipAudio(String str, float f, boolean z, long j, String str2, float f2, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, f, z, j, (i & 16) != 0 ? "" : str2, (i & 32) != 0 ? 1.0f : f2);
    }

    @NotNull
    public final String getPath() {
        return this.path;
    }

    public final float getVolume() {
        return this.volume;
    }

    public final boolean getLoop() {
        return this.loop;
    }

    public final long getDurMs() {
        return this.durMs;
    }

    @NotNull
    public final String getLayerId() {
        return this.layerId;
    }

    public final float getSpeed() {
        return this.speed;
    }
}
