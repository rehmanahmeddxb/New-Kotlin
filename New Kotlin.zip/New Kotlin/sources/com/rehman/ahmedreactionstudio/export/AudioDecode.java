package com.rehman.ahmedreactionstudio.export;

import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.view.Surface;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: AudioDecode.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J \u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u000bH\u0002J.\u0010\f\u001a\u00020\u00062\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00060\u000e2\u0006\u0010\u000f\u001a\u00020\u00042\u0006\u0010\u0010\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\u0004H\u0002J\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u00132\u0006\u0010\u0014\u001a\u00020\u0015R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082D¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/AudioDecode;", "", "()V", "TARGET_RATE", "", "readSamples", "", "buf", "Ljava/nio/ByteBuffer;", "size", "pcmFloat", "", "resampleToMono", "chunks", "", "totalSamples", "nativeRate", "nativeChannels", "toPcmMono", "Lcom/rehman/ahmedreactionstudio/export/PcmClip;", "path", ""}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class AudioDecode {

    @NotNull
    public static final AudioDecode INSTANCE = new AudioDecode();
    private static final int TARGET_RATE = 44100;

    private AudioDecode() {
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r12v2 */
    /* JADX WARN: Type inference failed for: r2v1, types: [android.media.MediaExtractor] */
    /* JADX WARN: Type inference failed for: r4v0 */
    /* JADX WARN: Type inference failed for: r4v1, types: [int] */
    /* JADX WARN: Type inference failed for: r4v11 */
    /* JADX WARN: Type inference failed for: r4v15 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6 */
    /* JADX WARN: Type inference failed for: r4v7 */
    @Nullable
    public final PcmClip toPcmMono(@NotNull String path) {
        String string;
        MediaCodec mediaCodecCreateDecoderByType;
        boolean z;
        int i;
        int i2;
        ArrayList arrayList;
        String str;
        boolean z2;
        long j;
        MediaCodec.BufferInfo bufferInfo;
        String str2;
        int integer;
        int integer2;
        boolean z3;
        AudioDecode audioDecode;
        ArrayList arrayList2;
        boolean z4;
        boolean z5;
        int iDequeueInputBuffer;
        AudioDecode audioDecode2 = this;
        Intrinsics.checkNotNullParameter(path, "path");
        ?? mediaExtractor = new MediaExtractor();
        try {
            mediaExtractor.setDataSource(path);
            int trackCount = mediaExtractor.getTrackCount();
            ?? r4 = 0;
            int i3 = 0;
            while (true) {
                if (i3 >= trackCount) {
                    string = null;
                    i3 = -1;
                    break;
                }
                string = mediaExtractor.getTrackFormat(i3).getString("mime");
                if (string != null && StringsKt.startsWith$default(string, "audio/", false, 2, (Object) null)) {
                    break;
                }
                i3++;
            }
            if (i3 < 0 || string == null) {
                mediaExtractor.release();
                return null;
            }
            mediaExtractor.selectTrack(i3);
            MediaFormat trackFormat = mediaExtractor.getTrackFormat(i3);
            try {
                mediaCodecCreateDecoderByType = MediaCodec.createDecoderByType(string);
            } catch (Exception unused) {
                mediaCodecCreateDecoderByType = null;
            }
            if (mediaCodecCreateDecoderByType == null) {
                mediaExtractor.release();
                return null;
            }
            try {
                mediaCodecCreateDecoderByType.configure(trackFormat, (Surface) null, (MediaCrypto) null, 0);
                mediaCodecCreateDecoderByType.start();
                String str3 = "sample-rate";
                int integer3 = trackFormat.containsKey("sample-rate") ? trackFormat.getInteger("sample-rate") : 0;
                int integer4 = trackFormat.containsKey("channel-count") ? trackFormat.getInteger("channel-count") : 0;
                String str4 = "pcm-encoding";
                boolean z6 = trackFormat.containsKey("pcm-encoding") && trackFormat.getInteger("pcm-encoding") == 4;
                MediaCodec.BufferInfo bufferInfo2 = new MediaCodec.BufferInfo();
                ArrayList arrayList3 = new ArrayList();
                int i4 = 0;
                boolean z7 = false;
                int i5 = integer3;
                int i6 = integer4;
                boolean z8 = z6;
                boolean z9 = false;
                int length = 0;
                while (!z9 && i4 < 500) {
                    String str5 = str4;
                    String str6 = str3;
                    if (z7 || (iDequeueInputBuffer = mediaCodecCreateDecoderByType.dequeueInputBuffer(10000L)) < 0) {
                        z = z8;
                        i = length;
                        i2 = i4;
                        arrayList = arrayList3;
                        str = str5;
                        z2 = z9;
                        j = 10000;
                        bufferInfo = bufferInfo2;
                        z7 = z7;
                    } else {
                        ByteBuffer inputBuffer = mediaCodecCreateDecoderByType.getInputBuffer(iDequeueInputBuffer);
                        Intrinsics.checkNotNull(inputBuffer);
                        int sampleData = mediaExtractor.readSampleData(inputBuffer, r4);
                        if (sampleData < 0) {
                            z = z8;
                            i = length;
                            i2 = i4;
                            bufferInfo = bufferInfo2;
                            arrayList = arrayList3;
                            str = str5;
                            z2 = z9;
                            j = 10000;
                            mediaCodecCreateDecoderByType.queueInputBuffer(iDequeueInputBuffer, 0, 0, 0L, 4);
                            z7 = true;
                        } else {
                            z = z8;
                            i = length;
                            i2 = i4;
                            arrayList = arrayList3;
                            bufferInfo = bufferInfo2;
                            str = str5;
                            z2 = z9;
                            j = 10000;
                            mediaCodecCreateDecoderByType.queueInputBuffer(iDequeueInputBuffer, 0, sampleData, mediaExtractor.getSampleTime(), 0);
                            mediaExtractor.advance();
                            z7 = z7;
                        }
                    }
                    int iDequeueOutputBuffer = mediaCodecCreateDecoderByType.dequeueOutputBuffer(bufferInfo, j);
                    if (iDequeueOutputBuffer == -2) {
                        MediaFormat outputFormat = mediaCodecCreateDecoderByType.getOutputFormat();
                        str2 = str6;
                        if (outputFormat.containsKey(str2) && (integer2 = outputFormat.getInteger(str2)) > 0) {
                            i5 = integer2;
                        }
                        if (outputFormat.containsKey("channel-count") && (integer = outputFormat.getInteger("channel-count")) > 0) {
                            i6 = integer;
                        }
                        if (outputFormat.containsKey(str)) {
                            z8 = outputFormat.getInteger(str) == 4;
                            audioDecode2 = this;
                        } else {
                            audioDecode2 = this;
                            z8 = z;
                        }
                        length = i;
                        str4 = str;
                        bufferInfo2 = bufferInfo;
                        i4 = i2;
                    } else {
                        str2 = str6;
                        if (iDequeueOutputBuffer == -1) {
                            i4 = i2 + 1;
                            audioDecode2 = this;
                            z8 = z;
                            length = i;
                            str4 = str;
                            bufferInfo2 = bufferInfo;
                        } else if (iDequeueOutputBuffer >= 0) {
                            ByteBuffer outputBuffer = mediaCodecCreateDecoderByType.getOutputBuffer(iDequeueOutputBuffer);
                            if (outputBuffer == null || bufferInfo.size <= 0) {
                                audioDecode = this;
                                arrayList2 = arrayList;
                                length = i;
                            } else {
                                outputBuffer.position(bufferInfo.offset);
                                outputBuffer.limit(bufferInfo.offset + bufferInfo.size);
                                audioDecode = this;
                                short[] samples = audioDecode.readSamples(outputBuffer, bufferInfo.size, z);
                                arrayList2 = arrayList;
                                arrayList2.add(samples);
                                length = samples.length + i;
                            }
                            if ((bufferInfo.flags & 4) != 0) {
                                z5 = true;
                                z4 = false;
                            } else {
                                z4 = false;
                                z5 = false;
                            }
                            mediaCodecCreateDecoderByType.releaseOutputBuffer(iDequeueOutputBuffer, z4);
                            boolean z10 = z2;
                            if (z5) {
                                z10 = true;
                            }
                            z8 = z;
                            str4 = str;
                            audioDecode2 = audioDecode;
                            boolean z11 = z4;
                            arrayList3 = arrayList2;
                            i4 = z11 ? 1 : 0;
                            bufferInfo2 = bufferInfo;
                            r4 = z11;
                            z3 = z10;
                            str3 = str2;
                            z9 = z3;
                        } else {
                            z8 = z;
                            length = i;
                            str4 = str;
                            r4 = 0;
                            bufferInfo2 = bufferInfo;
                            str3 = str2;
                            z9 = z2;
                            i4 = i2 + 1;
                            audioDecode2 = this;
                            arrayList3 = arrayList;
                        }
                    }
                    arrayList3 = arrayList;
                    r4 = 0;
                    z3 = z2;
                    str3 = str2;
                    z9 = z3;
                }
                ?? r12 = r4;
                int i7 = length;
                ArrayList arrayList4 = arrayList3;
                AudioDecode audioDecode3 = audioDecode2;
                try {
                    mediaCodecCreateDecoderByType.stop();
                } catch (Exception unused2) {
                }
                try {
                    mediaCodecCreateDecoderByType.release();
                } catch (Exception unused3) {
                }
                try {
                    mediaExtractor.release();
                } catch (Exception unused4) {
                }
                if (i7 == 0) {
                    return null;
                }
                if (i5 <= 0) {
                    i5 = TARGET_RATE;
                }
                short[] sArrResampleToMono = audioDecode3.resampleToMono(arrayList4, i7, i5, i6 <= 0 ? 1 : i6);
                if (sArrResampleToMono.length != 0 ? r12 == true ? 1 : 0 : true) {
                    return null;
                }
                return new PcmClip(sArrResampleToMono, TARGET_RATE);
            } catch (Exception unused5) {
                mediaExtractor.release();
                return null;
            }
        } catch (Exception unused6) {
            mediaExtractor.release();
            return null;
        }
    }

    private final short[] readSamples(ByteBuffer buf, int size, boolean pcmFloat) {
        try {
            buf.order(ByteOrder.nativeOrder());
        } catch (Exception unused) {
        }
        if (pcmFloat) {
            int i = size / 4;
            short[] sArr = new short[i];
            for (int i2 = 0; i2 < i; i2++) {
                sArr[i2] = (short) RangesKt.coerceIn((int) (buf.getFloat() * 32767.0f), -32768, 32767);
            }
            return sArr;
        }
        short[] sArr2 = new short[size / 2];
        buf.asShortBuffer().get(sArr2);
        return sArr2;
    }

    private final short[] resampleToMono(List<short[]> chunks, int totalSamples, int nativeRate, int nativeChannels) {
        short[] sArr = new short[totalSamples];
        int length = 0;
        for (short[] sArr2 : chunks) {
            System.arraycopy(sArr2, 0, sArr, length, sArr2.length);
            length += sArr2.length;
        }
        int i = totalSamples / nativeChannels;
        if (i <= 0) {
            return new short[0];
        }
        int iCoerceAtLeast = RangesKt.coerceAtLeast((int) ((((long) i) * ((long) TARGET_RATE)) / ((long) nativeRate)), 1);
        short[] sArr3 = new short[iCoerceAtLeast];
        for (int i2 = 0; i2 < iCoerceAtLeast; i2++) {
            double d = (((double) i2) * ((double) nativeRate)) / ((double) TARGET_RATE);
            float f = (float) (d - ((double) ((int) d)));
            float f2 = 0.0f;
            for (int i3 = 0; i3 < nativeChannels; i3++) {
                f2 += (sArr[(r11 * nativeChannels) + i3] * (1.0f - f)) + (sArr[(RangesKt.coerceAtMost(r11 + 1, i - 1) * nativeChannels) + i3] * f);
            }
            sArr3[i2] = (short) RangesKt.coerceIn((int) (f2 / nativeChannels), -32768, 32767);
        }
        return sArr3;
    }
}
