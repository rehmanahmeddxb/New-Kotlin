package com.rehman.ahmedreactionstudio.export;

import android.media.MediaExtractor;
import android.media.MediaFormat;
import java.io.File;
import java.nio.ByteBuffer;
import kotlin.Metadata;
import kotlin.Triple;
import kotlin.io.ConstantsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: ExportValidator.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0010\t\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001\u0011B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J*\u0010\u0003\u001a\u0014\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u00042\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0005H\u0002J \u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00072\b\b\u0002\u0010\u0010\u001a\u00020\u0006"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/ExportValidator;", "", "()V", "countTrack", "Lkotlin/Triple;", "", "", "", "ex", "Landroid/media/MediaExtractor;", "track", "validate", "Lcom/rehman/ahmedreactionstudio/export/ExportValidator$Report;", "path", "", "expectAudio", "minBytes", "Report"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class ExportValidator {

    @NotNull
    public static final ExportValidator INSTANCE = new ExportValidator();

    private ExportValidator() {
    }

    /* JADX INFO: compiled from: ExportValidator.kt */
    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b#\b\u0086\b\u0018\u00002\u00020\u0001Bi\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\u0007\u0012\b\b\u0002\u0010\t\u001a\u00020\n\u0012\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\r\u001a\u00020\u0007\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u0007\u0012\b\b\u0002\u0010\u000f\u001a\u00020\n¢\u0006\u0002\u0010\u0010J\t\u0010\u001f\u001a\u00020\u0003HÆ\u0003J\t\u0010 \u001a\u00020\nHÆ\u0003J\t\u0010!\u001a\u00020\u0005HÆ\u0003J\t\u0010\"\u001a\u00020\u0007HÆ\u0003J\t\u0010#\u001a\u00020\u0007HÆ\u0003J\t\u0010$\u001a\u00020\nHÆ\u0003J\u000b\u0010%\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000b\u0010&\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\t\u0010'\u001a\u00020\u0007HÆ\u0003J\t\u0010(\u001a\u00020\u0007HÆ\u0003Jq\u0010)\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00072\b\b\u0002\u0010\t\u001a\u00020\n2\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\r\u001a\u00020\u00072\b\b\u0002\u0010\u000e\u001a\u00020\u00072\b\b\u0002\u0010\u000f\u001a\u00020\nHÆ\u0001J\u0013\u0010*\u001a\u00020\u00032\b\u0010+\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010,\u001a\u00020\u0007HÖ\u0001J\t\u0010-\u001a\u00020\u0005HÖ\u0001R\u0013\u0010\f\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u000e\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u000f\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0016R\u0011\u0010\b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0014R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0012R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0013\u0010\u000b\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0012R\u0011\u0010\r\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0014R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0014"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/ExportValidator$Report;", "", "ok", "", "message", "", "width", "", "height", "durationUs", "", "videoMime", "audioMime", "videoSamples", "audioSamples", "bytes", "(ZLjava/lang/String;IIJLjava/lang/String;Ljava/lang/String;IIJ)V", "getAudioMime", "()Ljava/lang/String;", "getAudioSamples", "()I", "getBytes", "()J", "getDurationUs", "getHeight", "getMessage", "getOk", "()Z", "getVideoMime", "getVideoSamples", "getWidth", "component1", "component10", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "other", "hashCode", "toString"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final /* data */ class Report {

        @Nullable
        private final String audioMime;
        private final int audioSamples;
        private final long bytes;
        private final long durationUs;
        private final int height;

        @NotNull
        private final String message;
        private final boolean ok;

        @Nullable
        private final String videoMime;
        private final int videoSamples;
        private final int width;

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final boolean getOk() {
            return this.ok;
        }

        /* JADX INFO: renamed from: component10, reason: from getter */
        public final long getBytes() {
            return this.bytes;
        }

        @NotNull
        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getMessage() {
            return this.message;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final int getWidth() {
            return this.width;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final int getHeight() {
            return this.height;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final long getDurationUs() {
            return this.durationUs;
        }

        @Nullable
        /* JADX INFO: renamed from: component6, reason: from getter */
        public final String getVideoMime() {
            return this.videoMime;
        }

        @Nullable
        /* JADX INFO: renamed from: component7, reason: from getter */
        public final String getAudioMime() {
            return this.audioMime;
        }

        /* JADX INFO: renamed from: component8, reason: from getter */
        public final int getVideoSamples() {
            return this.videoSamples;
        }

        /* JADX INFO: renamed from: component9, reason: from getter */
        public final int getAudioSamples() {
            return this.audioSamples;
        }

        @NotNull
        public final Report copy(boolean ok, @NotNull String message, int width, int height, long durationUs, @Nullable String videoMime, @Nullable String audioMime, int videoSamples, int audioSamples, long bytes) {
            Intrinsics.checkNotNullParameter(message, "message");
            return new Report(ok, message, width, height, durationUs, videoMime, audioMime, videoSamples, audioSamples, bytes);
        }

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Report)) {
                return false;
            }
            Report report = (Report) other;
            return this.ok == report.ok && Intrinsics.areEqual(this.message, report.message) && this.width == report.width && this.height == report.height && this.durationUs == report.durationUs && Intrinsics.areEqual(this.videoMime, report.videoMime) && Intrinsics.areEqual(this.audioMime, report.audioMime) && this.videoSamples == report.videoSamples && this.audioSamples == report.audioSamples && this.bytes == report.bytes;
        }

        public int hashCode() {
            int iHashCode = ((((((((Boolean.hashCode(this.ok) * 31) + this.message.hashCode()) * 31) + Integer.hashCode(this.width)) * 31) + Integer.hashCode(this.height)) * 31) + Long.hashCode(this.durationUs)) * 31;
            String str = this.videoMime;
            int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
            String str2 = this.audioMime;
            return ((((((iHashCode2 + (str2 != null ? str2.hashCode() : 0)) * 31) + Integer.hashCode(this.videoSamples)) * 31) + Integer.hashCode(this.audioSamples)) * 31) + Long.hashCode(this.bytes);
        }

        @NotNull
        public String toString() {
            return "Report(ok=" + this.ok + ", message=" + this.message + ", width=" + this.width + ", height=" + this.height + ", durationUs=" + this.durationUs + ", videoMime=" + this.videoMime + ", audioMime=" + this.audioMime + ", videoSamples=" + this.videoSamples + ", audioSamples=" + this.audioSamples + ", bytes=" + this.bytes + ')';
        }

        public Report(boolean z, @NotNull String message, int i, int i2, long j, @Nullable String str, @Nullable String str2, int i3, int i4, long j2) {
            Intrinsics.checkNotNullParameter(message, "message");
            this.ok = z;
            this.message = message;
            this.width = i;
            this.height = i2;
            this.durationUs = j;
            this.videoMime = str;
            this.audioMime = str2;
            this.videoSamples = i3;
            this.audioSamples = i4;
            this.bytes = j2;
        }

        public /* synthetic */ Report(boolean z, String str, int i, int i2, long j, String str2, String str3, int i3, int i4, long j2, int i5, DefaultConstructorMarker defaultConstructorMarker) {
            this(z, str, (i5 & 4) != 0 ? 0 : i, (i5 & 8) != 0 ? 0 : i2, (i5 & 16) != 0 ? 0L : j, (i5 & 32) != 0 ? null : str2, (i5 & 64) != 0 ? null : str3, (i5 & 128) != 0 ? 0 : i3, (i5 & 256) != 0 ? 0 : i4, (i5 & ConstantsKt.MINIMUM_BLOCK_SIZE) != 0 ? 0L : j2);
        }

        public final boolean getOk() {
            return this.ok;
        }

        @NotNull
        public final String getMessage() {
            return this.message;
        }

        public final int getWidth() {
            return this.width;
        }

        public final int getHeight() {
            return this.height;
        }

        public final long getDurationUs() {
            return this.durationUs;
        }

        @Nullable
        public final String getVideoMime() {
            return this.videoMime;
        }

        @Nullable
        public final String getAudioMime() {
            return this.audioMime;
        }

        public final int getVideoSamples() {
            return this.videoSamples;
        }

        public final int getAudioSamples() {
            return this.audioSamples;
        }

        public final long getBytes() {
            return this.bytes;
        }
    }

    public static /* synthetic */ Report validate$default(ExportValidator exportValidator, String str, boolean z, long j, int i, Object obj) {
        if ((i & 4) != 0) {
            j = 4096;
        }
        return exportValidator.validate(str, z, j);
    }

    @NotNull
    public final Report validate(@NotNull String path, boolean expectAudio, long minBytes) {
        int iIntValue;
        int i;
        Intrinsics.checkNotNullParameter(path, "path");
        File file = new File(path);
        if (!file.exists()) {
            return new Report(false, "Export file is missing.", 0, 0, 0L, null, null, 0, 0, 0L, 1020, null);
        }
        long length = file.length();
        if (length < minBytes) {
            return new Report(false, "Export produced an empty file (" + length + " bytes).", 0, 0, 0L, null, null, 0, 0, length, 508, null);
        }
        MediaExtractor mediaExtractor = new MediaExtractor();
        try {
            try {
                mediaExtractor.setDataSource(path);
                try {
                    int trackCount = mediaExtractor.getTrackCount();
                    int i2 = -1;
                    int i3 = -1;
                    String str = null;
                    String str2 = null;
                    int i4 = 0;
                    int integer = 0;
                    int integer2 = 0;
                    long jLongValue = 0;
                    while (i4 < trackCount) {
                        MediaFormat trackFormat = mediaExtractor.getTrackFormat(i4);
                        String string = trackFormat.getString("mime");
                        if (string == null) {
                            i = trackCount;
                        } else if (!StringsKt.startsWith$default(string, "video/", false, 2, (Object) null) || i2 >= 0) {
                            i = trackCount;
                            if (StringsKt.startsWith$default(string, "audio/", false, 2, (Object) null) && i3 < 0) {
                                if (jLongValue <= 0 && trackFormat.containsKey("durationUs")) {
                                    jLongValue = trackFormat.getLong("durationUs");
                                }
                                i3 = i4;
                                str2 = string;
                            }
                        } else {
                            integer = trackFormat.containsKey("width") ? trackFormat.getInteger("width") : 0;
                            integer2 = trackFormat.containsKey("height") ? trackFormat.getInteger("height") : 0;
                            if (trackFormat.containsKey("durationUs")) {
                                jLongValue = trackFormat.getLong("durationUs");
                            }
                            i = trackCount;
                            i2 = i4;
                            str = string;
                        }
                        i4++;
                        trackCount = i;
                    }
                    if (i2 >= 0 && integer > 0 && integer2 > 0) {
                        String str3 = str;
                        if (!(str3 == null || StringsKt.isBlank(str3))) {
                            Triple<Integer, Long, Boolean> tripleCountTrack = countTrack(mediaExtractor, i2);
                            int iIntValue2 = tripleCountTrack.component1().intValue();
                            long jLongValue2 = tripleCountTrack.component2().longValue();
                            boolean zBooleanValue = tripleCountTrack.component3().booleanValue();
                            if (iIntValue2 <= 0) {
                                return new Report(false, "Export video track contains no samples.", integer, integer2, jLongValue, str, str2, iIntValue2, 0, length);
                            }
                            if (!zBooleanValue) {
                                Report report = new Report(false, "Export video timestamps go backwards — players will reject this file.", integer, integer2, jLongValue, str, str2, iIntValue2, 0, length);
                                try {
                                    mediaExtractor.release();
                                } catch (Exception unused) {
                                }
                                return report;
                            }
                            if (jLongValue2 > jLongValue) {
                                jLongValue = jLongValue2;
                            }
                            if (i3 >= 0) {
                                Triple<Integer, Long, Boolean> tripleCountTrack2 = countTrack(mediaExtractor, i3);
                                iIntValue = tripleCountTrack2.getFirst().intValue();
                                if (tripleCountTrack2.getSecond().longValue() > jLongValue) {
                                    jLongValue = tripleCountTrack2.getSecond().longValue();
                                }
                                if (!tripleCountTrack2.getThird().booleanValue()) {
                                    Report report2 = new Report(false, "Export audio timestamps go backwards — players will reject this file.", integer, integer2, jLongValue, str, str2, iIntValue2, iIntValue, length);
                                    try {
                                        mediaExtractor.release();
                                    } catch (Exception unused2) {
                                    }
                                    return report2;
                                }
                            } else {
                                if (expectAudio) {
                                    Report report3 = new Report(true, "Video is playable (audio track was not muxed).", integer, integer2, jLongValue, str, null, iIntValue2, 0, length);
                                    try {
                                        mediaExtractor.release();
                                    } catch (Exception unused3) {
                                    }
                                    return report3;
                                }
                                iIntValue = 0;
                            }
                            if (jLongValue <= 0) {
                                Report report4 = new Report(false, "Export has no duration — the container index is incomplete.", integer, integer2, 0L, str, str2, iIntValue2, iIntValue, length);
                                try {
                                    mediaExtractor.release();
                                } catch (Exception unused4) {
                                }
                                return report4;
                            }
                            Report report5 = new Report(true, "OK", integer, integer2, jLongValue, str, str2, iIntValue2, iIntValue, length);
                            try {
                                mediaExtractor.release();
                            } catch (Exception unused5) {
                            }
                            return report5;
                        }
                    }
                    Report report6 = new Report(false, "Export has no playable video track.", 0, 0, 0L, null, null, 0, 0, length, 508, null);
                    try {
                        mediaExtractor.release();
                    } catch (Exception unused6) {
                    }
                    return report6;
                } catch (Exception e) {
                    Report report7 = new Report(false, "Export validation failed: " + e.getMessage(), 0, 0, 0L, null, null, 0, 0, length, 508, null);
                    try {
                        mediaExtractor.release();
                    } catch (Exception unused7) {
                    }
                    return report7;
                }
            } catch (Exception e2) {
                try {
                    mediaExtractor.release();
                } catch (Exception unused8) {
                }
                return new Report(false, "Export container cannot be opened: " + e2.getMessage(), 0, 0, 0L, null, null, 0, 0, length, 508, null);
            }
        } finally {
            try {
                mediaExtractor.release();
            } catch (Exception unused9) {
            }
        }
    }

    private final Triple<Integer, Long, Boolean> countTrack(MediaExtractor ex, int track) {
        int sampleData;
        ex.selectTrack(track);
        try {
            ex.seekTo(0L, 0);
        } catch (Exception unused) {
        }
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(1048576);
        long j = 0;
        boolean z = true;
        long j2 = -1;
        int i = 0;
        while (i < 200000) {
            byteBufferAllocate.clear();
            try {
                sampleData = ex.readSampleData(byteBufferAllocate, 0);
            } catch (Exception unused2) {
                sampleData = -1;
            }
            if (sampleData >= 0) {
                long sampleTime = ex.getSampleTime();
                if (sampleTime >= 0) {
                    if (j2 >= 0 && sampleTime < j2) {
                        z = false;
                    }
                    j2 = sampleTime;
                    j = j2;
                }
                i++;
                if (ex.advance()) {
                }
            }
        }
        try {
            ex.unselectTrack(track);
        } catch (Exception unused3) {
        }
        return new Triple<>(Integer.valueOf(i), Long.valueOf(j), Boolean.valueOf(z));
    }
}
