package com.rehman.ahmedreactionstudio.export;

import com.rehman.ahmedreactionstudio.capture.ScreenCaptureService;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: AudioDecode.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0017\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/PcmClip;", "", ScreenCaptureService.EXTRA_RESULT_DATA, "", "sampleRate", "", "([SI)V", "getData", "()[S", "getSampleRate", "()I"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class PcmClip {

    @NotNull
    private final short[] data;
    private final int sampleRate;

    public PcmClip(@NotNull short[] data, int i) {
        Intrinsics.checkNotNullParameter(data, "data");
        this.data = data;
        this.sampleRate = i;
    }

    @NotNull
    public final short[] getData() {
        return this.data;
    }

    public final int getSampleRate() {
        return this.sampleRate;
    }
}
