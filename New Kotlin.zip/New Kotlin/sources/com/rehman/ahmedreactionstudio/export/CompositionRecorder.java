package com.rehman.ahmedreactionstudio.export;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.media.AudioRecord;
import android.media.AudioTimestamp;
import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.util.Log;
import android.view.Surface;
import com.rehman.ahmedreactionstudio.capture.ScreenCaptureService;
import com.rehman.ahmedreactionstudio.core.Compositor;
import com.rehman.ahmedreactionstudio.core.Layer;
import com.rehman.ahmedreactionstudio.core.Project;
import com.rehman.ahmedreactionstudio.export.EncoderConfig;
import com.rehman.ahmedreactionstudio.export.Exporter;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.MapsKt;
import kotlin.io.ConstantsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: CompositionRecorder.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000ö\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0007\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0018\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u000b\u0018\u0000 \u009b\u00012\u00020\u0001:\u0012\u0098\u0001\u0099\u0001\u009a\u0001\u009b\u0001\u009c\u0001\u009d\u0001\u009e\u0001\u009f\u0001 \u0001BO\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\u0014\u0010\u0005\u001a\u0010\u0012\u0004\u0012\u00020\u0007\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0006\u0012\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\n0\u0003\u0012\u0016\b\u0002\u0010\u000b\u001a\u0010\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\n\u0018\u00010\u0006¢\u0006\u0002\u0010\fJ\u0006\u0010m\u001a\u00020OJ\u0018\u0010n\u001a\u00020\u00122\u0006\u0010o\u001a\u00020p2\u0006\u0010q\u001a\u00020\u0012H\u0002J\b\u0010r\u001a\u00020\nH\u0002J\b\u0010s\u001a\u00020OH\u0002J\u0010\u0010t\u001a\u00020O2\u0006\u0010u\u001a\u00020\u0012H\u0002J\u001a\u0010v\u001a\u00020O2\u0012\u0010M\u001a\u000e\u0012\u0004\u0012\u00020N\u0012\u0004\u0012\u00020O0\u0006J\u0006\u0010w\u001a\u00020OJ\n\u0010x\u001a\u0004\u0018\u00010\bH\u0002J\b\u0010y\u001a\u00020OH\u0002J\u0010\u0010z\u001a\u00020O2\u0006\u0010{\u001a\u00020\u0004H\u0002J\u0010\u0010|\u001a\u00020O2\u0006\u0010}\u001a\u00020\bH\u0002J\b\u0010~\u001a\u00020OH\u0002J\u0006\u0010\u007f\u001a\u00020OJ\u0012\u0010\u0080\u0001\u001a\u00020O2\u0007\u0010\u0081\u0001\u001a\u00020QH\u0002J\t\u0010\u0082\u0001\u001a\u00020OH\u0002J\u001b\u0010\u0083\u0001\u001a\u00020\u00122\u0007\u0010\u0084\u0001\u001a\u00020Q2\u0007\u0010\u0085\u0001\u001a\u00020\u0018H\u0002J\t\u0010\u0086\u0001\u001a\u00020OH\u0002J_\u0010\u0087\u0001\u001a\u00020\u00122\u0006\u0010T\u001a\u00020S2\u0006\u0010k\u001a\u00020\u00182\u0006\u0010*\u001a\u00020\u00182\u0006\u0010)\u001a\u00020\u00182\b\u0010\u0088\u0001\u001a\u00030\u0089\u00012\u000f\u0010\u008a\u0001\u001a\n\u0012\u0005\u0012\u00030\u008c\u00010\u008b\u00012\u0007\u0010\u008d\u0001\u001a\u00020\u00122\u0012\u0010P\u001a\u000e\u0012\u0004\u0012\u00020Q\u0012\u0004\u0012\u00020O0\u0006J\u0007\u0010\u008e\u0001\u001a\u00020QJ\t\u0010\u008f\u0001\u001a\u00020OH\u0002JJ\u0010\u0090\u0001\u001a\u00020\u00122\u0007\u0010\u0091\u0001\u001a\u00020\u00182\u0007\u0010\u0092\u0001\u001a\u00020\u000e2\u0007\u0010\u0093\u0001\u001a\u00020\u00182\b\u0010\u0094\u0001\u001a\u00030\u0095\u00012\u0007\u0010\u0096\u0001\u001a\u00020\u00162\u0011\b\u0002\u0010\u0097\u0001\u001a\n\u0012\u0004\u0012\u00020O\u0018\u00010\u0003H\u0002R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0019\u001a\b\u0018\u00010\u001aR\u00020\u0000X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010\u000b\u001a\u0010\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\n\u0018\u00010\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\u001e\u001a\u0012\u0012\u0004\u0012\u00020 0\u001fj\b\u0012\u0004\u0012\u00020 `!X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\"\u001a\u0004\u0018\u00010\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020%X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010\u0005\u001a\u0010\u0012\u0004\u0012\u00020\u0007\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010+\u001a\u0004\u0018\u00010,X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u00020,X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u00100\u001a\u000201X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b2\u00103\"\u0004\b4\u00105R\u000e\u00106\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00107\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00108\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00109\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010:\u001a\u000201X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b;\u00103\"\u0004\b<\u00105R\u0014\u0010=\u001a\b\u0012\u0004\u0012\u00020?0>X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010@\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010A\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010B\u001a\u0004\u0018\u00010CX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010D\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010E\u001a\b\u0018\u00010FR\u00020\u0000X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010G\u001a\u0004\u0018\u00010HX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010I\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010J\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010K\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010L\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010M\u001a\u0010\u0012\u0004\u0012\u00020N\u0012\u0004\u0012\u00020O\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010P\u001a\u0010\u0012\u0004\u0012\u00020Q\u0012\u0004\u0012\u00020O\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\"\u0010T\u001a\u0004\u0018\u00010S2\b\u0010R\u001a\u0004\u0018\u00010S@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\bU\u0010VR\u001e\u0010W\u001a\u0012\u0012\u0004\u0012\u00020X0\u001fj\b\u0012\u0004\u0012\u00020X`!X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010Y\u001a\b\u0012\u0004\u0012\u00020\b0ZX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010[\u001a\b\u0012\u0004\u0012\u00020]0\\X\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010^\u001a\u00020\u00122\u0006\u0010R\u001a\u00020\u0012@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b_\u0010`R\u000e\u0010a\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010b\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010c\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010d\u001a\u0004\u0018\u00010eX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\n0\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010f\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010g\u001a\u00020QX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010h\u001a\u00020\u0016X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010i\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010j\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010k\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010l\u001a\u0012\u0012\u0004\u0012\u00020Q0\u001fj\b\u0012\u0004\u0012\u00020Q`!X\u0082\u0004¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder;", "", "projectRef", "Lkotlin/Function0;", "Lcom/rehman/ahmedreactionstudio/core/Project;", "frameOf", "Lkotlin/Function1;", "Lcom/rehman/ahmedreactionstudio/core/Layer;", "Landroid/graphics/Bitmap;", "timeMs", "", "clipMediaMs", "(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;)V", "audioCodec", "Landroid/media/MediaCodec;", "audioDone", "Ljava/util/concurrent/CountDownLatch;", "audioEnabled", "", "audioFailed", "audioGaveUp", "audioPtsClock", "Lcom/rehman/ahmedreactionstudio/export/MonotonicPts;", "audioSamplesMuxed", "", "audioThread", "Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$AudioThread;", "audioTrack", "audioZeroNs", "clipResyncs", "clips", "Ljava/util/ArrayList;", "Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$ClipState;", "Lkotlin/collections/ArrayList;", "codec", "compStartNs", "ctx", "Lcom/rehman/ahmedreactionstudio/core/Compositor$Ctx;", "discard", "encoderInputWaits", "finishing", "fps", "h", "handler", "Landroid/os/Handler;", "lastVideoPtsUs", "limiterEngaged", "mainHandler", "masterGain", "", "getMasterGain", "()F", "setMasterGain", "(F)V", "micActive", "micChunksCaptured", "micDroppedSamples", "micEnabledFlag", "micGain", "getMicGain", "setMicGain", "micQueue", "Ljava/util/concurrent/LinkedBlockingQueue;", "Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$MicChunk;", "micRate", "micReadErrors", "micRec", "Landroid/media/AudioRecord;", "micStarvedPolls", "micThread", "Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$MicThread;", "muxer", "Landroid/media/MediaMuxer;", "muxerFailed", "muxerLock", "muxerStarted", "nv12", "onDone", "Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$Result;", "", "onError", "", "<set-?>", "Ljava/io/File;", "outFile", "getOutFile", "()Ljava/io/File;", "pending", "Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$Pending;", "pool", "Ljava/util/ArrayDeque;", "queue", "Ljava/util/concurrent/ArrayBlockingQueue;", "Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$Frame;", "recording", "getRecording", "()Z", "samplesEncoded", "setupFailed", "startNs", "thread", "Landroid/os/HandlerThread;", "videoFramesDropped", "videoMime", "videoPts", "videoSamplesWritten", "videoTrack", "w", "warnings", "abort", "addTrack", "fmt", "Landroid/media/MediaFormat;", "video", "audioZero", "closeMic", "finalize", "failed", "finish", "markCompositionStart", "obtain", "openMic", "publishClipControls", "p", "recycle", "b", "recyclePool", "renderAndSubmit", "report", "msg", "runLoop", "setup", "encName", "colorFmt", "setupAudio", "start", "codecKind", "Lcom/rehman/ahmedreactionstudio/export/Exporter$Codec;", "audio", "", "Lcom/rehman/ahmedreactionstudio/export/DecodedClip;", "micEnabled", "stats", "tryStartMuxer", "writeOut", "track", "c", "index", "info", "Landroid/media/MediaCodec$BufferInfo;", "clock", "onSample", "AudioThread", "ClipControl", "ClipState", "Companion", "Frame", "MicChunk", "MicThread", "Pending", "Result"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nCompositionRecorder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CompositionRecorder.kt\ncom/rehman/ahmedreactionstudio/export/CompositionRecorder\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,1099:1\n1#2:1100\n1747#3,3:1101\n*S KotlinDebug\n*F\n+ 1 CompositionRecorder.kt\ncom/rehman/ahmedreactionstudio/export/CompositionRecorder\n*L\n486#1:1101,3\n*E\n"})
public final class CompositionRecorder {
    private static final int AUDIO_BITRATE = 128000;
    public static final int AUDIO_FRAME = 1024;
    public static final int AUDIO_RATE = 44100;
    private static final int MIC_QUEUE_CAP = 256;
    private static final long NS_PER_S = 1000000000;
    private static final int PENDING_CAP = 128;
    private static final int RESYNC_SAMPLES = 5292;

    @NotNull
    private static final String TAG = "AhmedRecorder";

    @Nullable
    private MediaCodec audioCodec;

    @NotNull
    private final CountDownLatch audioDone;
    private volatile boolean audioEnabled;
    private volatile boolean audioFailed;
    private volatile boolean audioGaveUp;

    @NotNull
    private final MonotonicPts audioPtsClock;
    private volatile int audioSamplesMuxed;

    @Nullable
    private AudioThread audioThread;
    private volatile int audioTrack;
    private volatile long audioZeroNs;

    @Nullable
    private final Function1<Layer, Long> clipMediaMs;
    private volatile int clipResyncs;

    @NotNull
    private final ArrayList<ClipState> clips;

    @Nullable
    private MediaCodec codec;
    private volatile long compStartNs;

    @NotNull
    private final Compositor.Ctx ctx;
    private volatile boolean discard;
    private volatile int encoderInputWaits;
    private volatile boolean finishing;
    private int fps;

    @NotNull
    private final Function1<Layer, Bitmap> frameOf;
    private int h;

    @Nullable
    private Handler handler;
    private volatile long lastVideoPtsUs;
    private volatile int limiterEngaged;

    @NotNull
    private final Handler mainHandler;
    private volatile float masterGain;
    private volatile boolean micActive;
    private volatile long micChunksCaptured;
    private volatile long micDroppedSamples;
    private boolean micEnabledFlag;
    private volatile float micGain;

    @NotNull
    private final LinkedBlockingQueue<MicChunk> micQueue;
    private int micRate;
    private volatile int micReadErrors;

    @Nullable
    private AudioRecord micRec;
    private volatile int micStarvedPolls;

    @Nullable
    private MicThread micThread;

    @Nullable
    private MediaMuxer muxer;
    private volatile boolean muxerFailed;

    @NotNull
    private final Object muxerLock;
    private volatile boolean muxerStarted;
    private boolean nv12;

    @Nullable
    private Function1<? super Result, Unit> onDone;

    @Nullable
    private Function1<? super String, Unit> onError;

    @Nullable
    private File outFile;

    @NotNull
    private final ArrayList<Pending> pending;

    @NotNull
    private final ArrayDeque<Bitmap> pool;

    @NotNull
    private final Function0<Project> projectRef;

    @NotNull
    private final ArrayBlockingQueue<Frame> queue;
    private volatile boolean recording;
    private volatile long samplesEncoded;
    private volatile boolean setupFailed;
    private volatile long startNs;

    @Nullable
    private HandlerThread thread;

    @NotNull
    private final Function0<Long> timeMs;
    private volatile int videoFramesDropped;

    @NotNull
    private String videoMime;

    @NotNull
    private final MonotonicPts videoPts;
    private volatile int videoSamplesWritten;
    private volatile int videoTrack;
    private int w;

    @NotNull
    private final ArrayList<String> warnings;

    /* JADX WARN: Multi-variable type inference failed */
    public CompositionRecorder(@NotNull Function0<Project> projectRef, @NotNull Function1<? super Layer, Bitmap> frameOf, @NotNull Function0<Long> timeMs, @Nullable Function1<? super Layer, Long> function1) {
        Intrinsics.checkNotNullParameter(projectRef, "projectRef");
        Intrinsics.checkNotNullParameter(frameOf, "frameOf");
        Intrinsics.checkNotNullParameter(timeMs, "timeMs");
        this.projectRef = projectRef;
        this.frameOf = frameOf;
        this.timeMs = timeMs;
        this.clipMediaMs = function1;
        this.fps = 30;
        this.nv12 = true;
        this.videoMime = "video/avc";
        this.queue = new ArrayBlockingQueue<>(4);
        this.ctx = new Compositor.Ctx();
        this.pool = new ArrayDeque<>();
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.micRate = 44100;
        this.micQueue = new LinkedBlockingQueue<>(MIC_QUEUE_CAP);
        this.clips = new ArrayList<>();
        this.audioDone = new CountDownLatch(1);
        this.micGain = 1.0f;
        this.masterGain = 1.0f;
        this.muxerLock = new Object();
        this.videoTrack = -1;
        this.audioTrack = -1;
        this.pending = new ArrayList<>();
        this.videoPts = new MonotonicPts(0L, 1, null);
        this.audioPtsClock = new MonotonicPts(0L, 1, null);
        this.warnings = new ArrayList<>();
    }

    public /* synthetic */ CompositionRecorder(Function0 function0, Function1 function1, Function0 function02, Function1 function12, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(function0, function1, function02, (i & 8) != 0 ? null : function12);
    }

    /* JADX INFO: compiled from: CompositionRecorder.kt */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\u0018\u00002\u00020\u0001B!\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005¢\u0006\u0002\u0010\u0007R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000b"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$Result;", "", "file", "Ljava/io/File;", "message", "", "stats", "(Ljava/io/File;Ljava/lang/String;Ljava/lang/String;)V", "getFile", "()Ljava/io/File;", "getMessage", "()Ljava/lang/String;", "getStats"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Result {

        @Nullable
        private final File file;

        @Nullable
        private final String message;

        @NotNull
        private final String stats;

        public Result(@Nullable File file, @Nullable String str, @NotNull String stats) {
            Intrinsics.checkNotNullParameter(stats, "stats");
            this.file = file;
            this.message = str;
            this.stats = stats;
        }

        @Nullable
        public final File getFile() {
            return this.file;
        }

        @Nullable
        public final String getMessage() {
            return this.message;
        }

        @NotNull
        public final String getStats() {
            return this.stats;
        }
    }

    /* JADX INFO: compiled from: CompositionRecorder.kt */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u000b\n\u0002\u0010\u0007\n\u0002\b\u0004\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002R\u001a\u0010\u0003\u001a\u00020\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001a\u0010\t\u001a\u00020\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\f\"\u0004\b\u0011\u0010\u000eR\u001a\u0010\u0012\u001a\u00020\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0013\u0010\u0006\"\u0004\b\u0014\u0010\bR\u001a\u0010\u0015\u001a\u00020\u0016X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0017\u0010\u0018\"\u0004\b\u0019\u0010\u001a"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$ClipControl;", "", "()V", "mediaMs", "", "getMediaMs", "()J", "setMediaMs", "(J)V", "muted", "", "getMuted", "()Z", "setMuted", "(Z)V", "playing", "getPlaying", "setPlaying", "stampNs", "getStampNs", "setStampNs", "volume", "", "getVolume", "()F", "setVolume", "(F)V"}, k = 1, mv = {1, 9, 0}, xi = 48)
    private static final class ClipControl {
        private volatile boolean muted;
        private volatile long stampNs;
        private volatile boolean playing = true;
        private volatile float volume = 1.0f;
        private volatile long mediaMs = -1;

        public final boolean getPlaying() {
            return this.playing;
        }

        public final void setPlaying(boolean z) {
            this.playing = z;
        }

        public final boolean getMuted() {
            return this.muted;
        }

        public final void setMuted(boolean z) {
            this.muted = z;
        }

        public final float getVolume() {
            return this.volume;
        }

        public final void setVolume(float f) {
            this.volume = f;
        }

        public final long getMediaMs() {
            return this.mediaMs;
        }

        public final void setMediaMs(long j) {
            this.mediaMs = j;
        }

        public final long getStampNs() {
            return this.stampNs;
        }

        public final void setStampNs(long j) {
            this.stampNs = j;
        }
    }

    /* JADX INFO: compiled from: CompositionRecorder.kt */
    @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0017\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\r\u001a\u00020\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$ClipState;", "", "clip", "Lcom/rehman/ahmedreactionstudio/export/ClipAudio;", "pcm", "", "(Lcom/rehman/ahmedreactionstudio/export/ClipAudio;[S)V", "getClip", "()Lcom/rehman/ahmedreactionstudio/export/ClipAudio;", "control", "Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$ClipControl;", "getControl", "()Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$ClipControl;", "cursor", "Lcom/rehman/ahmedreactionstudio/export/ClipCursor;", "getCursor", "()Lcom/rehman/ahmedreactionstudio/export/ClipCursor;"}, k = 1, mv = {1, 9, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nCompositionRecorder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CompositionRecorder.kt\ncom/rehman/ahmedreactionstudio/export/CompositionRecorder$ClipState\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,1099:1\n1#2:1100\n*E\n"})
    private static final class ClipState {

        @NotNull
        private final ClipAudio clip;

        @NotNull
        private final ClipControl control;

        @NotNull
        private final ClipCursor cursor;

        public ClipState(@NotNull ClipAudio clip, @NotNull short[] pcm) {
            Intrinsics.checkNotNullParameter(clip, "clip");
            Intrinsics.checkNotNullParameter(pcm, "pcm");
            this.clip = clip;
            ClipControl clipControl = new ClipControl();
            clipControl.setVolume(this.clip.getVolume());
            this.control = clipControl;
            this.cursor = new ClipCursor(pcm, this.clip.getDurMs(), this.clip.getLoop(), this.clip.getSpeed());
        }

        @NotNull
        public final ClipAudio getClip() {
            return this.clip;
        }

        @NotNull
        public final ClipControl getControl() {
            return this.control;
        }

        @NotNull
        public final ClipCursor getCursor() {
            return this.cursor;
        }
    }

    /* JADX INFO: compiled from: CompositionRecorder.kt */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0017\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\b\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$MicChunk;", "", "pcm", "", "eos", "", "([SZ)V", "getEos", "()Z", "getPcm", "()[S"}, k = 1, mv = {1, 9, 0}, xi = 48)
    private static final class MicChunk {
        private final boolean eos;

        @Nullable
        private final short[] pcm;

        public MicChunk(@Nullable short[] sArr, boolean z) {
            this.pcm = sArr;
            this.eos = z;
        }

        public final boolean getEos() {
            return this.eos;
        }

        @Nullable
        public final short[] getPcm() {
            return this.pcm;
        }
    }

    /* JADX INFO: compiled from: CompositionRecorder.kt */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0005\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$Frame;", "", "bmp", "Landroid/graphics/Bitmap;", "stampNs", "", "(Landroid/graphics/Bitmap;J)V", "getBmp", "()Landroid/graphics/Bitmap;", "getStampNs", "()J"}, k = 1, mv = {1, 9, 0}, xi = 48)
    private static final class Frame {

        @NotNull
        private final Bitmap bmp;
        private final long stampNs;

        public Frame(@NotNull Bitmap bmp, long j) {
            Intrinsics.checkNotNullParameter(bmp, "bmp");
            this.bmp = bmp;
            this.stampNs = j;
        }

        @NotNull
        public final Bitmap getBmp() {
            return this.bmp;
        }

        public final long getStampNs() {
            return this.stampNs;
        }
    }

    /* JADX INFO: compiled from: CompositionRecorder.kt */
    @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\b\u0002\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000e"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$Pending;", "", "track", "", ScreenCaptureService.EXTRA_RESULT_DATA, "Ljava/nio/ByteBuffer;", "info", "Landroid/media/MediaCodec$BufferInfo;", "(ILjava/nio/ByteBuffer;Landroid/media/MediaCodec$BufferInfo;)V", "getData", "()Ljava/nio/ByteBuffer;", "getInfo", "()Landroid/media/MediaCodec$BufferInfo;", "getTrack", "()I"}, k = 1, mv = {1, 9, 0}, xi = 48)
    private static final class Pending {

        @NotNull
        private final ByteBuffer data;

        @NotNull
        private final MediaCodec.BufferInfo info;
        private final int track;

        public Pending(int i, @NotNull ByteBuffer data, @NotNull MediaCodec.BufferInfo info) {
            Intrinsics.checkNotNullParameter(data, "data");
            Intrinsics.checkNotNullParameter(info, "info");
            this.track = i;
            this.data = data;
            this.info = info;
        }

        @NotNull
        public final ByteBuffer getData() {
            return this.data;
        }

        @NotNull
        public final MediaCodec.BufferInfo getInfo() {
            return this.info;
        }

        public final int getTrack() {
            return this.track;
        }
    }

    public final float getMicGain() {
        return this.micGain;
    }

    public final void setMicGain(float f) {
        this.micGain = f;
    }

    public final float getMasterGain() {
        return this.masterGain;
    }

    public final void setMasterGain(float f) {
        this.masterGain = f;
    }

    public final boolean getRecording() {
        return this.recording;
    }

    @Nullable
    public final File getOutFile() {
        return this.outFile;
    }

    public final boolean start(@NotNull File outFile, int w, int h, int fps, @NotNull Exporter.Codec codecKind, @NotNull List<DecodedClip> audio, boolean micEnabled, @NotNull Function1<? super String, Unit> onError) {
        Intrinsics.checkNotNullParameter(outFile, "outFile");
        Intrinsics.checkNotNullParameter(codecKind, "codecKind");
        Intrinsics.checkNotNullParameter(audio, "audio");
        Intrinsics.checkNotNullParameter(onError, "onError");
        this.w = w;
        this.h = h;
        this.fps = fps;
        this.outFile = outFile;
        this.micEnabledFlag = micEnabled;
        this.onError = onError;
        this.videoMime = "video/avc";
        this.clips.clear();
        for (DecodedClip decodedClip : audio) {
            if (decodedClip.getPcm().length > 1) {
                this.clips.add(new ClipState(decodedClip.getClip(), decodedClip.getPcm()));
            }
        }
        Pair<String, Integer> pairPickEncoder$main = Exporter.INSTANCE.pickEncoder$main("video/avc");
        final String strComponent1 = pairPickEncoder$main.component1();
        final int iIntValue = pairPickEncoder$main.component2().intValue();
        if ((strComponent1.length() == 0) || iIntValue < 0) {
            onError.invoke("No H.264 encoder on this device");
            return false;
        }
        this.nv12 = iIntValue != 19;
        for (int i = 0; i < 3; i++) {
            try {
                this.pool.addLast(Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888));
            } catch (Exception e) {
                String message = e.getMessage();
                if (message == null) {
                    message = "Out of memory";
                }
                onError.invoke(message);
                return false;
            }
        }
        HandlerThread handlerThread = new HandlerThread("compo-rec");
        handlerThread.start();
        this.thread = handlerThread;
        this.handler = new Handler(handlerThread.getLooper());
        this.startNs = System.nanoTime();
        this.compStartNs = 0L;
        this.recording = true;
        this.finishing = false;
        this.discard = false;
        this.setupFailed = false;
        final CountDownLatch countDownLatch = new CountDownLatch(1);
        Handler handler = this.handler;
        Intrinsics.checkNotNull(handler);
        handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.export.-$$Lambda$CompositionRecorder$UvNhuVtbzEGK7ZNKfdzbu_xsfCI
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                CompositionRecorder.start$lambda$0(this.f$0, strComponent1, iIntValue, countDownLatch);
            }
        });
        try {
            countDownLatch.await(6L, TimeUnit.SECONDS);
        } catch (Exception unused) {
        }
        if (!this.setupFailed && this.codec != null) {
            return true;
        }
        this.recording = false;
        onError.invoke("Could not start the H.264 encoder");
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void start$lambda$0(CompositionRecorder this$0, String encName, int i, CountDownLatch ready) throws Throwable {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(encName, "$encName");
        Intrinsics.checkNotNullParameter(ready, "$ready");
        boolean upVar = this$0.setup(encName, i);
        if (!upVar) {
            this$0.setupFailed = true;
        }
        ready.countDown();
        if (upVar) {
            this$0.runLoop();
        } else {
            this$0.finalize(true);
        }
    }

    public final void markCompositionStart() {
        this.compStartNs = System.nanoTime();
    }

    public final void renderAndSubmit() {
        if (!this.recording || this.setupFailed) {
            return;
        }
        Project projectInvoke = this.projectRef.invoke();
        publishClipControls(projectInvoke);
        Bitmap bitmapObtain = obtain();
        if (bitmapObtain == null) {
            this.videoFramesDropped++;
            return;
        }
        Compositor.INSTANCE.draw(this.ctx, new Canvas(bitmapObtain), this.w, this.h, projectInvoke, this.frameOf, this.timeMs.invoke().longValue(), (256 & 128) != 0 ? null : null, (256 & 256) != 0 ? MapsKt.emptyMap() : null);
        if (this.queue.offer(new Frame(bitmapObtain, System.nanoTime()))) {
            return;
        }
        recycle(bitmapObtain);
        this.videoFramesDropped++;
    }

    public final void finish(@NotNull Function1<? super Result, Unit> onDone) {
        Intrinsics.checkNotNullParameter(onDone, "onDone");
        if (!this.recording) {
            onDone.invoke(new Result(null, "Not recording", stats()));
            return;
        }
        this.recording = false;
        this.onDone = onDone;
        this.finishing = true;
        MicThread micThread = this.micThread;
        if (micThread != null) {
            micThread.requestStop();
        }
    }

    public final void abort() {
        if (this.recording || this.handler != null) {
            this.recording = false;
            this.discard = true;
            this.finishing = true;
            MicThread micThread = this.micThread;
            if (micThread != null) {
                micThread.requestStop();
            }
        }
    }

    @NotNull
    public final String stats() {
        float f = this.samplesEncoded / 44100.0f;
        StringBuilder sb = new StringBuilder();
        sb.append("REC v ");
        sb.append(this.videoSamplesWritten);
        sb.append("f ");
        StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
        Locale locale = Locale.US;
        Object[] objArr = {Float.valueOf(this.lastVideoPtsUs / 1000000.0f)};
        String str = String.format(locale, "%.1fs", Arrays.copyOf(objArr, objArr.length));
        Intrinsics.checkNotNullExpressionValue(str, "format(...)");
        sb.append(str);
        if (this.videoFramesDropped > 0) {
            sb.append(" drop ");
            sb.append(this.videoFramesDropped);
        }
        if (this.audioEnabled) {
            sb.append(" · a ");
            StringCompanionObject stringCompanionObject2 = StringCompanionObject.INSTANCE;
            Locale locale2 = Locale.US;
            Object[] objArr2 = {Float.valueOf(f)};
            String str2 = String.format(locale2, "%.1fs", Arrays.copyOf(objArr2, objArr2.length));
            Intrinsics.checkNotNullExpressionValue(str2, "format(...)");
            sb.append(str2);
            sb.append(this.micActive ? " mic" : " nomic");
            if (this.micDroppedSamples > 0) {
                sb.append(" drop ");
                sb.append(this.micDroppedSamples / ((long) 1024));
                sb.append("f");
            }
            if (this.micStarvedPolls > 0) {
                sb.append(" starve ");
                sb.append(this.micStarvedPolls);
            }
            if (this.encoderInputWaits > 0) {
                sb.append(" wait ");
                sb.append(this.encoderInputWaits);
            }
            if (this.limiterEngaged > 0) {
                sb.append(" lim ");
                sb.append(this.limiterEngaged);
            }
            if (this.clipResyncs > 0) {
                sb.append(" resync ");
                sb.append(this.clipResyncs);
            }
            sb.append(" q ");
            sb.append(this.micQueue.size());
        } else {
            sb.append(" · no audio");
        }
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        return string;
    }

    private final boolean setup(String encName, int colorFmt) {
        File parentFile;
        try {
            File file = this.outFile;
            if (file != null && (parentFile = file.getParentFile()) != null) {
                parentFile.mkdirs();
            }
            MediaFormat mediaFormatVideoFormat = EncoderConfig.INSTANCE.videoFormat("video/avc", this.w, this.h, this.fps, colorFmt, EncoderConfig.Quality.BALANCED, true, true);
            this.codec = MediaCodec.createByCodecName(encName);
            MediaCodec mediaCodec = this.codec;
            Intrinsics.checkNotNull(mediaCodec);
            mediaCodec.configure(mediaFormatVideoFormat, (Surface) null, (MediaCrypto) null, 1);
            MediaCodec mediaCodec2 = this.codec;
            Intrinsics.checkNotNull(mediaCodec2);
            mediaCodec2.start();
            File file2 = this.outFile;
            Intrinsics.checkNotNull(file2);
            this.muxer = new MediaMuxer(file2.getAbsolutePath(), 0);
            this.audioEnabled = (this.clips.isEmpty() ^ true) || this.micEnabledFlag;
            if (this.audioEnabled) {
                setupAudio();
            }
            return true;
        } catch (Exception e) {
            Log.e(TAG, "setup failed", e);
            return false;
        }
    }

    private final void setupAudio() {
        if (this.micEnabledFlag) {
            openMic();
        }
        if (this.micRec == null && this.clips.isEmpty()) {
            this.audioEnabled = false;
            return;
        }
        try {
            MediaFormat mediaFormatCreateAudioFormat = MediaFormat.createAudioFormat("audio/mp4a-latm", 44100, 1);
            mediaFormatCreateAudioFormat.setInteger("aac-profile", 2);
            mediaFormatCreateAudioFormat.setInteger("bitrate", AUDIO_BITRATE);
            mediaFormatCreateAudioFormat.setInteger("max-input-size", ConstantsKt.DEFAULT_BUFFER_SIZE);
            mediaFormatCreateAudioFormat.setInteger("channel-count", 1);
            this.audioCodec = MediaCodec.createEncoderByType("audio/mp4a-latm");
            MediaCodec mediaCodec = this.audioCodec;
            Intrinsics.checkNotNull(mediaCodec);
            mediaCodec.configure(mediaFormatCreateAudioFormat, (Surface) null, (MediaCrypto) null, 1);
            MediaCodec mediaCodec2 = this.audioCodec;
            Intrinsics.checkNotNull(mediaCodec2);
            mediaCodec2.start();
            AudioRecord audioRecord = this.micRec;
            if (audioRecord != null) {
                MicThread micThread = new MicThread(this, audioRecord, this.micRate);
                this.micThread = micThread;
                micThread.start();
            }
            MediaCodec mediaCodec3 = this.audioCodec;
            Intrinsics.checkNotNull(mediaCodec3);
            AudioThread audioThread = new AudioThread(this, mediaCodec3);
            this.audioThread = audioThread;
            audioThread.start();
        } catch (Exception e) {
            Log.e(TAG, "AAC encoder unavailable; recording video-only", e);
            try {
                MediaCodec mediaCodec4 = this.audioCodec;
                if (mediaCodec4 != null) {
                    mediaCodec4.release();
                }
            } catch (Exception unused) {
            }
            this.audioCodec = null;
            this.audioEnabled = false;
            closeMic();
            report("AAC audio encoder failed to start — recording video only");
        }
    }

    private final void openMic() {
        AudioRecord audioRecord;
        Exception e;
        for (int i : new int[]{44100, 48000}) {
            try {
                int minBufferSize = AudioRecord.getMinBufferSize(i, 16, 2);
                if (minBufferSize > 0) {
                    audioRecord = new AudioRecord(1, i, 16, 2, Math.max(minBufferSize * 2, i * 2));
                    try {
                        if (audioRecord.getState() != 1) {
                            audioRecord.release();
                        } else {
                            audioRecord.startRecording();
                            if (audioRecord.getRecordingState() != 3) {
                                audioRecord.stop();
                                audioRecord.release();
                            } else {
                                this.startNs = System.nanoTime();
                                this.micRec = audioRecord;
                                this.micRate = i;
                                this.micActive = true;
                                return;
                            }
                        }
                    } catch (Exception e2) {
                        e = e2;
                        Log.w(TAG, "mic open at " + i + " failed", e);
                        if (audioRecord != null) {
                            try {
                                audioRecord.release();
                            } catch (Exception unused) {
                            }
                        }
                    }
                } else {
                    continue;
                }
            } catch (Exception e3) {
                audioRecord = null;
                e = e3;
            }
        }
        this.micRec = null;
        this.micActive = false;
        report(this.clips.isEmpty() ? "Microphone unavailable — recording has no audio" : "Microphone unavailable — recording clip audio only");
    }

    private final void closeMic() {
        try {
            AudioRecord audioRecord = this.micRec;
            if (audioRecord != null) {
                audioRecord.stop();
            }
        } catch (Exception unused) {
        }
        try {
            AudioRecord audioRecord2 = this.micRec;
            if (audioRecord2 != null) {
                audioRecord2.release();
            }
        } catch (Exception unused2) {
        }
        this.micRec = null;
        this.micActive = false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void report(final String msg) {
        synchronized (this.warnings) {
            if (!this.warnings.contains(msg)) {
                this.warnings.add(msg);
            }
            Unit unit = Unit.INSTANCE;
        }
        Log.w(TAG, msg);
        final Function1<? super String, Unit> function1 = this.onError;
        if (function1 == null) {
            return;
        }
        this.mainHandler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.export.-$$Lambda$CompositionRecorder$Ha_PcPWEexV3uqSWvWwLOPFz1Cw
            @Override // java.lang.Runnable
            public final void run() {
                CompositionRecorder.report$lambda$4(function1, msg);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void report$lambda$4(Function1 cb, String msg) {
        Intrinsics.checkNotNullParameter(cb, "$cb");
        Intrinsics.checkNotNullParameter(msg, "$msg");
        cb.invoke(msg);
    }

    private final void publishClipControls(Project p) {
        boolean z;
        if (this.clips.isEmpty()) {
            return;
        }
        List<Layer> layers = p.getLayers();
        if ((layers instanceof Collection) && layers.isEmpty()) {
            z = false;
        } else {
            Iterator<T> it = layers.iterator();
            while (it.hasNext()) {
                if (((Layer) it.next()).getSolo()) {
                    z = true;
                    break;
                }
            }
            z = false;
        }
        long jNanoTime = System.nanoTime();
        for (ClipState clipState : this.clips) {
            Layer layerLayerById = clipState.getClip().getLayerId().length() > 0 ? p.layerById(clipState.getClip().getLayerId()) : null;
            ClipControl control = clipState.getControl();
            if (layerLayerById != null) {
                control.setPlaying(layerLayerById.getPlaying());
                control.setMuted(layerLayerById.getMuted() || (z && !layerLayerById.getSolo()));
                control.setVolume(layerLayerById.getVolume());
                Function1<Layer, Long> function1 = this.clipMediaMs;
                if (function1 != null) {
                    try {
                        control.setMediaMs(function1.invoke(layerLayerById).longValue());
                        control.setStampNs(jNanoTime);
                    } catch (Exception unused) {
                    }
                }
            }
        }
    }

    /* JADX INFO: compiled from: CompositionRecorder.kt */
    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\b\u0010\t\u001a\u00020\nH\u0002J\u0006\u0010\u000b\u001a\u00020\nJ\b\u0010\f\u001a\u00020\nH\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$MicThread;", "Ljava/lang/Thread;", "rec", "Landroid/media/AudioRecord;", "rate", "", "(Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder;Landroid/media/AudioRecord;I)V", "stopRequested", "", "anchorClock", "", "requestStop", "run"}, k = 1, mv = {1, 9, 0}, xi = 48)
    private final class MicThread extends Thread {
        private final int rate;

        @NotNull
        private final AudioRecord rec;
        private volatile boolean stopRequested;
        final /* synthetic */ CompositionRecorder this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public MicThread(@NotNull CompositionRecorder compositionRecorder, AudioRecord rec, int i) {
            super("compo-mic");
            Intrinsics.checkNotNullParameter(rec, "rec");
            this.this$0 = compositionRecorder;
            this.rec = rec;
            this.rate = i;
        }

        public final void requestStop() {
            this.stopRequested = true;
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
        /* JADX WARN: Type inference failed for: r0v3, types: [int] */
        /* JADX WARN: Type inference failed for: r0v6 */
        /* JADX WARN: Type inference failed for: r8v13 */
        /* JADX WARN: Type inference failed for: r8v3 */
        /* JADX WARN: Type inference failed for: r8v4 */
        /* JADX WARN: Type inference failed for: r8v5 */
        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            char c;
            boolean zOffer;
            int i;
            try {
                Process.setThreadPriority(-19);
            } catch (Exception unused) {
            }
            int i2 = this.rate;
            int i3 = i2 / 50;
            Resampler resampler = i2 != 44100 ? new Resampler(i2, 44100) : null;
            ?? r0 = 0;
            int i4 = 0;
            int i5 = 0;
            while (true) {
                try {
                    if (this.stopRequested) {
                        break;
                    }
                    short[] sArrProcess = new short[i3];
                    try {
                        i = this.rec.read(sArrProcess, 0, i3, 0);
                    } catch (Exception unused2) {
                        i = -1;
                    }
                    if (i <= 0) {
                        this.this$0.micReadErrors++;
                        if (i == -6 || i == -3 || this.this$0.micReadErrors > 50) {
                            break;
                        }
                    } else {
                        this.this$0.micChunksCaptured++;
                        if (resampler != null) {
                            sArrProcess = resampler.process(sArrProcess, i);
                        } else if (i != i3) {
                            sArrProcess = Arrays.copyOf(sArrProcess, i);
                            Intrinsics.checkNotNullExpressionValue(sArrProcess, "copyOf(...)");
                        }
                        if (((sArrProcess.length == 0) ^ true) != false && !this.this$0.micQueue.offer(new MicChunk(sArrProcess, false))) {
                            this.this$0.micDroppedSamples += (long) sArrProcess.length;
                            if (this.this$0.micDroppedSamples == sArrProcess.length) {
                                this.this$0.report("Audio encoder fell behind the microphone — some mic audio was replaced by silence");
                            }
                        }
                        if (this.this$0.audioZeroNs == 0 && i5 < 40) {
                            i5++;
                            anchorClock();
                        }
                    }
                } finally {
                    this.this$0.micActive = false;
                    while (!this.this$0.micQueue.offer(new MicChunk(null, true))) {
                        int i6 = r0 + 1;
                        if (r0 >= CompositionRecorder.MIC_QUEUE_CAP) {
                            break;
                        }
                        this.this$0.micQueue.poll();
                        r0 = i6;
                    }
                }
            }
            this.this$0.report("Microphone stopped delivering audio (error " + i + ')');
            while (true) {
                if (zOffer) {
                    return;
                } else {
                    if (i4 >= c) {
                        return;
                    }
                }
            }
        }

        private final void anchorClock() {
            try {
                AudioTimestamp audioTimestamp = new AudioTimestamp();
                if (this.rec.getTimestamp(audioTimestamp, 0) != 0 || audioTimestamp.framePosition <= 0 || audioTimestamp.nanoTime <= 0) {
                    return;
                }
                long j = audioTimestamp.nanoTime - ((audioTimestamp.framePosition * CompositionRecorder.NS_PER_S) / ((long) this.rate));
                if (Math.abs(j - this.this$0.startNs) < 500000000) {
                    this.this$0.audioZeroNs = j;
                }
            } catch (Throwable unused) {
            }
        }
    }

    /* JADX INFO: compiled from: CompositionRecorder.kt */
    @Metadata(d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0017\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0014\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\b\u0005\b\u0082\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0010\u0010\u0017\u001a\u00020\u00152\u0006\u0010\u0018\u001a\u00020\fH\u0002J\b\u0010\u0019\u001a\u00020\u0015H\u0002J\b\u0010\u001a\u001a\u00020\u0015H\u0002J\b\u0010\u001b\u001a\u00020\u001cH\u0002J\b\u0010\u001d\u001a\u00020\u001cH\u0016J\"\u0010\u001e\u001a\u00020\u00152\b\u0010\u001f\u001a\u0004\u0018\u00010\u00062\u0006\u0010 \u001a\u00020\b2\u0006\u0010!\u001a\u00020\u0015H\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$AudioThread;", "Ljava/lang/Thread;", "ac", "Landroid/media/MediaCodec;", "(Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder;Landroid/media/MediaCodec;)V", "carry", "", "carryOff", "", "frame", "frameLen", "frameNs", "", "info", "Landroid/media/MediaCodec$BufferInfo;", "limiter", "Lcom/rehman/ahmedreactionstudio/export/Limiter;", "mix", "", "silenceOwed", "streamClosed", "", "useMic", "drain", "blockUs", "fillFromMic", "fillSilencePaced", "mixClips", "", "run", "submit", "pcm", "n", "eos"}, k = 1, mv = {1, 9, 0}, xi = 48)
    private final class AudioThread extends Thread {

        @NotNull
        private final MediaCodec ac;

        @Nullable
        private short[] carry;
        private int carryOff;

        @NotNull
        private final short[] frame;
        private int frameLen;
        private final long frameNs;

        @NotNull
        private final MediaCodec.BufferInfo info;

        @NotNull
        private final Limiter limiter;

        @NotNull
        private final float[] mix;
        private long silenceOwed;
        private boolean streamClosed;
        final /* synthetic */ CompositionRecorder this$0;
        private boolean useMic;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public AudioThread(@NotNull CompositionRecorder compositionRecorder, MediaCodec ac) {
            super("compo-rec-audio");
            Intrinsics.checkNotNullParameter(ac, "ac");
            this.this$0 = compositionRecorder;
            this.ac = ac;
            this.info = new MediaCodec.BufferInfo();
            this.frame = new short[1024];
            this.mix = new float[1024];
            this.useMic = this.this$0.micThread != null;
            this.limiter = new Limiter(0.0f, 0.0f, 3, null);
            this.frameNs = 23219954L;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            try {
                Process.setThreadPriority(-16);
            } catch (Exception unused) {
            }
            while (!this.this$0.audioFailed && !this.this$0.muxerFailed) {
                try {
                    try {
                        if (!(this.useMic ? fillFromMic() : fillSilencePaced())) {
                            if (this.streamClosed || (!this.useMic && this.this$0.finishing)) {
                                break;
                            }
                        } else {
                            mixClips();
                            if (!submit(this.frame, 1024, false)) {
                                break;
                            } else {
                                this.frameLen = 0;
                            }
                        }
                    } catch (Exception e) {
                        Log.e(CompositionRecorder.TAG, "audio thread", e);
                        this.this$0.audioFailed = true;
                        CompositionRecorder compositionRecorder = this.this$0;
                        StringBuilder sb = new StringBuilder();
                        sb.append("Audio encoding failed: ");
                        String message = e.getMessage();
                        if (message == null) {
                            message = e.getClass().getSimpleName();
                        }
                        sb.append(message);
                        compositionRecorder.report(sb.toString());
                    }
                } finally {
                    this.this$0.audioDone.countDown();
                }
            }
            if (!this.this$0.audioFailed && !this.this$0.muxerFailed) {
                submit(null, 0, true);
                long jElapsedRealtime = SystemClock.elapsedRealtime() + 3000;
                while (SystemClock.elapsedRealtime() < jElapsedRealtime && !this.this$0.audioFailed && !this.this$0.muxerFailed && !drain(10000L)) {
                }
            }
        }

        private final boolean fillFromMic() {
            if (this.frameLen == 0 && this.this$0.micDroppedSamples - this.silenceOwed >= 1024) {
                Arrays.fill(this.frame, (short) 0);
                this.frameLen = 1024;
                this.silenceOwed += (long) 1024;
                return true;
            }
            while (this.frameLen < 1024) {
                short[] sArr = this.carry;
                if (sArr == null) {
                    MicChunk micChunk = (MicChunk) this.this$0.micQueue.poll(200L, TimeUnit.MILLISECONDS);
                    if (micChunk == null) {
                        this.this$0.micStarvedPolls++;
                        drain(0L);
                        if (!this.this$0.audioFailed && !this.this$0.muxerFailed) {
                            if (this.this$0.finishing && !this.this$0.micActive && this.this$0.micQueue.isEmpty()) {
                                this.streamClosed = true;
                            }
                            if (this.streamClosed) {
                                break;
                            }
                        } else {
                            return false;
                        }
                    } else {
                        short[] pcm = micChunk.getPcm();
                        if (micChunk.getEos() || pcm == null) {
                            if (!this.this$0.finishing) {
                                this.useMic = false;
                                return false;
                            }
                            this.streamClosed = true;
                        } else {
                            this.carry = pcm;
                            this.carryOff = 0;
                            sArr = pcm;
                        }
                    }
                }
                int iMin = Math.min(1024 - this.frameLen, sArr.length - this.carryOff);
                System.arraycopy(sArr, this.carryOff, this.frame, this.frameLen, iMin);
                this.frameLen += iMin;
                this.carryOff += iMin;
                if (this.carryOff >= sArr.length) {
                    this.carry = null;
                }
            }
            int i = this.frameLen;
            if (i >= 1024) {
                return true;
            }
            if (!this.streamClosed || i <= 0) {
                return false;
            }
            Arrays.fill(this.frame, i, 1024, (short) 0);
            this.frameLen = 1024;
            return true;
        }

        private final boolean fillSilencePaced() {
            if (this.this$0.samplesEncoded + ((long) 1024) > ((System.nanoTime() - this.this$0.startNs) * ((long) 44100)) / CompositionRecorder.NS_PER_S) {
                if (this.this$0.finishing) {
                    return false;
                }
                drain(0L);
                LockSupport.parkNanos(this.frameNs / ((long) 2));
                return false;
            }
            Arrays.fill(this.frame, (short) 0);
            this.frameLen = 1024;
            return true;
        }

        private final void mixClips() {
            int i;
            float micGain = this.this$0.getMicGain();
            for (int i2 = 0; i2 < 1024; i2++) {
                this.mix[i2] = this.frame[i2] * micGain;
            }
            long j = this.this$0.compStartNs;
            if (j != 0 && (!this.this$0.clips.isEmpty())) {
                int i3 = 44100;
                long j2 = 44100;
                long jAudioZero = this.this$0.audioZero() + ((this.this$0.samplesEncoded * CompositionRecorder.NS_PER_S) / j2);
                int iCoerceIn = jAudioZero < j ? RangesKt.coerceIn((int) (((j - jAudioZero) * j2) / CompositionRecorder.NS_PER_S), 0, 1024) : 0;
                float masterGain = this.this$0.getMasterGain();
                for (ClipState clipState : this.this$0.clips) {
                    ClipControl control = clipState.getControl();
                    if (control.getPlaying()) {
                        ClipCursor cursor = clipState.getCursor();
                        long mediaMs = control.getMediaMs();
                        if (mediaMs >= 0) {
                            double d = i3;
                            i = iCoerceIn;
                            if (cursor.resyncIfDrifted(((mediaMs / 1000.0d) * d) + (((jAudioZero - control.getStampNs()) / 1.0E9d) * d * cursor.getStep()), 5292.0d)) {
                                this.this$0.clipResyncs++;
                            }
                        } else {
                            i = iCoerceIn;
                        }
                        float volume = control.getMuted() ? 0.0f : control.getVolume() * masterGain;
                        int i4 = i;
                        cursor.mixInto(this.mix, i4, 1024, volume);
                        iCoerceIn = i4;
                        i3 = 44100;
                    }
                }
            }
            int engaged = this.limiter.getEngaged();
            this.limiter.apply(this.mix, 1024, this.frame);
            if (this.limiter.getEngaged() != engaged) {
                this.this$0.limiterEngaged++;
            }
        }

        private final boolean submit(short[] pcm, int n, boolean eos) {
            int i;
            long jElapsedRealtime = SystemClock.elapsedRealtime();
            while (!this.this$0.audioFailed && !this.this$0.muxerFailed) {
                try {
                    int iDequeueInputBuffer = this.ac.dequeueInputBuffer(10000L);
                    if (iDequeueInputBuffer >= 0) {
                        ByteBuffer inputBuffer = this.ac.getInputBuffer(iDequeueInputBuffer);
                        if (inputBuffer == null) {
                            this.this$0.audioFailed = true;
                            this.this$0.report("AAC encoder returned no input buffer");
                            return false;
                        }
                        inputBuffer.clear();
                        inputBuffer.order(ByteOrder.nativeOrder());
                        if (pcm == null || n <= 0) {
                            i = 0;
                        } else {
                            inputBuffer.asShortBuffer().put(pcm, 0, n);
                            i = n * 2;
                        }
                        try {
                            this.ac.queueInputBuffer(iDequeueInputBuffer, 0, i, this.this$0.audioPtsClock.next((this.this$0.samplesEncoded * 1000000) / ((long) 44100)), eos ? 4 : 0);
                            if (!eos) {
                                this.this$0.samplesEncoded += (long) n;
                            }
                            drain(0L);
                            return true;
                        } catch (Exception e) {
                            this.this$0.audioFailed = true;
                            this.this$0.report("AAC encoder rejected input: " + e.getMessage());
                            return false;
                        }
                    }
                    this.this$0.encoderInputWaits++;
                    drain(5000L);
                    if (SystemClock.elapsedRealtime() - jElapsedRealtime > 4000) {
                        this.this$0.audioFailed = true;
                        this.this$0.report("AAC encoder stalled (no input buffer for 4 s)");
                        return false;
                    }
                } catch (Exception e2) {
                    this.this$0.audioFailed = true;
                    this.this$0.report("AAC encoder error: " + e2.getMessage());
                }
            }
            return false;
        }

        private final boolean drain(long blockUs) {
            boolean z = true;
            while (true) {
                try {
                    int iDequeueOutputBuffer = this.ac.dequeueOutputBuffer(this.info, z ? blockUs : 0L);
                    if (iDequeueOutputBuffer == -2) {
                        MediaFormat outputFormat = this.ac.getOutputFormat();
                        CompositionRecorder compositionRecorder = this.this$0;
                        Intrinsics.checkNotNull(outputFormat);
                        if (!compositionRecorder.addTrack(outputFormat, false)) {
                            this.this$0.audioEnabled = false;
                            this.this$0.audioGaveUp = true;
                            this.this$0.tryStartMuxer();
                            return true;
                        }
                        this.this$0.tryStartMuxer();
                    } else {
                        if (iDequeueOutputBuffer == -1 || iDequeueOutputBuffer < 0) {
                            return false;
                        }
                        CompositionRecorder compositionRecorder2 = this.this$0;
                        int i = compositionRecorder2.audioTrack;
                        MediaCodec mediaCodec = this.ac;
                        MediaCodec.BufferInfo bufferInfo = this.info;
                        MonotonicPts monotonicPts = this.this$0.audioPtsClock;
                        final CompositionRecorder compositionRecorder3 = this.this$0;
                        if (compositionRecorder2.writeOut(i, mediaCodec, iDequeueOutputBuffer, bufferInfo, monotonicPts, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.export.CompositionRecorder$AudioThread$drain$eos$1
                            {
                                super(0);
                            }

                            @Override // kotlin.jvm.functions.Function0
                            public /* bridge */ /* synthetic */ Unit invoke() {
                                invoke2();
                                return Unit.INSTANCE;
                            }

                            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                            public final void invoke2() {
                                compositionRecorder3.audioSamplesMuxed++;
                            }
                        })) {
                            return true;
                        }
                    }
                    z = false;
                } catch (Exception unused) {
                    this.this$0.audioFailed = true;
                    return true;
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final long audioZero() {
        long j = this.audioZeroNs;
        return j != 0 ? j : this.startNs;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean addTrack(MediaFormat fmt, boolean video) {
        synchronized (this.muxerLock) {
            MediaMuxer mediaMuxer = this.muxer;
            boolean z = false;
            if (mediaMuxer == null) {
                return false;
            }
            if (this.muxerStarted) {
                return false;
            }
            try {
                int iAddTrack = mediaMuxer.addTrack(fmt);
                if (video) {
                    this.videoTrack = iAddTrack;
                } else {
                    this.audioTrack = iAddTrack;
                }
                z = true;
            } catch (Exception e) {
                StringBuilder sb = new StringBuilder();
                sb.append("add ");
                sb.append(video ? "video" : "audio");
                sb.append(" track");
                Log.e(TAG, sb.toString(), e);
                if (video) {
                    this.muxerFailed = true;
                } else {
                    report("Could not add the audio track — recording video only");
                }
            }
            return z;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void tryStartMuxer() {
        synchronized (this.muxerLock) {
            if (!this.muxerStarted && !this.muxerFailed) {
                if (this.videoTrack < 0) {
                    return;
                }
                if (!this.audioEnabled || this.audioTrack >= 0 || this.audioGaveUp) {
                    MediaMuxer mediaMuxer = this.muxer;
                    if (mediaMuxer == null) {
                        return;
                    }
                    try {
                        mediaMuxer.start();
                        this.muxerStarted = true;
                        for (Pending pending : this.pending) {
                            if (pending.getTrack() >= 0 && (pending.getTrack() != this.audioTrack || (this.audioEnabled && !this.audioGaveUp))) {
                                try {
                                    mediaMuxer.writeSampleData(pending.getTrack(), pending.getData(), pending.getInfo());
                                } catch (Exception e) {
                                    Log.w(TAG, "flush pending", e);
                                }
                            }
                        }
                        this.pending.clear();
                        Unit unit = Unit.INSTANCE;
                    } catch (Exception e2) {
                        Log.e(TAG, "muxer.start failed", e2);
                        this.muxerFailed = true;
                        report("MP4 muxer failed to start: " + e2.getMessage());
                    }
                }
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    static /* synthetic */ boolean writeOut$default(CompositionRecorder compositionRecorder, int i, MediaCodec mediaCodec, int i2, MediaCodec.BufferInfo bufferInfo, MonotonicPts monotonicPts, Function0 function0, int i3, Object obj) {
        if ((i3 & 32) != 0) {
            function0 = null;
        }
        return compositionRecorder.writeOut(i, mediaCodec, i2, bufferInfo, monotonicPts, function0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean writeOut(int track, MediaCodec c, int index, MediaCodec.BufferInfo info, MonotonicPts clock, Function0<Unit> onSample) {
        ByteBuffer outputBuffer;
        boolean z = (info.flags & 4) != 0;
        try {
            try {
            } catch (Exception e) {
                Log.w(TAG, "writeSampleData", e);
            }
            if ((info.flags & 2) != 0) {
                c.releaseOutputBuffer(index, false);
                return false;
            }
            if (track >= 0 && info.size > 0 && !this.muxerFailed && (outputBuffer = c.getOutputBuffer(index)) != null) {
                info.presentationTimeUs = clock.next(info.presentationTimeUs);
                int i = info.offset + info.size;
                if (i <= outputBuffer.capacity()) {
                    outputBuffer.position(info.offset);
                    outputBuffer.limit(i);
                    synchronized (this.muxerLock) {
                        MediaMuxer mediaMuxer = this.muxer;
                        if (this.muxerStarted && mediaMuxer != null) {
                            mediaMuxer.writeSampleData(track, outputBuffer, info);
                            if (onSample != null) {
                                onSample.invoke();
                            }
                        } else if (this.pending.size() < PENDING_CAP) {
                            ByteBuffer byteBufferAllocate = ByteBuffer.allocate(info.size);
                            byteBufferAllocate.put(outputBuffer);
                            byteBufferAllocate.flip();
                            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
                            bufferInfo.set(0, info.size, info.presentationTimeUs, info.flags);
                            ArrayList<Pending> arrayList = this.pending;
                            Intrinsics.checkNotNull(byteBufferAllocate);
                            arrayList.add(new Pending(track, byteBufferAllocate, bufferInfo));
                            if (onSample != null) {
                                onSample.invoke();
                            }
                        } else {
                            Log.w(TAG, "pending queue full before muxer start; sample dropped");
                        }
                        Unit unit = Unit.INSTANCE;
                    }
                }
            }
            try {
                c.releaseOutputBuffer(index, false);
            } catch (Exception unused) {
            }
            return z;
        } finally {
            try {
                c.releaseOutputBuffer(index, false);
            } catch (Exception unused2) {
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:76:0x0152, code lost:
    
        android.util.Log.w(com.rehman.ahmedreactionstudio.export.CompositionRecorder.TAG, "video EOS deadline hit");
     */
    /* JADX WARN: Removed duplicated region for block: B:134:0x0152 A[EDGE_INSN: B:134:0x0152->B:76:0x0152 BREAK  A[LOOP:0: B:118:0x0037->B:79:0x0159], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:136:0x0159 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:73:0x0148  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void runLoop() throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 413
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.export.CompositionRecorder.runLoop():void");
    }

    private static final boolean runLoop$drainVideo(MediaCodec mediaCodec, MediaCodec.BufferInfo bufferInfo, final CompositionRecorder compositionRecorder, Ref.BooleanRef booleanRef) {
        while (true) {
            try {
                int iDequeueOutputBuffer = mediaCodec.dequeueOutputBuffer(bufferInfo, 2000L);
                if (iDequeueOutputBuffer == -2) {
                    MediaFormat outputFormat = mediaCodec.getOutputFormat();
                    Intrinsics.checkNotNullExpressionValue(outputFormat, "getOutputFormat(...)");
                    if (!compositionRecorder.addTrack(outputFormat, true)) {
                        booleanRef.element = true;
                        return true;
                    }
                    compositionRecorder.tryStartMuxer();
                } else {
                    if (iDequeueOutputBuffer == -1 || iDequeueOutputBuffer < 0) {
                        return false;
                    }
                    boolean zWriteOut = compositionRecorder.writeOut(compositionRecorder.videoTrack, mediaCodec, iDequeueOutputBuffer, bufferInfo, compositionRecorder.videoPts, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.export.CompositionRecorder$runLoop$drainVideo$eos$1
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            this.this$0.videoSamplesWritten++;
                        }
                    });
                    if (bufferInfo.presentationTimeUs > compositionRecorder.lastVideoPtsUs) {
                        compositionRecorder.lastVideoPtsUs = bufferInfo.presentationTimeUs;
                    }
                    if (zWriteOut) {
                        return true;
                    }
                }
            } catch (Exception unused) {
                return true;
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:83:0x0138  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void finalize(boolean r20) {
        /*
            Method dump skipped, instruction units count: 542
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.export.CompositionRecorder.finalize(boolean):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void finalize$lambda$14(Function1 function1, Result result) {
        Intrinsics.checkNotNullParameter(result, "$result");
        if (function1 != null) {
            function1.invoke(result);
        }
    }

    private final Bitmap obtain() {
        Bitmap bitmapRemoveFirst;
        synchronized (this.pool) {
            bitmapRemoveFirst = this.pool.isEmpty() ? null : this.pool.removeFirst();
        }
        return bitmapRemoveFirst;
    }

    private final void recycle(Bitmap b) {
        synchronized (this.pool) {
            if (this.pool.size() < 3) {
                this.pool.addLast(b);
            } else {
                b.recycle();
            }
            Unit unit = Unit.INSTANCE;
        }
    }

    private final void recyclePool() {
        synchronized (this.pool) {
            while (!this.pool.isEmpty()) {
                try {
                    this.pool.removeFirst().recycle();
                } catch (Exception unused) {
                }
            }
            Unit unit = Unit.INSTANCE;
        }
    }
}
