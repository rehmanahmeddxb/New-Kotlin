package com.rehman.ahmedreactionstudio.export;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: AudioMixer.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0017\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\n\n\u0002\u0010\b\n\u0000\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\u0007¢\u0006\u0002\u0010\tJ*\u0010\u001f\u001a\u00020\u00132\u0006\u0010 \u001a\u00020\u00182\u0006\u0010!\u001a\u00020\u00032\b\b\u0002\u0010\"\u001a\u00020#2\b\b\u0002\u0010$\u001a\u00020#R\u001a\u0010\u0006\u001a\u00020\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR\u001a\u0010\b\u001a\u00020\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000b\"\u0004\b\u000f\u0010\rR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u001e\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0012\u001a\u00020\u0013@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0011\u0010\u0017\u001a\u00020\u00188F¢\u0006\u0006\u001a\u0004\b\u0019\u0010\u001aR\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001b\u0010\u001c\"\u0004\b\u001d\u0010\u001e"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/ClipAudioSource;", "", "pcm", "", "volume", "", "loop", "", "muted", "([SFZZ)V", "getLoop", "()Z", "setLoop", "(Z)V", "getMuted", "setMuted", "getPcm", "()[S", "<set-?>", "Lcom/rehman/ahmedreactionstudio/export/AudioSourceState;", "state", "getState", "()Lcom/rehman/ahmedreactionstudio/export/AudioSourceState;", "totalFrames", "", "getTotalFrames", "()J", "getVolume", "()F", "setVolume", "(F)V", "mixInto", "baseFrames", "out", "offset", "", "len"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class ClipAudioSource {
    private volatile boolean loop;
    private volatile boolean muted;

    @NotNull
    private final short[] pcm;

    @NotNull
    private volatile AudioSourceState state;
    private volatile float volume;

    public ClipAudioSource(@NotNull short[] pcm, float f, boolean z, boolean z2) {
        Intrinsics.checkNotNullParameter(pcm, "pcm");
        this.pcm = pcm;
        this.volume = f;
        this.loop = z;
        this.muted = z2;
        this.state = this.pcm.length == 0 ? AudioSourceState.ENDED : AudioSourceState.ACTIVE;
    }

    public /* synthetic */ ClipAudioSource(short[] sArr, float f, boolean z, boolean z2, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(sArr, f, z, (i & 8) != 0 ? false : z2);
    }

    @NotNull
    public final short[] getPcm() {
        return this.pcm;
    }

    public final float getVolume() {
        return this.volume;
    }

    public final void setVolume(float f) {
        this.volume = f;
    }

    public final boolean getLoop() {
        return this.loop;
    }

    public final void setLoop(boolean z) {
        this.loop = z;
    }

    public final boolean getMuted() {
        return this.muted;
    }

    public final void setMuted(boolean z) {
        this.muted = z;
    }

    public final long getTotalFrames() {
        return this.pcm.length;
    }

    @NotNull
    public final AudioSourceState getState() {
        return this.state;
    }

    public static /* synthetic */ AudioSourceState mixInto$default(ClipAudioSource clipAudioSource, long j, short[] sArr, int i, int i2, int i3, Object obj) {
        if ((i3 & 4) != 0) {
            i = 0;
        }
        int i4 = i;
        if ((i3 & 8) != 0) {
            i2 = sArr.length - i4;
        }
        return clipAudioSource.mixInto(j, sArr, i4, i2);
    }

    @NotNull
    public final AudioSourceState mixInto(long baseFrames, @NotNull short[] out, int offset, int len) {
        AudioSourceState audioSourceState;
        int i;
        Intrinsics.checkNotNullParameter(out, "out");
        if (this.muted) {
            this.state = AudioSourceState.MUTED;
            return this.state;
        }
        short[] sArr = this.pcm;
        long length = sArr.length;
        if (length <= 0) {
            this.state = AudioSourceState.ENDED;
            return this.state;
        }
        float f = this.volume;
        int iCoerceAtMost = RangesKt.coerceAtMost(offset + len, out.length);
        int i2 = offset;
        boolean z = false;
        boolean z2 = false;
        while (i2 < iCoerceAtMost) {
            long j = baseFrames + ((long) (i2 - offset));
            if (j < length) {
                i = (int) j;
            } else if (this.loop) {
                j %= length;
                i = (int) j;
            } else {
                i = -1;
            }
            if (i < 0 || i >= sArr.length) {
                i2++;
                z2 = true;
            } else {
                if (!(f == 0.0f)) {
                    out[i2] = (short) RangesKt.coerceIn(out[i2] + ((int) (sArr[i] * f)), -32768, 32767);
                }
                i2++;
                z = true;
            }
        }
        if (!z && z2) {
            audioSourceState = AudioSourceState.ENDED;
        } else {
            audioSourceState = AudioSourceState.ACTIVE;
        }
        this.state = audioSourceState;
        return this.state;
    }
}
