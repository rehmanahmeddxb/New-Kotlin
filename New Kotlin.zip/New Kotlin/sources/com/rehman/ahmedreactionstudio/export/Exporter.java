package com.rehman.ahmedreactionstudio.export;

import android.graphics.Bitmap;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaMuxer;
import android.util.Log;
import com.rehman.ahmedreactionstudio.core.Layer;
import com.rehman.ahmedreactionstudio.core.MediaKit;
import com.rehman.ahmedreactionstudio.core.Project;
import com.rehman.ahmedreactionstudio.core.ProjectStore;
import com.rehman.ahmedreactionstudio.core.gpu.GpuVideoDecoder;
import com.rehman.ahmedreactionstudio.core.gpu.GpuVideoPipeline;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.MapsKt;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.math.MathKt;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: Exporter.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0082\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\bÆ\u0002\u0018\u00002\u00020\u0001:\u00066789:;B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0006H\u0002J*\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\n0\t2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\nJ6\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00140\u00132\u0006\u0010\u0015\u001a\u00020\u00062\u0006\u0010\u0016\u001a\u00020\n2\u0006\u0010\u0017\u001a\u00020\u0018H\u0002JT\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\"2\u0018\u0010#\u001a\u0014\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u001a0$2\u0012\u0010%\u001a\u000e\u0012\u0004\u0012\u00020'\u0012\u0004\u0012\u00020\u001a0&J[\u0010(\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\"2\u0018\u0010#\u001a\u0014\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u001a0$2\u0012\u0010%\u001a\u000e\u0012\u0004\u0012\u00020'\u0012\u0004\u0012\u00020\u001a0&H\u0000¢\u0006\u0002\b)J!\u0010*\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\n0\t2\u0006\u0010+\u001a\u00020\u0004H\u0000¢\u0006\u0002\b,J5\u0010-\u001a\u00020\n2\u0006\u0010.\u001a\u00020/2\u0006\u00100\u001a\u0002012\u0006\u00102\u001a\u00020\n2\u0006\u00103\u001a\u00020\n2\u0006\u00104\u001a\u00020\u000fH\u0000¢\u0006\u0002\b5R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/Exporter;", "", "()V", "TAG", "", "audioPts", "", "samples", "chooseSize", "Lkotlin/Pair;", "", "cw", "ch", "maxDim", "encodeAudioChunk", "", "codec", "Landroid/media/MediaCodec;", "clips", "", "Lcom/rehman/ahmedreactionstudio/export/Exporter$ClipState;", "baseSamples", "chunk", "mixer", "Lcom/rehman/ahmedreactionstudio/export/Exporter$Mixer;", "export", "", "p", "Lcom/rehman/ahmedreactionstudio/core/Project;", "store", "Lcom/rehman/ahmedreactionstudio/core/ProjectStore;", "opts", "Lcom/rehman/ahmedreactionstudio/export/Exporter$Options;", "cancel", "Ljava/util/concurrent/atomic/AtomicBoolean;", "onProgress", "Lkotlin/Function2;", "onDone", "Lkotlin/Function1;", "Lcom/rehman/ahmedreactionstudio/export/Exporter$Result;", "exportInternal", "exportInternal$main", "pickEncoder", "mime", "pickEncoder$main", "writeYuv", "dst", "Ljava/nio/ByteBuffer;", "bmp", "Landroid/graphics/Bitmap;", "w", "h", "nv12", "writeYuv$main", "ClipState", "Codec", "Dec", "Mixer", "Options", "Result"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nExporter.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Exporter.kt\ncom/rehman/ahmedreactionstudio/export/Exporter\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,698:1\n3792#2:699\n4307#2,2:700\n1045#3:702\n1747#3,3:704\n1#4:703\n*S KotlinDebug\n*F\n+ 1 Exporter.kt\ncom/rehman/ahmedreactionstudio/export/Exporter\n*L\n124#1:699\n124#1:700,2\n127#1:702\n270#1:704,3\n*E\n"})
public final class Exporter {

    @NotNull
    public static final Exporter INSTANCE = new Exporter();

    @NotNull
    private static final String TAG = "AhmedExporter";

    private Exporter() {
    }

    /* JADX INFO: compiled from: Exporter.kt */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\f\b\u0086\u0081\u0002\u0018\u0000 \u00132\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u0013B'\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0002\u0010\bR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\nR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000ej\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011j\u0002\b\u0012"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/Exporter$Codec;", "", "mime", "", "label", "ext", "webm", "", "(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V", "getExt", "()Ljava/lang/String;", "getLabel", "getMime", "getWebm", "()Z", "H264", "H265", "VP8", "VP9", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public enum Codec {
        H264("video/avc", "H.264 / AVC", "mp4", false),
        H265("video/hevc", "H.265 / HEVC", "mp4", false),
        VP8("video/x-vnd.on2.vp8", "VP8 (WebM)", "webm", true),
        VP9("video/x-vnd.on2.vp9", "VP9 (WebM)", "webm", true);


        @NotNull
        private final String ext;

        @NotNull
        private final String label;

        @NotNull
        private final String mime;
        private final boolean webm;
        private static final /* synthetic */ EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

        /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
        @NotNull
        public static final Companion INSTANCE = new Companion(null);

        @NotNull
        public static EnumEntries<Codec> getEntries() {
            return $ENTRIES;
        }

        Codec(String str, String str2, String str3, boolean z) {
            this.mime = str;
            this.label = str2;
            this.ext = str3;
            this.webm = z;
        }

        @NotNull
        public final String getExt() {
            return this.ext;
        }

        @NotNull
        public final String getLabel() {
            return this.label;
        }

        @NotNull
        public final String getMime() {
            return this.mime;
        }

        public final boolean getWebm() {
            return this.webm;
        }

        /* JADX INFO: compiled from: Exporter.kt */
        @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/Exporter$Codec$Companion;", "", "()V", "available", "", "Lcom/rehman/ahmedreactionstudio/export/Exporter$Codec;"}, k = 1, mv = {1, 9, 0}, xi = 48)
        @SourceDebugExtension({"SMAP\nExporter.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Exporter.kt\ncom/rehman/ahmedreactionstudio/export/Exporter$Codec$Companion\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,698:1\n766#2:699\n857#2,2:700\n*S KotlinDebug\n*F\n+ 1 Exporter.kt\ncom/rehman/ahmedreactionstudio/export/Exporter$Codec$Companion\n*L\n67#1:699\n67#1:700,2\n*E\n"})
        public static final class Companion {
            public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
                this();
            }

            private Companion() {
            }

            @NotNull
            public final List<Codec> available() {
                HashSet hashSet = new HashSet();
                try {
                    MediaCodecInfo[] codecInfos = new MediaCodecList(0).getCodecInfos();
                    Intrinsics.checkNotNullExpressionValue(codecInfos, "getCodecInfos(...)");
                    for (MediaCodecInfo mediaCodecInfo : codecInfos) {
                        if (mediaCodecInfo.isEncoder()) {
                            String[] supportedTypes = mediaCodecInfo.getSupportedTypes();
                            Intrinsics.checkNotNullExpressionValue(supportedTypes, "getSupportedTypes(...)");
                            for (String str : supportedTypes) {
                                hashSet.add(str);
                            }
                        }
                    }
                } catch (Exception unused) {
                }
                EnumEntries<Codec> entries = Codec.getEntries();
                ArrayList arrayList = new ArrayList();
                for (Codec codec : entries) {
                    if (hashSet.contains(codec.getMime())) {
                        arrayList.add(codec);
                    }
                }
                return arrayList;
            }
        }
    }

    /* JADX INFO: compiled from: Exporter.kt */
    @Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0019\b\u0086\b\u0018\u00002\u00020\u0001BU\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\b\b\u0002\u0010\n\u001a\u00020\u000b\u0012\u0014\b\u0002\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u000f0\r¢\u0006\u0002\u0010\u0010J\t\u0010\u001d\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0003HÆ\u0003J\t\u0010 \u001a\u00020\u0007HÆ\u0003J\t\u0010!\u001a\u00020\tHÆ\u0003J\t\u0010\"\u001a\u00020\u000bHÆ\u0003J\u0015\u0010#\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u000f0\rHÆ\u0003J[\u0010$\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\u000b2\u0014\b\u0002\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u000f0\rHÆ\u0001J\u0013\u0010%\u001a\u00020\u000b2\b\u0010&\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010'\u001a\u00020\u0003HÖ\u0001J\t\u0010(\u001a\u00020\u000eHÖ\u0001R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\n\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u001d\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u000f0\r¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0016R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0016"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/Exporter$Options;", "", "fps", "", "maxDim", "quality", "codec", "Lcom/rehman/ahmedreactionstudio/export/Exporter$Codec;", "outFile", "Ljava/io/File;", "compat", "", "liveFrames", "", "", "Landroid/graphics/Bitmap;", "(IIILcom/rehman/ahmedreactionstudio/export/Exporter$Codec;Ljava/io/File;ZLjava/util/Map;)V", "getCodec", "()Lcom/rehman/ahmedreactionstudio/export/Exporter$Codec;", "getCompat", "()Z", "getFps", "()I", "getLiveFrames", "()Ljava/util/Map;", "getMaxDim", "getOutFile", "()Ljava/io/File;", "getQuality", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "copy", "equals", "other", "hashCode", "toString"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final /* data */ class Options {

        @NotNull
        private final Codec codec;
        private final boolean compat;
        private final int fps;

        @NotNull
        private final Map<String, Bitmap> liveFrames;
        private final int maxDim;

        @NotNull
        private final File outFile;
        private final int quality;

        /* JADX WARN: Multi-variable type inference failed */
        public static /* synthetic */ Options copy$default(Options options, int i, int i2, int i3, Codec codec, File file, boolean z, Map map, int i4, Object obj) {
            if ((i4 & 1) != 0) {
                i = options.fps;
            }
            if ((i4 & 2) != 0) {
                i2 = options.maxDim;
            }
            int i5 = i2;
            if ((i4 & 4) != 0) {
                i3 = options.quality;
            }
            int i6 = i3;
            if ((i4 & 8) != 0) {
                codec = options.codec;
            }
            Codec codec2 = codec;
            if ((i4 & 16) != 0) {
                file = options.outFile;
            }
            File file2 = file;
            if ((i4 & 32) != 0) {
                z = options.compat;
            }
            boolean z2 = z;
            if ((i4 & 64) != 0) {
                map = options.liveFrames;
            }
            return options.copy(i, i5, i6, codec2, file2, z2, map);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final int getFps() {
            return this.fps;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final int getMaxDim() {
            return this.maxDim;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final int getQuality() {
            return this.quality;
        }

        @NotNull
        /* JADX INFO: renamed from: component4, reason: from getter */
        public final Codec getCodec() {
            return this.codec;
        }

        @NotNull
        /* JADX INFO: renamed from: component5, reason: from getter */
        public final File getOutFile() {
            return this.outFile;
        }

        /* JADX INFO: renamed from: component6, reason: from getter */
        public final boolean getCompat() {
            return this.compat;
        }

        @NotNull
        public final Map<String, Bitmap> component7() {
            return this.liveFrames;
        }

        @NotNull
        public final Options copy(int fps, int maxDim, int quality, @NotNull Codec codec, @NotNull File outFile, boolean compat, @NotNull Map<String, Bitmap> liveFrames) {
            Intrinsics.checkNotNullParameter(codec, "codec");
            Intrinsics.checkNotNullParameter(outFile, "outFile");
            Intrinsics.checkNotNullParameter(liveFrames, "liveFrames");
            return new Options(fps, maxDim, quality, codec, outFile, compat, liveFrames);
        }

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Options)) {
                return false;
            }
            Options options = (Options) other;
            return this.fps == options.fps && this.maxDim == options.maxDim && this.quality == options.quality && this.codec == options.codec && Intrinsics.areEqual(this.outFile, options.outFile) && this.compat == options.compat && Intrinsics.areEqual(this.liveFrames, options.liveFrames);
        }

        public int hashCode() {
            return (((((((((((Integer.hashCode(this.fps) * 31) + Integer.hashCode(this.maxDim)) * 31) + Integer.hashCode(this.quality)) * 31) + this.codec.hashCode()) * 31) + this.outFile.hashCode()) * 31) + Boolean.hashCode(this.compat)) * 31) + this.liveFrames.hashCode();
        }

        @NotNull
        public String toString() {
            return "Options(fps=" + this.fps + ", maxDim=" + this.maxDim + ", quality=" + this.quality + ", codec=" + this.codec + ", outFile=" + this.outFile + ", compat=" + this.compat + ", liveFrames=" + this.liveFrames + ')';
        }

        public Options(int i, int i2, int i3, @NotNull Codec codec, @NotNull File outFile, boolean z, @NotNull Map<String, Bitmap> liveFrames) {
            Intrinsics.checkNotNullParameter(codec, "codec");
            Intrinsics.checkNotNullParameter(outFile, "outFile");
            Intrinsics.checkNotNullParameter(liveFrames, "liveFrames");
            this.fps = i;
            this.maxDim = i2;
            this.quality = i3;
            this.codec = codec;
            this.outFile = outFile;
            this.compat = z;
            this.liveFrames = liveFrames;
        }

        public final int getFps() {
            return this.fps;
        }

        public final int getMaxDim() {
            return this.maxDim;
        }

        public final int getQuality() {
            return this.quality;
        }

        public /* synthetic */ Options(int i, int i2, int i3, Codec codec, File file, boolean z, Map map, int i4, DefaultConstructorMarker defaultConstructorMarker) {
            this((i4 & 1) != 0 ? 30 : i, (i4 & 2) != 0 ? 720 : i2, (i4 & 4) != 0 ? 2 : i3, (i4 & 8) != 0 ? Codec.H264 : codec, file, (i4 & 32) != 0 ? false : z, (i4 & 64) != 0 ? MapsKt.emptyMap() : map);
        }

        @NotNull
        public final Codec getCodec() {
            return this.codec;
        }

        @NotNull
        public final File getOutFile() {
            return this.outFile;
        }

        public final boolean getCompat() {
            return this.compat;
        }

        @NotNull
        public final Map<String, Bitmap> getLiveFrames() {
            return this.liveFrames;
        }
    }

    /* JADX INFO: compiled from: Exporter.kt */
    @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\u0018\u00002\u00020\u0001B)\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\u0003¢\u0006\u0002\u0010\tR\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000f"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/Exporter$Result;", "", "ok", "", "message", "", "file", "Ljava/io/File;", "retry", "(ZLjava/lang/String;Ljava/io/File;Z)V", "getFile", "()Ljava/io/File;", "getMessage", "()Ljava/lang/String;", "getOk", "()Z", "getRetry"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Result {

        @Nullable
        private final File file;

        @NotNull
        private final String message;
        private final boolean ok;
        private final boolean retry;

        public Result(boolean z, @NotNull String message, @Nullable File file, boolean z2) {
            Intrinsics.checkNotNullParameter(message, "message");
            this.ok = z;
            this.message = message;
            this.file = file;
            this.retry = z2;
        }

        public /* synthetic */ Result(boolean z, String str, File file, boolean z2, int i, DefaultConstructorMarker defaultConstructorMarker) {
            this(z, str, file, (i & 8) != 0 ? false : z2);
        }

        @Nullable
        public final File getFile() {
            return this.file;
        }

        @NotNull
        public final String getMessage() {
            return this.message;
        }

        public final boolean getOk() {
            return this.ok;
        }

        public final boolean getRetry() {
            return this.retry;
        }
    }

    @NotNull
    public final Pair<Integer, Integer> chooseSize(int cw, int ch, int maxDim) {
        Pair pair;
        boolean z = cw >= ch;
        int iCoerceIn = RangesKt.coerceIn(maxDim, 240, 1920);
        if (z) {
            pair = new Pair(Integer.valueOf(iCoerceIn), Integer.valueOf(MathKt.roundToInt((((double) iCoerceIn) * ((double) ch)) / ((double) cw))));
        } else {
            pair = new Pair(Integer.valueOf(MathKt.roundToInt((((double) iCoerceIn) * ((double) cw)) / ((double) ch))), Integer.valueOf(iCoerceIn));
        }
        return new Pair<>(Integer.valueOf(RangesKt.coerceAtLeast(chooseSize$r16(((Number) pair.component1()).intValue()), 160)), Integer.valueOf(RangesKt.coerceAtLeast(chooseSize$r16(((Number) pair.component2()).intValue()), 160)));
    }

    private static final int chooseSize$r16(int i) {
        return (i / 16) * 16;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0046  */
    @org.jetbrains.annotations.NotNull
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final kotlin.Pair<java.lang.String, java.lang.Integer> pickEncoder$main(@org.jetbrains.annotations.NotNull java.lang.String r13) {
        /*
            Method dump skipped, instruction units count: 252
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.export.Exporter.pickEncoder$main(java.lang.String):kotlin.Pair");
    }

    public final void export(@NotNull final Project p, @NotNull final ProjectStore store, @NotNull final Options opts, @NotNull final AtomicBoolean cancel, @NotNull final Function2<? super Integer, ? super String, Unit> onProgress, @NotNull final Function1<? super Result, Unit> onDone) {
        Intrinsics.checkNotNullParameter(p, "p");
        Intrinsics.checkNotNullParameter(store, "store");
        Intrinsics.checkNotNullParameter(opts, "opts");
        Intrinsics.checkNotNullParameter(cancel, "cancel");
        Intrinsics.checkNotNullParameter(onProgress, "onProgress");
        Intrinsics.checkNotNullParameter(onDone, "onDone");
        exportInternal$main(p, store, opts, cancel, onProgress, new Function1<Result, Unit>() { // from class: com.rehman.ahmedreactionstudio.export.Exporter.export.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            /* JADX WARN: Multi-variable type inference failed */
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Result result) {
                invoke2(result);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Result res) {
                Intrinsics.checkNotNullParameter(res, "res");
                if (!res.getOk() && res.getRetry() && !cancel.get()) {
                    try {
                        opts.getOutFile().delete();
                    } catch (Exception unused) {
                    }
                    onProgress.invoke(2, "Trying compatibility mode (H.264)");
                    Exporter.INSTANCE.exportInternal$main(p, store, Options.copy$default(opts, 0, 0, 0, Codec.H264, null, true, null, 87, null), cancel, onProgress, onDone);
                    return;
                }
                onDone.invoke(res);
            }
        });
    }

    public final void exportInternal$main(@NotNull final Project p, @NotNull final ProjectStore store, @NotNull final Options opts, @NotNull final AtomicBoolean cancel, @NotNull final Function2<? super Integer, ? super String, Unit> onProgress, @NotNull final Function1<? super Result, Unit> onDone) {
        Intrinsics.checkNotNullParameter(p, "p");
        Intrinsics.checkNotNullParameter(store, "store");
        Intrinsics.checkNotNullParameter(opts, "opts");
        Intrinsics.checkNotNullParameter(cancel, "cancel");
        Intrinsics.checkNotNullParameter(onProgress, "onProgress");
        Intrinsics.checkNotNullParameter(onDone, "onDone");
        new Thread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.export.-$$Lambda$Exporter$4G2GpiWX50LjoVkAPq0dRXZI1F8
            @Override // java.lang.Runnable
            public final void run() {
                Exporter.exportInternal$lambda$5(p, opts, onProgress, onDone, store, cancel);
            }
        }, "ahmed-export").start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /*  JADX ERROR: Type inference failed with stack overflow
        jadx.core.utils.exceptions.JadxOverflowException
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:77)
        */
    public static final void exportInternal$lambda$5(com.rehman.ahmedreactionstudio.core.Project r85, com.rehman.ahmedreactionstudio.export.Exporter.Options r86, kotlin.jvm.functions.Function2 r87, kotlin.jvm.functions.Function1 r88, com.rehman.ahmedreactionstudio.core.ProjectStore r89, java.util.concurrent.atomic.AtomicBoolean r90) {
        /*
            Method dump skipped, instruction units count: 4046
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.export.Exporter.exportInternal$lambda$5(com.rehman.ahmedreactionstudio.core.Project, com.rehman.ahmedreactionstudio.export.Exporter$Options, kotlin.jvm.functions.Function2, kotlin.jvm.functions.Function1, com.rehman.ahmedreactionstudio.core.ProjectStore, java.util.concurrent.atomic.AtomicBoolean):void");
    }

    private static final boolean exportInternal$lambda$5$effectiveMuted(boolean z, Layer layer) {
        return layer.getMuted() || (z && !layer.getSolo());
    }

    private static final void exportInternal$lambda$5$tryStartMuxer(Ref.BooleanRef booleanRef, Ref.BooleanRef booleanRef2, Ref.IntRef intRef, Ref.BooleanRef booleanRef3, Ref.IntRef intRef2, Ref.ObjectRef<MediaMuxer> objectRef) {
        if (booleanRef.element || booleanRef2.element || intRef.element < 0) {
            return;
        }
        if (!booleanRef3.element || intRef2.element >= 0) {
            try {
                MediaMuxer mediaMuxer = objectRef.element;
                Intrinsics.checkNotNull(mediaMuxer);
                mediaMuxer.start();
                booleanRef.element = true;
            } catch (Exception e) {
                Log.e(TAG, "muxer.start failed", e);
                booleanRef2.element = true;
            }
        }
    }

    private static final boolean exportInternal$lambda$5$writeTrack(Ref.BooleanRef booleanRef, Ref.ObjectRef<MediaMuxer> objectRef, MediaCodec mediaCodec, int i, int i2, MediaCodec.BufferInfo bufferInfo, MonotonicPts monotonicPts) {
        ByteBuffer outputBuffer;
        boolean z = (bufferInfo.flags & 4) != 0;
        try {
            try {
            } finally {
                try {
                    mediaCodec.releaseOutputBuffer(i2, false);
                } catch (Exception unused) {
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "writeSampleData", e);
        }
        if ((bufferInfo.flags & 2) != 0) {
            mediaCodec.releaseOutputBuffer(i2, false);
            return false;
        }
        if (i >= 0 && booleanRef.element && bufferInfo.size > 0 && (outputBuffer = mediaCodec.getOutputBuffer(i2)) != null) {
            bufferInfo.presentationTimeUs = monotonicPts.next(bufferInfo.presentationTimeUs);
            int i3 = bufferInfo.offset + bufferInfo.size;
            if (i3 <= outputBuffer.capacity()) {
                outputBuffer.position(bufferInfo.offset);
                outputBuffer.limit(i3);
                MediaMuxer mediaMuxer = objectRef.element;
                Intrinsics.checkNotNull(mediaMuxer);
                mediaMuxer.writeSampleData(i, outputBuffer, bufferInfo);
            }
        }
        try {
            mediaCodec.releaseOutputBuffer(i2, false);
        } catch (Exception unused2) {
        }
        return z;
    }

    private static final boolean exportInternal$lambda$5$drainVideo(Ref.ObjectRef<MediaCodec> objectRef, MediaCodec.BufferInfo bufferInfo, Ref.IntRef intRef, Ref.ObjectRef<MediaMuxer> objectRef2, Ref.BooleanRef booleanRef, MonotonicPts monotonicPts, Ref.BooleanRef booleanRef2, Ref.BooleanRef booleanRef3, Ref.IntRef intRef2) {
        while (true) {
            MediaCodec mediaCodec = objectRef.element;
            Intrinsics.checkNotNull(mediaCodec);
            int iDequeueOutputBuffer = mediaCodec.dequeueOutputBuffer(bufferInfo, 3000L);
            if (iDequeueOutputBuffer == -2) {
                try {
                    MediaMuxer mediaMuxer = objectRef2.element;
                    Intrinsics.checkNotNull(mediaMuxer);
                    MediaCodec mediaCodec2 = objectRef.element;
                    Intrinsics.checkNotNull(mediaCodec2);
                    intRef.element = mediaMuxer.addTrack(mediaCodec2.getOutputFormat());
                    exportInternal$lambda$5$tryStartMuxer(booleanRef2, booleanRef, intRef, booleanRef3, intRef2, objectRef2);
                } catch (Exception e) {
                    Log.e(TAG, "add video track", e);
                    booleanRef.element = true;
                    return true;
                }
            } else {
                if (iDequeueOutputBuffer == -1 || iDequeueOutputBuffer < 0) {
                    return false;
                }
                MediaCodec mediaCodec3 = objectRef.element;
                Intrinsics.checkNotNull(mediaCodec3);
                if (exportInternal$lambda$5$writeTrack(booleanRef2, objectRef2, mediaCodec3, intRef.element, iDequeueOutputBuffer, bufferInfo, monotonicPts)) {
                    return true;
                }
            }
        }
    }

    private static final boolean exportInternal$lambda$5$drainAudio(Ref.ObjectRef<MediaCodec> objectRef, MediaCodec.BufferInfo bufferInfo, Ref.IntRef intRef, Ref.ObjectRef<MediaMuxer> objectRef2, Ref.BooleanRef booleanRef, Ref.BooleanRef booleanRef2, MonotonicPts monotonicPts, Ref.BooleanRef booleanRef3, Ref.BooleanRef booleanRef4, Ref.IntRef intRef2) {
        MediaCodec mediaCodec = objectRef.element;
        if (mediaCodec == null) {
            return true;
        }
        while (true) {
            int iDequeueOutputBuffer = mediaCodec.dequeueOutputBuffer(bufferInfo, 3000L);
            if (iDequeueOutputBuffer == -2) {
                try {
                    MediaMuxer mediaMuxer = objectRef2.element;
                    Intrinsics.checkNotNull(mediaMuxer);
                    intRef.element = mediaMuxer.addTrack(mediaCodec.getOutputFormat());
                    exportInternal$lambda$5$tryStartMuxer(booleanRef3, booleanRef4, intRef2, booleanRef, intRef, objectRef2);
                } catch (Exception e) {
                    Log.w(TAG, "add audio track; muxing video-only", e);
                    booleanRef.element = false;
                    booleanRef2.element = true;
                    exportInternal$lambda$5$tryStartMuxer(booleanRef3, booleanRef4, intRef2, booleanRef, intRef, objectRef2);
                    return true;
                }
            } else {
                if (iDequeueOutputBuffer == -1 || iDequeueOutputBuffer < 0) {
                    return false;
                }
                if (exportInternal$lambda$5$writeTrack(booleanRef3, objectRef2, mediaCodec, intRef.element, iDequeueOutputBuffer, bufferInfo, monotonicPts)) {
                    return true;
                }
            }
        }
    }

    /* JADX INFO: compiled from: Exporter.kt */
    @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0017\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0002\u0018\u00002\u00020\u0001B9\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\b\b\u0002\u0010\n\u001a\u00020\u0007\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0005¢\u0006\u0002\u0010\fR\u0011\u0010\r\u001a\u00020\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\n\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/Exporter$ClipState;", "", "pcm", "", "volume", "", "loop", "", "durMs", "", "playing", "speed", "([SFZJZF)V", "cursor", "Lcom/rehman/ahmedreactionstudio/export/ClipCursor;", "getCursor", "()Lcom/rehman/ahmedreactionstudio/export/ClipCursor;", "getPlaying", "()Z", "getVolume", "()F"}, k = 1, mv = {1, 9, 0}, xi = 48)
    private static final class ClipState {

        @NotNull
        private final ClipCursor cursor;
        private final boolean playing;
        private final float volume;

        public ClipState(@NotNull short[] pcm, float f, boolean z, long j, boolean z2, float f2) {
            Intrinsics.checkNotNullParameter(pcm, "pcm");
            this.volume = f;
            this.playing = z2;
            this.cursor = new ClipCursor(pcm, j, z, f2);
        }

        public /* synthetic */ ClipState(short[] sArr, float f, boolean z, long j, boolean z2, float f2, int i, DefaultConstructorMarker defaultConstructorMarker) {
            this(sArr, f, z, j, (i & 16) != 0 ? true : z2, (i & 32) != 0 ? 1.0f : f2);
        }

        public final float getVolume() {
            return this.volume;
        }

        public final boolean getPlaying() {
            return this.playing;
        }

        @NotNull
        public final ClipCursor getCursor() {
            return this.cursor;
        }
    }

    private final long audioPts(long samples) {
        return AudioMath.samplesToUs$default(AudioMath.INSTANCE, samples, 0, 2, null);
    }

    /* JADX INFO: compiled from: Exporter.kt */
    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0014\n\u0002\b\u0002\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\f"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/Exporter$Mixer;", "", "chunk", "", "(I)V", "limiter", "Lcom/rehman/ahmedreactionstudio/export/Limiter;", "getLimiter", "()Lcom/rehman/ahmedreactionstudio/export/Limiter;", "mix", "", "getMix", "()[F"}, k = 1, mv = {1, 9, 0}, xi = 48)
    private static final class Mixer {

        @NotNull
        private final Limiter limiter = new Limiter(0.0f, 0.0f, 3, null);

        @NotNull
        private final float[] mix;

        public Mixer(int i) {
            this.mix = new float[i];
        }

        @NotNull
        public final Limiter getLimiter() {
            return this.limiter;
        }

        @NotNull
        public final float[] getMix() {
            return this.mix;
        }
    }

    private final boolean encodeAudioChunk(MediaCodec codec, List<ClipState> clips, long baseSamples, int chunk, Mixer mixer) {
        ByteBuffer inputBuffer;
        int iDequeueInputBuffer = codec.dequeueInputBuffer(20000L);
        if (iDequeueInputBuffer < 0 || (inputBuffer = codec.getInputBuffer(iDequeueInputBuffer)) == null) {
            return false;
        }
        float[] mix = mixer.getMix();
        Arrays.fill(mix, 0, chunk, 0.0f);
        for (ClipState clipState : clips) {
            if (clipState.getPlaying() && clipState.getVolume() > 5.0E-4f) {
                clipState.getCursor().seekComposition(baseSamples);
                clipState.getCursor().mixInto(mix, 0, chunk, clipState.getVolume());
            }
        }
        short[] sArr = new short[chunk];
        mixer.getLimiter().apply(mix, chunk, sArr);
        inputBuffer.clear();
        inputBuffer.order(ByteOrder.nativeOrder());
        inputBuffer.asShortBuffer().put(sArr);
        codec.queueInputBuffer(iDequeueInputBuffer, 0, sArr.length * 2, audioPts(baseSamples), 0);
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: Exporter.kt */
    @Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\u0006\u0010\u0016\u001a\u00020\u0017J\u000e\u0010\u0018\u001a\u00020\u00172\u0006\u0010\u0019\u001a\u00020\bR\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\"\u0010\u000b\u001a\u0004\u0018\u00010\n2\b\u0010\t\u001a\u0004\u0018\u00010\n@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u000e\u0010\u000e\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/Exporter$Dec;", "", "path", "", "maxPx", "", "(Ljava/lang/String;I)V", "cacheTime", "", "<set-?>", "Landroid/graphics/Bitmap;", "current", "getCurrent", "()Landroid/graphics/Bitmap;", "gpuId", "lastSoft", "getPath", "()Ljava/lang/String;", "soft", "Lcom/rehman/ahmedreactionstudio/core/MediaKit$FrameSource;", "useGpu", "", "close", "", "seekTo", "mediaTimeMs"}, k = 1, mv = {1, 9, 0}, xi = 48)
    static final class Dec {
        private long cacheTime;

        @Nullable
        private Bitmap current;

        @NotNull
        private final String gpuId;

        @Nullable
        private Bitmap lastSoft;
        private final int maxPx;

        @NotNull
        private final String path;

        @Nullable
        private MediaKit.FrameSource soft;
        private boolean useGpu;

        public Dec(@NotNull String path, int i) {
            Intrinsics.checkNotNullParameter(path, "path");
            this.path = path;
            this.maxPx = i;
            this.gpuId = "export_" + Integer.toHexString(System.identityHashCode(this)) + '_' + this.path.hashCode();
            this.useGpu = true;
            this.cacheTime = Long.MIN_VALUE;
            try {
                GpuVideoPipeline.INSTANCE.getOrCreate(this.gpuId, this.path);
            } catch (Exception unused) {
                this.useGpu = false;
                this.soft = new MediaKit.FrameSource(this.path);
            }
        }

        @NotNull
        public final String getPath() {
            return this.path;
        }

        @Nullable
        public final Bitmap getCurrent() {
            return this.current;
        }

        public final void seekTo(final long mediaTimeMs) {
            Bitmap bitmapFrameAt$default;
            if (this.current == null || Math.abs(mediaTimeMs - this.cacheTime) >= 25) {
                if (this.useGpu) {
                    final Ref.BooleanRef booleanRef = new Ref.BooleanRef();
                    GpuVideoPipeline.INSTANCE.runSync(8000L, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.export.Exporter$Dec$seekTo$1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            GpuVideoDecoder gpuVideoDecoderDecoder = GpuVideoPipeline.INSTANCE.decoder(this.this$0.gpuId);
                            if (gpuVideoDecoderDecoder == null) {
                                this.this$0.useGpu = false;
                                return;
                            }
                            booleanRef.element = gpuVideoDecoderDecoder.advanceTo(mediaTimeMs, this.this$0.maxPx, (8 & 4) != 0 ? false : this.this$0.cacheTime == Long.MIN_VALUE || Math.abs(mediaTimeMs - this.this$0.cacheTime) > 200 || mediaTimeMs + 40 < this.this$0.cacheTime, (8 & 8) != 0 ? false : false);
                            if (booleanRef.element) {
                                this.this$0.current = gpuVideoDecoderDecoder.getPublished();
                                this.this$0.cacheTime = mediaTimeMs;
                            }
                        }
                    });
                    if (booleanRef.element && this.current != null) {
                        return;
                    }
                    if (this.soft == null) {
                        this.soft = new MediaKit.FrameSource(this.path);
                    }
                }
                MediaKit.FrameSource frameSource = this.soft;
                if (frameSource == null || (bitmapFrameAt$default = MediaKit.FrameSource.frameAt$default(frameSource, mediaTimeMs, this.maxPx, false, 4, null)) == null) {
                    return;
                }
                Bitmap bitmap = this.lastSoft;
                this.lastSoft = bitmapFrameAt$default;
                this.current = bitmapFrameAt$default;
                this.cacheTime = mediaTimeMs;
                if (bitmap == null || bitmap == bitmapFrameAt$default) {
                    return;
                }
                try {
                    bitmap.recycle();
                } catch (Exception unused) {
                }
            }
        }

        public final void close() {
            try {
                GpuVideoPipeline.INSTANCE.releaseDecoder(this.gpuId);
            } catch (Exception unused) {
            }
            try {
                Bitmap bitmap = this.lastSoft;
                if (bitmap != null) {
                    bitmap.recycle();
                }
            } catch (Exception unused2) {
            }
            this.lastSoft = null;
            this.current = null;
            MediaKit.FrameSource frameSource = this.soft;
            if (frameSource != null) {
                frameSource.release();
            }
            this.soft = null;
        }
    }

    public final int writeYuv$main(@NotNull ByteBuffer dst, @NotNull Bitmap bmp, int w, int h, boolean nv12) {
        Intrinsics.checkNotNullParameter(dst, "dst");
        Intrinsics.checkNotNullParameter(bmp, "bmp");
        return YuvWriter.INSTANCE.fillPacked(dst, bmp, w, h, nv12);
    }
}
