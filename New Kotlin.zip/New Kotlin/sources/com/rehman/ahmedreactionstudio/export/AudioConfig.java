package com.rehman.ahmedreactionstudio.export;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: AudioMixer.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\t\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\nJ\u000e\u0010\f\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\nR\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/AudioConfig;", "", "()V", "BYTES_PER_SAMPLE", "", "CHANNEL_COUNT", "CHUNK_BYTES", "CHUNK_FRAMES", "SAMPLE_RATE", "framesForMs", "", "ms", "ptsUs", "totalFramesWritten"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class AudioConfig {
    public static final int BYTES_PER_SAMPLE = 2;
    public static final int CHANNEL_COUNT = 1;
    public static final int CHUNK_BYTES = 2048;
    public static final int CHUNK_FRAMES = 1024;

    @NotNull
    public static final AudioConfig INSTANCE = new AudioConfig();
    public static final int SAMPLE_RATE = 44100;

    private AudioConfig() {
    }

    public final long ptsUs(long totalFramesWritten) {
        return (totalFramesWritten * 1000000) / ((long) 44100);
    }

    public final long framesForMs(long ms) {
        return (ms * ((long) 44100)) / 1000;
    }
}
