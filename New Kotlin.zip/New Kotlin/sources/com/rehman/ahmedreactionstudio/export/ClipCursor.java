package com.rehman.ahmedreactionstudio.export;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: AudioMath.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0017\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0007\n\u0002\b\r\n\u0002\u0010\u0006\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0014\n\u0000\n\u0002\u0010\b\n\u0002\b\t\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\t¢\u0006\u0002\u0010\nJ&\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00020#2\u0006\u0010%\u001a\u00020\tJ\u0016\u0010&\u001a\u00020\u00072\u0006\u0010'\u001a\u00020\u00172\u0006\u0010(\u001a\u00020\u0017J\u000e\u0010)\u001a\u00020\u001f2\u0006\u0010*\u001a\u00020\u0005J\u000e\u0010+\u001a\u00020\u001f2\u0006\u0010,\u001a\u00020\u0005R\u0011\u0010\u000b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u001a\u0010\u000e\u001a\u00020\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000f\u0010\u0010\"\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0010R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u001a\u0010\u0016\u001a\u00020\u0017X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0019\"\u0004\b\u001a\u0010\u001bR\u0011\u0010\u001c\u001a\u00020\u0017¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0019"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/ClipCursor;", "", "pcm", "", "durMs", "", "loop", "", "speed", "", "([SJZF)V", "durSamples", "getDurSamples", "()J", "ended", "getEnded", "()Z", "setEnded", "(Z)V", "getLoop", "getPcm", "()[S", "pos", "", "getPos", "()D", "setPos", "(D)V", "step", "getStep", "mixInto", "", "mix", "", "from", "", "to", "vol", "resyncIfDrifted", "expectedPos", "toleranceSamples", "seekComposition", "compSamples", "seekMediaMs", "ms"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class ClipCursor {
    private final long durSamples;
    private boolean ended;
    private final boolean loop;

    @NotNull
    private final short[] pcm;
    private double pos;
    private final double step;

    public ClipCursor(@NotNull short[] pcm, long j, boolean z, float f) {
        Intrinsics.checkNotNullParameter(pcm, "pcm");
        this.pcm = pcm;
        this.loop = z;
        this.step = f > 0.05f ? f : 1.0d;
        this.durSamples = RangesKt.coerceAtLeast(j > 0 ? AudioMath.msToSamples$default(AudioMath.INSTANCE, j, 0, 2, null) : this.pcm.length, 1L);
    }

    public /* synthetic */ ClipCursor(short[] sArr, long j, boolean z, float f, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(sArr, j, z, (i & 8) != 0 ? 1.0f : f);
    }

    public final boolean getLoop() {
        return this.loop;
    }

    @NotNull
    public final short[] getPcm() {
        return this.pcm;
    }

    public final double getStep() {
        return this.step;
    }

    public final long getDurSamples() {
        return this.durSamples;
    }

    public final double getPos() {
        return this.pos;
    }

    public final void setPos(double d) {
        this.pos = d;
    }

    public final boolean getEnded() {
        return this.ended;
    }

    public final void setEnded(boolean z) {
        this.ended = z;
    }

    public final void seekComposition(long compSamples) {
        double d = compSamples * this.step;
        if (this.loop) {
            d %= this.durSamples;
        }
        this.pos = d;
        this.ended = !this.loop && d >= ((double) this.durSamples);
    }

    public final void seekMediaMs(long ms) {
        double dMsToSamples$default = AudioMath.msToSamples$default(AudioMath.INSTANCE, ms, 0, 2, null);
        if (this.loop) {
            dMsToSamples$default %= this.durSamples;
        }
        this.pos = RangesKt.coerceAtLeast(dMsToSamples$default, 0.0d);
        this.ended = !this.loop && dMsToSamples$default >= ((double) this.durSamples);
    }

    public final boolean resyncIfDrifted(double expectedPos, double toleranceSamples) {
        if (this.loop) {
            expectedPos %= this.durSamples;
        }
        double d = this.pos - expectedPos;
        if (this.loop) {
            long j = this.durSamples;
            if (d > j / 2.0d) {
                d -= j;
            }
            long j2 = this.durSamples;
            if (d < (-j2) / 2.0d) {
                d += j2;
            }
        }
        boolean z = false;
        if (Math.abs(d) <= toleranceSamples) {
            return false;
        }
        this.pos = RangesKt.coerceAtLeast(expectedPos, 0.0d);
        if (!this.loop && this.pos >= this.durSamples) {
            z = true;
        }
        this.ended = z;
        return true;
    }

    public final void mixInto(@NotNull float[] mix, int from, int to, float vol) {
        int i;
        Intrinsics.checkNotNullParameter(mix, "mix");
        if (this.ended) {
            return;
        }
        int length = this.pcm.length;
        double d = this.pos;
        boolean z = vol > 5.0E-4f;
        while (true) {
            if (from >= to) {
                break;
            }
            long j = this.durSamples;
            if (d >= j) {
                if (!this.loop) {
                    this.ended = true;
                    break;
                }
                d -= j;
            }
            int i2 = (int) d;
            if (z && (i = i2 + 1) < length) {
                float f = (float) (d - ((double) i2));
                float f2 = this.pcm[i2];
                mix[from] = mix[from] + ((f2 + ((r8[i] - f2) * f)) * vol);
            }
            d += this.step;
            from++;
        }
        this.pos = d;
    }
}
