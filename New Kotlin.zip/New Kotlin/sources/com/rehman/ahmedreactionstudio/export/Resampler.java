package com.rehman.ahmedreactionstudio.export;

import java.util.Arrays;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: AudioMath.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\n\n\u0000\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0017\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005J\u0016\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u0003R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/Resampler;", "", "from", "", "to", "(II)V", "last", "", "phase", "", "primed", "", "ratio", "process", "", "input", "n"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class Resampler {
    private short last;
    private double phase;
    private boolean primed;
    private final double ratio;

    public Resampler(int i, int i2) {
        this.ratio = ((double) i) / ((double) i2);
    }

    @NotNull
    public final short[] process(@NotNull short[] input, int n) {
        int i;
        Intrinsics.checkNotNullParameter(input, "input");
        int i2 = 0;
        if (n <= 0) {
            return new short[0];
        }
        double d = n;
        short[] sArr = new short[((int) (d / this.ratio)) + 2];
        if (!this.primed) {
            this.phase = 0.0d;
            this.primed = true;
        }
        double d2 = this.phase;
        while (true) {
            i = n - 1;
            if (d2 >= i || i2 >= sArr.length) {
                break;
            }
            int iFloor = (int) Math.floor(d2);
            double d3 = d2 - ((double) iFloor);
            short s = iFloor < 0 ? this.last : input[iFloor];
            sArr[i2] = (short) RangesKt.coerceIn((int) (((double) s) + (((double) (input[RangesKt.coerceAtMost(iFloor + 1, i)] - s)) * d3)), -32768, 32767);
            d2 += this.ratio;
            i2++;
        }
        this.phase = d2 - d;
        this.last = input[i];
        if (i2 == sArr.length) {
            return sArr;
        }
        short[] sArrCopyOf = Arrays.copyOf(sArr, i2);
        Intrinsics.checkNotNullExpressionValue(sArrCopyOf, "copyOf(...)");
        return sArrCopyOf;
    }
}
