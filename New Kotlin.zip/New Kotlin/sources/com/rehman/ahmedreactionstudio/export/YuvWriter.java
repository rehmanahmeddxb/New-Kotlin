package com.rehman.ahmedreactionstudio.export;

import android.graphics.Bitmap;
import android.media.Image;
import android.media.MediaCodec;
import java.nio.ByteBuffer;
import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: YuvWriter.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0015\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J(\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u00072\u0006\u0010\r\u001a\u00020\u0007H\u0002J6\u0010\u000e\u001a\u00020\u00072\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0012\u001a\u00020\u00072\u0006\u0010\u0013\u001a\u00020\u00072\u0006\u0010\u0014\u001a\u00020\u0015J.\u0010\u0016\u001a\u00020\u00072\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0012\u001a\u00020\u00072\u0006\u0010\u0013\u001a\u00020\u00072\u0006\u0010\u0019\u001a\u00020\u0015J \u0010\u001a\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0012\u001a\u00020\u00072\u0006\u0010\u0013\u001a\u00020\u0007H\u0002J\u000e\u0010\u001b\u001a\u00020\u00072\u0006\u0010\u001c\u001a\u00020\u0007J\u000e\u0010\u001d\u001a\u00020\u00072\u0006\u0010\u001c\u001a\u00020\u0007J\u000e\u0010\u001e\u001a\u00020\u00072\u0006\u0010\u001c\u001a\u00020\u0007R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/YuvWriter;", "", "()V", "localPx", "Ljava/lang/ThreadLocal;", "", "fillImage", "", "image", "Landroid/media/Image;", "bmp", "Landroid/graphics/Bitmap;", "srcW", "srcH", "fillInput", "codec", "Landroid/media/MediaCodec;", "index", "w", "h", "packedNv12", "", "fillPacked", "dst", "Ljava/nio/ByteBuffer;", "nv12", "pixelsOf", "uOf", "c", "vOf", "yOf"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class YuvWriter {

    @NotNull
    public static final YuvWriter INSTANCE = new YuvWriter();

    @NotNull
    private static final ThreadLocal<int[]> localPx = new ThreadLocal<>();

    public final int uOf(int c) {
        int i = (((((((c >> 16) & KotlinVersion.MAX_COMPONENT_VALUE) * (-26)) - (((c >> 8) & KotlinVersion.MAX_COMPONENT_VALUE) * 87)) + ((c & KotlinVersion.MAX_COMPONENT_VALUE) * 112)) + 128) >> 8) + 128;
        if (i < 16) {
            return 16;
        }
        if (i > 240) {
            return 240;
        }
        return i;
    }

    public final int vOf(int c) {
        int i = (((((((c >> 16) & KotlinVersion.MAX_COMPONENT_VALUE) * 112) - (((c >> 8) & KotlinVersion.MAX_COMPONENT_VALUE) * 102)) - ((c & KotlinVersion.MAX_COMPONENT_VALUE) * 10)) + 128) >> 8) + 128;
        if (i < 16) {
            return 16;
        }
        if (i > 240) {
            return 240;
        }
        return i;
    }

    public final int yOf(int c) {
        int i = (((((((c >> 16) & KotlinVersion.MAX_COMPONENT_VALUE) * 47) + (((c >> 8) & KotlinVersion.MAX_COMPONENT_VALUE) * 157)) + ((c & KotlinVersion.MAX_COMPONENT_VALUE) * 16)) + 128) >> 8) + 16;
        if (i < 16) {
            return 16;
        }
        if (i > 235) {
            return 235;
        }
        return i;
    }

    private YuvWriter() {
    }

    public final int fillInput(@NotNull MediaCodec codec, int index, @NotNull Bitmap bmp, int w, int h, boolean packedNv12) {
        Image inputImage;
        int iFillImage;
        Intrinsics.checkNotNullParameter(codec, "codec");
        Intrinsics.checkNotNullParameter(bmp, "bmp");
        if (bmp.isRecycled() || w <= 0 || h <= 0) {
            return 0;
        }
        ByteBuffer inputBuffer = null;
        try {
            inputImage = codec.getInputImage(index);
        } catch (Exception unused) {
            inputImage = null;
        }
        if (inputImage != null && (iFillImage = fillImage(inputImage, bmp, w, h)) > 0) {
            return iFillImage;
        }
        try {
            inputBuffer = codec.getInputBuffer(index);
        } catch (Exception unused2) {
        }
        ByteBuffer byteBuffer = inputBuffer;
        if (byteBuffer == null) {
            return 0;
        }
        byteBuffer.clear();
        return fillPacked(byteBuffer, bmp, w, h, packedNv12);
    }

    public final int fillPacked(@NotNull ByteBuffer dst, @NotNull Bitmap bmp, int w, int h, boolean nv12) {
        Intrinsics.checkNotNullParameter(dst, "dst");
        Intrinsics.checkNotNullParameter(bmp, "bmp");
        int[] iArrPixelsOf = pixelsOf(bmp, w, h);
        int i = w * h;
        int i2 = i / 4;
        int i3 = (i2 * 2) + i;
        if (dst.capacity() < i3) {
            return 0;
        }
        int iPosition = dst.position();
        int i4 = iPosition;
        int i5 = 0;
        int i6 = 0;
        while (i5 < h) {
            int i7 = i6;
            for (int i8 = 0; i8 < w; i8++) {
                dst.put(i4 + i8, (byte) yOf(iArrPixelsOf[i7]));
                i7++;
            }
            i4 += w;
            i5++;
            i6 = i7;
        }
        int i9 = iPosition + i;
        int i10 = i2 + i9;
        int i11 = h / 2;
        int i12 = i9;
        int i13 = 0;
        while (i13 < i11) {
            int i14 = w / 2;
            int i15 = i12;
            for (int i16 = 0; i16 < i14; i16++) {
                int i17 = iArrPixelsOf[(i13 * 2 * w) + (i16 * 2)];
                int iUOf = uOf(i17);
                int iVOf = vOf(i17);
                if (nv12) {
                    dst.put(i15, (byte) iUOf);
                    dst.put(i15 + 1, (byte) iVOf);
                    i15 += 2;
                } else {
                    dst.put(i15, (byte) iUOf);
                    dst.put((i15 - i9) + i10, (byte) iVOf);
                    i15++;
                }
            }
            i13++;
            i12 = i15;
        }
        return i3;
    }

    private final int fillImage(Image image, Bitmap bmp, int srcW, int srcH) {
        Image.Plane[] planes = image.getPlanes();
        int i = 0;
        if (planes.length < 3) {
            return 0;
        }
        int width = image.getWidth();
        int height = image.getHeight();
        if (width <= 0 || height <= 0) {
            return 0;
        }
        int iCoerceAtLeast = RangesKt.coerceAtLeast(Math.min(srcW, width) & (-2), 2);
        int iCoerceAtLeast2 = RangesKt.coerceAtLeast(Math.min(srcH, height) & (-2), 2);
        int[] iArrPixelsOf = pixelsOf(bmp, iCoerceAtLeast, iCoerceAtLeast2);
        Image.Plane plane = planes[0];
        Image.Plane plane2 = planes[1];
        Image.Plane plane3 = planes[2];
        ByteBuffer buffer = plane.getBuffer();
        ByteBuffer buffer2 = plane2.getBuffer();
        ByteBuffer buffer3 = plane3.getBuffer();
        int iPosition = buffer.position();
        int iPosition2 = buffer2.position();
        int iPosition3 = buffer3.position();
        int rowStride = plane.getRowStride();
        int iCoerceAtLeast3 = RangesKt.coerceAtLeast(plane.getPixelStride(), 1);
        int rowStride2 = plane2.getRowStride();
        int iCoerceAtLeast4 = RangesKt.coerceAtLeast(plane2.getPixelStride(), 1);
        int rowStride3 = plane3.getRowStride();
        int iCoerceAtLeast5 = RangesKt.coerceAtLeast(plane3.getPixelStride(), 1);
        int i2 = 0;
        while (i2 < iCoerceAtLeast2) {
            int i3 = iPosition + (i2 * rowStride);
            int i4 = i2 * iCoerceAtLeast;
            while (i < iCoerceAtLeast) {
                int i5 = i3 + (i * iCoerceAtLeast3);
                if (i5 < buffer.capacity()) {
                    buffer.put(i5, (byte) yOf(iArrPixelsOf[i4]));
                }
                i4++;
                i++;
            }
            i2++;
            i = 0;
        }
        int i6 = iCoerceAtLeast2 / 2;
        for (int i7 = 0; i7 < i6; i7++) {
            int i8 = (i7 * rowStride2) + iPosition2;
            int i9 = iPosition3 + (i7 * rowStride3);
            int i10 = iCoerceAtLeast / 2;
            int i11 = 0;
            while (i11 < i10) {
                int i12 = i6;
                int i13 = iArrPixelsOf[(i7 * 2 * iCoerceAtLeast) + (i11 * 2)];
                int[] iArr = iArrPixelsOf;
                int i14 = i8 + (i11 * iCoerceAtLeast4);
                int i15 = iCoerceAtLeast5;
                int i16 = i9 + (i11 * iCoerceAtLeast5);
                int i17 = i8;
                if (i14 < buffer2.capacity()) {
                    buffer2.put(i14, (byte) uOf(i13));
                }
                if (i16 < buffer3.capacity()) {
                    buffer3.put(i16, (byte) vOf(i13));
                }
                i11++;
                i6 = i12;
                iArrPixelsOf = iArr;
                iCoerceAtLeast5 = i15;
                i8 = i17;
            }
        }
        return RangesKt.coerceAtLeast(buffer.capacity(), ((iCoerceAtLeast * iCoerceAtLeast2) * 3) / 2);
    }

    private final int[] pixelsOf(Bitmap bmp, int w, int h) {
        int i = w * h;
        int[] iArr = localPx.get();
        if (iArr == null || iArr.length < i) {
            iArr = new int[i];
            localPx.set(iArr);
        }
        int width = bmp.getWidth();
        int height = bmp.getHeight();
        if (width == w && height == h) {
            bmp.getPixels(iArr, 0, w, 0, 0, w, h);
        } else {
            int[] iArr2 = new int[width * height];
            bmp.getPixels(iArr2, 0, width, 0, 0, width, height);
            for (int i2 = 0; i2 < h; i2++) {
                int iCoerceIn = RangesKt.coerceIn((int) ((((long) i2) * ((long) height)) / ((long) h)), 0, height - 1);
                for (int i3 = 0; i3 < w; i3++) {
                    iArr[(i2 * w) + i3] = iArr2[(iCoerceIn * width) + RangesKt.coerceIn((int) ((((long) i3) * ((long) width)) / ((long) w)), 0, width - 1)];
                }
            }
        }
        return iArr;
    }
}
