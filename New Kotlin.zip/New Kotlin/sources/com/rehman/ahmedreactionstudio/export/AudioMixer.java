package com.rehman.ahmedreactionstudio.export;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: AudioMixer.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0017\u0018\u00002\u00020\u0001B\u0013\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\u0002\u0010\u0005J\u001c\u0010\b\u001a\b\u0012\u0004\u0012\u00020\t0\u00032\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rR\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/AudioMixer;", "", "clips", "", "Lcom/rehman/ahmedreactionstudio/export/ClipAudioSource;", "(Ljava/util/List;)V", "getClips", "()Ljava/util/List;", "mixClips", "Lcom/rehman/ahmedreactionstudio/export/AudioSourceState;", "baseFrames", "", "out", ""}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class AudioMixer {

    @NotNull
    private final List<ClipAudioSource> clips;

    public AudioMixer(@NotNull List<ClipAudioSource> clips) {
        Intrinsics.checkNotNullParameter(clips, "clips");
        this.clips = clips;
    }

    @NotNull
    public final List<ClipAudioSource> getClips() {
        return this.clips;
    }

    @NotNull
    public final List<AudioSourceState> mixClips(long baseFrames, @NotNull short[] out) {
        Intrinsics.checkNotNullParameter(out, "out");
        if (this.clips.isEmpty()) {
            return CollectionsKt.emptyList();
        }
        ArrayList arrayList = new ArrayList(this.clips.size());
        Iterator<ClipAudioSource> it = this.clips.iterator();
        while (it.hasNext()) {
            try {
                arrayList.add(ClipAudioSource.mixInto$default(it.next(), baseFrames, out, 0, 0, 12, null));
            } catch (Exception unused) {
                arrayList.add(AudioSourceState.TEMPORARILY_EMPTY);
            }
        }
        return arrayList;
    }
}
