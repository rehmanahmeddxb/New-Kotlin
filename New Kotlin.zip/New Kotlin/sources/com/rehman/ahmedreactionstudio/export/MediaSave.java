package com.rehman.ahmedreactionstudio.export;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.io.ByteStreamsKt;
import kotlin.io.CloseableKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: MediaSave.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001\u0019B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0004J(\u0010\u0007\u001a\u0004\u0018\u00010\b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u00042\u0006\u0010\u000e\u001a\u00020\u0004J\u001c\u0010\u000f\u001a\u0004\u0018\u00010\b2\u0006\u0010\t\u001a\u00020\n2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0002J\"\u0010\u0012\u001a\u0004\u0018\u00010\u00112\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u0013\u001a\u00020\f2\u0006\u0010\u000e\u001a\u00020\u0004H\u0002J\u0018\u0010\u0014\u001a\u00020\u00152\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u0010\u001a\u00020\u0011H\u0002J2\u0010\u0016\u001a\u0004\u0018\u00010\b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\u0017\u001a\u00020\u00042\u0006\u0010\u000e\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u0015H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/MediaSave;", "", "()V", "ALBUM", "", "mimeFor", "ext", "publishVideo", "Lcom/rehman/ahmedreactionstudio/export/MediaSave$Saved;", "ctx", "Landroid/content/Context;", "src", "Ljava/io/File;", "displayName", "mime", "rollback", "uri", "Landroid/net/Uri;", "scan", "f", "sizeOf", "", "viaMediaStore", "name", "expected", "Saved"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nMediaSave.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MediaSave.kt\ncom/rehman/ahmedreactionstudio/export/MediaSave\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,193:1\n1#2:194\n*E\n"})
public final class MediaSave {

    @NotNull
    public static final String ALBUM = "AhmedReactionStudio";

    @NotNull
    public static final MediaSave INSTANCE = new MediaSave();

    private MediaSave() {
    }

    /* JADX INFO: compiled from: MediaSave.kt */
    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\n\u0018\u00002\u00020\u0001B1\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0005\u0012\u0006\u0010\t\u001a\u00020\n¢\u0006\u0002\u0010\u000bR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000fR\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/MediaSave$Saved;", "", "uri", "Landroid/net/Uri;", "path", "", "bytes", "", "location", "publiclyVisible", "", "(Landroid/net/Uri;Ljava/lang/String;JLjava/lang/String;Z)V", "getBytes", "()J", "getLocation", "()Ljava/lang/String;", "getPath", "getPubliclyVisible", "()Z", "getUri", "()Landroid/net/Uri;"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Saved {
        private final long bytes;

        @NotNull
        private final String location;

        @Nullable
        private final String path;
        private final boolean publiclyVisible;

        @Nullable
        private final Uri uri;

        public Saved(@Nullable Uri uri, @Nullable String str, long j, @NotNull String location, boolean z) {
            Intrinsics.checkNotNullParameter(location, "location");
            this.uri = uri;
            this.path = str;
            this.bytes = j;
            this.location = location;
            this.publiclyVisible = z;
        }

        @Nullable
        public final Uri getUri() {
            return this.uri;
        }

        @Nullable
        public final String getPath() {
            return this.path;
        }

        public final long getBytes() {
            return this.bytes;
        }

        @NotNull
        public final String getLocation() {
            return this.location;
        }

        public final boolean getPubliclyVisible() {
            return this.publiclyVisible;
        }
    }

    @NotNull
    public final String mimeFor(@NotNull String ext) {
        Intrinsics.checkNotNullParameter(ext, "ext");
        String lowerCase = ext.toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        return Intrinsics.areEqual(lowerCase, "webm") ? "video/webm" : "video/mp4";
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x00a9  */
    @org.jetbrains.annotations.Nullable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final com.rehman.ahmedreactionstudio.export.MediaSave.Saved publishVideo(@org.jetbrains.annotations.NotNull android.content.Context r23, @org.jetbrains.annotations.NotNull java.io.File r24, @org.jetbrains.annotations.NotNull java.lang.String r25, @org.jetbrains.annotations.NotNull java.lang.String r26) {
        /*
            Method dump skipped, instruction units count: 255
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.export.MediaSave.publishVideo(android.content.Context, java.io.File, java.lang.String, java.lang.String):com.rehman.ahmedreactionstudio.export.MediaSave$Saved");
    }

    private final Saved viaMediaStore(Context ctx, File src, String name, String mime, long expected) {
        Unit unit;
        long jCopyTo$default;
        ContentResolver contentResolver = ctx.getContentResolver();
        Uri uri = null;
        try {
            ContentValues contentValues = new ContentValues();
            contentValues.put("_display_name", name);
            contentValues.put("mime_type", mime);
            contentValues.put("relative_path", Environment.DIRECTORY_MOVIES + "/AhmedReactionStudio");
            contentValues.put("is_pending", (Integer) 1);
            Uri uriInsert = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues);
            if (uriInsert == null) {
                return null;
            }
            try {
                OutputStream outputStreamOpenOutputStream = contentResolver.openOutputStream(uriInsert);
                if (outputStreamOpenOutputStream != null) {
                    FileInputStream fileInputStream = outputStreamOpenOutputStream;
                    try {
                        OutputStream outputStream = fileInputStream;
                        fileInputStream = new FileInputStream(src);
                        try {
                            jCopyTo$default = ByteStreamsKt.copyTo$default(fileInputStream, outputStream, 0, 2, null);
                            Unit unit2 = Unit.INSTANCE;
                            CloseableKt.closeFinally(fileInputStream, null);
                            outputStream.flush();
                            Unit unit3 = Unit.INSTANCE;
                            CloseableKt.closeFinally(fileInputStream, null);
                            unit = Unit.INSTANCE;
                        } finally {
                        }
                    } finally {
                    }
                } else {
                    unit = null;
                    jCopyTo$default = 0;
                }
                if (unit == null) {
                    return rollback(ctx, uriInsert);
                }
                if (jCopyTo$default < expected) {
                    return rollback(ctx, uriInsert);
                }
                long jSizeOf = sizeOf(ctx, uriInsert);
                if (jSizeOf <= 0) {
                    return rollback(ctx, uriInsert);
                }
                contentValues.clear();
                contentValues.put("is_pending", (Integer) 0);
                contentResolver.update(uriInsert, contentValues, null, null);
                return new Saved(uriInsert, null, jSizeOf, "Movies/AhmedReactionStudio (Gallery)", true);
            } catch (Throwable unused) {
                uri = uriInsert;
                return rollback(ctx, uri);
            }
        } catch (Throwable unused2) {
        }
    }

    private final Saved rollback(Context ctx, Uri uri) {
        if (uri != null) {
            try {
                ctx.getContentResolver().delete(uri, null, null);
            } catch (Exception unused) {
            }
        }
        return null;
    }

    private final long sizeOf(Context ctx, Uri uri) {
        try {
            ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor = ctx.getContentResolver().openFileDescriptor(uri, "r");
            if (parcelFileDescriptorOpenFileDescriptor == null) {
                return 0L;
            }
            ParcelFileDescriptor parcelFileDescriptor = parcelFileDescriptorOpenFileDescriptor;
            try {
                long jCoerceAtLeast = RangesKt.coerceAtLeast(parcelFileDescriptor.getStatSize(), 0L);
                CloseableKt.closeFinally(parcelFileDescriptor, null);
                return jCoerceAtLeast;
            } finally {
            }
        } catch (Throwable unused) {
            return 0L;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final Uri scan(Context ctx, File f, String mime) {
        T tInsert;
        final Ref.ObjectRef objectRef = new Ref.ObjectRef();
        try {
            final CountDownLatch countDownLatch = new CountDownLatch(1);
            MediaScannerConnection.scanFile(ctx, new String[]{f.getAbsolutePath()}, new String[]{mime}, new MediaScannerConnection.OnScanCompletedListener() { // from class: com.rehman.ahmedreactionstudio.export.-$$Lambda$MediaSave$ymzEEW97d2fcrs8h6Bpjr3HUPog
                @Override // android.media.MediaScannerConnection.OnScanCompletedListener
                public final void onScanCompleted(String str, Uri uri) {
                    MediaSave.scan$lambda$4(objectRef, countDownLatch, str, uri);
                }
            });
            countDownLatch.await(3L, TimeUnit.SECONDS);
        } catch (Throwable unused) {
        }
        if (objectRef.element == 0) {
            try {
                ContentValues contentValues = new ContentValues();
                contentValues.put("_data", f.getAbsolutePath());
                contentValues.put("mime_type", mime);
                contentValues.put("_display_name", f.getName());
                tInsert = ctx.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues);
            } catch (Throwable unused2) {
                tInsert = 0;
            }
            objectRef.element = tInsert;
        }
        return (Uri) objectRef.element;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public static final void scan$lambda$4(Ref.ObjectRef result, CountDownLatch latch, String str, Uri uri) {
        Intrinsics.checkNotNullParameter(result, "$result");
        Intrinsics.checkNotNullParameter(latch, "$latch");
        result.element = uri;
        latch.countDown();
    }
}
