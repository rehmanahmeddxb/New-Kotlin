package com.rehman.ahmedreactionstudio.export;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* JADX INFO: compiled from: YuvWriter.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u000f\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000e\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\u0003J\u000e\u0010\b\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u0003R\u000e\u0010\u0005\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/MonotonicPts;", "", "startUs", "", "(J)V", "last", "lastOr", "fallback", "next", "candidateUs"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class MonotonicPts {
    private long last;
    private final long startUs;

    public MonotonicPts() {
        this(0L, 1, null);
    }

    public MonotonicPts(long j) {
        this.startUs = j;
        this.last = -1L;
    }

    public /* synthetic */ MonotonicPts(long j, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? 0L : j);
    }

    public final long next(long candidateUs) {
        long j = this.startUs;
        if (candidateUs < j) {
            candidateUs = j;
        }
        long j2 = this.last;
        if (candidateUs <= j2) {
            candidateUs = 1 + j2;
        }
        this.last = candidateUs;
        return candidateUs;
    }

    public final long lastOr(long fallback) {
        long j = this.last;
        return j >= 0 ? j : fallback;
    }
}
