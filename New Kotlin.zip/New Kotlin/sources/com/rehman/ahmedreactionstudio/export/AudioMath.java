package com.rehman.ahmedreactionstudio.export;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: AudioMath.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\b\n\u0002\u0010\t\n\u0002\b\u0006\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0007\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\u00042\b\b\u0002\u0010\t\u001a\u00020\u0004J\u0018\u0010\n\u001a\u00020\u00042\u0006\u0010\u000b\u001a\u00020\u00042\b\b\u0002\u0010\t\u001a\u00020\u0004J\u0018\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\r2\b\b\u0002\u0010\u000f\u001a\u00020\u0004J\u0018\u0010\u0010\u001a\u00020\r2\u0006\u0010\u0011\u001a\u00020\r2\b\b\u0002\u0010\u000f\u001a\u00020\u0004J\u0018\u0010\u0012\u001a\u00020\r2\u0006\u0010\u0013\u001a\u00020\r2\b\b\u0002\u0010\u000f\u001a\u00020\u0004R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/AudioMath;", "", "()V", "BYTES_PER_SAMPLE", "", "FRAME", "RATE", "bytesToFrames", "bytes", "channels", "framesToBytes", "frames", "msToSamples", "", "ms", "rate", "samplesToUs", "samples", "usToSamples", "us"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class AudioMath {
    public static final int BYTES_PER_SAMPLE = 2;
    public static final int FRAME = 1024;

    @NotNull
    public static final AudioMath INSTANCE = new AudioMath();
    public static final int RATE = 44100;

    public final int framesToBytes(int frames, int channels) {
        return frames * 2 * channels;
    }

    private AudioMath() {
    }

    public static /* synthetic */ long samplesToUs$default(AudioMath audioMath, long j, int i, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            i = 44100;
        }
        return audioMath.samplesToUs(j, i);
    }

    public final long samplesToUs(long samples, int rate) {
        return (samples * 1000000) / ((long) rate);
    }

    public static /* synthetic */ long usToSamples$default(AudioMath audioMath, long j, int i, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            i = 44100;
        }
        return audioMath.usToSamples(j, i);
    }

    public final long usToSamples(long us, int rate) {
        return (us * ((long) rate)) / 1000000;
    }

    public static /* synthetic */ int bytesToFrames$default(AudioMath audioMath, int i, int i2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i2 = 1;
        }
        return audioMath.bytesToFrames(i, i2);
    }

    public final int bytesToFrames(int bytes, int channels) {
        return bytes / (channels * 2);
    }

    public static /* synthetic */ int framesToBytes$default(AudioMath audioMath, int i, int i2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i2 = 1;
        }
        return audioMath.framesToBytes(i, i2);
    }

    public static /* synthetic */ long msToSamples$default(AudioMath audioMath, long j, int i, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            i = 44100;
        }
        return audioMath.msToSamples(j, i);
    }

    public final long msToSamples(long ms, int rate) {
        return (ms * ((long) rate)) / 1000;
    }
}
