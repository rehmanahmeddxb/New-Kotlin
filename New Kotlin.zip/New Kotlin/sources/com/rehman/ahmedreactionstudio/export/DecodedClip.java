package com.rehman.ahmedreactionstudio.export;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: CompositionRecorder.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0017\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/DecodedClip;", "", "clip", "Lcom/rehman/ahmedreactionstudio/export/ClipAudio;", "pcm", "", "(Lcom/rehman/ahmedreactionstudio/export/ClipAudio;[S)V", "getClip", "()Lcom/rehman/ahmedreactionstudio/export/ClipAudio;", "getPcm", "()[S"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class DecodedClip {

    @NotNull
    private final ClipAudio clip;

    @NotNull
    private final short[] pcm;

    public DecodedClip(@NotNull ClipAudio clip, @NotNull short[] pcm) {
        Intrinsics.checkNotNullParameter(clip, "clip");
        Intrinsics.checkNotNullParameter(pcm, "pcm");
        this.clip = clip;
        this.pcm = pcm;
    }

    @NotNull
    public final ClipAudio getClip() {
        return this.clip;
    }

    @NotNull
    public final short[] getPcm() {
        return this.pcm;
    }
}
