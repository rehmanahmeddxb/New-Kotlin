package com.rehman.ahmedreactionstudio.export;

import android.media.MediaFormat;
import android.os.Build;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.io.encoding.Base64;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: EncoderConfig.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001\u001cB\u0007\b\u0002¢\u0006\u0002\u0010\u0002J.\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u00042\u0006\u0010\u000b\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\rJ(\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u00042\u0006\u0010\u0010\u001a\u00020\u0011H\u0002J.\u0010\u0012\u001a\u00020\u000f2\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u00042\u0006\u0010\u000b\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\rJ6\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u00042\u0006\u0010\u000b\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u0015\u001a\u00020\u0014JJ\u0010\u0016\u001a\u00020\u00172\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u00042\u0006\u0010\u000b\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u00042\u0006\u0010\u0019\u001a\u00020\b2\b\b\u0002\u0010\u001a\u001a\u00020\u00112\b\b\u0002\u0010\u001b\u001a\u00020\u0011R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/EncoderConfig;", "", "()V", "GOP_SECONDS_EXPORT", "", "GOP_SECONDS_RECORD", "bitrateFor", "q", "Lcom/rehman/ahmedreactionstudio/export/EncoderConfig$Quality;", "w", "h", "fps", "mime", "", "bitsPerPixel", "", "hevc", "", "megabytesPerMinute", "predictedBytes", "", "durationMs", "videoFormat", "Landroid/media/MediaFormat;", "colorFormat", "quality", "liveRecorder", "compat", "Quality"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class EncoderConfig {
    private static final int GOP_SECONDS_EXPORT = 4;
    private static final int GOP_SECONDS_RECORD = 2;

    @NotNull
    public static final EncoderConfig INSTANCE = new EncoderConfig();

    /* JADX INFO: compiled from: EncoderConfig.kt */
    @Metadata(k = Base64.bytesPerGroup, mv = {1, 9, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[Quality.values().length];
            try {
                iArr[Quality.TINY.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[Quality.SMALL.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[Quality.BALANCED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[Quality.HIGH.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    private EncoderConfig() {
    }

    /* JADX INFO: compiled from: EncoderConfig.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\b\n\b\u0086\u0081\u0002\u0018\u0000 \r2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\rB\u0017\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0007j\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\f"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/EncoderConfig$Quality;", "", "label", "", "hint", "(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V", "getHint", "()Ljava/lang/String;", "getLabel", "TINY", "SMALL", "BALANCED", "HIGH", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public enum Quality {
        TINY("Tiny", "smallest file · good for chat apps"),
        SMALL("Small", "small file · very good quality"),
        BALANCED("Balanced", "recommended · OBS-like"),
        HIGH("High", "near-master quality");


        @NotNull
        private final String hint;

        @NotNull
        private final String label;
        private static final /* synthetic */ EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

        /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
        @NotNull
        public static final Companion INSTANCE = new Companion(null);

        @NotNull
        public static EnumEntries<Quality> getEntries() {
            return $ENTRIES;
        }

        Quality(String str, String str2) {
            this.label = str;
            this.hint = str2;
        }

        @NotNull
        public final String getHint() {
            return this.hint;
        }

        @NotNull
        public final String getLabel() {
            return this.label;
        }

        /* JADX INFO: compiled from: EncoderConfig.kt */
        @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/EncoderConfig$Quality$Companion;", "", "()V", "of", "Lcom/rehman/ahmedreactionstudio/export/EncoderConfig$Quality;", "index", ""}, k = 1, mv = {1, 9, 0}, xi = 48)
        public static final class Companion {
            public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
                this();
            }

            private Companion() {
            }

            @NotNull
            public final Quality of(int index) {
                return Quality.getEntries().get(RangesKt.coerceIn(index, 0, Quality.getEntries().size() - 1));
            }
        }
    }

    private final double bitsPerPixel(Quality q, int w, int h, boolean hevc) {
        double d;
        int i = WhenMappings.$EnumSwitchMapping$0[q.ordinal()];
        if (i == 1) {
            d = 0.022d;
        } else if (i == 2) {
            d = 0.035d;
        } else if (i == 3) {
            d = 0.055d;
        } else {
            if (i != 4) {
                throw new NoWhenBranchMatchedException();
            }
            d = 0.085d;
        }
        return d * RangesKt.coerceIn(Math.pow(921600.0d / RangesKt.coerceAtLeast(((long) w) * ((long) h), 1L), 0.22d), 0.55d, 1.6d) * (hevc ? 0.62d : 1.0d);
    }

    public final int bitrateFor(@NotNull Quality q, int w, int h, int fps, @NotNull String mime) {
        Intrinsics.checkNotNullParameter(q, "q");
        Intrinsics.checkNotNullParameter(mime, "mime");
        return RangesKt.coerceIn((int) (((double) w) * ((double) h) * ((double) fps) * bitsPerPixel(q, w, h, Intrinsics.areEqual(mime, "video/hevc") || Intrinsics.areEqual(mime, "video/x-vnd.on2.vp9"))), 250000, 24000000);
    }

    public final long predictedBytes(@NotNull Quality q, int w, int h, int fps, @NotNull String mime, long durationMs) {
        Intrinsics.checkNotNullParameter(q, "q");
        Intrinsics.checkNotNullParameter(mime, "mime");
        return ((((long) bitrateFor(q, w, h, fps, mime)) + 128000) / 8) * RangesKt.coerceAtLeast(RangesKt.coerceAtLeast(durationMs, 0L) / 1000, 1L);
    }

    public final double megabytesPerMinute(@NotNull Quality q, int w, int h, int fps, @NotNull String mime) {
        Intrinsics.checkNotNullParameter(q, "q");
        Intrinsics.checkNotNullParameter(mime, "mime");
        return predictedBytes(q, w, h, fps, mime, 60000L) / 1048576.0d;
    }

    @NotNull
    public final MediaFormat videoFormat(@NotNull String mime, int w, int h, int fps, int colorFormat, @NotNull Quality quality, boolean liveRecorder, boolean compat) {
        Intrinsics.checkNotNullParameter(mime, "mime");
        Intrinsics.checkNotNullParameter(quality, "quality");
        MediaFormat mediaFormatCreateVideoFormat = MediaFormat.createVideoFormat(mime, w, h);
        mediaFormatCreateVideoFormat.setInteger("color-format", colorFormat);
        mediaFormatCreateVideoFormat.setInteger("bitrate", bitrateFor(quality, w, h, fps, mime));
        mediaFormatCreateVideoFormat.setInteger("frame-rate", fps);
        mediaFormatCreateVideoFormat.setInteger("i-frame-interval", (liveRecorder || compat) ? 2 : 4);
        if (!compat) {
            try {
                mediaFormatCreateVideoFormat.setInteger("bitrate-mode", 1);
            } catch (Throwable unused) {
            }
        }
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                mediaFormatCreateVideoFormat.setInteger("color-standard", 1);
                mediaFormatCreateVideoFormat.setInteger("color-range", 2);
                mediaFormatCreateVideoFormat.setInteger("color-transfer", 3);
            } catch (Throwable unused2) {
            }
        }
        Intrinsics.checkNotNull(mediaFormatCreateVideoFormat);
        return mediaFormatCreateVideoFormat;
    }
}
