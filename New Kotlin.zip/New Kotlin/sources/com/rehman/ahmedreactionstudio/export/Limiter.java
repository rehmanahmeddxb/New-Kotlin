package com.rehman.ahmedreactionstudio.export;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: AudioMath.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0014\n\u0002\b\u0002\n\u0002\u0010\u0017\u0018\u00002\u00020\u0001B\u0019\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005J\u001e\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00072\u0006\u0010\u0013\u001a\u00020\u0014R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0007@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u001e\u0010\u000b\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u0003@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u000e\u0010\u0004\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/export/Limiter;", "", "ceiling", "", "release", "(FF)V", "<set-?>", "", "engaged", "getEngaged", "()I", "gain", "getGain", "()F", "apply", "", "mix", "", "n", "out", ""}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class Limiter {
    private final float ceiling;
    private int engaged;
    private float gain;
    private final float release;

    /* JADX WARN: Illegal instructions before constructor call */
    public Limiter() {
        float f = 0.0f;
        this(f, f, 3, null);
    }

    public Limiter(float f, float f2) {
        this.ceiling = f;
        this.release = f2;
        this.gain = 1.0f;
    }

    public /* synthetic */ Limiter(float f, float f2, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? 32000.0f : f, (i & 2) != 0 ? 0.08f : f2);
    }

    public final float getGain() {
        return this.gain;
    }

    public final int getEngaged() {
        return this.engaged;
    }

    public final void apply(@NotNull float[] mix, int n, @NotNull short[] out) {
        Intrinsics.checkNotNullParameter(mix, "mix");
        Intrinsics.checkNotNullParameter(out, "out");
        float f = 0.0f;
        for (int i = 0; i < n; i++) {
            float fAbs = Math.abs(mix[i]);
            if (fAbs > f) {
                f = fAbs;
            }
        }
        float f2 = this.ceiling;
        float f3 = f > f2 ? f2 / f : 1.0f;
        float f4 = this.gain;
        if (f3 < f4) {
            this.gain = f3;
            this.engaged++;
        } else {
            this.gain = f4 + ((1.0f - f4) * this.release);
        }
        float f5 = this.gain;
        for (int i2 = 0; i2 < n; i2++) {
            out[i2] = (short) RangesKt.coerceIn((int) (mix[i2] * f5), -32768, 32767);
        }
    }
}
