package com.rehman.ahmedreactionstudio.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Arrays;
import java.util.Locale;
import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.math.MathKt;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: Util.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0015\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J*\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001e2\b\b\u0002\u0010\u001f\u001a\u00020 2\b\b\u0002\u0010!\u001a\u00020 J\u0016\u0010\"\u001a\u00020#2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001eJ\u0016\u0010$\u001a\u00020%2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010&\u001a\u00020 J\u0016\u0010'\u001a\u00020\u00042\u0006\u0010(\u001a\u00020\u00042\u0006\u0010)\u001a\u00020*J\u0016\u0010+\u001a\u00020\u00042\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010,\u001a\u00020\u0004J\u0016\u0010-\u001a\u00020*2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010,\u001a\u00020*J\u000e\u0010.\u001a\u00020\u001e2\u0006\u0010/\u001a\u000200J\u0016\u00101\u001a\u0002022\u0006\u00103\u001a\u0002042\u0006\u00105\u001a\u00020 J*\u0010\u001d\u001a\u00020#2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u00106\u001a\u00020\u001e2\b\b\u0002\u00107\u001a\u00020 2\b\b\u0002\u00108\u001a\u00020*J6\u00109\u001a\u0002022\u0006\u0010,\u001a\u00020:2\u0006\u0010;\u001a\u00020\u00042\u0006\u0010<\u001a\u00020\u00042\u0006\u0010=\u001a\u00020\u00042\u0006\u0010>\u001a\u00020\u00042\u0006\u0010\u001b\u001a\u00020\u001cJ\u000e\u0010?\u001a\u00020\u001e2\u0006\u0010@\u001a\u000200J\u000e\u0010A\u001a\u00020\u001e2\u0006\u0010/\u001a\u000200J \u0010B\u001a\u0002022\u0006\u0010C\u001a\u00020D2\u0006\u0010E\u001a\u00020F2\b\b\u0002\u0010G\u001a\u00020\u001eJ\u0018\u0010H\u001a\u0002022\u0006\u0010I\u001a\u00020D2\b\b\u0002\u0010J\u001a\u00020 J\u0016\u0010K\u001a\u00020#2\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u00106\u001a\u00020\u001eJ\u0016\u0010L\u001a\u0002022\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u00106\u001a\u00020\u001eR\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0011\u0010\u0007\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0006R\u0011\u0010\t\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u0006R\u0011\u0010\u000b\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u0006R\u0011\u0010\r\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u0006R\u0011\u0010\u000f\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0006R\u0011\u0010\u0011\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0006R\u0011\u0010\u0013\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0006R\u0011\u0010\u0015\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0006R\u0011\u0010\u0017\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0006"}, d2 = {"Lcom/rehman/ahmedreactionstudio/util/UI;", "", "()V", "ACCENT", "", "getACCENT", "()I", "ACCENT2", "getACCENT2", "BG", "getBG", "BG2", "getBG2", "BG3", "getBG3", "BLACK", "getBLACK", "DANGER", "getDANGER", "FG", "getFG", "FG2", "getFG2", "OK", "getOK", "btn", "Landroid/widget/Button;", "ctx", "Landroid/content/Context;", "label", "", "accent", "", "small", "chip", "Landroid/widget/TextView;", "col", "Landroid/widget/LinearLayout;", "vertical", "darken", "c", "f", "", "dp", "v", "dpf", "fmtTime", "ms", "", "keepScreenOn", "", "win", "Landroid/view/Window;", "on", "s", "dim", "size", "margin", "Landroid/view/View;", "l", "t", "r", "b", "niceBytes", "n", "relTime", "shareUri", "act", "Landroid/app/Activity;", "uri", "Landroid/net/Uri;", "mime", "styleWindow", "a", "lightNav", "title", "toast"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class UI {

    @NotNull
    public static final UI INSTANCE = new UI();
    private static final int BG = Color.rgb(16, 18, 24);
    private static final int BG2 = Color.rgb(27, 30, 38);
    private static final int BG3 = Color.rgb(38, 42, 52);
    private static final int FG = Color.rgb(235, 238, 245);
    private static final int FG2 = Color.rgb(160, 166, 180);
    private static final int ACCENT = Color.rgb(KotlinVersion.MAX_COMPONENT_VALUE, 90, 44);
    private static final int ACCENT2 = Color.rgb(KotlinVersion.MAX_COMPONENT_VALUE, 160, 44);
    private static final int OK = Color.rgb(70, 210, 130);
    private static final int DANGER = Color.rgb(235, 90, 90);
    private static final int BLACK = Color.rgb(10, 10, 12);

    private UI() {
    }

    public final int getBG() {
        return BG;
    }

    public final int getBG2() {
        return BG2;
    }

    public final int getBG3() {
        return BG3;
    }

    public final int getFG() {
        return FG;
    }

    public final int getFG2() {
        return FG2;
    }

    public final int getACCENT() {
        return ACCENT;
    }

    public final int getACCENT2() {
        return ACCENT2;
    }

    public final int getOK() {
        return OK;
    }

    public final int getDANGER() {
        return DANGER;
    }

    public final int getBLACK() {
        return BLACK;
    }

    public final int dp(@NotNull Context ctx, int v) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        return MathKt.roundToInt(v * ctx.getResources().getDisplayMetrics().density);
    }

    public final float dpf(@NotNull Context ctx, float v) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        return v * ctx.getResources().getDisplayMetrics().density;
    }

    public final void toast(@NotNull Context ctx, @NotNull String s) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(s, "s");
        Toast.makeText(ctx, s, 0).show();
    }

    @NotNull
    public final String fmtTime(long ms) {
        long jCoerceAtLeast = RangesKt.coerceAtLeast(ms / 1000, 0L);
        StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
        Locale locale = Locale.US;
        Object[] objArr = {Long.valueOf(jCoerceAtLeast / 60), Long.valueOf(jCoerceAtLeast % 60)};
        String str = String.format(locale, "%d:%02d", Arrays.copyOf(objArr, objArr.length));
        Intrinsics.checkNotNullExpressionValue(str, "format(...)");
        return str;
    }

    @NotNull
    public final String relTime(long ms) {
        if (ms <= 0) {
            return "just now";
        }
        long jCurrentTimeMillis = System.currentTimeMillis() - ms;
        if (jCurrentTimeMillis < 0) {
            return "just now";
        }
        long j = jCurrentTimeMillis / 60000;
        if (j < 1) {
            return "just now";
        }
        if (j < 60) {
            StringBuilder sb = new StringBuilder();
            sb.append(j);
            sb.append(" minute");
            sb.append(j != 1 ? "s" : "");
            sb.append(" ago");
            return sb.toString();
        }
        long j2 = j / 60;
        if (j2 < 24) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(j2);
            sb2.append(" hour");
            sb2.append(j2 != 1 ? "s" : "");
            sb2.append(" ago");
            return sb2.toString();
        }
        long j3 = j2 / 24;
        if (j3 < 7) {
            StringBuilder sb3 = new StringBuilder();
            sb3.append(j3);
            sb3.append(" day");
            sb3.append(j3 != 1 ? "s" : "");
            sb3.append(" ago");
            return sb3.toString();
        }
        long j4 = j3 / 7;
        if (j4 < 5) {
            StringBuilder sb4 = new StringBuilder();
            sb4.append(j4);
            sb4.append(" week");
            sb4.append(j4 != 1 ? "s" : "");
            sb4.append(" ago");
            return sb4.toString();
        }
        long j5 = j3 / 30;
        if (j5 < 12) {
            StringBuilder sb5 = new StringBuilder();
            sb5.append(j5);
            sb5.append(" month");
            sb5.append(j5 != 1 ? "s" : "");
            sb5.append(" ago");
            return sb5.toString();
        }
        long j6 = j3 / 365;
        StringBuilder sb6 = new StringBuilder();
        sb6.append(j6);
        sb6.append(" year");
        sb6.append(j6 != 1 ? "s" : "");
        sb6.append(" ago");
        return sb6.toString();
    }

    @NotNull
    public final String niceBytes(long n) {
        if (n < 1024) {
            return n + " B";
        }
        double d = n / 1024.0d;
        if (d < 1024.0d) {
            StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
            Locale locale = Locale.US;
            Object[] objArr = {Double.valueOf(d)};
            String str = String.format(locale, "%.1f KB", Arrays.copyOf(objArr, objArr.length));
            Intrinsics.checkNotNullExpressionValue(str, "format(...)");
            return str;
        }
        double d2 = d / 1024.0d;
        if (d2 < 1024.0d) {
            StringCompanionObject stringCompanionObject2 = StringCompanionObject.INSTANCE;
            Locale locale2 = Locale.US;
            Object[] objArr2 = {Double.valueOf(d2)};
            String str2 = String.format(locale2, "%.1f MB", Arrays.copyOf(objArr2, objArr2.length));
            Intrinsics.checkNotNullExpressionValue(str2, "format(...)");
            return str2;
        }
        StringCompanionObject stringCompanionObject3 = StringCompanionObject.INSTANCE;
        Locale locale3 = Locale.US;
        Object[] objArr3 = {Double.valueOf(d2 / 1024.0d)};
        String str3 = String.format(locale3, "%.2f GB", Arrays.copyOf(objArr3, objArr3.length));
        Intrinsics.checkNotNullExpressionValue(str3, "format(...)");
        return str3;
    }

    public final void keepScreenOn(@NotNull Window win, boolean on) {
        Intrinsics.checkNotNullParameter(win, "win");
        if (on) {
            win.addFlags(128);
        } else {
            win.clearFlags(128);
        }
    }

    public final int darken(int c, float f) {
        return Color.argb(Color.alpha(c), RangesKt.coerceIn((int) (Color.red(c) * f), 0, KotlinVersion.MAX_COMPONENT_VALUE), RangesKt.coerceIn((int) (Color.green(c) * f), 0, KotlinVersion.MAX_COMPONENT_VALUE), RangesKt.coerceIn((int) (Color.blue(c) * f), 0, KotlinVersion.MAX_COMPONENT_VALUE));
    }

    @NotNull
    public final LinearLayout col(@NotNull Context ctx, boolean vertical) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        LinearLayout linearLayout = new LinearLayout(ctx);
        linearLayout.setOrientation(vertical ? 1 : 0);
        linearLayout.setBackgroundColor(BG);
        return linearLayout;
    }

    public static /* synthetic */ Button btn$default(UI ui, Context context, String str, boolean z, boolean z2, int i, Object obj) {
        if ((i & 4) != 0) {
            z = true;
        }
        if ((i & 8) != 0) {
            z2 = false;
        }
        return ui.btn(context, str, z, z2);
    }

    @NotNull
    public final Button btn(@NotNull Context ctx, @NotNull String label, boolean accent, boolean small) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(label, "label");
        Button button = new Button(ctx);
        button.setText(label);
        button.setAllCaps(false);
        button.setTypeface(Typeface.create("sans-serif-medium", 0));
        button.setTextColor(accent ? -1 : FG);
        button.setTextSize(small ? 11.0f : 14.0f);
        button.setPadding(dp(ctx, small ? 8 : 14), 0, dp(ctx, small ? 8 : 14), 0);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        if (small) {
            button.setLayoutParams(new LinearLayout.LayoutParams(-2, dp(ctx, 30)));
        } else {
            button.setLayoutParams(new LinearLayout.LayoutParams(-2, dp(ctx, 42)));
        }
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(dpf(ctx, 12.0f));
        if (accent) {
            gradientDrawable.setColor(ACCENT);
            gradientDrawable.setStroke(dp(ctx, 1), Color.argb(120, KotlinVersion.MAX_COMPONENT_VALUE, 200, 160));
        } else {
            gradientDrawable.setColor(BG3);
            gradientDrawable.setStroke(dp(ctx, 1), Color.argb(90, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
        }
        button.setBackground(gradientDrawable);
        return button;
    }

    @NotNull
    public final TextView chip(@NotNull Context ctx, @NotNull String label) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(label, "label");
        TextView textView = new TextView(ctx);
        textView.setText(label);
        textView.setGravity(17);
        textView.setTextColor(FG);
        textView.setTextSize(12.0f);
        textView.setTypeface(Typeface.create("sans-serif-medium", 0));
        textView.setPadding(dp(ctx, 10), 0, dp(ctx, 10), 0);
        textView.setLayoutParams(new LinearLayout.LayoutParams(-2, dp(ctx, 34)));
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(dpf(ctx, 17.0f));
        gradientDrawable.setColor(BG3);
        gradientDrawable.setStroke(dp(ctx, 1), Color.argb(70, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
        textView.setBackground(gradientDrawable);
        return textView;
    }

    @NotNull
    public final TextView title(@NotNull Context ctx, @NotNull String s) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(s, "s");
        TextView textView = new TextView(ctx);
        textView.setText(s);
        textView.setTextColor(FG);
        textView.setTextSize(18.0f);
        textView.setTypeface(Typeface.create("sans-serif-medium", 1));
        textView.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        return textView;
    }

    public static /* synthetic */ TextView label$default(UI ui, Context context, String str, boolean z, float f, int i, Object obj) {
        if ((i & 4) != 0) {
            z = false;
        }
        if ((i & 8) != 0) {
            f = 12.0f;
        }
        return ui.label(context, str, z, f);
    }

    @NotNull
    public final TextView label(@NotNull Context ctx, @NotNull String s, boolean dim, float size) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(s, "s");
        TextView textView = new TextView(ctx);
        textView.setText(s);
        textView.setTextColor(dim ? FG2 : FG);
        textView.setTextSize(size);
        textView.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        return textView;
    }

    public final void margin(@NotNull View v, int l, int t, int r, int b, @NotNull Context ctx) {
        Intrinsics.checkNotNullParameter(v, "v");
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        ViewGroup.LayoutParams layoutParams = v.getLayoutParams();
        LinearLayout.LayoutParams layoutParams2 = layoutParams instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams : null;
        if (layoutParams2 == null) {
            return;
        }
        layoutParams2.setMargins(dp(ctx, l), dp(ctx, t), dp(ctx, r), dp(ctx, b));
    }

    public static /* synthetic */ void styleWindow$default(UI ui, Activity activity, boolean z, int i, Object obj) {
        if ((i & 2) != 0) {
            z = true;
        }
        ui.styleWindow(activity, z);
    }

    public final void styleWindow(@NotNull Activity a, boolean lightNav) {
        Intrinsics.checkNotNullParameter(a, "a");
        Window window = a.getWindow();
        window.setStatusBarColor(BG);
        window.setNavigationBarColor(BG);
    }

    public static /* synthetic */ void shareUri$default(UI ui, Activity activity, Uri uri, String str, int i, Object obj) {
        if ((i & 4) != 0) {
            str = "video/mp4";
        }
        ui.shareUri(activity, uri, str);
    }

    public final void shareUri(@NotNull Activity act, @NotNull Uri uri, @NotNull String mime) {
        Intrinsics.checkNotNullParameter(act, "act");
        Intrinsics.checkNotNullParameter(uri, "uri");
        Intrinsics.checkNotNullParameter(mime, "mime");
        try {
            Intent type = new Intent("android.intent.action.SEND").setType(mime);
            type.putExtra("android.intent.extra.STREAM", uri);
            type.addFlags(1);
            act.startActivity(Intent.createChooser(type, "Share video"));
        } catch (Exception e) {
            toast(act, "Share failed: " + e.getMessage());
        }
    }
}
