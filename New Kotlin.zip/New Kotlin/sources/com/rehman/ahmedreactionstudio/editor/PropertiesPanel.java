package com.rehman.ahmedreactionstudio.editor;

import android.content.Context;
import android.graphics.Color;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.rehman.ahmedreactionstudio.util.UI;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: PropertiesPanel.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/PropertiesPanel;", "Landroid/widget/LinearLayout;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class PropertiesPanel extends LinearLayout {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public PropertiesPanel(@NotNull Context context) {
        super(context);
        Intrinsics.checkNotNullParameter(context, "context");
        setOrientation(1);
        setBackgroundColor(Color.rgb(18, 20, 26));
        TextView textView = new TextView(context);
        textView.setText("Select an object to edit its properties");
        textView.setTextColor(-1);
        textView.setGravity(17);
        textView.setPadding(UI.INSTANCE.dp(context, 16), UI.INSTANCE.dp(context, 16), UI.INSTANCE.dp(context, 16), UI.INSTANCE.dp(context, 16));
        addView(textView, new LinearLayout.LayoutParams(-1, -1));
    }
}
