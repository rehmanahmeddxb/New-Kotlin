package com.rehman.ahmedreactionstudio.editor;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import com.rehman.ahmedreactionstudio.R;
import com.rehman.ahmedreactionstudio.core.LayerType;
import com.rehman.ahmedreactionstudio.util.UI;
import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.io.encoding.Base64;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: Icons.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0018\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J \u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\bJ*\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\f\u001a\u00020\b2\b\b\u0002\u0010\r\u001a\u00020\u000e2\b\b\u0002\u0010\u000f\u001a\u00020\bJ\u000e\u0010\u0010\u001a\u00020\b2\u0006\u0010\u0011\u001a\u00020\u0012"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/Ic;", "", "()V", "get", "Landroid/graphics/drawable/Drawable;", "ctx", "Landroid/content/Context;", "resId", "", "tint", "pill", "Landroid/graphics/drawable/GradientDrawable;", "color", "radiusDp", "", "stroke", "typeIcon", "t", "Lcom/rehman/ahmedreactionstudio/core/LayerType;"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class Ic {

    @NotNull
    public static final Ic INSTANCE = new Ic();

    /* JADX INFO: compiled from: Icons.kt */
    @Metadata(k = Base64.bytesPerGroup, mv = {1, 9, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[LayerType.values().length];
            try {
                iArr[LayerType.VIDEO.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[LayerType.CAMERA.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[LayerType.SCREEN.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[LayerType.IMAGE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[LayerType.TEXT.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    private Ic() {
    }

    public final int typeIcon(@NotNull LayerType t) {
        Intrinsics.checkNotNullParameter(t, "t");
        int i = WhenMappings.$EnumSwitchMapping$0[t.ordinal()];
        if (i == 1) {
            return R.drawable.ic_video;
        }
        if (i == 2) {
            return R.drawable.ic_camera;
        }
        if (i == 3) {
            return R.drawable.ic_screen;
        }
        if (i == 4) {
            return R.drawable.ic_image;
        }
        if (i == 5) {
            return R.drawable.ic_text;
        }
        throw new NoWhenBranchMatchedException();
    }

    public static /* synthetic */ Drawable get$default(Ic ic, Context context, int i, int i2, int i3, Object obj) {
        if ((i3 & 4) != 0) {
            i2 = UI.INSTANCE.getFG();
        }
        return ic.get(context, i, i2);
    }

    @NotNull
    public final Drawable get(@NotNull Context ctx, int resId, int tint) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Drawable drawableMutate = ctx.getResources().getDrawable(resId, ctx.getTheme()).mutate();
        drawableMutate.setTint(tint);
        Intrinsics.checkNotNull(drawableMutate);
        return drawableMutate;
    }

    public static /* synthetic */ GradientDrawable pill$default(Ic ic, Context context, int i, float f, int i2, int i3, Object obj) {
        if ((i3 & 4) != 0) {
            f = 20.0f;
        }
        if ((i3 & 8) != 0) {
            i2 = Color.argb(60, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE);
        }
        return ic.pill(context, i, f, i2);
    }

    @NotNull
    public final GradientDrawable pill(@NotNull Context ctx, int color, float radiusDp, int stroke) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(UI.INSTANCE.dpf(ctx, radiusDp));
        gradientDrawable.setColor(color);
        gradientDrawable.setStroke(1, stroke);
        return gradientDrawable;
    }
}
