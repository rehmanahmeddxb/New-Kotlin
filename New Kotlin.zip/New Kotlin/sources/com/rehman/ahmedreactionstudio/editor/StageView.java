package com.rehman.ahmedreactionstudio.editor;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import com.rehman.ahmedreactionstudio.core.Compositor;
import com.rehman.ahmedreactionstudio.core.Layer;
import com.rehman.ahmedreactionstudio.core.LayerFit;
import com.rehman.ahmedreactionstudio.core.Project;
import com.rehman.ahmedreactionstudio.core.ViewportFit;
import com.rehman.ahmedreactionstudio.util.UI;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.io.encoding.Base64;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.math.MathKt;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: StageView.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000ª\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010 \n\u0002\b\"\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0015\n\u0002\b\u0004\u0018\u0000 \u0086\u00012\u00020\u0001:\u0006\u0086\u0001\u0087\u0001\u0088\u0001B\u001b\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\u0002\u0010\u0006J\b\u0010H\u001a\u000204H\u0002J\u0006\u0010I\u001a\u00020\fJ\u0010\u0010J\u001a\u00020\f2\u0006\u0010K\u001a\u00020LH\u0002J\u0018\u0010M\u001a\u0002042\u0006\u0010N\u001a\u00020O2\u0006\u0010K\u001a\u00020LH\u0002J\"\u0010P\u001a\u0004\u0018\u00010A2\u0006\u0010Q\u001a\u00020\u00182\u0006\u0010R\u001a\u00020\u00182\u0006\u0010K\u001a\u00020LH\u0002J\u001a\u0010S\u001a\u0004\u0018\u00010L2\u0006\u0010Q\u001a\u00020\u00182\u0006\u0010R\u001a\u00020\u0018H\u0002J\b\u0010T\u001a\u000204H\u0002J\u001a\u0010U\u001a\u00020\u00182\u0006\u0010V\u001a\u00020W2\b\b\u0002\u0010X\u001a\u00020\bH\u0002J\u001a\u0010Y\u001a\u00020\u00182\u0006\u0010V\u001a\u00020W2\b\b\u0002\u0010X\u001a\u00020\bH\u0002J\u001e\u0010Z\u001a\u00020\u00182\u0006\u0010[\u001a\u00020\u00182\f\u0010\\\u001a\b\u0012\u0004\u0012\u00020\u00180]H\u0002J\u0010\u0010^\u001a\u00020\u00182\u0006\u0010_\u001a\u00020\u0018H\u0002J\u0010\u0010`\u001a\u00020\u00182\u0006\u0010a\u001a\u00020\u0018H\u0002J\u0010\u0010b\u001a\u0002042\u0006\u0010N\u001a\u00020OH\u0014J\u0018\u0010c\u001a\u0002042\u0006\u0010d\u001a\u00020\b2\u0006\u0010e\u001a\u00020\bH\u0014J(\u0010f\u001a\u0002042\u0006\u0010d\u001a\u00020\b2\u0006\u0010e\u001a\u00020\b2\u0006\u0010g\u001a\u00020\b2\u0006\u0010h\u001a\u00020\bH\u0014J\u0010\u0010i\u001a\u00020.2\u0006\u0010V\u001a\u00020WH\u0016J\u0018\u0010j\u001a\u0002042\u0006\u0010K\u001a\u00020L2\u0006\u0010V\u001a\u00020WH\u0002J\u0010\u0010k\u001a\u00020\f2\u0006\u0010K\u001a\u00020LH\u0002J\u0006\u0010l\u001a\u000204J \u0010m\u001a\u0002042\u0006\u0010K\u001a\u00020L2\u0006\u0010Q\u001a\u00020\u00182\u0006\u0010R\u001a\u00020\u0018H\u0002J \u0010n\u001a\u0002042\u0006\u0010K\u001a\u00020L2\u0006\u0010Q\u001a\u00020\u00182\u0006\u0010R\u001a\u00020\u0018H\u0002J(\u0010o\u001a\u0002042\u0006\u0010p\u001a\u00020\u00182\u0006\u0010q\u001a\u00020\u00182\u0006\u0010r\u001a\u00020\u00182\u0006\u0010s\u001a\u00020\u0018H\u0002J&\u0010t\u001a\u0002042\u0006\u0010u\u001a\u00020\b2\u0006\u0010v\u001a\u00020\b2\u0006\u0010w\u001a\u00020\b2\u0006\u0010x\u001a\u00020\bJ\u0010\u0010y\u001a\u0002042\u0006\u0010K\u001a\u00020LH\u0002J\u0018\u0010z\u001a\u00020\b2\u0006\u0010{\u001a\u00020\b2\u0006\u0010|\u001a\u00020\bH\u0002J\u0018\u0010}\u001a\u0002042\u0006\u0010K\u001a\u00020L2\u0006\u0010~\u001a\u00020AH\u0002J6\u0010\u007f\u001a\u000f\u0012\u0004\u0012\u00020\u0018\u0012\u0004\u0012\u00020\u00180\u0080\u00012\u0006\u0010Q\u001a\u00020\u00182\u0006\u0010R\u001a\u00020\u00182\u0006\u0010K\u001a\u00020L2\u0007\u0010\u0081\u0001\u001a\u00020\fH\u0002J\t\u0010\u0082\u0001\u001a\u000204H\u0002J\b\u0010\u0083\u0001\u001a\u00030\u0084\u0001J\u000f\u0010\u0085\u0001\u001a\u00020\b2\u0006\u0010K\u001a\u00020LR\u0011\u0010\u0007\u001a\u00020\b8F¢\u0006\u0006\u001a\u0004\b\t\u0010\nR\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\r\u001a\u00020\b8F¢\u0006\u0006\u001a\u0004\b\u000e\u0010\nR\u000e\u0010\u000f\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\u001b\u001a\u0004\u0018\u00010\u001cX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u001e\"\u0004\b\u001f\u0010 R\u000e\u0010!\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020*X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020.X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u000200X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00101\u001a\u00020.X\u0082\u000e¢\u0006\u0002\n\u0000R.\u00102\u001a\u0016\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u000204\u0018\u000103X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b5\u00106\"\u0004\b7\u00108R\u0010\u00109\u001a\u0004\u0018\u00010:X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010;\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010<\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010=\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010>\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010?\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010@\u001a\u0004\u0018\u00010AX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010B\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010C\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010D\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010E\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010F\u001a\u00020\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010G\u001a\u00020.X\u0082\u000e¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/StageView;", "Landroid/view/View;", "ctx", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "canvasH", "", "getCanvasH", "()I", "canvasRect", "Landroid/graphics/RectF;", "canvasW", "getCanvasW", "ch", "chrome", "Landroid/graphics/Paint;", "chromeFill", "chromeTmp", "ctxC", "Lcom/rehman/ahmedreactionstudio/core/Compositor$Ctx;", "cw", "downX", "", "downY", "framePaint", "host", "Lcom/rehman/ahmedreactionstudio/editor/StageView$Host;", "getHost", "()Lcom/rehman/ahmedreactionstudio/editor/StageView$Host;", "setHost", "(Lcom/rehman/ahmedreactionstudio/editor/StageView$Host;)V", "hsx", "hsy", "insetB", "insetL", "insetR", "insetT", "lastFitH", "lastFitW", "lastTapUp", "", "lastTapX", "lastTapY", "longPressFired", "", "mode", "Lcom/rehman/ahmedreactionstudio/editor/StageView$Mode;", "moved", "onCanvasLayout", "Lkotlin/Function2;", "", "getOnCanvasLayout", "()Lkotlin/jvm/functions/Function2;", "setOnCanvasLayout", "(Lkotlin/jvm/functions/Function2;)V", "pendingLongPress", "Ljava/lang/Runnable;", "startAngle", "startCx", "startCy", "startDist", "startHN", "startLayerId", "", "startMidX", "startMidY", "startRot", "startWN", "tmpRect", "undoPushed", "cancelRadialLongPress", "canvasBounds", "chromeRectOf", "l", "Lcom/rehman/ahmedreactionstudio/core/Layer;", "drawChrome", "canvas", "Landroid/graphics/Canvas;", "hitHandle", "x", "y", "layerAt", "layoutCanvas", "lx", "e", "Landroid/view/MotionEvent;", "i", "ly", "nearest", "v", "targets", "", "nx", "px", "ny", "py", "onDraw", "onMeasure", "w", "h", "onSizeChanged", "ow", "oh", "onTouchEvent", "pinchMove", "rectOf", "refresh", "resizeTo", "rotateTo", "scheduleLongPress", "rawX", "rawY", "cxp", "cyp", "setViewportInsets", "left", "top", "right", "bottom", "snapMove", "specSize", "spec", "fallbackDp", "startGesture", "m", "toLayerLocal", "Lkotlin/Pair;", "r", "touchMoved", "viewportInsets", "", "visibleFrameMaxPx", "Companion", "Host", "Mode"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nStageView.kt\nKotlin\n*S Kotlin\n*F\n+ 1 StageView.kt\ncom/rehman/ahmedreactionstudio/editor/StageView\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,749:1\n1#2:750\n*E\n"})
public final class StageView extends View {
    private static final float MAX_BOX_N = 3.0f;
    private static final float MIN_BOX_N = 0.03f;
    private static final float SNAP_N = 0.016f;
    private static final int SURROUND = -16382198;

    @NotNull
    private final RectF canvasRect;
    private int ch;

    @NotNull
    private final Paint chrome;

    @NotNull
    private final Paint chromeFill;

    @NotNull
    private final RectF chromeTmp;

    @NotNull
    private final Compositor.Ctx ctxC;
    private int cw;
    private float downX;
    private float downY;

    @NotNull
    private final Paint framePaint;

    @Nullable
    private Host host;
    private float hsx;
    private float hsy;
    private int insetB;
    private int insetL;
    private int insetR;
    private int insetT;
    private float lastFitH;
    private float lastFitW;
    private long lastTapUp;
    private float lastTapX;
    private float lastTapY;
    private boolean longPressFired;

    @NotNull
    private Mode mode;
    private boolean moved;

    @Nullable
    private Function2<? super Integer, ? super Integer, Unit> onCanvasLayout;

    @Nullable
    private Runnable pendingLongPress;
    private float startAngle;
    private float startCx;
    private float startCy;
    private float startDist;
    private float startHN;

    @Nullable
    private String startLayerId;
    private float startMidX;
    private float startMidY;
    private float startRot;
    private float startWN;

    @NotNull
    private final RectF tmpRect;
    private boolean undoPushed;

    /* JADX INFO: compiled from: StageView.kt */
    @Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0002\bf\u0018\u00002\u00020\u0001J\u0012\u0010\u0006\u001a\u0004\u0018\u00010\u00072\u0006\u0010\b\u001a\u00020\tH&J\b\u0010\n\u001a\u00020\u000bH&J\u0010\u0010\f\u001a\u00020\u000b2\u0006\u0010\b\u001a\u00020\tH&J\u0010\u0010\r\u001a\u00020\u000b2\u0006\u0010\b\u001a\u00020\tH&J\"\u0010\u000e\u001a\u00020\u000b2\b\u0010\b\u001a\u0004\u0018\u00010\t2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0010H&J\b\u0010\u0012\u001a\u00020\u000bH&J\b\u0010\u0013\u001a\u00020\u000bH&J\u0012\u0010\u0014\u001a\u00020\u000b2\b\u0010\u0015\u001a\u0004\u0018\u00010\u0016H&J\n\u0010\u0017\u001a\u0004\u0018\u00010\u0016H&J\u0010\u0010\u0018\u001a\u00020\u00162\u0006\u0010\b\u001a\u00020\tH&R\u0012\u0010\u0002\u001a\u00020\u0003X¦\u0004¢\u0006\u0006\u001a\u0004\b\u0004\u0010\u0005"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/StageView$Host;", "", "project", "Lcom/rehman/ahmedreactionstudio/core/Project;", "getProject", "()Lcom/rehman/ahmedreactionstudio/core/Project;", "bitmapOf", "Landroid/graphics/Bitmap;", "l", "Lcom/rehman/ahmedreactionstudio/core/Layer;", "onChanged", "", "onDoubleTap", "onLockedTap", "onLongPressCanvas", "x", "", "y", "onTapEmpty", "onTransform", "select", "id", "", "selectedId", "textOf"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public interface Host {
        @Nullable
        Bitmap bitmapOf(@NotNull Layer l);

        @NotNull
        Project getProject();

        void onChanged();

        void onDoubleTap(@NotNull Layer l);

        void onLockedTap(@NotNull Layer l);

        void onLongPressCanvas(@Nullable Layer l, float x, float y);

        void onTapEmpty();

        void onTransform();

        void select(@Nullable String id);

        @Nullable
        String selectedId();

        @NotNull
        String textOf(@NotNull Layer l);
    }

    /* JADX INFO: compiled from: StageView.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0007\b\u0082\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\b"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/StageView$Mode;", "", "(Ljava/lang/String;I)V", "NONE", "MOVE", "CORNER", "EDGE", "ROTATE", "PINCH"}, k = 1, mv = {1, 9, 0}, xi = 48)
    private enum Mode {
        NONE,
        MOVE,
        CORNER,
        EDGE,
        ROTATE,
        PINCH;

        private static final /* synthetic */ EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

        @NotNull
        public static EnumEntries<Mode> getEntries() {
            return $ENTRIES;
        }
    }

    /* JADX INFO: compiled from: StageView.kt */
    @Metadata(k = Base64.bytesPerGroup, mv = {1, 9, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[Mode.values().length];
            try {
                iArr[Mode.MOVE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[Mode.PINCH.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[Mode.CORNER.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[Mode.EDGE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[Mode.ROTATE.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    @JvmOverloads
    public StageView(@NotNull Context ctx) {
        this(ctx, null, 2, 0 == true ? 1 : 0);
        Intrinsics.checkNotNullParameter(ctx, "ctx");
    }

    public /* synthetic */ StageView(Context context, AttributeSet attributeSet, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, (i & 2) != 0 ? null : attributeSet);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    @JvmOverloads
    public StageView(@NotNull Context ctx, @Nullable AttributeSet attributeSet) {
        super(ctx, attributeSet);
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        this.canvasRect = new RectF(0.0f, 0.0f, 1.0f, 1.0f);
        this.cw = 1;
        this.ch = 1;
        this.ctxC = new Compositor.Ctx();
        this.chrome = new Paint(1);
        this.chromeFill = new Paint(1);
        this.framePaint = new Paint(1);
        this.tmpRect = new RectF();
        this.mode = Mode.NONE;
        this.chromeTmp = new RectF();
    }

    @Nullable
    public final Host getHost() {
        return this.host;
    }

    public final void setHost(@Nullable Host host) {
        this.host = host;
    }

    public final int getCanvasW() {
        layoutCanvas();
        return this.cw;
    }

    public final int getCanvasH() {
        layoutCanvas();
        return this.ch;
    }

    @NotNull
    public final RectF canvasBounds() {
        return new RectF(this.canvasRect);
    }

    @Nullable
    public final Function2<Integer, Integer, Unit> getOnCanvasLayout() {
        return this.onCanvasLayout;
    }

    public final void setOnCanvasLayout(@Nullable Function2<? super Integer, ? super Integer, Unit> function2) {
        this.onCanvasLayout = function2;
    }

    public final void setViewportInsets(int left, int top, int right, int bottom) {
        int iCoerceAtLeast = RangesKt.coerceAtLeast(left, 0);
        int iCoerceAtLeast2 = RangesKt.coerceAtLeast(top, 0);
        int iCoerceAtLeast3 = RangesKt.coerceAtLeast(right, 0);
        int iCoerceAtLeast4 = RangesKt.coerceAtLeast(bottom, 0);
        if (iCoerceAtLeast == this.insetL && iCoerceAtLeast2 == this.insetT && iCoerceAtLeast3 == this.insetR && iCoerceAtLeast4 == this.insetB) {
            return;
        }
        this.insetL = iCoerceAtLeast;
        this.insetT = iCoerceAtLeast2;
        this.insetR = iCoerceAtLeast3;
        this.insetB = iCoerceAtLeast4;
        layoutCanvas();
        invalidate();
    }

    @NotNull
    public final int[] viewportInsets() {
        return new int[]{this.insetL, this.insetT, this.insetR, this.insetB};
    }

    @Override // android.view.View
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(specSize(w, 360), specSize(h, 360));
    }

    private final int specSize(int spec, int fallbackDp) {
        int size = View.MeasureSpec.getSize(spec);
        if (View.MeasureSpec.getMode(spec) != 0 && size > 0) {
            return size;
        }
        UI ui = UI.INSTANCE;
        Context context = getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        return ui.dp(context, fallbackDp);
    }

    @Override // android.view.View
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        layoutCanvas();
    }

    private final void layoutCanvas() {
        Project project;
        Host host = this.host;
        if (host == null || (project = host.getProject()) == null) {
            return;
        }
        float width = getWidth();
        float height = getHeight();
        if (width <= 1.0f || height <= 1.0f) {
            return;
        }
        ViewportFit viewportFit = ViewportFit.INSTANCE;
        int i = this.insetL;
        int i2 = this.insetT;
        int i3 = this.insetR;
        int i4 = this.insetB;
        UI ui = UI.INSTANCE;
        Context context = getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        float fDpf = ui.dpf(context, 6.0f);
        int canvasW = project.getAspect().getCanvasW();
        int canvasH = project.getAspect().getCanvasH();
        UI ui2 = UI.INSTANCE;
        Context context2 = getContext();
        Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
        ViewportFit.Box boxContain = viewportFit.contain(width, height, i, i2, i3, i4, fDpf, canvasW, canvasH, ui2.dpf(context2, 96.0f));
        this.canvasRect.set(boxContain.getL(), boxContain.getTop(), boxContain.getRight(), boxContain.getBottom());
        this.cw = RangesKt.coerceAtLeast(MathKt.roundToInt(boxContain.getWidth()), 1);
        this.ch = RangesKt.coerceAtLeast(MathKt.roundToInt(boxContain.getHeight()), 1);
        if (boxContain.getWidth() == this.lastFitW) {
            if (boxContain.getHeight() == this.lastFitH) {
                return;
            }
        }
        this.lastFitW = boxContain.getWidth();
        this.lastFitH = boxContain.getHeight();
        Function2<? super Integer, ? super Integer, Unit> function2 = this.onCanvasLayout;
        if (function2 != null) {
            function2.invoke(Integer.valueOf(this.cw), Integer.valueOf(this.ch));
        }
    }

    public final void refresh() {
        invalidate();
    }

    private final float lx(MotionEvent e, int i) {
        return e.getX(i) - this.canvasRect.left;
    }

    static /* synthetic */ float lx$default(StageView stageView, MotionEvent motionEvent, int i, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            i = 0;
        }
        return stageView.lx(motionEvent, i);
    }

    private final float ly(MotionEvent e, int i) {
        return e.getY(i) - this.canvasRect.top;
    }

    static /* synthetic */ float ly$default(StageView stageView, MotionEvent motionEvent, int i, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            i = 0;
        }
        return stageView.ly(motionEvent, i);
    }

    private final float nx(float px) {
        return px / this.cw;
    }

    private final float ny(float py) {
        return py / this.ch;
    }

    @Override // android.view.View
    protected void onDraw(@NotNull Canvas canvas) {
        Intrinsics.checkNotNullParameter(canvas, "canvas");
        final Host host = this.host;
        if (host == null) {
            return;
        }
        layoutCanvas();
        Project project = host.getProject();
        canvas.drawColor(SURROUND);
        canvas.save();
        canvas.translate(this.canvasRect.left, this.canvasRect.top);
        canvas.clipRect(0.0f, 0.0f, this.cw, this.ch);
        Compositor.INSTANCE.draw(this.ctxC, canvas, this.cw, this.ch, project, new Function1<Layer, Bitmap>() { // from class: com.rehman.ahmedreactionstudio.editor.StageView.onDraw.1
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            @Nullable
            public final Bitmap invoke(@NotNull Layer it) {
                Intrinsics.checkNotNullParameter(it, "it");
                return host.bitmapOf(it);
            }
        }, 0L, host.selectedId(), MapsKt.emptyMap());
        canvas.restore();
        this.framePaint.setStyle(Paint.Style.STROKE);
        Paint paint = this.framePaint;
        UI ui = UI.INSTANCE;
        Context context = getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        paint.setStrokeWidth(ui.dpf(context, 1.0f));
        this.framePaint.setColor(Color.argb(90, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
        canvas.drawRect(this.canvasRect, this.framePaint);
        String strSelectedId = host.selectedId();
        canvas.save();
        canvas.translate(this.canvasRect.left, this.canvasRect.top);
        for (Layer layer : project.getLayers()) {
            if (!Intrinsics.areEqual(layer.getId(), strSelectedId) && layer.getVisible() && layer.getOpacity() > 0.01f && !LayerFit.INSTANCE.isFullBleed(layer)) {
                RectF rectFChromeRectOf = chromeRectOf(layer);
                canvas.save();
                canvas.rotate(layer.getRotDeg(), rectFChromeRectOf.centerX(), rectFChromeRectOf.centerY());
                Paint paint2 = this.framePaint;
                UI ui2 = UI.INSTANCE;
                Context context2 = getContext();
                Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
                paint2.setStrokeWidth(ui2.dpf(context2, 1.0f));
                this.framePaint.setColor(Color.argb(layer.getLocked() ? 70 : 48, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
                canvas.drawRect(rectFChromeRectOf, this.framePaint);
                canvas.restore();
            }
        }
        Layer layerLayerById = strSelectedId != null ? project.layerById(strSelectedId) : null;
        if (layerLayerById != null && layerLayerById.getVisible()) {
            drawChrome(canvas, layerLayerById);
        }
        canvas.restore();
    }

    private final RectF rectOf(Layer l) {
        float cx = l.getCx() * this.cw;
        float cy = l.getCy() * this.ch;
        this.tmpRect.set(cx - ((l.getWN() * this.cw) / 2.0f), cy - ((l.getHN() * this.ch) / 2.0f), cx + ((l.getWN() * this.cw) / 2.0f), cy + ((l.getHN() * this.ch) / 2.0f));
        return this.tmpRect;
    }

    private final RectF chromeRectOf(Layer l) {
        Host host = this.host;
        Compositor.INSTANCE.chromeRect(l, host != null ? host.bitmapOf(l) : null, this.cw, this.ch, this.chromeTmp);
        return this.chromeTmp;
    }

    public final int visibleFrameMaxPx(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        RectF rectFChromeRectOf = chromeRectOf(l);
        return RangesKt.coerceAtLeast((int) Math.max(rectFChromeRectOf.width(), rectFChromeRectOf.height()), 1);
    }

    private final void drawChrome(Canvas canvas, Layer l) {
        boolean z;
        float f;
        float fDpf;
        float fCenterX;
        float fCenterY;
        boolean z2;
        RectF rectF = new RectF(chromeRectOf(l));
        boolean locked = l.getLocked();
        UI ui = UI.INSTANCE;
        int fg2 = locked ? ui.getFG2() : ui.getACCENT();
        canvas.save();
        canvas.rotate(l.getRotDeg(), rectF.centerX(), rectF.centerY());
        this.chrome.setStyle(Paint.Style.STROKE);
        this.chrome.setPathEffect(null);
        this.chrome.setColor(Color.argb(150, 0, 0, 0));
        Paint paint = this.chrome;
        UI ui2 = UI.INSTANCE;
        Context context = getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        paint.setStrokeWidth(ui2.dpf(context, locked ? MAX_BOX_N : 4.5f));
        canvas.drawRect(rectF, this.chrome);
        this.chrome.setColor(fg2);
        Paint paint2 = this.chrome;
        UI ui3 = UI.INSTANCE;
        Context context2 = getContext();
        Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
        paint2.setStrokeWidth(ui3.dpf(context2, locked ? 1.5f : 2.5f));
        int i = 1;
        if (locked) {
            Paint paint3 = this.chrome;
            UI ui4 = UI.INSTANCE;
            Context context3 = getContext();
            Intrinsics.checkNotNullExpressionValue(context3, "getContext(...)");
            UI ui5 = UI.INSTANCE;
            Context context4 = getContext();
            Intrinsics.checkNotNullExpressionValue(context4, "getContext(...)");
            paint3.setPathEffect(new DashPathEffect(new float[]{ui4.dpf(context3, 6.0f), ui5.dpf(context4, 4.0f)}, 0.0f));
        }
        canvas.drawRect(rectF, this.chrome);
        this.chrome.setPathEffect(null);
        UI ui6 = UI.INSTANCE;
        Context context5 = getContext();
        Intrinsics.checkNotNullExpressionValue(context5, "getContext(...)");
        float fDpf2 = ui6.dpf(context5, 5.5f);
        Paint paint4 = new Paint(1);
        paint4.setColor(-1);
        paint4.setStyle(Paint.Style.STROKE);
        UI ui7 = UI.INSTANCE;
        Context context6 = getContext();
        Intrinsics.checkNotNullExpressionValue(context6, "getContext(...)");
        paint4.setStrokeWidth(ui7.dpf(context6, 1.2f));
        Paint paint5 = new Paint(1);
        paint5.setColor(Color.argb(120, 0, 0, 0));
        if (locked) {
            z = locked;
            f = 1.0f;
        } else {
            this.chromeFill.setColor(fg2);
            UI ui8 = UI.INSTANCE;
            Context context7 = getContext();
            Intrinsics.checkNotNullExpressionValue(context7, "getContext(...)");
            float fDpf3 = ui8.dpf(context7, 1.5f);
            int i2 = 0;
            while (true) {
                if (i2 >= 3) {
                    break;
                }
                int i3 = 0;
                for (int i4 = 3; i3 < i4; i4 = 3) {
                    if (i2 == i && i3 == i) {
                        z2 = locked;
                    } else {
                        if (i3 != 0) {
                            fCenterX = i3 != 2 ? rectF.centerX() : rectF.right;
                        } else {
                            fCenterX = rectF.left;
                        }
                        if (i2 != 0) {
                            fCenterY = i2 != 2 ? rectF.centerY() : rectF.bottom;
                        } else {
                            fCenterY = rectF.top;
                        }
                        int i5 = (i2 == i || i3 == i) ? 0 : i;
                        float f2 = (i5 != 0 || i2 == i) ? fDpf2 : 1.6f * fDpf2;
                        float f3 = (i5 != 0 || i3 == i) ? fDpf2 : 1.6f * fDpf2;
                        if (i5 == 0 && i2 == i) {
                            f2 = 0.6f * fDpf2;
                        }
                        if (i5 == 0 && i3 == i) {
                            f3 = fDpf2 * 0.6f;
                        }
                        z2 = locked;
                        this.tmpRect.set(fCenterX - f2, fCenterY - f3, fCenterX + f2, fCenterY + f3);
                        RectF rectF2 = this.tmpRect;
                        UI ui9 = UI.INSTANCE;
                        Context context8 = getContext();
                        Intrinsics.checkNotNullExpressionValue(context8, "getContext(...)");
                        rectF2.offset(0.0f, ui9.dpf(context8, 1.0f));
                        canvas.drawRoundRect(this.tmpRect, fDpf3, fDpf3, paint5);
                        RectF rectF3 = this.tmpRect;
                        UI ui10 = UI.INSTANCE;
                        Context context9 = getContext();
                        Intrinsics.checkNotNullExpressionValue(context9, "getContext(...)");
                        rectF3.offset(0.0f, -ui10.dpf(context9, 1.0f));
                        canvas.drawRoundRect(this.tmpRect, fDpf3, fDpf3, this.chromeFill);
                        canvas.drawRoundRect(this.tmpRect, fDpf3, fDpf3, paint4);
                    }
                    i3++;
                    locked = z2;
                    i = 1;
                }
                i2++;
                locked = locked;
                i = 1;
            }
            z = locked;
            f = 1.0f;
            float f4 = rectF.top;
            UI ui11 = UI.INSTANCE;
            Context context10 = getContext();
            Intrinsics.checkNotNullExpressionValue(context10, "getContext(...)");
            float fDpf4 = f4 - ui11.dpf(context10, 18.0f);
            float fCenterX2 = rectF.centerX();
            Paint paint6 = this.chrome;
            UI ui12 = UI.INSTANCE;
            Context context11 = getContext();
            Intrinsics.checkNotNullExpressionValue(context11, "getContext(...)");
            paint6.setStrokeWidth(ui12.dpf(context11, 1.5f));
            this.chrome.setColor(fg2);
            canvas.drawLine(fCenterX2, rectF.top, fCenterX2, fDpf4, this.chrome);
            this.chromeFill.setColor(fg2);
            UI ui13 = UI.INSTANCE;
            Context context12 = getContext();
            Intrinsics.checkNotNullExpressionValue(context12, "getContext(...)");
            float fDpf5 = ui13.dpf(context12, 1.0f) + fDpf4;
            float f5 = 1.35f * fDpf2;
            canvas.drawCircle(fCenterX2, fDpf5, f5, paint5);
            canvas.drawCircle(fCenterX2, fDpf4, f5, this.chromeFill);
            canvas.drawCircle(fCenterX2, fDpf4, f5, paint4);
            this.chromeFill.setColor(-1);
            canvas.drawCircle(fCenterX2, fDpf4, 0.55f * fDpf2, this.chromeFill);
        }
        String str = z ? "  🔒 LOCKED" : "";
        StringBuilder sb = new StringBuilder();
        sb.append(l.isLive() ? "LIVE  " : "");
        String name = l.getName();
        if (StringsKt.isBlank(name)) {
            name = l.getType().getLabel();
        }
        sb.append(name);
        sb.append(str);
        String string = sb.toString();
        UI ui14 = UI.INSTANCE;
        Context context13 = getContext();
        Intrinsics.checkNotNullExpressionValue(context13, "getContext(...)");
        float fDpf6 = ui14.dpf(context13, 8.0f);
        UI ui15 = UI.INSTANCE;
        Context context14 = getContext();
        Intrinsics.checkNotNullExpressionValue(context14, "getContext(...)");
        float fDpf7 = ui15.dpf(context14, MAX_BOX_N);
        Paint paint7 = new Paint(1);
        paint7.setColor(-1);
        UI ui16 = UI.INSTANCE;
        Context context15 = getContext();
        Intrinsics.checkNotNullExpressionValue(context15, "getContext(...)");
        paint7.setTextSize(ui16.dpf(context15, 10.0f));
        paint7.setTypeface(Typeface.create("sans-serif-medium", 1));
        Paint paint8 = new Paint(1);
        paint8.setColor(Color.argb(215, 18, 20, 26));
        Paint paint9 = new Paint(1);
        paint9.setColor(fg2);
        paint9.setStyle(Paint.Style.STROKE);
        UI ui17 = UI.INSTANCE;
        Context context16 = getContext();
        Intrinsics.checkNotNullExpressionValue(context16, "getContext(...)");
        paint9.setStrokeWidth(ui17.dpf(context16, f));
        float f6 = 2;
        float fMeasureText = paint7.measureText(string) + (fDpf6 * f6);
        float textSize = paint7.getTextSize() + (fDpf7 * f6);
        UI ui18 = UI.INSTANCE;
        Context context17 = getContext();
        Intrinsics.checkNotNullExpressionValue(context17, "getContext(...)");
        float fDpf8 = textSize + ui18.dpf(context17, 2.0f);
        float fCenterX3 = rectF.centerX() - (fMeasureText / f6);
        float f7 = rectF.top;
        UI ui19 = UI.INSTANCE;
        Context context18 = getContext();
        Intrinsics.checkNotNullExpressionValue(context18, "getContext(...)");
        float fDpf9 = (z ? f7 - ui19.dpf(context18, 6.0f) : (f7 - ui19.dpf(context18, 18.0f)) - (fDpf2 * 1.8f)) - fDpf8;
        UI ui20 = UI.INSTANCE;
        Context context19 = getContext();
        Intrinsics.checkNotNullExpressionValue(context19, "getContext(...)");
        if (fDpf9 < ui20.dpf(context19, 2.0f)) {
            float f8 = rectF.top;
            UI ui21 = UI.INSTANCE;
            Context context20 = getContext();
            Intrinsics.checkNotNullExpressionValue(context20, "getContext(...)");
            fDpf = f8 + ui21.dpf(context20, 6.0f);
        } else {
            fDpf = fDpf9;
        }
        UI ui22 = UI.INSTANCE;
        Context context21 = getContext();
        Intrinsics.checkNotNullExpressionValue(context21, "getContext(...)");
        float fDpf10 = ui22.dpf(context21, 10.0f);
        float f9 = fCenterX3 + fMeasureText;
        float f10 = fDpf + fDpf8;
        float f11 = fDpf;
        canvas.drawRoundRect(fCenterX3, f11, f9, f10, fDpf10, fDpf10, paint8);
        canvas.drawRoundRect(fCenterX3, f11, f9, f10, fDpf10, fDpf10, paint9);
        UI ui23 = UI.INSTANCE;
        Context context22 = getContext();
        Intrinsics.checkNotNullExpressionValue(context22, "getContext(...)");
        canvas.drawText(string, fCenterX3 + fDpf6, (f10 - fDpf7) - ui23.dpf(context22, 1.0f), paint7);
        canvas.restore();
    }

    private final Pair<Float, Float> toLayerLocal(float x, float y, Layer l, RectF r) {
        double radians = Math.toRadians(-l.getRotDeg());
        double dCenterX = x - r.centerX();
        double dCenterY = y - r.centerY();
        return new Pair<>(Float.valueOf((float) ((Math.cos(radians) * dCenterX) - (Math.sin(radians) * dCenterY))), Float.valueOf((float) ((dCenterX * Math.sin(radians)) + (dCenterY * Math.cos(radians)))));
    }

    private final String hitHandle(float x, float y, Layer l) {
        RectF rectFChromeRectOf = chromeRectOf(l);
        float fWidth = rectFChromeRectOf.width() / 2.0f;
        float fHeight = rectFChromeRectOf.height() / 2.0f;
        Pair<Float, Float> layerLocal = toLayerLocal(x, y, l, rectFChromeRectOf);
        float fFloatValue = layerLocal.component1().floatValue();
        float fFloatValue2 = layerLocal.component2().floatValue();
        UI ui = UI.INSTANCE;
        Context context = getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        float fMin = Math.min(ui.dpf(context, 24.0f), Math.min(fWidth, fHeight) * 0.9f);
        UI ui2 = UI.INSTANCE;
        Context context2 = getContext();
        Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
        float fCoerceAtLeast = RangesKt.coerceAtLeast(fMin, ui2.dpf(context2, 10.0f));
        float f = 0.0f;
        if (fCoerceAtLeast <= 0.0f) {
            return null;
        }
        UI ui3 = UI.INSTANCE;
        Context context3 = getContext();
        Intrinsics.checkNotNullExpressionValue(context3, "getContext(...)");
        float fDpf = (-fHeight) - ui3.dpf(context3, 18.0f);
        if (Math.abs(fFloatValue) <= fCoerceAtLeast && Math.abs(fFloatValue2 - fDpf) <= fCoerceAtLeast) {
            return "ROT";
        }
        float f2 = Math.abs(fFloatValue + fWidth) <= fCoerceAtLeast ? -1.0f : Math.abs(fFloatValue - fWidth) <= fCoerceAtLeast ? 1.0f : 0.0f;
        if (Math.abs(fFloatValue2 + fHeight) <= fCoerceAtLeast) {
            f = -1.0f;
        } else if (Math.abs(fFloatValue2 - fHeight) <= fCoerceAtLeast) {
            f = 1.0f;
        }
        boolean z = Math.abs(fFloatValue) <= fCoerceAtLeast;
        boolean z2 = Math.abs(fFloatValue2) <= fCoerceAtLeast;
        if (f2 == -1.0f) {
            if (f == -1.0f) {
                return "TL";
            }
        }
        if (f2 == 1.0f) {
            if (f == -1.0f) {
                return "TR";
            }
        }
        if (f2 == -1.0f) {
            if (f == 1.0f) {
                return "BL";
            }
        }
        if (f2 == 1.0f) {
            if (f == 1.0f) {
                return "BR";
            }
        }
        if (z) {
            if (f == -1.0f) {
                return "TC";
            }
        }
        if (z) {
            if (f == 1.0f) {
                return "BC";
            }
        }
        if ((f2 == -1.0f) && z2) {
            return "ML";
        }
        if ((f2 == 1.0f) && z2) {
            return "MR";
        }
        return null;
    }

    private final Layer layerAt(float x, float y) {
        Host host = this.host;
        if (host == null) {
            return null;
        }
        return LayerFit.INSTANCE.hitTest(host.getProject().getLayers(), x, y, this.cw, this.ch);
    }

    /* JADX WARN: Removed duplicated region for block: B:98:0x0224  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean onTouchEvent(@org.jetbrains.annotations.NotNull android.view.MotionEvent r14) {
        /*
            Method dump skipped, instruction units count: 692
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.editor.StageView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    private final void scheduleLongPress(final float rawX, final float rawY, final float cxp, final float cyp) {
        cancelRadialLongPress();
        this.longPressFired = false;
        Runnable runnable = new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$StageView$oI-_MDvzTMcRSAktdsBevmGQrps
            @Override // java.lang.Runnable
            public final void run() {
                StageView.scheduleLongPress$lambda$11(this.f$0, cxp, cyp, rawX, rawY);
            }
        };
        this.pendingLongPress = runnable;
        postDelayed(runnable, 460L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void scheduleLongPress$lambda$11(StageView this$0, float f, float f2, float f3, float f4) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.moved) {
            return;
        }
        this$0.longPressFired = true;
        this$0.performHapticFeedback(0);
        this$0.mode = Mode.NONE;
        this$0.startLayerId = null;
        Host host = this$0.host;
        if (host != null) {
            host.onLongPressCanvas(this$0.layerAt(f, f2), f3, f4);
        }
    }

    private final void cancelRadialLongPress() {
        Runnable runnable = this.pendingLongPress;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
        this.pendingLongPress = null;
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x005e  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0061  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x00aa  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00b2  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x00b4  */
    /* JADX WARN: Removed duplicated region for block: B:89:0x00f9  */
    /* JADX WARN: Removed duplicated region for block: B:90:0x00fb  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void startGesture(com.rehman.ahmedreactionstudio.core.Layer r17, java.lang.String r18) {
        /*
            Method dump skipped, instruction units count: 362
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.editor.StageView.startGesture(com.rehman.ahmedreactionstudio.core.Layer, java.lang.String):void");
    }

    private final void touchMoved() {
        if (!this.undoPushed) {
            this.undoPushed = true;
            Host host = this.host;
            if (host != null) {
                host.onChanged();
            }
        }
        this.moved = true;
        Host host2 = this.host;
        if (host2 != null) {
            host2.onTransform();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x00cc  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void resizeTo(com.rehman.ahmedreactionstudio.core.Layer r20, float r21, float r22) {
        /*
            Method dump skipped, instruction units count: 311
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.editor.StageView.resizeTo(com.rehman.ahmedreactionstudio.core.Layer, float, float):void");
    }

    private final void rotateTo(Layer l, float x, float y) {
        float cx = l.getCx() * this.cw;
        float cy = l.getCy() * this.ch;
        float fAtan2 = (float) Math.atan2(this.downY - cy, this.downX - cx);
        float degrees = (((this.startRot + ((float) Math.toDegrees(((float) Math.atan2(y - cy, x - cx)) - fAtan2))) % 360.0f) + 360.0f) % 360.0f;
        for (float f : new float[]{0.0f, 90.0f, 180.0f, 270.0f}) {
            if (Math.abs(degrees - f) < 5.0f) {
                degrees = f;
            }
        }
        l.setRotDeg(degrees);
    }

    private final void pinchMove(Layer l, MotionEvent e) {
        float fLx = lx(e, 0);
        float fLy = ly(e, 0);
        double dLx = lx(e, 1) - fLx;
        double dLy = ly(e, 1) - fLy;
        float fCoerceAtLeast = RangesKt.coerceAtLeast((float) Math.hypot(dLx, dLy), 1.0f);
        float fAtan2 = (float) Math.atan2(dLy, dLx);
        float fCoerceIn = RangesKt.coerceIn(fCoerceAtLeast / this.startDist, 0.15f, 6.0f);
        float degrees = (float) Math.toDegrees(fAtan2 - this.startAngle);
        float f = (this.startCx * this.cw) - this.startMidX;
        float f2 = (this.startCy * this.ch) - this.startMidY;
        double radians = Math.toRadians(degrees);
        float fCos = (float) Math.cos(radians);
        float fSin = (float) Math.sin(radians);
        l.setCx((this.startMidX + (((f * fCos) - (f2 * fSin)) * fCoerceIn)) / this.cw);
        l.setCy((this.startMidY + (((f * fSin) + (f2 * fCos)) * fCoerceIn)) / this.ch);
        l.setWN(RangesKt.coerceIn(this.startWN * fCoerceIn, MIN_BOX_N, MAX_BOX_N));
        l.setHN(RangesKt.coerceIn(this.startHN * fCoerceIn, MIN_BOX_N, MAX_BOX_N));
        l.setRotDeg((((this.startRot + degrees) % 360.0f) + 360.0f) % 360.0f);
        LayerFit.INSTANCE.clampInside(l, 0.25f);
    }

    private final void snapMove(Layer l) {
        List<Layer> listEmptyList;
        Project project;
        List<Layer> listEmptyList2;
        Project project2;
        float wn = l.getWN() / 2.0f;
        float hn = l.getHN() / 2.0f;
        float wn2 = l.getWN();
        Float fValueOf = Float.valueOf(0.5f);
        if (wn2 < 0.9f) {
            ArrayList arrayList = new ArrayList(10);
            arrayList.add(fValueOf);
            arrayList.add(Float.valueOf(wn));
            arrayList.add(Float.valueOf(1.0f - wn));
            Host host = this.host;
            if (host == null || (project2 = host.getProject()) == null || (listEmptyList2 = project2.getLayers()) == null) {
                listEmptyList2 = CollectionsKt.emptyList();
            }
            for (Layer layer : listEmptyList2) {
                if (!Intrinsics.areEqual(layer.getId(), l.getId())) {
                    arrayList.add(Float.valueOf(layer.getCx() + (layer.getWN() / 2.0f) + wn));
                    arrayList.add(Float.valueOf((layer.getCx() - (layer.getWN() / 2.0f)) - wn));
                    arrayList.add(Float.valueOf(layer.getCx()));
                }
            }
            l.setCx(nearest(l.getCx(), arrayList));
        }
        if (l.getHN() < 0.9f) {
            ArrayList arrayList2 = new ArrayList(10);
            arrayList2.add(fValueOf);
            arrayList2.add(Float.valueOf(hn));
            arrayList2.add(Float.valueOf(1.0f - hn));
            Host host2 = this.host;
            if (host2 == null || (project = host2.getProject()) == null || (listEmptyList = project.getLayers()) == null) {
                listEmptyList = CollectionsKt.emptyList();
            }
            for (Layer layer2 : listEmptyList) {
                if (!Intrinsics.areEqual(layer2.getId(), l.getId())) {
                    arrayList2.add(Float.valueOf(layer2.getCy() + (layer2.getHN() / 2.0f) + hn));
                    arrayList2.add(Float.valueOf((layer2.getCy() - (layer2.getHN() / 2.0f)) - hn));
                    arrayList2.add(Float.valueOf(layer2.getCy()));
                }
            }
            l.setCy(nearest(l.getCy(), arrayList2));
        }
    }

    private final float nearest(float v, List<Float> targets) {
        Iterator<Float> it = targets.iterator();
        float f = 0.016f;
        float f2 = v;
        while (it.hasNext()) {
            float fFloatValue = it.next().floatValue();
            float fAbs = Math.abs(v - fFloatValue);
            if (fAbs < f) {
                f2 = fFloatValue;
                f = fAbs;
            }
        }
        return f2;
    }
}
