package com.rehman.ahmedreactionstudio.editor;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import com.rehman.ahmedreactionstudio.core.Layer;
import com.rehman.ahmedreactionstudio.core.LayerType;
import com.rehman.ahmedreactionstudio.core.MediaKit;
import com.rehman.ahmedreactionstudio.core.Project;
import com.rehman.ahmedreactionstudio.core.ProjectStore;
import com.rehman.ahmedreactionstudio.core.gpu.GpuVideoDecoder;
import com.rehman.ahmedreactionstudio.core.gpu.GpuVideoPipeline;
import com.rehman.ahmedreactionstudio.export.AudioConfig;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: PreviewEngine.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000¯\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\b\u0014\n\u0002\u0018\u0002\n\u0002\b$*\u0001P\u0018\u0000 \u0088\u00012\u00020\u0001:\u0004\u0087\u0001\u0088\u0001B7\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0012\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\f0\n¢\u0006\u0002\u0010\rJ\b\u0010S\u001a\u00020\fH\u0002J\u0006\u0010T\u001a\u00020\u001bJ\b\u0010U\u001a\u00020\fH\u0002J\u000e\u0010V\u001a\u00020\f2\u0006\u0010F\u001a\u00020\u0013J\u000e\u0010W\u001a\u00020\f2\u0006\u0010X\u001a\u00020\u0013J\u0006\u0010Y\u001a\u00020\u001bJ\u0018\u0010Z\u001a\u00020\u001b2\u0006\u0010X\u001a\u00020\u00132\u0006\u0010[\u001a\u00020(H\u0002J\u0006\u0010\\\u001a\u00020\fJ\u0010\u0010]\u001a\u00020\u001b2\u0006\u0010^\u001a\u000203H\u0002J\b\u0010_\u001a\u00020\fH\u0002J\u0010\u0010`\u001a\u00020\f2\u0006\u0010^\u001a\u000203H\u0002J\u0018\u0010a\u001a\u00020#2\u0006\u0010X\u001a\u00020\u00132\u0006\u0010b\u001a\u00020\u0013H\u0002J\u001a\u0010c\u001a\u0004\u0018\u00010d2\u0006\u0010X\u001a\u00020\u00132\u0006\u0010b\u001a\u00020\u0013H\u0002J\u000e\u0010e\u001a\u00020\f2\u0006\u0010X\u001a\u00020\u0013J\u0010\u0010f\u001a\u0004\u0018\u00010(2\u0006\u0010^\u001a\u000203J\u0006\u0010g\u001a\u00020\u000bJ\u0010\u0010h\u001a\u00020\u00172\u0006\u0010^\u001a\u000203H\u0002J\u000e\u0010i\u001a\u00020\u000b2\u0006\u0010^\u001a\u000203J\u0012\u0010j\u001a\u0004\u0018\u00010\u00132\u0006\u0010^\u001a\u000203H\u0002J\u0006\u0010k\u001a\u00020\fJ\b\u0010l\u001a\u00020\fH\u0002J\u0006\u0010m\u001a\u00020\fJ\u0010\u0010n\u001a\u0004\u0018\u00010C2\u0006\u0010X\u001a\u00020\u0013J\b\u0010o\u001a\u00020\u0006H\u0002J\u0018\u0010p\u001a\u00020\f2\u0006\u0010X\u001a\u00020\u00132\u0006\u0010[\u001a\u00020(H\u0002J\u0018\u0010q\u001a\u00020\f2\u0006\u0010X\u001a\u00020\u00132\u0006\u0010[\u001a\u00020(H\u0002J\u0006\u0010r\u001a\u00020\fJ\u0006\u0010s\u001a\u00020\fJ\u0006\u0010t\u001a\u00020\fJ\u0006\u0010u\u001a\u00020\fJ\u0010\u0010v\u001a\u00020\f2\u0006\u0010X\u001a\u00020\u0013H\u0002J\u0010\u0010w\u001a\u00020\f2\u0006\u0010x\u001a\u00020\u001bH\u0002J\u0010\u0010y\u001a\u00020\f2\u0006\u0010^\u001a\u000203H\u0002J\u000e\u0010z\u001a\u00020\f2\u0006\u0010{\u001a\u00020\u000bJ\u0018\u0010|\u001a\u00020\f2\u0006\u0010^\u001a\u0002032\b\u0010[\u001a\u0004\u0018\u00010(J\u0016\u0010}\u001a\u00020\f2\u0006\u0010^\u001a\u0002032\u0006\u0010~\u001a\u00020\u000fJ\u0006\u0010\u007f\u001a\u00020\fJ\t\u0010\u0080\u0001\u001a\u00020\fH\u0002J\u0007\u0010\u0081\u0001\u001a\u00020\u0013J\u0007\u0010\u0082\u0001\u001a\u00020\fJ\t\u0010\u0083\u0001\u001a\u00020\fH\u0002J\u0012\u0010\u0084\u0001\u001a\u00020\f2\u0007\u0010\u0085\u0001\u001a\u00020\u000bH\u0002J\u000f\u0010\u0086\u0001\u001a\u00020\u001b2\u0006\u0010^\u001a\u000203R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R*\u0010\u0011\u001a\u001e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u00140\u0012j\u000e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u0014`\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000RN\u0010\u0018\u001aB\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u00130\u0013\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u001b0\u001b \u001a* \u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u00130\u0013\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u001b0\u001b\u0018\u00010\u00190\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u001c\u001a\n \u001a*\u0004\u0018\u00010\u001d0\u001dX\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u001e\u001a\u0012\u0012\u0004\u0012\u00020\u00130\u001fj\b\u0012\u0004\u0012\u00020\u0013` X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010!\u001a\u000e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020#0\"X\u0082\u0004¢\u0006\u0002\n\u0000RN\u0010$\u001aB\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u00130\u0013\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u001b0\u001b \u001a* \u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u00130\u0013\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u001b0\u001b\u0018\u00010\u00190\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R*\u0010'\u001a\u001e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020(0\u0012j\u000e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020(`\u0015X\u0082\u0004¢\u0006\u0002\n\u0000RN\u0010)\u001aB\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u00130\u0013\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u001b0\u001b \u001a* \u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u00130\u0013\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u001b0\u001b\u0018\u00010\u00190\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010*\u001a\u000e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u000b0\"X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020,X\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010-\u001a\u0012\u0012\u0004\u0012\u00020\u00130\u001fj\b\u0012\u0004\u0012\u00020\u0013` X\u0082\u0004¢\u0006\u0002\n\u0000RN\u0010.\u001aB\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u00130\u0013\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u001b0\u001b \u001a* \u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u00130\u0013\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u001b0\u001b\u0018\u00010\u00190\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R*\u00100\u001a\u001e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u000b0\u0012j\u000e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u000b`\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u00101\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R(\u00102\u001a\u0010\u0012\u0004\u0012\u000203\u0012\u0004\u0012\u00020\u0017\u0018\u00010\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b4\u00105\"\u0004\b6\u00107R\u000e\u00108\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R$\u0010:\u001a\u00020\u001b2\u0006\u00109\u001a\u00020\u001b@FX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b;\u0010<\"\u0004\b=\u0010>R\u000e\u0010?\u001a\u00020@X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\f0\nX\u0082\u0004¢\u0006\u0002\n\u0000R*\u0010A\u001a\u001e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u00130\u0012j\u000e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u0013`\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R*\u0010B\u001a\u001e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020C0\u0012j\u000e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020C`\u0015X\u0082\u0004¢\u0006\u0002\n\u0000RN\u0010D\u001aB\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u00130\u0013\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u001b0\u001b \u001a* \u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u00130\u0013\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u001b0\u001b\u0018\u00010\u00190\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010E\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010F\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010G\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000RN\u0010H\u001aB\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u00130\u0013\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u001b0\u001b \u001a* \u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u00130\u0013\u0012\f\u0012\n \u001a*\u0004\u0018\u00010\u001b0\u001b\u0018\u00010\u00190\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010I\u001a\u000e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u00170\"X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010J\u001a\u00020\u0017X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bK\u0010L\"\u0004\bM\u0010NR\u0010\u0010O\u001a\u00020PX\u0082\u0004¢\u0006\u0004\n\u0002\u0010QR\u000e\u0010R\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/PreviewEngine;", "", "ctx", "Landroid/content/Context;", "projectRef", "Lkotlin/Function0;", "Lcom/rehman/ahmedreactionstudio/core/Project;", "store", "Lcom/rehman/ahmedreactionstudio/core/ProjectStore;", "onFrameReady", "Lkotlin/Function1;", "", "", "(Landroid/content/Context;Lkotlin/jvm/functions/Function0;Lcom/rehman/ahmedreactionstudio/core/ProjectStore;Lkotlin/jvm/functions/Function1;)V", "adaptiveScale", "", "avgDecodeMs", "clocks", "Ljava/util/HashMap;", "", "Lcom/rehman/ahmedreactionstudio/editor/PreviewEngine$Clock;", "Lkotlin/collections/HashMap;", "costCount", "", "decoding", "Ljava/util/concurrent/ConcurrentHashMap$KeySetView;", "kotlin.jvm.PlatformType", "", "exec", "Ljava/util/concurrent/ExecutorService;", "externalIds", "Ljava/util/HashSet;", "Lkotlin/collections/HashSet;", "fallback", "Ljava/util/concurrent/ConcurrentHashMap;", "Lcom/rehman/ahmedreactionstudio/core/MediaKit$FrameSource;", "forceSeek", "fpsCount", "fpsSince", "frames", "Landroid/graphics/Bitmap;", "gpuIds", "gpuRetryAt", "handler", "Landroid/os/Handler;", "imageIds", "imageLoading", "lastAdapt", "lastSeekAt", "lastTick", "layerTargetPx", "Lcom/rehman/ahmedreactionstudio/core/Layer;", "getLayerTargetPx", "()Lkotlin/jvm/functions/Function1;", "setLayerTargetPx", "(Lkotlin/jvm/functions/Function1;)V", "masterMs", "value", "monitorMuted", "getMonitorMuted", "()Z", "setMonitorMuted", "(Z)V", "newFrames", "Ljava/util/concurrent/atomic/AtomicBoolean;", "paths", "players", "Landroid/media/MediaPlayer;", "preparing", "previewFps", "projectId", "snapshotLoop", "softNow", "softStreak", "targetMaxPx", "getTargetMaxPx", "()I", "setTargetMaxPx", "(I)V", "tick", "com/rehman/ahmedreactionstudio/editor/PreviewEngine$tick$1", "Lcom/rehman/ahmedreactionstudio/editor/PreviewEngine$tick$1;", "ticking", "adaptQuality", "anyPlaying", "applyMonitorVolume", "attach", "clearExternal", "id", "consumeNewFrames", "decoderOwns", "bmp", "detach", "effectiveMuted", "l", "endOfMediaCheck", "ensureAudioPlayer", "ensureFallback", "path", "ensureGpu", "Lcom/rehman/ahmedreactionstudio/core/gpu/GpuVideoDecoder;", "evict", "frameOf", "master", "maxPxFor", "mediaTimeOf", "pathOf", "pauseAll", "pausePlayers", "playAll", "playerOf", "project", "publishGpu", "publishSoftware", "recycleFrames", "refreshFrames", "release", "releaseAllPlayers", "releaseSource", "requestFrames", "closest", "requestImage", "seekTo", "ms", "setFrame", "setVolume", "v", "startSnapshots", "startTicker", "stats", "stopSnapshots", "stopTicker", "syncPlayers", "now", "toggleLayerPlay", "Clock", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nPreviewEngine.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PreviewEngine.kt\ncom/rehman/ahmedreactionstudio/editor/PreviewEngine\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,788:1\n1#2:789\n1747#3,3:790\n*S KotlinDebug\n*F\n+ 1 PreviewEngine.kt\ncom/rehman/ahmedreactionstudio/editor/PreviewEngine\n*L\n198#1:790,3\n*E\n"})
public final class PreviewEngine {
    private static final int MIN_DECODE_PX = 240;
    private static final float START_SCALE = 0.8f;
    private static final long TICK_MS = 16;
    private volatile float adaptiveScale;
    private float avgDecodeMs;

    @NotNull
    private final HashMap<String, Clock> clocks;
    private int costCount;

    @NotNull
    private final Context ctx;
    private final ConcurrentHashMap.KeySetView<String, Boolean> decoding;
    private final ExecutorService exec;

    @NotNull
    private final HashSet<String> externalIds;

    @NotNull
    private final ConcurrentHashMap<String, MediaKit.FrameSource> fallback;
    private final ConcurrentHashMap.KeySetView<String, Boolean> forceSeek;
    private int fpsCount;
    private long fpsSince;

    @NotNull
    private final HashMap<String, Bitmap> frames;
    private final ConcurrentHashMap.KeySetView<String, Boolean> gpuIds;

    @NotNull
    private final ConcurrentHashMap<String, Long> gpuRetryAt;

    @NotNull
    private final Handler handler;

    @NotNull
    private final HashSet<String> imageIds;
    private final ConcurrentHashMap.KeySetView<String, Boolean> imageLoading;
    private long lastAdapt;

    @NotNull
    private final HashMap<String, Long> lastSeekAt;
    private long lastTick;

    @Nullable
    private Function1<? super Layer, Integer> layerTargetPx;
    private long masterMs;
    private volatile boolean monitorMuted;

    @NotNull
    private final AtomicBoolean newFrames;

    @NotNull
    private final Function1<Long, Unit> onFrameReady;

    @NotNull
    private final HashMap<String, String> paths;

    @NotNull
    private final HashMap<String, MediaPlayer> players;
    private final ConcurrentHashMap.KeySetView<String, Boolean> preparing;
    private volatile float previewFps;

    @NotNull
    private String projectId;

    @NotNull
    private final Function0<Project> projectRef;
    private boolean snapshotLoop;
    private final ConcurrentHashMap.KeySetView<String, Boolean> softNow;

    @NotNull
    private final ConcurrentHashMap<String, Integer> softStreak;

    @NotNull
    private final ProjectStore store;
    private volatile int targetMaxPx;

    @NotNull
    private final PreviewEngine$tick$1 tick;
    private boolean ticking;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v24, types: [com.rehman.ahmedreactionstudio.editor.PreviewEngine$tick$1] */
    public PreviewEngine(@NotNull Context ctx, @NotNull Function0<Project> projectRef, @NotNull ProjectStore store, @NotNull Function1<? super Long, Unit> onFrameReady) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(projectRef, "projectRef");
        Intrinsics.checkNotNullParameter(store, "store");
        Intrinsics.checkNotNullParameter(onFrameReady, "onFrameReady");
        this.ctx = ctx;
        this.projectRef = projectRef;
        this.store = store;
        this.onFrameReady = onFrameReady;
        this.clocks = new HashMap<>();
        this.players = new HashMap<>();
        this.frames = new HashMap<>();
        this.gpuIds = ConcurrentHashMap.newKeySet();
        this.fallback = new ConcurrentHashMap<>();
        this.decoding = ConcurrentHashMap.newKeySet();
        this.preparing = ConcurrentHashMap.newKeySet();
        this.paths = new HashMap<>();
        this.lastSeekAt = new HashMap<>();
        this.softStreak = new ConcurrentHashMap<>();
        this.gpuRetryAt = new ConcurrentHashMap<>();
        this.forceSeek = ConcurrentHashMap.newKeySet();
        this.externalIds = new HashSet<>();
        this.imageLoading = ConcurrentHashMap.newKeySet();
        this.imageIds = new HashSet<>();
        this.exec = Executors.newFixedThreadPool(2);
        this.handler = new Handler(Looper.getMainLooper());
        this.projectId = "";
        this.targetMaxPx = 720;
        this.adaptiveScale = START_SCALE;
        this.newFrames = new AtomicBoolean(false);
        this.softNow = ConcurrentHashMap.newKeySet();
        this.tick = new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.PreviewEngine$tick$1
            @Override // java.lang.Runnable
            public void run() {
                if (this.this$0.ticking) {
                    long jElapsedRealtime = SystemClock.elapsedRealtime();
                    long jMin = Math.min(jElapsedRealtime - this.this$0.lastTick, 120L);
                    this.this$0.lastTick = jElapsedRealtime;
                    if (jElapsedRealtime - this.this$0.fpsSince >= 500) {
                        this.this$0.previewFps = (r4.fpsCount * 1000.0f) / RangesKt.coerceAtLeast(jElapsedRealtime - this.this$0.fpsSince, 1L);
                        this.this$0.fpsCount = 0;
                        this.this$0.fpsSince = jElapsedRealtime;
                    }
                    if (this.this$0.anyPlaying()) {
                        this.this$0.masterMs += jMin;
                        long jDurationMs = this.this$0.project().durationMs();
                        if (jDurationMs > 0 && this.this$0.masterMs >= jDurationMs) {
                            this.this$0.masterMs %= jDurationMs;
                        }
                        this.this$0.endOfMediaCheck();
                        this.this$0.syncPlayers(jElapsedRealtime);
                        if (this.this$0.snapshotLoop || this.this$0.anyPlaying()) {
                            this.this$0.requestFrames(false);
                        }
                        if (jElapsedRealtime - this.this$0.lastAdapt > 1000) {
                            this.this$0.lastAdapt = jElapsedRealtime;
                            this.this$0.adaptQuality();
                        }
                    }
                    this.this$0.onFrameReady.invoke(Long.valueOf(this.this$0.masterMs));
                    this.this$0.handler.postDelayed(this, 16L);
                }
            }
        };
    }

    /* JADX INFO: compiled from: PreviewEngine.kt */
    @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0016\u0010\u0012\u001a\u00020\u00042\u0006\u0010\u0013\u001a\u00020\u00042\u0006\u0010\u0014\u001a\u00020\u0015J\u000e\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0013\u001a\u00020\u0004J\u000e\u0010\u0018\u001a\u00020\u00172\u0006\u0010\u0013\u001a\u00020\u0004J\u0016\u0010\u0019\u001a\u00020\u00172\u0006\u0010\u0013\u001a\u00020\u00042\u0006\u0010\u0014\u001a\u00020\u0015R\u001a\u0010\u0003\u001a\u00020\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001a\u0010\t\u001a\u00020\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u0006\"\u0004\b\u000b\u0010\bR\u001a\u0010\f\u001a\u00020\rX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/PreviewEngine$Clock;", "", "()V", "freeze", "", "getFreeze", "()J", "setFreeze", "(J)V", "resumeAt", "getResumeAt", "setResumeAt", "wasPlaying", "", "getWasPlaying", "()Z", "setWasPlaying", "(Z)V", "media", "master", "speed", "", "pause", "", "resume", "seek"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Clock {
        private long freeze;
        private long resumeAt;
        private boolean wasPlaying;

        public final long getFreeze() {
            return this.freeze;
        }

        public final void setFreeze(long j) {
            this.freeze = j;
        }

        public final long getResumeAt() {
            return this.resumeAt;
        }

        public final void setResumeAt(long j) {
            this.resumeAt = j;
        }

        public final boolean getWasPlaying() {
            return this.wasPlaying;
        }

        public final void setWasPlaying(boolean z) {
            this.wasPlaying = z;
        }

        public final long media(long master, float speed) {
            return RangesKt.coerceAtLeast(this.wasPlaying ? this.freeze + ((long) (RangesKt.coerceAtLeast(master - this.resumeAt, 0L) * speed)) : this.freeze, 0L);
        }

        public final void resume(long master) {
            this.resumeAt = master;
            this.wasPlaying = true;
        }

        public final void pause(long master) {
            this.freeze = media(master, 1.0f);
            this.wasPlaying = false;
        }

        public final void seek(long master, float speed) {
            this.freeze = (long) (master * speed);
            this.resumeAt = master;
        }
    }

    public final int getTargetMaxPx() {
        return this.targetMaxPx;
    }

    public final void setTargetMaxPx(int i) {
        this.targetMaxPx = i;
    }

    @Nullable
    public final Function1<Layer, Integer> getLayerTargetPx() {
        return this.layerTargetPx;
    }

    public final void setLayerTargetPx(@Nullable Function1<? super Layer, Integer> function1) {
        this.layerTargetPx = function1;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void endOfMediaCheck() {
        Clock clock;
        for (Layer layer : project().getLayers()) {
            if (layer.isClip() && layer.getPlaying() && !layer.getLoop() && layer.getDurMs() > 0 && (clock = this.clocks.get(layer.getId())) != null && clock.media(this.masterMs, layer.getSpeed()) >= layer.getDurMs()) {
                layer.setPlaying(false);
                layer.setPausedMediaMs(layer.getDurMs());
                Clock clock2 = this.clocks.get(layer.getId());
                if (clock2 != null) {
                    clock2.setWasPlaying(false);
                    clock2.setFreeze(layer.getDurMs());
                }
                MediaPlayer mediaPlayerPlayerOf = playerOf(layer.getId());
                if (mediaPlayerPlayerOf != null) {
                    try {
                        mediaPlayerPlayerOf.pause();
                    } catch (Exception unused) {
                    }
                }
            }
        }
    }

    private final boolean effectiveMuted(Layer l) {
        boolean z;
        if (l.getMuted()) {
            return true;
        }
        List<Layer> layers = project().getLayers();
        if ((layers instanceof Collection) && layers.isEmpty()) {
            z = false;
        } else {
            Iterator<T> it = layers.iterator();
            while (it.hasNext()) {
                if (((Layer) it.next()).getSolo()) {
                    z = true;
                    break;
                }
            }
            z = false;
        }
        return z && !l.getSolo();
    }

    public final boolean getMonitorMuted() {
        return this.monitorMuted;
    }

    public final void setMonitorMuted(boolean z) {
        if (this.monitorMuted == z) {
            return;
        }
        this.monitorMuted = z;
        this.handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$PreviewEngine$c3zcJjWkgu7MeuScvHm9cR_cs_4
            @Override // java.lang.Runnable
            public final void run() {
                PreviewEngine._set_monitorMuted_$lambda$3(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _set_monitorMuted_$lambda$3(PreviewEngine this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.applyMonitorVolume();
    }

    private final void applyMonitorVolume() {
        Project project = project();
        for (Map.Entry<String, MediaPlayer> entry : this.players.entrySet()) {
            String key = entry.getKey();
            MediaPlayer value = entry.getValue();
            Layer layerLayerById = project.layerById(key);
            if (layerLayerById != null) {
                float volume = this.monitorMuted ? 0.0f : layerLayerById.getVolume();
                try {
                    value.setVolume(volume, volume);
                } catch (Exception unused) {
                }
            }
        }
    }

    public final void attach(@NotNull String projectId) {
        Intrinsics.checkNotNullParameter(projectId, "projectId");
        boolean z = this.ticking;
        boolean z2 = this.snapshotLoop;
        detach();
        this.projectId = projectId;
        Project project = project();
        this.clocks.clear();
        this.paths.clear();
        HashSet hashSet = new HashSet();
        for (Layer layer : project.getLayers()) {
            hashSet.add(layer.getId());
            if (layer.isClip()) {
                Clock clock = new Clock();
                clock.setFreeze(layer.getPausedMediaMs());
                clock.setWasPlaying(layer.getPlaying());
                clock.setResumeAt(0L);
                this.clocks.put(layer.getId(), clock);
                String strPathOf = pathOf(layer);
                if (strPathOf != null) {
                    this.paths.put(layer.getId(), strPathOf);
                }
            }
        }
        for (String str : new ArrayList(this.gpuIds)) {
            if (!hashSet.contains(str)) {
                Intrinsics.checkNotNull(str);
                releaseSource(str);
            }
        }
        for (String str2 : new ArrayList(this.fallback.keySet())) {
            if (!hashSet.contains(str2)) {
                Intrinsics.checkNotNull(str2);
                releaseSource(str2);
            }
        }
        if (z || z2 || anyPlaying()) {
            if (z2) {
                this.snapshotLoop = true;
            }
            startTicker();
        }
    }

    public final void detach() {
        stopTicker();
        stopSnapshots();
        releaseAllPlayers();
        recycleFrames();
        for (String str : new ArrayList(this.gpuIds)) {
            Intrinsics.checkNotNull(str);
            releaseSource(str);
        }
        for (String str2 : new ArrayList(this.fallback.keySet())) {
            Intrinsics.checkNotNull(str2);
            releaseSource(str2);
        }
        this.clocks.clear();
        this.paths.clear();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Project project() {
        return this.projectRef.invoke();
    }

    /* JADX INFO: renamed from: master, reason: from getter */
    public final long getMasterMs() {
        return this.masterMs;
    }

    public final boolean consumeNewFrames() {
        return this.newFrames.getAndSet(false);
    }

    @NotNull
    public final String stats() {
        String str;
        if (this.softNow.isEmpty()) {
            str = "HW";
        } else {
            str = "SW×" + this.softNow.size();
        }
        return str + " · " + ((int) this.previewFps) + " fps · " + ((int) this.avgDecodeMs) + " ms/f";
    }

    public final void seekTo(long ms) {
        this.masterMs = RangesKt.coerceAtLeast(ms, 0L);
        Project project = project();
        project.setLastPlayheadMs(this.masterMs);
        for (Layer layer : project.getLayers()) {
            if (layer.isClip()) {
                Clock clock = this.clocks.get(layer.getId());
                if (clock != null) {
                    clock.seek(this.masterMs, layer.getSpeed());
                }
                this.forceSeek.add(layer.getId());
            }
        }
        syncPlayers(SystemClock.elapsedRealtime());
        refreshFrames();
    }

    public final void playAll() {
        Clock clock;
        this.adaptiveScale = START_SCALE;
        for (Layer layer : project().getLayers()) {
            if (layer.isClip() && (clock = this.clocks.get(layer.getId())) != null) {
                if (!layer.getLoop() && layer.getDurMs() > 0 && clock.getFreeze() >= layer.getDurMs() - ((long) 80)) {
                    clock.setFreeze(0L);
                    layer.setPausedMediaMs(0L);
                    this.forceSeek.add(layer.getId());
                }
                layer.setPlaying(true);
                clock.resume(this.masterMs);
            }
        }
        startTicker();
        refreshFrames();
    }

    public final void pauseAll() {
        for (Layer layer : project().getLayers()) {
            if (layer.isClip()) {
                layer.setPlaying(false);
                Clock clock = this.clocks.get(layer.getId());
                if (clock != null) {
                    clock.pause(this.masterMs);
                }
            }
        }
        pausePlayers();
    }

    public final boolean toggleLayerPlay(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        if (!l.isClip()) {
            return l.getPlaying();
        }
        if (l.getPlaying()) {
            l.setPlaying(false);
            Clock clock = this.clocks.get(l.getId());
            if (clock != null) {
                clock.pause(this.masterMs);
            }
            Clock clock2 = this.clocks.get(l.getId());
            l.setPausedMediaMs(clock2 != null ? clock2.getFreeze() : 0L);
            MediaPlayer mediaPlayerPlayerOf = playerOf(l.getId());
            if (mediaPlayerPlayerOf != null) {
                try {
                    mediaPlayerPlayerOf.pause();
                } catch (Exception unused) {
                }
            }
        } else {
            Clock clock3 = this.clocks.get(l.getId());
            if (clock3 != null && !l.getLoop() && l.getDurMs() > 0 && clock3.getFreeze() >= l.getDurMs() - ((long) 80)) {
                clock3.setFreeze(0L);
                this.forceSeek.add(l.getId());
            }
            l.setPlaying(true);
            l.setPausedMediaMs(0L);
            if (clock3 != null) {
                clock3.resume(this.masterMs);
            }
            startTicker();
        }
        refreshFrames();
        return l.getPlaying();
    }

    public final boolean anyPlaying() {
        for (Layer layer : project().getLayers()) {
            if (layer.isClip() && layer.getPlaying()) {
                return true;
            }
        }
        return false;
    }

    private final void startTicker() {
        if (this.ticking) {
            return;
        }
        this.ticking = true;
        this.lastTick = SystemClock.elapsedRealtime();
        this.handler.post(this.tick);
    }

    private final void stopTicker() {
        this.ticking = false;
        this.handler.removeCallbacks(this.tick);
    }

    private final String pathOf(Layer l) {
        String relPath = l.getRelPath();
        if (relPath == null || StringsKt.isBlank(relPath)) {
            return null;
        }
        File file = new File(this.store.projectDir(this.projectId), relPath);
        if (file.exists()) {
            return file.getAbsolutePath();
        }
        return null;
    }

    private final GpuVideoDecoder ensureGpu(String id, String path) {
        try {
            GpuVideoDecoder orCreate = GpuVideoPipeline.INSTANCE.getOrCreate(id, path);
            this.gpuIds.add(id);
            MediaKit.FrameSource frameSourceRemove = this.fallback.remove(id);
            if (frameSourceRemove == null) {
                return orCreate;
            }
            frameSourceRemove.release();
            return orCreate;
        } catch (Exception unused) {
            return null;
        }
    }

    private final MediaKit.FrameSource ensureFallback(String id, String path) {
        MediaKit.FrameSource frameSource = this.fallback.get(id);
        if (frameSource != null && Intrinsics.areEqual(frameSource.getPath(), path)) {
            return frameSource;
        }
        if (frameSource != null) {
            frameSource.release();
        }
        MediaKit.FrameSource frameSource2 = new MediaKit.FrameSource(path);
        this.fallback.put(id, frameSource2);
        return frameSource2;
    }

    private final void releaseSource(String id) {
        this.gpuIds.remove(id);
        this.forceSeek.remove(id);
        this.decoding.remove(id);
        this.softStreak.remove(id);
        this.gpuRetryAt.remove(id);
        this.softNow.remove(id);
        try {
            GpuVideoPipeline.INSTANCE.releaseDecoder(id);
        } catch (Exception unused) {
        }
        MediaKit.FrameSource frameSourceRemove = this.fallback.remove(id);
        if (frameSourceRemove != null) {
            try {
                frameSourceRemove.release();
            } catch (Exception unused2) {
            }
        }
    }

    private final void ensureAudioPlayer(Layer l) {
        if (effectiveMuted(l) || !l.isClip() || this.players.containsKey(l.getId()) || this.preparing.contains(l.getId())) {
            return;
        }
        String strPathOf = this.paths.get(l.getId());
        if (strPathOf == null && (strPathOf = pathOf(l)) == null) {
            return;
        }
        final String str = strPathOf;
        this.preparing.add(l.getId());
        final String id = l.getId();
        final float volume = l.getVolume();
        final boolean loop = l.getLoop();
        this.exec.execute(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$PreviewEngine$7wTlMa8IUrddHqFUzAp5vSecuwU
            @Override // java.lang.Runnable
            public final void run() {
                PreviewEngine.ensureAudioPlayer$lambda$8(str, loop, this, volume, id);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void ensureAudioPlayer$lambda$8(String path, boolean z, final PreviewEngine this$0, float f, final String id) {
        MediaPlayer mediaPlayer;
        Intrinsics.checkNotNullParameter(path, "$path");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(id, "$id");
        final MediaPlayer mediaPlayer2 = null;
        try {
            mediaPlayer = new MediaPlayer();
            try {
                mediaPlayer.setDataSource(path);
                mediaPlayer.setLooping(z);
                if (this$0.monitorMuted) {
                    f = 0.0f;
                }
                mediaPlayer.setVolume(f, f);
                mediaPlayer.prepare();
                mediaPlayer2 = mediaPlayer;
            } catch (Exception unused) {
                if (mediaPlayer != null) {
                    try {
                        mediaPlayer.release();
                    } catch (Exception unused2) {
                    }
                }
            }
        } catch (Exception unused3) {
            mediaPlayer = null;
        }
        this$0.handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$PreviewEngine$5MjtnfRJgjBMIKp_nBtEPLs6ryU
            @Override // java.lang.Runnable
            public final void run() {
                PreviewEngine.ensureAudioPlayer$lambda$8$lambda$7(this.f$0, id, mediaPlayer2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void ensureAudioPlayer$lambda$8$lambda$7(PreviewEngine this$0, String id, MediaPlayer mediaPlayer) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(id, "$id");
        this$0.preparing.remove(id);
        if (mediaPlayer == null) {
            return;
        }
        MediaPlayer mediaPlayerPut = this$0.players.put(id, mediaPlayer);
        if (mediaPlayerPut != null) {
            try {
                mediaPlayerPut.release();
            } catch (Exception unused) {
            }
        }
        Layer layerLayerById = this$0.project().layerById(id);
        try {
            if (layerLayerById == null || !layerLayerById.getPlaying() || this$0.effectiveMuted(layerLayerById)) {
                mediaPlayer.pause();
            } else {
                mediaPlayer.seekTo((int) this$0.mediaTimeOf(layerLayerById));
                mediaPlayer.start();
            }
        } catch (Exception unused2) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void syncPlayers(long now) {
        for (Layer layer : project().getLayers()) {
            if (layer.isClip()) {
                boolean z = layer.getPlaying() && !effectiveMuted(layer);
                MediaPlayer mediaPlayer = this.players.get(layer.getId());
                if (z) {
                    if (mediaPlayer == null) {
                        ensureAudioPlayer(layer);
                    } else {
                        try {
                            mediaPlayer.setLooping(layer.getLoop());
                        } catch (Exception unused) {
                        }
                        try {
                            if (!mediaPlayer.isPlaying()) {
                                long jMediaTimeOf = mediaTimeOf(layer);
                                if (layer.getLoop() || layer.getDurMs() <= 0 || jMediaTimeOf < layer.getDurMs() - ((long) 80)) {
                                    mediaPlayer.seekTo((int) jMediaTimeOf);
                                    mediaPlayer.start();
                                }
                            } else {
                                Long l = this.lastSeekAt.get(layer.getId());
                                if (l == null) {
                                    l = 0L;
                                }
                                if (now - l.longValue() > 1200) {
                                    long jMediaTimeOf2 = mediaTimeOf(layer);
                                    if (Math.abs(((long) mediaPlayer.getCurrentPosition()) - jMediaTimeOf2) > 400) {
                                        mediaPlayer.seekTo((int) jMediaTimeOf2);
                                        this.lastSeekAt.put(layer.getId(), Long.valueOf(now));
                                    }
                                }
                            }
                        } catch (Exception unused2) {
                        }
                    }
                } else if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();
                }
            }
        }
    }

    private final void pausePlayers() {
        Iterator<Map.Entry<String, MediaPlayer>> it = this.players.entrySet().iterator();
        while (it.hasNext()) {
            MediaPlayer value = it.next().getValue();
            try {
                if (value.isPlaying()) {
                    value.pause();
                }
            } catch (Exception unused) {
            }
        }
    }

    public final void releaseAllPlayers() {
        Iterator<Map.Entry<String, MediaPlayer>> it = this.players.entrySet().iterator();
        while (it.hasNext()) {
            try {
                it.next().getValue().release();
            } catch (Exception unused) {
            }
        }
        this.players.clear();
        this.preparing.clear();
        this.lastSeekAt.clear();
    }

    @Nullable
    public final MediaPlayer playerOf(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return this.players.get(id);
    }

    public final long mediaTimeOf(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        Clock clock = this.clocks.get(l.getId());
        long jMedia = clock != null ? clock.media(this.masterMs, l.getSpeed()) : 0L;
        return (!l.getLoop() || l.getDurMs() <= 0) ? jMedia : jMedia % l.getDurMs();
    }

    public final void setVolume(@NotNull Layer l, float v) {
        Intrinsics.checkNotNullParameter(l, "l");
        l.setVolume(v);
        if (this.monitorMuted) {
            v = 0.0f;
        }
        try {
            MediaPlayer mediaPlayer = this.players.get(l.getId());
            if (mediaPlayer != null) {
                mediaPlayer.setVolume(v, v);
            }
        } catch (Exception unused) {
        }
    }

    public final void refreshFrames() {
        boolean z = false;
        for (Layer layer : project().getLayers()) {
            if (layer.isClip() && layer.getVisible()) {
                String relPath = layer.getRelPath();
                if (!(relPath == null || StringsKt.isBlank(relPath))) {
                    HashMap<String, String> map = this.paths;
                    String id = layer.getId();
                    String strPathOf = pathOf(layer);
                    if (strPathOf != null) {
                        map.put(id, strPathOf);
                        this.forceSeek.add(layer.getId());
                    }
                    z = true;
                }
            }
        }
        if (!z) {
            this.onFrameReady.invoke(Long.valueOf(this.masterMs));
        } else {
            requestFrames(true);
        }
    }

    public final void startSnapshots() {
        this.snapshotLoop = true;
        startTicker();
    }

    public final void stopSnapshots() {
        this.snapshotLoop = false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00a5  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x00b6 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:58:0x00a8 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void requestFrames(boolean r14) {
        /*
            r13 = this;
            com.rehman.ahmedreactionstudio.core.Project r0 = r13.project()
            java.util.List r0 = r0.getLayers()
            java.util.Iterator r0 = r0.iterator()
        Lc:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto Lc4
            java.lang.Object r1 = r0.next()
            com.rehman.ahmedreactionstudio.core.Layer r1 = (com.rehman.ahmedreactionstudio.core.Layer) r1
            boolean r2 = r1.isClip()
            if (r2 == 0) goto Lc
            boolean r2 = r1.getVisible()
            if (r2 == 0) goto Lc
            java.lang.String r2 = r1.getRelPath()
            java.lang.CharSequence r2 = (java.lang.CharSequence) r2
            r3 = 0
            r4 = 1
            if (r2 == 0) goto L37
            boolean r2 = kotlin.text.StringsKt.isBlank(r2)
            if (r2 == 0) goto L35
            goto L37
        L35:
            r2 = r3
            goto L38
        L37:
            r2 = r4
        L38:
            if (r2 == 0) goto L3b
            goto Lc
        L3b:
            if (r14 != 0) goto L43
            boolean r2 = r1.getPlaying()
            if (r2 == 0) goto Lc
        L43:
            java.lang.String r7 = r1.getId()
            java.util.HashMap<java.lang.String, java.lang.String> r2 = r13.paths
            java.lang.Object r2 = r2.get(r7)
            java.lang.String r2 = (java.lang.String) r2
            if (r2 != 0) goto L58
            java.lang.String r2 = r13.pathOf(r1)
            if (r2 != 0) goto L58
            goto Lc
        L58:
            r8 = r2
            long r9 = r13.mediaTimeOf(r1)
            java.util.concurrent.ConcurrentHashMap$KeySetView<java.lang.String, java.lang.Boolean> r2 = r13.decoding
            boolean r2 = r2.add(r7)
            if (r2 == 0) goto Lc
            java.util.concurrent.ConcurrentHashMap$KeySetView<java.lang.String, java.lang.Boolean> r2 = r13.forceSeek
            boolean r2 = r2.remove(r7)
            if (r2 != 0) goto L72
            if (r14 == 0) goto L70
            goto L72
        L70:
            r12 = r3
            goto L73
        L72:
            r12 = r4
        L73:
            int r11 = r13.maxPxFor(r1)
            java.util.concurrent.ConcurrentHashMap$KeySetView<java.lang.String, java.lang.Boolean> r1 = r13.gpuIds
            boolean r1 = r1.contains(r7)
            if (r1 != 0) goto La5
            java.util.concurrent.ConcurrentHashMap<java.lang.String, com.rehman.ahmedreactionstudio.core.MediaKit$FrameSource> r1 = r13.fallback
            boolean r1 = r1.containsKey(r7)
            if (r1 == 0) goto La5
            long r1 = android.os.SystemClock.elapsedRealtime()
            java.util.concurrent.ConcurrentHashMap<java.lang.String, java.lang.Long> r5 = r13.gpuRetryAt
            java.lang.Object r5 = r5.get(r7)
            java.lang.Long r5 = (java.lang.Long) r5
            if (r5 != 0) goto L9b
            r5 = 0
            java.lang.Long r5 = java.lang.Long.valueOf(r5)
        L9b:
            java.lang.Number r5 = (java.lang.Number) r5
            long r5 = r5.longValue()
            int r1 = (r1 > r5 ? 1 : (r1 == r5 ? 0 : -1))
            if (r1 < 0) goto La6
        La5:
            r3 = r4
        La6:
            if (r3 == 0) goto Lb6
            com.rehman.ahmedreactionstudio.core.gpu.GpuVideoPipeline r1 = com.rehman.ahmedreactionstudio.core.gpu.GpuVideoPipeline.INSTANCE
            com.rehman.ahmedreactionstudio.editor.-$$Lambda$PreviewEngine$kAV9Z4EJFJxYIsxFwlk_mnn4KX0 r2 = new com.rehman.ahmedreactionstudio.editor.-$$Lambda$PreviewEngine$kAV9Z4EJFJxYIsxFwlk_mnn4KX0
            r5 = r2
            r6 = r13
            r5.<init>()
            r1.post(r2)
            goto Lc
        Lb6:
            java.util.concurrent.ExecutorService r1 = r13.exec
            com.rehman.ahmedreactionstudio.editor.-$$Lambda$PreviewEngine$KRe2OvYnppEaaqJG-LwGh7mfWm0 r2 = new com.rehman.ahmedreactionstudio.editor.-$$Lambda$PreviewEngine$KRe2OvYnppEaaqJG-LwGh7mfWm0
            r5 = r2
            r6 = r13
            r5.<init>()
            r1.execute(r2)
            goto Lc
        Lc4:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.editor.PreviewEngine.requestFrames(boolean):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void requestFrames$lambda$10(final PreviewEngine this$0, final String id, String path, long j, int i, boolean z) {
        boolean zAdvanceTo;
        final Bitmap bitmap;
        final long lastDecodeMs;
        final boolean z2;
        GpuVideoDecoder gpuVideoDecoderEnsureGpu;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(id, "$id");
        Intrinsics.checkNotNullParameter(path, "$path");
        long lastDecodeMs2 = 0;
        Bitmap bitmapFrameAt = null;
        try {
            gpuVideoDecoderEnsureGpu = this$0.ensureGpu(id, path);
        } catch (Exception unused) {
        }
        if (gpuVideoDecoderEnsureGpu != null) {
            zAdvanceTo = gpuVideoDecoderEnsureGpu.advanceTo(j, i, z, true);
            lastDecodeMs2 = gpuVideoDecoderEnsureGpu.getLastDecodeMs();
            bitmapFrameAt = gpuVideoDecoderEnsureGpu.getPublished();
        } else {
            zAdvanceTo = false;
        }
        if (!zAdvanceTo || bitmapFrameAt == null) {
            try {
                MediaKit.FrameSource frameSourceEnsureFallback = this$0.ensureFallback(id, path);
                bitmapFrameAt = frameSourceEnsureFallback.frameAt(j, i, z);
                bitmap = bitmapFrameAt;
                lastDecodeMs = frameSourceEnsureFallback.getLastDecodeMs();
                z2 = true;
            } catch (Exception unused2) {
                long j2 = lastDecodeMs2;
                z2 = false;
                bitmap = bitmapFrameAt;
                lastDecodeMs = j2;
            }
        } else {
            long j22 = lastDecodeMs2;
            z2 = false;
            bitmap = bitmapFrameAt;
            lastDecodeMs = j22;
        }
        if (z2) {
            Integer num = this$0.softStreak.get(id);
            if (num == null) {
                num = 0;
            }
            int iIntValue = num.intValue() + 1;
            this$0.softStreak.put(id, Integer.valueOf(iIntValue));
            this$0.gpuRetryAt.put(id, Long.valueOf(SystemClock.elapsedRealtime() + (((long) RangesKt.coerceAtMost(iIntValue, 6)) * 1000)));
        } else {
            this$0.softStreak.remove(id);
            this$0.gpuRetryAt.remove(id);
        }
        this$0.handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$PreviewEngine$c5mcXv3du_yFbU5ngx4fTIHoCAw
            @Override // java.lang.Runnable
            public final void run() {
                PreviewEngine.requestFrames$lambda$10$lambda$9(lastDecodeMs, this$0, bitmap, z2, id);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void requestFrames$lambda$10$lambda$9(long j, PreviewEngine this$0, Bitmap bitmap, boolean z, String id) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(id, "$id");
        if (j > 0) {
            this$0.costCount++;
            float f = this$0.avgDecodeMs;
            if (f <= 0.0f) {
                this$0.avgDecodeMs = j;
            } else {
                this$0.avgDecodeMs = (f * 0.7f) + (j * 0.3f);
            }
        }
        if (bitmap != null) {
            if (z) {
                this$0.publishSoftware(id, bitmap);
            } else {
                this$0.publishGpu(id, bitmap);
            }
        }
        this$0.decoding.remove(id);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void requestFrames$lambda$12(final PreviewEngine this$0, final String id, String path, long j, int i, boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(id, "$id");
        Intrinsics.checkNotNullParameter(path, "$path");
        try {
            MediaKit.FrameSource frameSourceEnsureFallback = this$0.ensureFallback(id, path);
            final Bitmap bitmapFrameAt = frameSourceEnsureFallback.frameAt(j, i, z);
            final long lastDecodeMs = frameSourceEnsureFallback.getLastDecodeMs();
            this$0.handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$PreviewEngine$ii1CoY-GNlKf_eAc9mrjKnwNvrI
                @Override // java.lang.Runnable
                public final void run() {
                    PreviewEngine.requestFrames$lambda$12$lambda$11(this.f$0, lastDecodeMs, bitmapFrameAt, id);
                }
            });
        } catch (Exception unused) {
        } catch (Throwable th) {
            this$0.decoding.remove(id);
            throw th;
        }
        this$0.decoding.remove(id);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void requestFrames$lambda$12$lambda$11(PreviewEngine this$0, long j, Bitmap bitmap, String id) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(id, "$id");
        float f = this$0.avgDecodeMs;
        if (f <= 0.0f) {
            this$0.avgDecodeMs = j;
        } else {
            this$0.avgDecodeMs = (f * 0.7f) + (j * 0.3f);
        }
        if (bitmap != null) {
            this$0.publishSoftware(id, bitmap);
        }
    }

    private final void publishGpu(String id, Bitmap bmp) {
        if (project().layerById(id) == null || this.frames.put(id, bmp) == bmp) {
            return;
        }
        this.softNow.remove(id);
        this.fpsCount++;
        this.newFrames.set(true);
        this.onFrameReady.invoke(Long.valueOf(this.masterMs));
    }

    private final void publishSoftware(String id, Bitmap bmp) {
        if (project().layerById(id) == null) {
            bmp.recycle();
            return;
        }
        Bitmap bitmapPut = this.frames.put(id, bmp);
        if (bitmapPut == bmp) {
            return;
        }
        this.softNow.add(id);
        this.fpsCount++;
        if (bitmapPut != null && !this.externalIds.contains(id) && !decoderOwns(id, bitmapPut)) {
            try {
                bitmapPut.recycle();
            } catch (Exception unused) {
            }
        }
        this.newFrames.set(true);
        this.onFrameReady.invoke(Long.valueOf(this.masterMs));
    }

    private final boolean decoderOwns(String id, Bitmap bmp) {
        try {
            GpuVideoDecoder gpuVideoDecoderDecoder = GpuVideoPipeline.INSTANCE.decoder(id);
            if (gpuVideoDecoderDecoder != null) {
                return gpuVideoDecoderDecoder.owns(bmp);
            }
            return false;
        } catch (Exception unused) {
            return false;
        }
    }

    private final int maxPxFor(Layer l) {
        Function1<? super Layer, Integer> function1 = this.layerTargetPx;
        int iCoerceIn = RangesKt.coerceIn(Math.min(function1 != null ? function1.invoke(l).intValue() : this.targetMaxPx, this.targetMaxPx), MIN_DECODE_PX, 1920);
        return !anyPlaying() ? RangesKt.coerceAtLeast(Math.min(1440, (int) (iCoerceIn * 1.35f)), iCoerceIn) : RangesKt.coerceIn((int) (iCoerceIn * this.adaptiveScale), MIN_DECODE_PX, iCoerceIn);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void adaptQuality() {
        float fCoerceAtMost;
        boolean z = false;
        boolean z2 = this.costCount > 0;
        this.costCount = 0;
        if (z2 || this.adaptiveScale >= 1.0f) {
            float f = this.avgDecodeMs;
            if (f > 55.0f) {
                fCoerceAtMost = RangesKt.coerceAtLeast(this.adaptiveScale * START_SCALE, 0.4f);
            } else {
                if (0.5f <= f && f <= 24.0f) {
                    z = true;
                }
                fCoerceAtMost = (!z || this.adaptiveScale >= 1.0f) ? this.adaptiveScale : RangesKt.coerceAtMost(this.adaptiveScale * 1.2f, 1.0f);
            }
        } else {
            fCoerceAtMost = RangesKt.coerceAtMost(this.adaptiveScale * 1.2f, 1.0f);
        }
        this.adaptiveScale = fCoerceAtMost;
    }

    public final void evict(@NotNull final String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        releaseSource(id);
        final boolean zRemove = this.externalIds.remove(id);
        this.imageIds.remove(id);
        this.imageLoading.remove(id);
        this.handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$PreviewEngine$Jo33FI9KlyHU1b0aN4W04LK0ReM
            @Override // java.lang.Runnable
            public final void run() {
                PreviewEngine.evict$lambda$13(this.f$0, id, zRemove);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void evict$lambda$13(PreviewEngine this$0, String id, boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(id, "$id");
        Bitmap bitmapRemove = this$0.frames.remove(id);
        if (bitmapRemove != null && !z && !this$0.gpuIds.contains(id)) {
            try {
                bitmapRemove.recycle();
            } catch (Exception unused) {
            }
        }
        this$0.newFrames.set(true);
    }

    @Nullable
    public final Bitmap frameOf(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        Bitmap bitmap = this.frames.get(l.getId());
        if (bitmap == null && l.getType() == LayerType.IMAGE) {
            requestImage(l);
        }
        return bitmap;
    }

    private final void requestImage(Layer l) {
        final String id = l.getId();
        final String strPathOf = pathOf(l);
        if (strPathOf != null && this.imageLoading.add(id)) {
            Function1<? super Layer, Integer> function1 = this.layerTargetPx;
            final int iCoerceIn = RangesKt.coerceIn(function1 != null ? function1.invoke(l).intValue() : this.targetMaxPx, 256, AudioConfig.CHUNK_BYTES);
            try {
                this.exec.execute(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$PreviewEngine$TjDABoU16_UpAINUc3Y1ufP1dNs
                    @Override // java.lang.Runnable
                    public final void run() {
                        PreviewEngine.requestImage$lambda$16(strPathOf, iCoerceIn, this, id);
                    }
                });
            } catch (RejectedExecutionException unused) {
                this.imageLoading.remove(id);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void requestImage$lambda$16(String path, int i, final PreviewEngine this$0, final String id) {
        final Bitmap bitmapImage;
        Intrinsics.checkNotNullParameter(path, "$path");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(id, "$id");
        try {
            bitmapImage = MediaKit.INSTANCE.image(path, i);
        } catch (Throwable unused) {
            bitmapImage = null;
        }
        this$0.handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$PreviewEngine$Nq0p5q4cNr_F_vKNiaPfcF05zgE
            @Override // java.lang.Runnable
            public final void run() {
                PreviewEngine.requestImage$lambda$16$lambda$15(this.f$0, id, bitmapImage);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void requestImage$lambda$16$lambda$15(PreviewEngine this$0, String id, Bitmap bitmap) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(id, "$id");
        this$0.imageLoading.remove(id);
        if (bitmap == null) {
            return;
        }
        if (this$0.project().layerById(id) == null) {
            try {
                bitmap.recycle();
                return;
            } catch (Exception unused) {
                return;
            }
        }
        this$0.imageIds.add(id);
        Bitmap bitmapPut = this$0.frames.put(id, bitmap);
        if (bitmapPut != null && bitmapPut != bitmap) {
            try {
                bitmapPut.recycle();
            } catch (Exception unused2) {
            }
        }
        this$0.newFrames.set(true);
        this$0.onFrameReady.invoke(Long.valueOf(this$0.masterMs));
    }

    public final void setFrame(@NotNull Layer l, @Nullable Bitmap bmp) {
        Intrinsics.checkNotNullParameter(l, "l");
        if (bmp == null) {
            return;
        }
        this.externalIds.add(l.getId());
        this.frames.put(l.getId(), bmp);
        this.newFrames.set(true);
    }

    public final void clearExternal(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        this.externalIds.remove(id);
        this.frames.remove(id);
        this.newFrames.set(true);
    }

    public final void recycleFrames() {
        HashMap map = new HashMap();
        for (Map.Entry<String, Bitmap> entry : this.frames.entrySet()) {
            String key = entry.getKey();
            Bitmap value = entry.getValue();
            if (this.externalIds.contains(key)) {
                map.put(key, value);
            } else if (!this.gpuIds.contains(key)) {
                try {
                    value.recycle();
                } catch (Exception unused) {
                }
            }
        }
        this.frames.clear();
        this.frames.putAll(map);
        this.imageIds.clear();
    }

    public final void release() {
        detach();
        try {
            GpuVideoPipeline.INSTANCE.releaseAll();
        } catch (Exception unused) {
        }
        this.exec.shutdown();
    }
}
