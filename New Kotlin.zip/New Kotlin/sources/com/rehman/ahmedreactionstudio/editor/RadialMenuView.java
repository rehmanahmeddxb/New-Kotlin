package com.rehman.ahmedreactionstudio.editor;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.rehman.ahmedreactionstudio.R;
import com.rehman.ahmedreactionstudio.util.UI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: RadialWheel.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0019\u0018\u0000 62\u00020\u0001:\u0003678B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J8\u0010\u001d\u001a\u00020\u000e2\u0006\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u00062\u0006\u0010!\u001a\u00020\u00062\u0006\u0010\"\u001a\u00020\u00062\u0006\u0010#\u001a\u00020\u00162\u0006\u0010$\u001a\u00020\u000bH\u0002J \u0010%\u001a\u00020\u000e2\u0006\u0010&\u001a\u00020\u001c2\u0006\u0010'\u001a\u00020\u00062\u0006\u0010$\u001a\u00020\u000bH\u0002J\u0006\u0010(\u001a\u00020\u0016J\u000e\u0010)\u001a\u00020\u000e2\u0006\u0010*\u001a\u00020\u000bJ\b\u0010+\u001a\u00020\u000eH\u0002J\u0010\u0010,\u001a\u00020\u000e2\u0006\u0010\u001e\u001a\u00020\u001fH\u0002J\u0006\u0010-\u001a\u00020\u000bJ\u0006\u0010.\u001a\u00020\u000bJ\u0010\u0010/\u001a\u00020\u000e2\u0006\u0010&\u001a\u00020\u001cH\u0002J\u0006\u00100\u001a\u00020\u000eJ\u0010\u00101\u001a\u00020\u000e2\u0006\u0010$\u001a\u00020\u000bH\u0002J\"\u00102\u001a\u00020\u000e2\u0006\u00103\u001a\u00020\u001c2\b\b\u0002\u00104\u001a\u00020\u00062\b\b\u0002\u00105\u001a\u00020\u0006R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\"\u0010\f\u001a\n\u0012\u0004\u0012\u00020\u000e\u0018\u00010\rX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000f\u0010\u0010\"\u0004\b\u0011\u0010\u0012R\u000e\u0010\u0013\u001a\u00020\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\u0014\u001a\u0012\u0012\u0004\u0012\u00020\u00160\u0015j\b\u0012\u0004\u0012\u00020\u0016`\u0017X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u001b\u001a\u0012\u0012\u0004\u0012\u00020\u001c0\u0015j\b\u0012\u0004\u0012\u00020\u001c`\u0017X\u0082\u0004¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/RadialMenuView;", "Landroid/widget/FrameLayout;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "anchorX", "", "anchorY", "cx", "cy", "dismissing", "", "onDismiss", "Lkotlin/Function0;", "", "getOnDismiss", "()Lkotlin/jvm/functions/Function0;", "setOnDismiss", "(Lkotlin/jvm/functions/Function0;)V", "open", "pages", "Ljava/util/ArrayList;", "", "Lkotlin/collections/ArrayList;", "ring", "scrim", "Landroid/view/View;", "stack", "Lcom/rehman/ahmedreactionstudio/editor/RadialMenuView$Level;", "addPetal", "pt", "Lcom/rehman/ahmedreactionstudio/editor/RadialMenuView$Item;", "px", "py", "size", "index", "fresh", "buildHub", "level", "hubSize", "depth", "dismiss", "animated", "finishDismiss", "handleTap", "isOpen", "pop", "push", "refresh", "render", "show", "root", "ax", "ay", "Companion", "Item", "Level"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class RadialMenuView extends FrameLayout {
    private static final float BADGE_ABOVE_DP = 14.0f;
    private static final float EDGE_PAD_DP = 10.0f;
    private static final float LABEL_BELOW_DP = 28.0f;
    private static final float LABEL_HALF_DP = 48.0f;
    private static final int PAGE = 8;
    private float anchorX;
    private float anchorY;
    private float cx;
    private float cy;
    private boolean dismissing;

    @Nullable
    private Function0<Unit> onDismiss;
    private boolean open;

    @NotNull
    private final ArrayList<Integer> pages;

    @NotNull
    private final FrameLayout ring;

    @NotNull
    private final View scrim;

    @NotNull
    private final ArrayList<Level> stack;

    private static final boolean render$fits(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10) {
        float f11 = f8 + (f / 2.0f);
        return (f9 - f11) - f2 >= f3 && (f9 + f11) + f2 <= f4 - f3 && (f10 - f11) - f5 >= f3 && (f10 + f11) + f6 <= f7 - f3;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public RadialMenuView(@NotNull Context context) {
        super(context);
        Intrinsics.checkNotNullParameter(context, "context");
        this.stack = new ArrayList<>();
        this.pages = new ArrayList<>();
        this.anchorX = -1.0f;
        this.anchorY = -1.0f;
        this.ring = new FrameLayout(context);
        this.scrim = new View(context);
        setVisibility(8);
        setClickable(true);
    }

    /* JADX INFO: compiled from: RadialWheel.kt */
    @Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u000e\u0018\u00002\u00020\u0001Bm\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\u0007\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\u0005\u0012\u0010\b\u0002\u0010\n\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u000b\u0012\b\b\u0002\u0010\r\u001a\u00020\u0007\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u0007\u0012\u0010\b\u0002\u0010\u000f\u001a\n\u0012\u0004\u0012\u00020\u0010\u0018\u00010\u000b¢\u0006\u0002\u0010\u0011R\u0019\u0010\u000f\u001a\n\u0012\u0004\u0012\u00020\u0010\u0018\u00010\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0013\u0010\t\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0015R\u0011\u0010\u000e\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0015R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0011\u0010\r\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0015R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0017R\u0019\u0010\n\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0013"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/RadialMenuView$Item;", "", "icon", "", "label", "", "active", "", "danger", "badge", "submenu", "Lkotlin/Function0;", "Lcom/rehman/ahmedreactionstudio/editor/RadialMenuView$Level;", "keepOpen", "enabled", "action", "", "(ILjava/lang/String;ZZLjava/lang/String;Lkotlin/jvm/functions/Function0;ZZLkotlin/jvm/functions/Function0;)V", "getAction", "()Lkotlin/jvm/functions/Function0;", "getActive", "()Z", "getBadge", "()Ljava/lang/String;", "getDanger", "getEnabled", "getIcon", "()I", "getKeepOpen", "getLabel", "getSubmenu"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Item {

        @Nullable
        private final Function0<Unit> action;
        private final boolean active;

        @Nullable
        private final String badge;
        private final boolean danger;
        private final boolean enabled;
        private final int icon;
        private final boolean keepOpen;

        @NotNull
        private final String label;

        @Nullable
        private final Function0<Level> submenu;

        public Item(int i, @NotNull String label, boolean z, boolean z2, @Nullable String str, @Nullable Function0<Level> function0, boolean z3, boolean z4, @Nullable Function0<Unit> function02) {
            Intrinsics.checkNotNullParameter(label, "label");
            this.icon = i;
            this.label = label;
            this.active = z;
            this.danger = z2;
            this.badge = str;
            this.submenu = function0;
            this.keepOpen = z3;
            this.enabled = z4;
            this.action = function02;
        }

        public /* synthetic */ Item(int i, String str, boolean z, boolean z2, String str2, Function0 function0, boolean z3, boolean z4, Function0 function02, int i2, DefaultConstructorMarker defaultConstructorMarker) {
            this(i, str, (i2 & 4) != 0 ? false : z, (i2 & 8) != 0 ? false : z2, (i2 & 16) != 0 ? null : str2, (i2 & 32) != 0 ? null : function0, (i2 & 64) != 0 ? false : z3, (i2 & 128) != 0 ? true : z4, (i2 & 256) != 0 ? null : function02);
        }

        public final int getIcon() {
            return this.icon;
        }

        @NotNull
        public final String getLabel() {
            return this.label;
        }

        public final boolean getActive() {
            return this.active;
        }

        public final boolean getDanger() {
            return this.danger;
        }

        @Nullable
        public final String getBadge() {
            return this.badge;
        }

        @Nullable
        public final Function0<Level> getSubmenu() {
            return this.submenu;
        }

        public final boolean getKeepOpen() {
            return this.keepOpen;
        }

        public final boolean getEnabled() {
            return this.enabled;
        }

        @Nullable
        public final Function0<Unit> getAction() {
            return this.action;
        }
    }

    /* JADX INFO: compiled from: RadialWheel.kt */
    @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\b\u0018\u00002\u00020\u0001B3\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\u0012\u0010\u0007\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\t0\b¢\u0006\u0002\u0010\u000bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u001d\u0010\u0007\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\t0\b¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0011"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/RadialMenuView$Level;", "", "icon", "", "title", "", "subtitle", "items", "Lkotlin/Function0;", "", "Lcom/rehman/ahmedreactionstudio/editor/RadialMenuView$Item;", "(ILjava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V", "getIcon", "()I", "getItems", "()Lkotlin/jvm/functions/Function0;", "getSubtitle", "()Ljava/lang/String;", "getTitle"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Level {
        private final int icon;

        @NotNull
        private final Function0<List<Item>> items;

        @NotNull
        private final String subtitle;

        @NotNull
        private final String title;

        /* JADX WARN: Multi-variable type inference failed */
        public Level(int i, @NotNull String title, @NotNull String subtitle, @NotNull Function0<? extends List<Item>> items) {
            Intrinsics.checkNotNullParameter(title, "title");
            Intrinsics.checkNotNullParameter(subtitle, "subtitle");
            Intrinsics.checkNotNullParameter(items, "items");
            this.icon = i;
            this.title = title;
            this.subtitle = subtitle;
            this.items = items;
        }

        public /* synthetic */ Level(int i, String str, String str2, Function0 function0, int i2, DefaultConstructorMarker defaultConstructorMarker) {
            this(i, str, (i2 & 4) != 0 ? "" : str2, function0);
        }

        public final int getIcon() {
            return this.icon;
        }

        @NotNull
        public final String getTitle() {
            return this.title;
        }

        @NotNull
        public final String getSubtitle() {
            return this.subtitle;
        }

        @NotNull
        public final Function0<List<Item>> getItems() {
            return this.items;
        }
    }

    @Nullable
    public final Function0<Unit> getOnDismiss() {
        return this.onDismiss;
    }

    public final void setOnDismiss(@Nullable Function0<Unit> function0) {
        this.onDismiss = function0;
    }

    /* JADX INFO: renamed from: isOpen, reason: from getter */
    public final boolean getOpen() {
        return this.open;
    }

    public final int depth() {
        return this.stack.size();
    }

    public static /* synthetic */ void show$default(RadialMenuView radialMenuView, Level level, float f, float f2, int i, Object obj) {
        if ((i & 2) != 0) {
            f = -1.0f;
        }
        if ((i & 4) != 0) {
            f2 = -1.0f;
        }
        radialMenuView.show(level, f, f2);
    }

    public final void show(@NotNull Level root, float ax, float ay) {
        Intrinsics.checkNotNullParameter(root, "root");
        if (this.open) {
            dismiss(false);
        }
        this.stack.clear();
        this.pages.clear();
        this.stack.add(root);
        this.pages.add(0);
        this.anchorX = ax;
        this.anchorY = ay;
        this.open = true;
        this.dismissing = false;
        setVisibility(0);
        removeAllViews();
        this.scrim.setBackgroundColor(Color.argb(165, 4, 5, 8));
        this.scrim.setAlpha(0.0f);
        this.scrim.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$RadialMenuView$c_W8e-wW2Pbh5bIKwJBk4q100yY
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                RadialMenuView.show$lambda$0(this.f$0, view);
            }
        });
        addView(this.scrim, new FrameLayout.LayoutParams(-1, -1));
        addView(this.ring, new FrameLayout.LayoutParams(-1, -1));
        this.scrim.animate().alpha(1.0f).setDuration(200L).start();
        final Runnable runnable = new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$RadialMenuView$SRuiFfqmUwmnmqsF9v8EPKYCeSo
            @Override // java.lang.Runnable
            public final void run() {
                RadialMenuView.show$lambda$1(this.f$0);
            }
        };
        if (getWidth() <= 0 || getHeight() <= 0) {
            addOnLayoutChangeListener(new View.OnLayoutChangeListener() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenuView.show.2
                @Override // android.view.View.OnLayoutChangeListener
                public void onLayoutChange(@NotNull View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                    Intrinsics.checkNotNullParameter(v, "v");
                    RadialMenuView.this.removeOnLayoutChangeListener(this);
                    RadialMenuView.this.post(runnable);
                }
            });
        } else {
            post(runnable);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void show$lambda$0(RadialMenuView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.dismiss(true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void show$lambda$1(RadialMenuView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.render(true);
    }

    private final void push(Level level) {
        this.stack.add(level);
        this.pages.add(0);
        render(true);
    }

    public final boolean pop() {
        if (this.stack.size() <= 1) {
            dismiss(true);
            return false;
        }
        ArrayList<Level> arrayList = this.stack;
        arrayList.remove(arrayList.size() - 1);
        ArrayList<Integer> arrayList2 = this.pages;
        arrayList2.remove(arrayList2.size() - 1);
        render(true);
        return true;
    }

    public final void refresh() {
        if (this.open && (!this.stack.isEmpty())) {
            render(false);
        }
    }

    private final void render(boolean fresh) {
        List<Item> listEmptyList;
        float f;
        float f2;
        float f3;
        float f4;
        float f5;
        if (!this.open || this.stack.isEmpty()) {
            return;
        }
        this.ring.removeAllViews();
        UI ui = UI.INSTANCE;
        Context context = getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        float fDpf = ui.dpf(context, 1.0f);
        Level level = (Level) CollectionsKt.last((List) this.stack);
        try {
            listEmptyList = level.getItems().invoke();
        } catch (Exception unused) {
            listEmptyList = CollectionsKt.emptyList();
        }
        int iCoerceAtLeast = RangesKt.coerceAtLeast(((Number) CollectionsKt.last((List) this.pages)).intValue(), 0);
        final int iCeil = listEmptyList.size() <= 8 ? 1 : (int) Math.ceil(listEmptyList.size() / 7.0f);
        final int i = iCeil <= 1 ? 0 : iCoerceAtLeast % iCeil;
        if (iCeil > 1) {
            int i2 = i * 7;
            listEmptyList = CollectionsKt.plus((Collection<? extends Item>) listEmptyList.subList(i2, Math.min(i2 + 7, listEmptyList.size())), new Item(R.drawable.ic_more, "More  " + (i + 1) + '/' + iCeil, false, false, null, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenuView$render$items$1
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    this.this$0.pages.set(this.this$0.pages.size() - 1, Integer.valueOf((i + 1) % iCeil));
                }
            }, 188, null));
        }
        int iCoerceAtLeast2 = RangesKt.coerceAtLeast(listEmptyList.size(), 1);
        float fCoerceAtLeast = RangesKt.coerceAtLeast(getWidth(), 1.0f);
        float fCoerceAtLeast2 = RangesKt.coerceAtLeast(getHeight(), 1.0f);
        float f6 = EDGE_PAD_DP * fDpf;
        float f7 = fDpf * LABEL_BELOW_DP;
        float f8 = fDpf * BADGE_ABOVE_DP;
        float f9 = fDpf * LABEL_HALF_DP;
        float fMin = Math.min(fCoerceAtLeast, fCoerceAtLeast2);
        float f10 = 46.0f;
        if (iCoerceAtLeast2 <= 8 && fMin >= 520 * fDpf) {
            f10 = 52.0f;
        }
        float f11 = f10 * fDpf;
        float f12 = (fMin < ((float) 520) * fDpf ? 68.0f : 74.0f) * fDpf;
        float fMax = Math.max(100.0f * fDpf, ((f11 + (12 * fDpf)) * iCoerceAtLeast2) / 6.2831855f);
        float f13 = f11 / 2.0f;
        float fMax2 = ((((fMin / 2.0f) - f13) - Math.max(f7, f8)) - f6) - (8 * fDpf);
        if (fMax2 > f11) {
            fMax = Math.min(fMax, fMax2);
        }
        float f14 = fMax + f13;
        float fMax3 = Math.max(f9, f13) + f14 + f6;
        float f15 = fMax;
        float f16 = f14 + f8 + f6;
        float f17 = f8;
        float f18 = (f12 / 2.0f) + (44 * fDpf);
        float fMax4 = Math.max(f14 + f7, f18) + f6;
        float f19 = f18;
        float f20 = this.anchorX;
        if (f20 < 0.0f) {
            f20 = fCoerceAtLeast / 2.0f;
        }
        float f21 = this.anchorY;
        if (f21 < 0.0f) {
            f21 = fCoerceAtLeast2 / 2.0f;
        }
        int i3 = iCoerceAtLeast2;
        float f22 = fCoerceAtLeast / 2.0f;
        List<Item> list = listEmptyList;
        float fCoerceAtMost = RangesKt.coerceAtMost(fMax3, f22);
        float fCoerceAtLeast3 = RangesKt.coerceAtLeast(fCoerceAtLeast - fMax3, fCoerceAtMost);
        float f23 = fCoerceAtLeast2 / 2.0f;
        float fCoerceAtMost2 = RangesKt.coerceAtMost(f16, f23);
        float fCoerceAtLeast4 = RangesKt.coerceAtLeast(fCoerceAtLeast2 - fMax4, fCoerceAtMost2);
        float fCoerceIn = RangesKt.coerceIn(f20, fCoerceAtMost, fCoerceAtLeast3);
        float fCoerceIn2 = RangesKt.coerceIn(f21, fCoerceAtMost2, fCoerceAtLeast4);
        float fCoerceIn3 = fCoerceIn;
        float fCoerceIn4 = fCoerceIn2;
        float f24 = f15;
        int i4 = 0;
        while (f24 > 64 * fDpf) {
            float f25 = fDpf;
            int i5 = i4;
            f = f12;
            f2 = f9;
            float f26 = fCoerceIn4;
            f5 = f17;
            float f27 = f19;
            float f28 = fCoerceIn3;
            if (render$fits(f11, f9, f6, fCoerceAtLeast, f5, f7, fCoerceAtLeast2, f24, f28, f26) || i5 >= 24) {
                f3 = f26;
                f4 = f28;
                break;
            }
            f24 *= 0.92f;
            i4 = i5 + 1;
            float f29 = f24 + f13;
            float fMax5 = Math.max(f2, f13) + f29 + f6;
            float f30 = f29 + f5 + f6;
            float fMax6 = Math.max(f29 + f7, f27) + f6;
            fCoerceIn3 = RangesKt.coerceIn(f28, RangesKt.coerceAtMost(fMax5, f22), RangesKt.coerceAtLeast(fCoerceAtLeast - fMax5, RangesKt.coerceAtMost(fMax5, f22)));
            fCoerceIn4 = RangesKt.coerceIn(f26, RangesKt.coerceAtMost(f30, f23), RangesKt.coerceAtLeast(fCoerceAtLeast2 - fMax6, RangesKt.coerceAtMost(f30, f23)));
            f9 = f2;
            f19 = f27;
            fDpf = f25;
            f12 = f;
            f17 = f5;
        }
        f = f12;
        f2 = f9;
        f3 = fCoerceIn4;
        f4 = fCoerceIn3;
        f5 = f17;
        this.cx = f4;
        this.cy = f3;
        buildHub(level, f, fresh);
        float fMax7 = f6 + Math.max(f13, f2);
        float fMax8 = (fCoerceAtLeast - f6) - Math.max(f13, f2);
        float f31 = f6 + f13 + f5;
        float f32 = ((fCoerceAtLeast2 - f6) - f13) - f7;
        Iterator<Item> it = list.iterator();
        int i6 = 0;
        while (it.hasNext()) {
            int i7 = i3;
            double d = (-1.5707963267948966d) + (((((double) i6) * 2.0d) * 3.141592653589793d) / ((double) i7));
            double d2 = f24;
            addPetal(it.next(), RangesKt.coerceIn(this.cx + ((float) (d2 * Math.cos(d))), fMax7, RangesKt.coerceAtLeast(fMax8, fMax7)), RangesKt.coerceIn(this.cy + ((float) (d2 * Math.sin(d))), f31, RangesKt.coerceAtLeast(f32, f31)), f11, i6, fresh);
            f24 = f24;
            i3 = i7;
            i6++;
        }
    }

    private final void buildHub(Level level, float hubSize, boolean fresh) {
        String string;
        String subtitle;
        UI ui = UI.INSTANCE;
        Context context = getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        float fDpf = ui.dpf(context, 1.0f);
        int i = (int) hubSize;
        float fCoerceAtLeast = RangesKt.coerceAtLeast(getWidth(), 1.0f);
        float fCoerceAtLeast2 = RangesKt.coerceAtLeast(getHeight(), 1.0f);
        float f = EDGE_PAD_DP * fDpf;
        FrameLayout frameLayout = new FrameLayout(getContext());
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        gradientDrawable.setColor(Color.argb(242, 16, 19, 26));
        UI ui2 = UI.INSTANCE;
        Context context2 = getContext();
        Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
        gradientDrawable.setStroke(ui2.dp(context2, 2), this.stack.size() > 1 ? UI.INSTANCE.getACCENT2() : UI.INSTANCE.getACCENT());
        frameLayout.setBackground(gradientDrawable);
        this.ring.addView(frameLayout, new FrameLayout.LayoutParams(i, i, 8388659));
        float f2 = i;
        float f3 = f2 / 2.0f;
        frameLayout.setX(RangesKt.coerceIn(this.cx - f3, f, RangesKt.coerceAtLeast((fCoerceAtLeast - f2) - f, f)));
        frameLayout.setY(RangesKt.coerceIn(this.cy - f3, f, RangesKt.coerceAtLeast((fCoerceAtLeast2 - f2) - f, f)));
        ImageView imageView = new ImageView(getContext());
        Ic ic = Ic.INSTANCE;
        Context context3 = getContext();
        Intrinsics.checkNotNullExpressionValue(context3, "getContext(...)");
        imageView.setImageDrawable(ic.get(context3, this.stack.size() > 1 ? R.drawable.ic_back : level.getIcon(), this.stack.size() > 1 ? UI.INSTANCE.getACCENT2() : UI.INSTANCE.getACCENT()));
        int i2 = (int) (0.28f * hubSize);
        imageView.setPadding(i2, i2, i2, i2);
        frameLayout.addView(imageView, new FrameLayout.LayoutParams(-1, -1));
        if (this.stack.size() > 1) {
            StringBuilder sb = new StringBuilder();
            sb.append("Back to ");
            ArrayList<Level> arrayList = this.stack;
            sb.append(arrayList.get(arrayList.size() - 2).getTitle());
            string = sb.toString();
        } else {
            string = "Close menu";
        }
        frameLayout.setContentDescription(string);
        frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$RadialMenuView$AOkLaiHUmQMJsHjWG1lcNElIZw4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                RadialMenuView.buildHub$lambda$2(this.f$0, view);
            }
        });
        int i3 = (int) (200 * fDpf);
        TextView textView = new TextView(getContext());
        textView.setText(level.getTitle());
        textView.setTextSize(12.0f);
        textView.setGravity(17);
        textView.setMaxLines(1);
        textView.setTextColor(-1);
        textView.setTypeface(Typeface.create("sans-serif-medium", 1));
        textView.setShadowLayer(6.0f, 0.0f, 2.0f, -16777216);
        this.ring.addView(textView, new FrameLayout.LayoutParams(i3, -2, 8388659));
        float f4 = i3;
        textView.setX(RangesKt.coerceIn(this.cx - (f4 / 2.0f), f, RangesKt.coerceAtLeast((fCoerceAtLeast - f4) - f, f)));
        textView.setY(RangesKt.coerceAtMost(this.cy + (hubSize / 2.0f) + (6 * fDpf), fCoerceAtLeast2 - (40 * fDpf)));
        int i4 = (int) (220 * fDpf);
        TextView textView2 = new TextView(getContext());
        if (this.stack.size() > 1) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("‹ Back to ");
            sb2.append(this.stack.get(r5.size() - 2).getTitle());
            subtitle = sb2.toString();
        } else {
            subtitle = level.getSubtitle();
        }
        textView2.setText(subtitle);
        textView2.setTextSize(9.0f);
        textView2.setGravity(17);
        textView2.setMaxLines(1);
        textView2.setTextColor(Color.argb(200, 235, 238, 245));
        textView2.setShadowLayer(5.0f, 0.0f, 1.0f, -16777216);
        this.ring.addView(textView2, new FrameLayout.LayoutParams(i4, -2, 8388659));
        float f5 = i4;
        textView2.setX(RangesKt.coerceIn(this.cx - (f5 / 2.0f), f, RangesKt.coerceAtLeast((fCoerceAtLeast - f5) - f, f)));
        textView2.setY(RangesKt.coerceAtMost(textView.getY() + (18 * fDpf), fCoerceAtLeast2 - (22 * fDpf)));
        if (fresh) {
            for (View view : CollectionsKt.listOf((Object[]) new View[]{frameLayout, textView, textView2})) {
                view.setAlpha(0.0f);
                view.setScaleX(0.4f);
                view.setScaleY(0.4f);
                view.animate().alpha(1.0f).scaleX(1.0f).scaleY(1.0f).setDuration(280L).setInterpolator(new OvershootInterpolator(1.7f)).start();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildHub$lambda$2(RadialMenuView this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.performHapticFeedback(1);
        if (this$0.stack.size() > 1) {
            this$0.pop();
        } else {
            this$0.dismiss(true);
        }
    }

    private final void addPetal(final Item pt, float px, float py, float size, int index, boolean fresh) {
        int fg;
        int iArgb;
        TextView textView;
        String str;
        TextView textView2;
        ViewPropertyAnimator viewPropertyAnimatorAnimate;
        ViewPropertyAnimator viewPropertyAnimatorAlpha;
        ViewPropertyAnimator startDelay;
        ViewPropertyAnimator duration;
        UI ui = UI.INSTANCE;
        Context context = getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        float fDpf = ui.dpf(context, 1.0f);
        int i = (int) size;
        boolean z = pt.getSubmenu() != null;
        final FrameLayout frameLayout = new FrameLayout(getContext());
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        gradientDrawable.setColor(Color.argb(240, 18, 21, 29));
        if (pt.getDanger()) {
            fg = UI.INSTANCE.getDANGER();
        } else if (pt.getActive()) {
            fg = UI.INSTANCE.getACCENT2();
        } else if (z) {
            fg = UI.INSTANCE.getFG();
        } else {
            fg = UI.INSTANCE.getFG();
        }
        UI ui2 = UI.INSTANCE;
        Context context2 = getContext();
        Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
        int iDp = ui2.dp(context2, z ? 2 : 1);
        if (pt.getDanger()) {
            iArgb = UI.INSTANCE.getDANGER();
        } else if (pt.getActive()) {
            iArgb = UI.INSTANCE.getACCENT2();
        } else if (z) {
            iArgb = Color.argb(150, KotlinVersion.MAX_COMPONENT_VALUE, 90, 44);
        } else {
            iArgb = Color.argb(70, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE);
        }
        gradientDrawable.setStroke(iDp, iArgb);
        frameLayout.setBackground(gradientDrawable);
        this.ring.addView(frameLayout, new FrameLayout.LayoutParams(i, i, 8388659));
        ImageView imageView = new ImageView(getContext());
        Ic ic = Ic.INSTANCE;
        Context context3 = getContext();
        Intrinsics.checkNotNullExpressionValue(context3, "getContext(...)");
        imageView.setImageDrawable(ic.get(context3, pt.getIcon(), fg));
        int i2 = (int) (0.27f * size);
        imageView.setPadding(i2, i2, i2, i2);
        frameLayout.addView(imageView, new FrameLayout.LayoutParams(-1, -1));
        if (z) {
            ImageView imageView2 = new ImageView(getContext());
            Ic ic2 = Ic.INSTANCE;
            Context context4 = getContext();
            Intrinsics.checkNotNullExpressionValue(context4, "getContext(...)");
            imageView2.setImageDrawable(ic2.get(context4, R.drawable.ic_more, Color.argb(210, KotlinVersion.MAX_COMPONENT_VALUE, 140, 90)));
            int i3 = (int) (0.26f * size);
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(i3, i3, 8388693);
            int i4 = (int) (0.06f * size);
            layoutParams.setMargins(0, 0, i4, i4);
            frameLayout.addView(imageView2, layoutParams);
        }
        float fCoerceAtLeast = RangesKt.coerceAtLeast(getWidth(), 1.0f);
        float fCoerceAtLeast2 = RangesKt.coerceAtLeast(getHeight(), 1.0f);
        float f = EDGE_PAD_DP * fDpf;
        int i5 = (int) (96 * fDpf);
        TextView textView3 = new TextView(getContext());
        textView3.setText(pt.getLabel());
        textView3.setTextSize(9.0f);
        textView3.setGravity(17);
        textView3.setMaxLines(2);
        textView3.setTextColor(pt.getDanger() ? UI.INSTANCE.getDANGER() : Color.argb(240, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
        textView3.setShadowLayer(4.0f, 0.0f, 1.0f, -16777216);
        this.ring.addView(textView3, new FrameLayout.LayoutParams(i5, -2, 8388659));
        float f2 = i5;
        textView3.setX(RangesKt.coerceIn(px - (f2 / 2.0f), f, RangesKt.coerceAtLeast((fCoerceAtLeast - f2) - f, f)));
        float f3 = size / 2.0f;
        textView3.setY(RangesKt.coerceIn(py + f3 + (2 * fDpf), f, RangesKt.coerceAtLeast(fCoerceAtLeast2 - (22 * fDpf), f)));
        TextView textView4 = null;
        String badge = pt.getBadge();
        if (badge == null || StringsKt.isBlank(badge)) {
            textView = textView3;
        } else {
            textView4 = new TextView(getContext());
            textView4.setText(pt.getBadge());
            textView4.setTextSize(7.0f);
            textView4.setGravity(17);
            textView4.setTypeface(Typeface.create("sans-serif-medium", 1));
            int danger = pt.getDanger() ? UI.INSTANCE.getDANGER() : UI.INSTANCE.getACCENT2();
            textView4.setTextColor(danger);
            UI ui3 = UI.INSTANCE;
            Context context5 = getContext();
            Intrinsics.checkNotNullExpressionValue(context5, "getContext(...)");
            int iDp2 = ui3.dp(context5, 4);
            UI ui4 = UI.INSTANCE;
            Context context6 = getContext();
            Intrinsics.checkNotNullExpressionValue(context6, "getContext(...)");
            int iDp3 = ui4.dp(context6, 1);
            UI ui5 = UI.INSTANCE;
            Context context7 = getContext();
            Intrinsics.checkNotNullExpressionValue(context7, "getContext(...)");
            int iDp4 = ui5.dp(context7, 4);
            UI ui6 = UI.INSTANCE;
            Context context8 = getContext();
            Intrinsics.checkNotNullExpressionValue(context8, "getContext(...)");
            textView = textView3;
            textView4.setPadding(iDp2, iDp3, iDp4, ui6.dp(context8, 1));
            GradientDrawable gradientDrawable2 = new GradientDrawable();
            UI ui7 = UI.INSTANCE;
            Context context9 = getContext();
            Intrinsics.checkNotNullExpressionValue(context9, "getContext(...)");
            gradientDrawable2.setCornerRadius(ui7.dpf(context9, 6.0f));
            gradientDrawable2.setColor(Color.argb(230, 14, 16, 22));
            gradientDrawable2.setStroke(1, danger);
            textView4.setBackground(gradientDrawable2);
            this.ring.addView(textView4, new FrameLayout.LayoutParams(-2, -2, 8388659));
            textView4.measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
            float fCoerceAtLeast3 = RangesKt.coerceAtLeast(textView4.getMeasuredWidth(), 28 * fDpf);
            float f4 = 14 * fDpf;
            float fCoerceAtLeast4 = RangesKt.coerceAtLeast(textView4.getMeasuredHeight(), f4);
            textView4.setX(RangesKt.coerceIn((px + f3) - f4, f, RangesKt.coerceAtLeast((fCoerceAtLeast - fCoerceAtLeast3) - f, f)));
            textView4.setY(RangesKt.coerceIn((py - f3) - (4 * fDpf), f, RangesKt.coerceAtLeast((fCoerceAtLeast2 - fCoerceAtLeast4) - f, f)));
        }
        StringBuilder sb = new StringBuilder();
        sb.append(pt.getLabel());
        if (pt.getEnabled()) {
            str = pt.getSubmenu() != null ? ". Opens options" : "";
        } else {
            str = ". Unavailable";
        }
        sb.append(str);
        frameLayout.setContentDescription(sb.toString());
        frameLayout.setImportantForAccessibility(1);
        if (pt.getEnabled()) {
            textView2 = textView;
        } else {
            frameLayout.setAlpha(0.38f);
            textView2 = textView;
            textView2.setAlpha(0.55f);
        }
        frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$RadialMenuView$NVhQ8fWZFt7U3zUm1v4MxIA-0OE
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                RadialMenuView.addPetal$lambda$3(this.f$0, pt, frameLayout, view);
            }
        });
        float f5 = (fCoerceAtLeast - size) - f;
        float fCoerceIn = RangesKt.coerceIn(px - f3, f, RangesKt.coerceAtLeast(f5, f));
        float f6 = (fCoerceAtLeast2 - size) - f;
        float fCoerceIn2 = RangesKt.coerceIn(py - f3, f, RangesKt.coerceAtLeast(f6, f));
        if (fresh) {
            frameLayout.setX(RangesKt.coerceIn(this.cx - f3, f, RangesKt.coerceAtLeast(f5, f)));
            frameLayout.setY(RangesKt.coerceIn(this.cy - f3, f, RangesKt.coerceAtLeast(f6, f)));
            frameLayout.setScaleX(0.2f);
            frameLayout.setScaleY(0.2f);
            frameLayout.setAlpha(0.0f);
            textView2.setAlpha(0.0f);
            if (textView4 != null) {
                textView4.setAlpha(0.0f);
            }
            long j = (((long) index) * 24) + 30;
            frameLayout.animate().x(fCoerceIn).y(fCoerceIn2).scaleX(1.0f).scaleY(1.0f).alpha(1.0f).setStartDelay(j).setDuration(280L).setInterpolator(new OvershootInterpolator(1.12f)).start();
            long j2 = j + ((long) 120);
            textView2.animate().alpha(1.0f).setStartDelay(j2).setDuration(160L).start();
            if (textView4 == null || (viewPropertyAnimatorAnimate = textView4.animate()) == null || (viewPropertyAnimatorAlpha = viewPropertyAnimatorAnimate.alpha(1.0f)) == null || (startDelay = viewPropertyAnimatorAlpha.setStartDelay(j2)) == null || (duration = startDelay.setDuration(160L)) == null) {
                return;
            }
            duration.start();
            return;
        }
        frameLayout.setX(fCoerceIn);
        frameLayout.setY(fCoerceIn2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void addPetal$lambda$3(final RadialMenuView this$0, final Item pt, final FrameLayout petal, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(pt, "$pt");
        Intrinsics.checkNotNullParameter(petal, "$petal");
        if (!this$0.dismissing && pt.getEnabled()) {
            this$0.performHapticFeedback(16);
            petal.animate().scaleX(1.16f).scaleY(1.16f).setDuration(85L).setListener(new AnimatorListenerAdapter() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenuView$addPetal$1$1
                @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
                public void onAnimationEnd(@NotNull Animator a) {
                    Intrinsics.checkNotNullParameter(a, "a");
                    petal.animate().setListener(null);
                    this$0.handleTap(pt);
                }
            }).start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleTap(Item pt) {
        Level levelInvoke;
        Function0<Level> submenu = pt.getSubmenu();
        if (submenu != null) {
            try {
                levelInvoke = submenu.invoke();
            } catch (Exception unused) {
                levelInvoke = null;
            }
            if (levelInvoke != null) {
                push(levelInvoke);
                return;
            }
            return;
        }
        Function0<Unit> action = pt.getAction();
        if (action == null) {
            dismiss(true);
        } else if (pt.getKeepOpen()) {
            try {
                action.invoke();
            } catch (Exception unused2) {
            }
            refresh();
        } else {
            try {
                action.invoke();
            } catch (Exception unused3) {
            }
            dismiss(true);
        }
    }

    public final void dismiss(boolean animated) {
        if (!this.open || this.dismissing) {
            return;
        }
        this.dismissing = true;
        if (!animated) {
            finishDismiss();
            return;
        }
        this.scrim.animate().alpha(0.0f).setDuration(170L).start();
        int childCount = this.ring.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = this.ring.getChildAt(i);
            childAt.animate().cancel();
            childAt.animate().scaleX(0.0f).scaleY(0.0f).alpha(0.0f).setStartDelay(RangesKt.coerceAtMost(((long) (childCount - i)) * 7, 80L)).setDuration(145L).setInterpolator(new AccelerateInterpolator()).start();
        }
        postDelayed(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$RadialMenuView$JxQUX1Ip7HBb41ILInxQ2ZZXFK0
            @Override // java.lang.Runnable
            public final void run() {
                RadialMenuView.dismiss$lambda$4(this.f$0);
            }
        }, 300L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void dismiss$lambda$4(RadialMenuView this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.finishDismiss();
    }

    private final void finishDismiss() {
        this.open = false;
        this.dismissing = false;
        this.stack.clear();
        this.pages.clear();
        this.ring.removeAllViews();
        removeAllViews();
        setVisibility(8);
        Function0<Unit> function0 = this.onDismiss;
        if (function0 != null) {
            function0.invoke();
        }
    }
}
