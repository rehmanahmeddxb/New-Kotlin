package com.rehman.ahmedreactionstudio.editor;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.rehman.ahmedreactionstudio.R;
import com.rehman.ahmedreactionstudio.core.Layer;
import com.rehman.ahmedreactionstudio.util.UI;
import java.util.List;
import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: SourcesPanel.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001\u001eB\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0018\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0011H\u0002J.\u0010\u0012\u001a\u00020\r2\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00142\f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\r0\u0019H\u0002J\u001e\u0010\u001a\u001a\u00020\r2\f\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u000f0\u001c2\b\u0010\u001d\u001a\u0004\u0018\u00010\u0014R\u000e\u0010\u0005\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\b\u0010\t\"\u0004\b\n\u0010\u000b"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/SourcesPanel;", "Landroid/widget/LinearLayout;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "list", "listener", "Lcom/rehman/ahmedreactionstudio/editor/SourcesPanel$Listener;", "getListener", "()Lcom/rehman/ahmedreactionstudio/editor/SourcesPanel$Listener;", "setListener", "(Lcom/rehman/ahmedreactionstudio/editor/SourcesPanel$Listener;)V", "addLayerRow", "", "l", "Lcom/rehman/ahmedreactionstudio/core/Layer;", "selected", "", "addShortcut", "name", "", "icon", "", "desc", "onTap", "Lkotlin/Function0;", "bind", "layers", "", "selectedId", "Listener"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nSourcesPanel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SourcesPanel.kt\ncom/rehman/ahmedreactionstudio/editor/SourcesPanel\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,209:1\n1#2:210\n*E\n"})
public final class SourcesPanel extends LinearLayout {

    @NotNull
    private final LinearLayout list;

    @Nullable
    private Listener listener;

    /* JADX INFO: compiled from: SourcesPanel.kt */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0005\bf\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H&J\b\u0010\u0004\u001a\u00020\u0003H&J\b\u0010\u0005\u001a\u00020\u0003H&J\b\u0010\u0006\u001a\u00020\u0003H&J\u0010\u0010\u0007\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\tH&J\u0010\u0010\n\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\tH&J\b\u0010\u000b\u001a\u00020\u0003H&J\b\u0010\f\u001a\u00020\u0003H&J\u0010\u0010\r\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\tH&J\u0010\u0010\u000e\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\tH&"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/SourcesPanel$Listener;", "", "onAdd", "", "onAddImage", "onAddVideo", "onHide", "onMoveDown", "id", "", "onMoveUp", "onProperties", "onRemove", "onSelect", "onToggleVisible"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public interface Listener {
        void onAdd();

        void onAddImage();

        void onAddVideo();

        void onHide();

        void onMoveDown(@NotNull String id);

        void onMoveUp(@NotNull String id);

        void onProperties();

        void onRemove();

        void onSelect(@NotNull String id);

        void onToggleVisible(@NotNull String id);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public SourcesPanel(@NotNull Context context) {
        super(context);
        Intrinsics.checkNotNullParameter(context, "context");
        setOrientation(1);
        setPadding(UI.INSTANCE.dp(context, 12), UI.INSTANCE.dp(context, 10), UI.INSTANCE.dp(context, 12), UI.INSTANCE.dp(context, 10));
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(UI.INSTANCE.dpf(context, 14.0f));
        gradientDrawable.setColor(Color.rgb(18, 20, 26));
        gradientDrawable.setStroke(UI.INSTANCE.dp(context, 1), Color.argb(60, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
        setBackground(gradientDrawable);
        TextView textView = new TextView(context);
        textView.setText("Sources");
        textView.setTextColor(-1);
        textView.setTextSize(16.0f);
        textView.setTypeface(textView.getTypeface(), 1);
        textView.setPadding(0, 0, 0, UI.INSTANCE.dp(context, 8));
        textView.setCompoundDrawablesRelativeWithIntrinsicBounds(Ic.INSTANCE.get(context, R.drawable.ic_layers, -1), (Drawable) null, (Drawable) null, (Drawable) null);
        textView.setCompoundDrawablePadding(UI.INSTANCE.dp(context, 8));
        textView.setGravity(16);
        addView(textView);
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        this.list = linearLayout;
        ScrollView scrollView = new ScrollView(context);
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(true);
        scrollView.addView(this.list, new FrameLayout.LayoutParams(-1, -2));
        addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        LinearLayout linearLayout2 = new LinearLayout(context);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(17);
        linearLayout2.setPadding(0, UI.INSTANCE.dp(context, 8), 0, 0);
        _init_$bottom(context, linearLayout2, "+ Add", "Add a source", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.SourcesPanel.3
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                Listener listener = SourcesPanel.this.getListener();
                if (listener != null) {
                    listener.onAdd();
                }
            }
        });
        _init_$bottom(context, linearLayout2, "− Remove", "Remove the selected source", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.SourcesPanel.4
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                Listener listener = SourcesPanel.this.getListener();
                if (listener != null) {
                    listener.onRemove();
                }
            }
        });
        _init_$bottom(context, linearLayout2, "Hide", "Hide the selected source", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.SourcesPanel.5
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                Listener listener = SourcesPanel.this.getListener();
                if (listener != null) {
                    listener.onHide();
                }
            }
        });
        _init_$bottom(context, linearLayout2, "Properties", "Source properties", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.SourcesPanel.6
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                Listener listener = SourcesPanel.this.getListener();
                if (listener != null) {
                    listener.onProperties();
                }
            }
        });
        addView(linearLayout2, new LinearLayout.LayoutParams(-1, -2));
        bind(CollectionsKt.emptyList(), null);
    }

    @Nullable
    public final Listener getListener() {
        return this.listener;
    }

    public final void setListener(@Nullable Listener listener) {
        this.listener = listener;
    }

    private static final void _init_$bottom(Context context, LinearLayout linearLayout, String str, String str2, final Function0<Unit> function0) {
        Button button = new Button(context);
        button.setText(str);
        button.setTextSize(11.0f);
        button.setAllCaps(false);
        button.setTextColor(-1);
        button.setContentDescription(str2);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        button.setPadding(UI.INSTANCE.dp(context, 4), 0, UI.INSTANCE.dp(context, 4), 0);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(UI.INSTANCE.dpf(context, 10.0f));
        gradientDrawable.setColor(Color.rgb(30, 34, 48));
        gradientDrawable.setStroke(UI.INSTANCE.dp(context, 1), Color.rgb(80, 85, 100));
        button.setBackground(gradientDrawable);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$SourcesPanel$A9vn8ZjGQwpzJNAZT29aJkwy6Dc
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                SourcesPanel.bottom$lambda$7$lambda$6(function0, view);
            }
        });
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, UI.INSTANCE.dp(context, 40), 1.0f);
        layoutParams.setMargins(UI.INSTANCE.dp(context, 3), 0, UI.INSTANCE.dp(context, 3), 0);
        Unit unit = Unit.INSTANCE;
        linearLayout.addView(button, layoutParams);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void bottom$lambda$7$lambda$6(Function0 fn, View view) {
        Intrinsics.checkNotNullParameter(fn, "$fn");
        fn.invoke();
    }

    public final void bind(@NotNull List<Layer> layers, @Nullable String selectedId) {
        Intrinsics.checkNotNullParameter(layers, "layers");
        this.list.removeAllViews();
        if (layers.isEmpty()) {
            addShortcut("Camera", R.drawable.ic_camera, "Add the live camera", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.SourcesPanel.bind.1
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    Listener listener = SourcesPanel.this.getListener();
                    if (listener != null) {
                        listener.onAdd();
                    }
                }
            });
            addShortcut("Local Video", R.drawable.ic_video, "Add a local video", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.SourcesPanel.bind.2
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    Listener listener = SourcesPanel.this.getListener();
                    if (listener != null) {
                        listener.onAddVideo();
                    }
                }
            });
            addShortcut("Image", R.drawable.ic_image, "Add an image", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.SourcesPanel.bind.3
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    Listener listener = SourcesPanel.this.getListener();
                    if (listener != null) {
                        listener.onAddImage();
                    }
                }
            });
            TextView textView = new TextView(getContext());
            textView.setText("Tap a row or + Add");
            textView.setTextColor(Color.rgb(140, 148, 162));
            textView.setTextSize(11.0f);
            UI ui = UI.INSTANCE;
            Context context = textView.getContext();
            Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
            textView.setPadding(0, ui.dp(context, 8), 0, 0);
            this.list.addView(textView);
            return;
        }
        for (Layer layer : CollectionsKt.asReversed(layers)) {
            addLayerRow(layer, Intrinsics.areEqual(layer.getId(), selectedId));
        }
    }

    private final void addShortcut(String name, int icon, String desc, final Function0<Unit> onTap) {
        LinearLayout linearLayout = new LinearLayout(getContext());
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        UI ui = UI.INSTANCE;
        Context context = linearLayout.getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        int iDp = ui.dp(context, 6);
        UI ui2 = UI.INSTANCE;
        Context context2 = linearLayout.getContext();
        Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
        int iDp2 = ui2.dp(context2, 8);
        UI ui3 = UI.INSTANCE;
        Context context3 = linearLayout.getContext();
        Intrinsics.checkNotNullExpressionValue(context3, "getContext(...)");
        int iDp3 = ui3.dp(context3, 6);
        UI ui4 = UI.INSTANCE;
        Context context4 = linearLayout.getContext();
        Intrinsics.checkNotNullExpressionValue(context4, "getContext(...)");
        linearLayout.setPadding(iDp, iDp2, iDp3, ui4.dp(context4, 8));
        linearLayout.setClickable(true);
        linearLayout.setFocusable(true);
        linearLayout.setContentDescription(desc);
        UI ui5 = UI.INSTANCE;
        Context context5 = linearLayout.getContext();
        Intrinsics.checkNotNullExpressionValue(context5, "getContext(...)");
        linearLayout.setMinimumHeight(ui5.dp(context5, 44));
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$SourcesPanel$ocqx8QcCZRIv926lWL8HTkKMI_c
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                SourcesPanel.addShortcut$lambda$11$lambda$10(onTap, view);
            }
        });
        ImageView imageView = new ImageView(getContext());
        Ic ic = Ic.INSTANCE;
        Context context6 = imageView.getContext();
        Intrinsics.checkNotNullExpressionValue(context6, "getContext(...)");
        imageView.setImageDrawable(ic.get(context6, icon, Color.rgb(200, 210, 230)));
        UI ui6 = UI.INSTANCE;
        Context context7 = getContext();
        Intrinsics.checkNotNullExpressionValue(context7, "getContext(...)");
        int iDp4 = ui6.dp(context7, 22);
        UI ui7 = UI.INSTANCE;
        Context context8 = getContext();
        Intrinsics.checkNotNullExpressionValue(context8, "getContext(...)");
        linearLayout.addView(imageView, new LinearLayout.LayoutParams(iDp4, ui7.dp(context8, 22)));
        TextView textView = new TextView(getContext());
        textView.setText(name);
        textView.setTextColor(Color.rgb(230, 232, 238));
        textView.setTextSize(13.0f);
        UI ui8 = UI.INSTANCE;
        Context context9 = textView.getContext();
        Intrinsics.checkNotNullExpressionValue(context9, "getContext(...)");
        textView.setPadding(ui8.dp(context9, 8), 0, 0, 0);
        linearLayout.addView(textView, new LinearLayout.LayoutParams(0, -2, 1.0f));
        this.list.addView(linearLayout);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void addShortcut$lambda$11$lambda$10(Function0 onTap, View view) {
        Intrinsics.checkNotNullParameter(onTap, "$onTap");
        onTap.invoke();
    }

    private final void addLayerRow(final Layer l, boolean selected) {
        StringBuilder sb;
        String str;
        LinearLayout linearLayout = new LinearLayout(getContext());
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        UI ui = UI.INSTANCE;
        Context context = linearLayout.getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        int iDp = ui.dp(context, 6);
        UI ui2 = UI.INSTANCE;
        Context context2 = linearLayout.getContext();
        Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
        int iDp2 = ui2.dp(context2, 6);
        UI ui3 = UI.INSTANCE;
        Context context3 = linearLayout.getContext();
        Intrinsics.checkNotNullExpressionValue(context3, "getContext(...)");
        int iDp3 = ui3.dp(context3, 4);
        UI ui4 = UI.INSTANCE;
        Context context4 = linearLayout.getContext();
        Intrinsics.checkNotNullExpressionValue(context4, "getContext(...)");
        linearLayout.setPadding(iDp, iDp2, iDp3, ui4.dp(context4, 6));
        linearLayout.setClickable(true);
        linearLayout.setFocusable(true);
        linearLayout.setSelected(selected);
        UI ui5 = UI.INSTANCE;
        Context context5 = linearLayout.getContext();
        Intrinsics.checkNotNullExpressionValue(context5, "getContext(...)");
        linearLayout.setMinimumHeight(ui5.dp(context5, 44));
        StringBuilder sb2 = new StringBuilder();
        sb2.append("Select ");
        String name = l.getName();
        if (StringsKt.isBlank(name)) {
            name = l.getType().getLabel();
        }
        sb2.append(name);
        linearLayout.setContentDescription(sb2.toString());
        GradientDrawable gradientDrawable = new GradientDrawable();
        UI ui6 = UI.INSTANCE;
        Context context6 = linearLayout.getContext();
        Intrinsics.checkNotNullExpressionValue(context6, "getContext(...)");
        gradientDrawable.setCornerRadius(ui6.dpf(context6, 8.0f));
        gradientDrawable.setColor(selected ? Color.rgb(36, 72, 120) : 0);
        linearLayout.setBackground(gradientDrawable);
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$SourcesPanel$nCh-IznvbzjhCtxjkQ7nKrF2ad4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                SourcesPanel.addLayerRow$lambda$17$lambda$16(this.f$0, l, view);
            }
        });
        ImageView imageView = new ImageView(getContext());
        Ic ic = Ic.INSTANCE;
        Context context7 = imageView.getContext();
        Intrinsics.checkNotNullExpressionValue(context7, "getContext(...)");
        imageView.setImageDrawable(ic.get(context7, Ic.INSTANCE.typeIcon(l.getType()), selected ? -1 : Color.rgb(200, 210, 230)));
        UI ui7 = UI.INSTANCE;
        Context context8 = getContext();
        Intrinsics.checkNotNullExpressionValue(context8, "getContext(...)");
        int iDp4 = ui7.dp(context8, 22);
        UI ui8 = UI.INSTANCE;
        Context context9 = getContext();
        Intrinsics.checkNotNullExpressionValue(context9, "getContext(...)");
        linearLayout.addView(imageView, new LinearLayout.LayoutParams(iDp4, ui8.dp(context9, 22)));
        TextView textView = new TextView(getContext());
        String name2 = l.getName();
        if (StringsKt.isBlank(name2)) {
            name2 = l.getType().getLabel();
        }
        textView.setText(name2);
        textView.setTextColor(l.getVisible() ? Color.rgb(230, 232, 238) : Color.argb(140, 230, 232, 238));
        textView.setTextSize(13.0f);
        textView.setMaxLines(1);
        UI ui9 = UI.INSTANCE;
        Context context10 = textView.getContext();
        Intrinsics.checkNotNullExpressionValue(context10, "getContext(...)");
        textView.setPadding(ui9.dp(context10, 8), 0, 0, 0);
        linearLayout.addView(textView, new LinearLayout.LayoutParams(0, -2, 1.0f));
        ImageButton imageButton = new ImageButton(getContext());
        Ic ic2 = Ic.INSTANCE;
        Context context11 = imageButton.getContext();
        Intrinsics.checkNotNullExpressionValue(context11, "getContext(...)");
        imageButton.setImageDrawable(ic2.get(context11, R.drawable.ic_up, -1));
        imageButton.setBackgroundColor(0);
        imageButton.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$SourcesPanel$Ey1pxS11opG2GoGAmelFj0qZhe0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                SourcesPanel.addLayerRow$lambda$22$lambda$21(this.f$0, l, view);
            }
        });
        UI ui10 = UI.INSTANCE;
        Context context12 = getContext();
        Intrinsics.checkNotNullExpressionValue(context12, "getContext(...)");
        int iDp5 = ui10.dp(context12, 36);
        UI ui11 = UI.INSTANCE;
        Context context13 = getContext();
        Intrinsics.checkNotNullExpressionValue(context13, "getContext(...)");
        linearLayout.addView(imageButton, new LinearLayout.LayoutParams(iDp5, ui11.dp(context13, 36)));
        ImageButton imageButton2 = new ImageButton(getContext());
        Ic ic3 = Ic.INSTANCE;
        Context context14 = imageButton2.getContext();
        Intrinsics.checkNotNullExpressionValue(context14, "getContext(...)");
        imageButton2.setImageDrawable(ic3.get(context14, R.drawable.ic_down, -1));
        imageButton2.setBackgroundColor(0);
        imageButton2.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$SourcesPanel$4Jkl1M7-I-epUFAqvk-QHpozlCo
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                SourcesPanel.addLayerRow$lambda$24$lambda$23(this.f$0, l, view);
            }
        });
        UI ui12 = UI.INSTANCE;
        Context context15 = getContext();
        Intrinsics.checkNotNullExpressionValue(context15, "getContext(...)");
        int iDp6 = ui12.dp(context15, 36);
        UI ui13 = UI.INSTANCE;
        Context context16 = getContext();
        Intrinsics.checkNotNullExpressionValue(context16, "getContext(...)");
        linearLayout.addView(imageButton2, new LinearLayout.LayoutParams(iDp6, ui13.dp(context16, 36)));
        ImageButton imageButton3 = new ImageButton(getContext());
        Ic ic4 = Ic.INSTANCE;
        Context context17 = imageButton3.getContext();
        Intrinsics.checkNotNullExpressionValue(context17, "getContext(...)");
        imageButton3.setImageDrawable(ic4.get(context17, l.getVisible() ? R.drawable.ic_eye : R.drawable.ic_eye_off, l.getVisible() ? -1 : Color.argb(140, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE)));
        imageButton3.setBackgroundColor(0);
        if (l.getVisible()) {
            sb = new StringBuilder();
            str = "Hide ";
        } else {
            sb = new StringBuilder();
            str = "Show ";
        }
        sb.append(str);
        sb.append(l.getName());
        imageButton3.setContentDescription(sb.toString());
        imageButton3.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$SourcesPanel$0ygTCVT1Y2usMOvDiEQQb3XCoqY
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                SourcesPanel.addLayerRow$lambda$26$lambda$25(this.f$0, l, view);
            }
        });
        UI ui14 = UI.INSTANCE;
        Context context18 = getContext();
        Intrinsics.checkNotNullExpressionValue(context18, "getContext(...)");
        int iDp7 = ui14.dp(context18, 36);
        UI ui15 = UI.INSTANCE;
        Context context19 = getContext();
        Intrinsics.checkNotNullExpressionValue(context19, "getContext(...)");
        linearLayout.addView(imageButton3, new LinearLayout.LayoutParams(iDp7, ui15.dp(context19, 36)));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        UI ui16 = UI.INSTANCE;
        Context context20 = getContext();
        Intrinsics.checkNotNullExpressionValue(context20, "getContext(...)");
        layoutParams.bottomMargin = ui16.dp(context20, 2);
        Unit unit = Unit.INSTANCE;
        this.list.addView(linearLayout, layoutParams);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void addLayerRow$lambda$17$lambda$16(SourcesPanel this$0, Layer l, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(l, "$l");
        Listener listener = this$0.listener;
        if (listener != null) {
            listener.onSelect(l.getId());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void addLayerRow$lambda$22$lambda$21(SourcesPanel this$0, Layer l, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(l, "$l");
        Listener listener = this$0.listener;
        if (listener != null) {
            listener.onMoveUp(l.getId());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void addLayerRow$lambda$24$lambda$23(SourcesPanel this$0, Layer l, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(l, "$l");
        Listener listener = this$0.listener;
        if (listener != null) {
            listener.onMoveDown(l.getId());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void addLayerRow$lambda$26$lambda$25(SourcesPanel this$0, Layer l, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(l, "$l");
        Listener listener = this$0.listener;
        if (listener != null) {
            listener.onToggleVisible(l.getId());
        }
    }
}
