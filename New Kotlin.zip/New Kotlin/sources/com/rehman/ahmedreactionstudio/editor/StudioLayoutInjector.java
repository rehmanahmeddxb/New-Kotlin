package com.rehman.ahmedreactionstudio.editor;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import com.rehman.ahmedreactionstudio.R;
import com.rehman.ahmedreactionstudio.core.Aspect;
import com.rehman.ahmedreactionstudio.core.Layer;
import com.rehman.ahmedreactionstudio.core.Project;
import com.rehman.ahmedreactionstudio.editor.MixerPanel;
import com.rehman.ahmedreactionstudio.editor.SourcesPanel;
import com.rehman.ahmedreactionstudio.util.UI;
import java.util.List;
import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: StudioLayoutInjector.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J(\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fH\u0002J\u0018\u0010\r\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u000e\u001a\u00020\u000fH\u0002J\u0016\u0010\u0010\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u0012JJ\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u00182\b\b\u0002\u0010\u001a\u001a\u00020\u00182\b\b\u0002\u0010\u001b\u001a\u00020\u001c2\f\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u00040\u001eH\u0002"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/StudioLayoutInjector;", "", "()V", "bindPanels", "", "activity", "Lcom/rehman/ahmedreactionstudio/editor/EditorActivity;", "sourcesPanel", "Lcom/rehman/ahmedreactionstudio/editor/SourcesPanel;", "mixerPanel", "Lcom/rehman/ahmedreactionstudio/editor/MixerPanel;", "propertiesPanel", "Landroid/view/View;", "buildTransport", "bar", "Landroid/widget/LinearLayout;", "inject", "root", "Landroid/widget/FrameLayout;", "pillBtn", "Landroid/widget/TextView;", "text", "", "textColor", "", Layer.FIT_FILL, "heightDp", "bold", "", "onClick", "Lkotlin/Function0;"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nStudioLayoutInjector.kt\nKotlin\n*S Kotlin\n*F\n+ 1 StudioLayoutInjector.kt\ncom/rehman/ahmedreactionstudio/editor/StudioLayoutInjector\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,635:1\n1#2:636\n*E\n"})
public final class StudioLayoutInjector {

    @NotNull
    public static final StudioLayoutInjector INSTANCE = new StudioLayoutInjector();

    private StudioLayoutInjector() {
    }

    static /* synthetic */ TextView pillBtn$default(StudioLayoutInjector studioLayoutInjector, EditorActivity editorActivity, String str, int i, int i2, int i3, boolean z, Function0 function0, int i4, Object obj) {
        return studioLayoutInjector.pillBtn(editorActivity, str, i, i2, (i4 & 16) != 0 ? 32 : i3, (i4 & 32) != 0 ? true : z, function0);
    }

    private final TextView pillBtn(EditorActivity activity, String text, int textColor, int fill, int heightDp, boolean bold, final Function0<Unit> onClick) {
        EditorActivity editorActivity = activity;
        TextView textView = new TextView(editorActivity);
        textView.setText(text);
        textView.setTextSize(12.0f);
        textView.setTypeface(Typeface.create("sans-serif-medium", bold ? 1 : 0));
        textView.setAllCaps(false);
        textView.setGravity(17);
        textView.setTextColor(textColor);
        textView.setIncludeFontPadding(false);
        textView.setPadding(UI.INSTANCE.dp(editorActivity, 12), 0, UI.INSTANCE.dp(editorActivity, 12), 0);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(UI.INSTANCE.dpf(editorActivity, heightDp / 2.0f));
        gradientDrawable.setColor(fill);
        gradientDrawable.setStroke(UI.INSTANCE.dp(editorActivity, 1), Color.argb(70, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
        textView.setBackground(gradientDrawable);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, UI.INSTANCE.dp(editorActivity, heightDp));
        layoutParams.setMargins(UI.INSTANCE.dp(editorActivity, 2), 0, UI.INSTANCE.dp(editorActivity, 2), 0);
        textView.setLayoutParams(layoutParams);
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$StudioLayoutInjector$-pDC_HLFfDoZ4XVWWy_1IuTJTB8
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                StudioLayoutInjector.pillBtn$lambda$0(onClick, view);
            }
        });
        return textView;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void pillBtn$lambda$0(Function0 onClick, View view) {
        Intrinsics.checkNotNullParameter(onClick, "$onClick");
        onClick.invoke();
    }

    public final void inject(@NotNull final EditorActivity activity, @NotNull FrameLayout root) {
        List<Layer> listEmptyList;
        List<Layer> listEmptyList2;
        Intrinsics.checkNotNullParameter(activity, "activity");
        Intrinsics.checkNotNullParameter(root, "root");
        DisplayMetrics displayMetrics = activity.getResources().getDisplayMetrics();
        boolean z = displayMetrics.widthPixels > displayMetrics.heightPixels;
        EditorActivity editorActivity = activity;
        activity.setEmptyOverlay(new LinearLayout(editorActivity));
        activity.setPlayBtn(new IconBtn(editorActivity));
        activity.setTimeLabel(new TextView(editorActivity));
        activity.setDurationLabel(new TextView(editorActivity));
        activity.setSeek(new SeekBar(editorActivity));
        activity.setAspectChip(new TextView(editorActivity));
        activity.setQuickBar(new LinearLayout(editorActivity));
        activity.setPanelDivider(new View(editorActivity));
        activity.setPanelContent(new LinearLayout(editorActivity));
        activity.setSheet(new LinearLayout(editorActivity));
        activity.setDockContainer(new LinearLayout(editorActivity));
        activity.setRecChip(new TextView(editorActivity));
        activity.setStatsHud(new TextView(editorActivity));
        activity.setHiddenPill(new TextView(editorActivity));
        activity.setDock(new SourceDock(activity, activity.getDockContainer(), new Function0<Project>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector.inject.1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final Project invoke() {
                Project proj = activity.getProj();
                return proj == null ? new Project("", "", Aspect.R169, 0, null, 0L, 0L, 0L, 248, null) : proj;
            }
        }, new Function0<String>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector.inject.2
            @Override // kotlin.jvm.functions.Function0
            @Nullable
            public final String invoke() {
                return null;
            }
        }, new Function1<String, Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector.inject.3
            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@Nullable String str) {
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(String str) {
                invoke2(str);
                return Unit.INSTANCE;
            }
        }, new Function2<Layer, String, Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector.inject.4
            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer layer, @NotNull String str) {
                Intrinsics.checkNotNullParameter(layer, "<anonymous parameter 0>");
                Intrinsics.checkNotNullParameter(str, "<anonymous parameter 1>");
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer, String str) {
                invoke2(layer, str);
                return Unit.INSTANCE;
            }
        }, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector.inject.5
            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer it) {
                Intrinsics.checkNotNullParameter(it, "it");
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }
        }, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector.inject.6
            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer it) {
                Intrinsics.checkNotNullParameter(it, "it");
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }
        }, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector.inject.7
            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }
        }, new Function2<Integer, Integer, Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector.inject.8
            public final void invoke(int i, int i2) {
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Integer num, Integer num2) {
                invoke(num.intValue(), num2.intValue());
                return Unit.INSTANCE;
            }
        }, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector.inject.9
            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }
        }));
        activity.setStudioBtn(new IconBtn(editorActivity));
        activity.setTabBar(new LinearLayout(editorActivity));
        activity.setTransportBar(new LinearLayout(editorActivity));
        activity.setSourceStripWrap(new HorizontalScrollView(editorActivity));
        activity.setSourceStrip(new LinearLayout(editorActivity));
        activity.setTopBar(new LinearLayout(editorActivity));
        activity.setQuickWrap(new HorizontalScrollView(editorActivity));
        activity.setFullExitBtn(new TextView(editorActivity));
        activity.setPanelScroll(new ScrollView(editorActivity));
        activity.setLaunchRow(new LinearLayout(editorActivity));
        activity.setSideRail(new ScrollView(editorActivity));
        activity.setRailContent(new LinearLayout(editorActivity));
        activity.setRecordBtn(new TextView(editorActivity));
        LinearLayout linearLayout = new LinearLayout(editorActivity);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        linearLayout.setBackgroundColor(Color.rgb(18, 20, 26));
        root.addView(linearLayout);
        LinearLayout linearLayout2 = new LinearLayout(editorActivity);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        linearLayout2.setPadding(UI.INSTANCE.dp(editorActivity, 12), UI.INSTANCE.dp(editorActivity, 8), UI.INSTANCE.dp(editorActivity, 12), UI.INSTANCE.dp(editorActivity, 8));
        linearLayout2.setBackgroundColor(Color.rgb(12, 14, 19));
        linearLayout.addView(linearLayout2, new LinearLayout.LayoutParams(-1, 0, 0.07f));
        TextView textView = new TextView(editorActivity);
        textView.setText("← Studio");
        textView.setTextColor(-1);
        textView.setTextSize(16.0f);
        textView.setTypeface(Typeface.create("sans-serif-medium", 1));
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$StudioLayoutInjector$M3yANOmdtGKAN4kgVeUAhRbOpfU
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                StudioLayoutInjector.inject$lambda$2$lambda$1(activity, view);
            }
        });
        linearLayout2.addView(textView, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView2 = new TextView(editorActivity);
        textView2.setText("16:9 ▾");
        textView2.setTextColor(-1);
        textView2.setPadding(UI.INSTANCE.dp(editorActivity, 8), UI.INSTANCE.dp(editorActivity, 4), UI.INSTANCE.dp(editorActivity, 8), UI.INSTANCE.dp(editorActivity, 4));
        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$StudioLayoutInjector$mxHxAQF0_WLMMAVuaHD0FdfxV08
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                StudioLayoutInjector.inject$lambda$4$lambda$3(activity, view);
            }
        });
        activity.setAspectChip(textView2);
        linearLayout2.addView(textView2);
        ImageView imageView = new ImageView(editorActivity);
        imageView.setImageDrawable(Ic.INSTANCE.get(editorActivity, R.drawable.ic_settings, -1));
        imageView.setPadding(UI.INSTANCE.dp(editorActivity, 8), UI.INSTANCE.dp(editorActivity, 4), UI.INSTANCE.dp(editorActivity, 8), UI.INSTANCE.dp(editorActivity, 4));
        imageView.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$StudioLayoutInjector$te_ilYBTbkG4S1oVwxAY_UNaC6o
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                StudioLayoutInjector.inject$lambda$6$lambda$5(activity, view);
            }
        });
        linearLayout2.addView(imageView);
        linearLayout2.addView(pillBtn$default(this, activity, "Save", -1, Color.rgb(230, 70, 32), 30, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector$inject$saveBtnTop$1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                activity.saveNow();
            }
        }, 32, null));
        linearLayout2.addView(pillBtn$default(this, activity, "Export", -1, UI.INSTANCE.getACCENT2(), 30, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector$inject$exportBtnTop$1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                activity.quickExport();
            }
        }, 32, null));
        if (!z) {
            FrameLayout frameLayout = new FrameLayout(editorActivity);
            frameLayout.setBackgroundColor(Color.rgb(4, 5, 7));
            linearLayout.addView(frameLayout, new LinearLayout.LayoutParams(-1, 0, 0.5f));
            activity.setStage(new StageView(editorActivity, null, 2, null));
            activity.getStage().setHost(activity);
            frameLayout.addView(activity.getStage(), new FrameLayout.LayoutParams(-1, -1, 17));
            LinearLayout linearLayout3 = new LinearLayout(editorActivity);
            linearLayout3.setOrientation(1);
            linearLayout.addView(linearLayout3, new LinearLayout.LayoutParams(-1, 0, 0.2f));
            LinearLayout linearLayout4 = new LinearLayout(editorActivity);
            linearLayout4.setOrientation(0);
            linearLayout3.addView(linearLayout4, new LinearLayout.LayoutParams(-1, -2));
            FrameLayout frameLayout2 = new FrameLayout(editorActivity);
            linearLayout3.addView(frameLayout2, new LinearLayout.LayoutParams(-1, 0, 1.0f));
            SourcesPanel sourcesPanel = new SourcesPanel(editorActivity);
            MixerPanel mixerPanel = new MixerPanel(editorActivity);
            FrameLayout frameLayout3 = new FrameLayout(editorActivity);
            ScrollView scrollView = new ScrollView(editorActivity);
            scrollView.addView(activity.getPanelContent(), new FrameLayout.LayoutParams(-1, -2));
            frameLayout3.addView(scrollView, new FrameLayout.LayoutParams(-1, -1));
            TextView textView3 = new TextView(editorActivity);
            textView3.setText("Select an object to edit its properties");
            textView3.setTextColor(-1);
            textView3.setGravity(17);
            activity.getPanelContent().addView(textView3, new LinearLayout.LayoutParams(-1, -1));
            EffectsPanel effectsPanel = new EffectsPanel(editorActivity);
            activity.setSourcesPanel(sourcesPanel);
            activity.setMixerPanel(mixerPanel);
            SourcesPanel sourcesPanel2 = sourcesPanel;
            frameLayout2.addView(sourcesPanel2, new FrameLayout.LayoutParams(-1, -1));
            MixerPanel mixerPanel2 = mixerPanel;
            frameLayout2.addView(mixerPanel2, new FrameLayout.LayoutParams(-1, -1));
            FrameLayout frameLayout4 = frameLayout3;
            frameLayout2.addView(frameLayout4, new FrameLayout.LayoutParams(-1, -1));
            EffectsPanel effectsPanel2 = effectsPanel;
            frameLayout2.addView(effectsPanel2, new FrameLayout.LayoutParams(-1, -1));
            inject$createTab$23(activity, linearLayout4, sourcesPanel, mixerPanel, frameLayout3, effectsPanel, linearLayout3, "Sources", sourcesPanel2);
            inject$createTab$23(activity, linearLayout4, sourcesPanel, mixerPanel, frameLayout3, effectsPanel, linearLayout3, "Mixer", mixerPanel2);
            inject$createTab$23(activity, linearLayout4, sourcesPanel, mixerPanel, frameLayout3, effectsPanel, linearLayout3, "Props", frameLayout4);
            inject$createTab$23(activity, linearLayout4, sourcesPanel, mixerPanel, frameLayout3, effectsPanel, linearLayout3, "Effects", effectsPanel2);
            inject$createTab$23(activity, linearLayout4, sourcesPanel, mixerPanel, frameLayout3, effectsPanel, linearLayout3, "X", null);
            inject$showPanel$19(sourcesPanel, mixerPanel, frameLayout3, effectsPanel, linearLayout3, sourcesPanel2);
            LinearLayout linearLayout5 = new LinearLayout(editorActivity);
            linearLayout5.setOrientation(1);
            linearLayout5.setBackgroundColor(Color.rgb(15, 17, 22));
            linearLayout.addView(linearLayout5, new LinearLayout.LayoutParams(-1, 0, 0.15f));
            ScrollView scrollView2 = new ScrollView(editorActivity);
            LinearLayout linearLayout6 = new LinearLayout(editorActivity);
            linearLayout6.setOrientation(1);
            linearLayout6.setPadding(UI.INSTANCE.dp(editorActivity, 8), UI.INSTANCE.dp(editorActivity, 8), UI.INSTANCE.dp(editorActivity, 8), UI.INSTANCE.dp(editorActivity, 8));
            scrollView2.addView(linearLayout6);
            LinearLayout linearLayout7 = new LinearLayout(editorActivity);
            linearLayout7.setOrientation(0);
            linearLayout7.setGravity(16);
            SeekBar seekBar = new SeekBar(editorActivity);
            seekBar.setProgressTintList(ColorStateList.valueOf(UI.INSTANCE.getACCENT()));
            seekBar.setThumbTintList(ColorStateList.valueOf(UI.INSTANCE.getACCENT2()));
            Project proj = activity.getProj();
            seekBar.setMax(proj != null ? RangesKt.coerceAtLeast((int) proj.durationMs(), 1) : 1);
            seekBar.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector$inject$seek$2$1
                @Override // android.widget.SeekBar.OnSeekBarChangeListener
                public void onProgressChanged(@Nullable SeekBar sb, int v, boolean fromUser) {
                    if (fromUser) {
                        long j = v;
                        activity.getTimeLabel().setText(UI.INSTANCE.fmtTime(j));
                        if (activity.engineReady()) {
                            activity.getEngine().seekTo(j);
                        }
                    }
                }

                @Override // android.widget.SeekBar.OnSeekBarChangeListener
                public void onStartTrackingTouch(@Nullable SeekBar sb) {
                    activity.setScrubbing(true);
                }

                @Override // android.widget.SeekBar.OnSeekBarChangeListener
                public void onStopTrackingTouch(@Nullable SeekBar sb) {
                    activity.setScrubbing(false);
                    if (activity.engineReady()) {
                        activity.getEngine().refreshFrames();
                    }
                }
            });
            activity.setSeek(seekBar);
            activity.setSeek(seekBar);
            linearLayout7.addView(seekBar);
            linearLayout6.addView(linearLayout7);
            HorizontalScrollView horizontalScrollView = new HorizontalScrollView(editorActivity);
            horizontalScrollView.setHorizontalScrollBarEnabled(false);
            LinearLayout linearLayout8 = new LinearLayout(editorActivity);
            linearLayout8.setOrientation(0);
            Project proj2 = activity.getProj();
            if (proj2 == null || (listEmptyList = proj2.getLayers()) == null) {
                listEmptyList = CollectionsKt.emptyList();
            }
            for (Layer layer : listEmptyList) {
                TextView textView4 = new TextView(editorActivity);
                String name = layer.getName();
                if (StringsKt.isBlank(name)) {
                    name = layer.getType().getLabel();
                }
                textView4.setText(name);
                textView4.setTextColor(-1);
                textView4.setTextSize(10.0f);
                textView4.setBackgroundColor(Color.rgb(30, 34, 48));
                textView4.setPadding(UI.INSTANCE.dp(editorActivity, 8), UI.INSTANCE.dp(editorActivity, 4), UI.INSTANCE.dp(editorActivity, 8), UI.INSTANCE.dp(editorActivity, 4));
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
                layoutParams.setMarginEnd(UI.INSTANCE.dp(editorActivity, 4));
                linearLayout8.addView(textView4, layoutParams);
            }
            horizontalScrollView.addView(linearLayout8);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams2.topMargin = UI.INSTANCE.dp(editorActivity, 2);
            Unit unit = Unit.INSTANCE;
            linearLayout6.addView(horizontalScrollView, layoutParams2);
            linearLayout5.addView(scrollView2, new LinearLayout.LayoutParams(-1, -1));
            LinearLayout linearLayout9 = new LinearLayout(editorActivity);
            linearLayout9.setOrientation(0);
            linearLayout9.setGravity(16);
            linearLayout9.setBackgroundColor(Color.rgb(9, 10, 14));
            linearLayout.addView(linearLayout9, new LinearLayout.LayoutParams(-1, 0, 0.08f));
            activity.setTransportBar(linearLayout9);
            buildTransport(activity, linearLayout9);
            bindPanels(activity, sourcesPanel, mixerPanel, frameLayout4);
            return;
        }
        LinearLayout linearLayout10 = new LinearLayout(editorActivity);
        linearLayout10.setOrientation(0);
        int i = -1;
        linearLayout.addView(linearLayout10, new LinearLayout.LayoutParams(-1, 0, 0.74f));
        LinearLayout linearLayout11 = new LinearLayout(editorActivity);
        linearLayout11.setOrientation(1);
        linearLayout11.setGravity(1);
        linearLayout11.setBackgroundColor(Color.rgb(15, 17, 22));
        linearLayout10.addView(linearLayout11, new LinearLayout.LayoutParams(0, -1, 0.08f));
        List<Triple> listListOf = CollectionsKt.listOf((Object[]) new Triple[]{new Triple(Integer.valueOf(R.drawable.ic_add), "Add", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector$inject$tools$1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                activity.openAddSourceChooser();
            }
        }), new Triple(Integer.valueOf(R.drawable.ic_camera), "Camera", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector$inject$tools$2
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.addLiveCamera$default(activity, false, 1, null);
            }
        }), new Triple(Integer.valueOf(R.drawable.ic_video), "Video", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector$inject$tools$3
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                activity.pickMedia(true);
            }
        }), new Triple(Integer.valueOf(R.drawable.ic_image), "Image", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector$inject$tools$4
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                activity.pickMedia(false);
            }
        }), new Triple(Integer.valueOf(R.drawable.ic_flash), "Light", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector$inject$tools$5
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                activity.openLightMenuFromToolbar();
            }
        }), new Triple(Integer.valueOf(R.drawable.ic_text), "Text", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector$inject$tools$6
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                activity.addText();
            }
        }), new Triple(Integer.valueOf(R.drawable.ic_undo), "Undo", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector$inject$tools$7
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                activity.doUndo();
            }
        }), new Triple(Integer.valueOf(R.drawable.ic_redo), "Redo", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector$inject$tools$8
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                activity.doRedo();
            }
        })});
        ScrollView scrollView3 = new ScrollView(editorActivity);
        scrollView3.setVerticalScrollBarEnabled(false);
        LinearLayout linearLayout12 = new LinearLayout(editorActivity);
        linearLayout12.setOrientation(1);
        linearLayout12.setGravity(1);
        for (Triple triple : listListOf) {
            int iIntValue = ((Number) triple.component1()).intValue();
            String str = (String) triple.component2();
            final Function0 function0 = (Function0) triple.component3();
            ImageView imageView2 = new ImageView(editorActivity);
            imageView2.setImageDrawable(Ic.INSTANCE.get(editorActivity, iIntValue, i));
            imageView2.setPadding(0, UI.INSTANCE.dp(editorActivity, 12), 0, UI.INSTANCE.dp(editorActivity, 12));
            imageView2.setContentDescription(str);
            imageView2.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$StudioLayoutInjector$H3TsYkdBv75ZrvmpIwr979q0-_U
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    StudioLayoutInjector.inject$lambda$8$lambda$7(function0, view);
                }
            });
            linearLayout12.addView(imageView2, new LinearLayout.LayoutParams(UI.INSTANCE.dp(editorActivity, 44), UI.INSTANCE.dp(editorActivity, 44)));
            i = -1;
        }
        scrollView3.addView(linearLayout12);
        linearLayout11.addView(scrollView3);
        FrameLayout frameLayout5 = new FrameLayout(editorActivity);
        frameLayout5.setBackgroundColor(Color.rgb(4, 5, 7));
        linearLayout10.addView(frameLayout5, new LinearLayout.LayoutParams(0, -1, 0.67f));
        activity.setStage(new StageView(editorActivity, null, 2, null));
        activity.getStage().setHost(activity);
        frameLayout5.addView(activity.getStage(), new FrameLayout.LayoutParams(-1, -1, 17));
        LinearLayout linearLayout13 = new LinearLayout(editorActivity);
        linearLayout13.setOrientation(1);
        linearLayout13.setBackgroundColor(Color.rgb(18, 20, 26));
        linearLayout10.addView(linearLayout13, new LinearLayout.LayoutParams(0, -1, 0.25f));
        LinearLayout linearLayout14 = new LinearLayout(editorActivity);
        linearLayout14.setOrientation(0);
        linearLayout13.addView(linearLayout14, new LinearLayout.LayoutParams(-1, -2));
        FrameLayout frameLayout6 = new FrameLayout(editorActivity);
        linearLayout13.addView(frameLayout6, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        SourcesPanel sourcesPanel3 = new SourcesPanel(editorActivity);
        MixerPanel mixerPanel3 = new MixerPanel(editorActivity);
        FrameLayout frameLayout7 = new FrameLayout(editorActivity);
        ScrollView scrollView4 = new ScrollView(editorActivity);
        scrollView4.addView(activity.getPanelContent(), new FrameLayout.LayoutParams(-1, -2));
        frameLayout7.addView(scrollView4, new FrameLayout.LayoutParams(-1, -1));
        TextView textView5 = new TextView(editorActivity);
        textView5.setText("Select an object to edit its properties");
        textView5.setTextColor(-1);
        textView5.setGravity(17);
        activity.getPanelContent().addView(textView5, new LinearLayout.LayoutParams(-1, -1));
        EffectsPanel effectsPanel3 = new EffectsPanel(editorActivity);
        activity.setSourcesPanel(sourcesPanel3);
        activity.setMixerPanel(mixerPanel3);
        SourcesPanel sourcesPanel4 = sourcesPanel3;
        frameLayout6.addView(sourcesPanel4, new FrameLayout.LayoutParams(-1, -1));
        MixerPanel mixerPanel4 = mixerPanel3;
        frameLayout6.addView(mixerPanel4, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout frameLayout8 = frameLayout7;
        frameLayout6.addView(frameLayout8, new FrameLayout.LayoutParams(-1, -1));
        EffectsPanel effectsPanel4 = effectsPanel3;
        frameLayout6.addView(effectsPanel4, new FrameLayout.LayoutParams(-1, -1));
        inject$createTab(activity, linearLayout14, sourcesPanel3, mixerPanel3, frameLayout7, effectsPanel3, linearLayout13, "Sources", sourcesPanel4);
        inject$createTab(activity, linearLayout14, sourcesPanel3, mixerPanel3, frameLayout7, effectsPanel3, linearLayout13, "Mixer", mixerPanel4);
        inject$createTab(activity, linearLayout14, sourcesPanel3, mixerPanel3, frameLayout7, effectsPanel3, linearLayout13, "Props", frameLayout8);
        inject$createTab(activity, linearLayout14, sourcesPanel3, mixerPanel3, frameLayout7, effectsPanel3, linearLayout13, "Effects", effectsPanel4);
        inject$createTab(activity, linearLayout14, sourcesPanel3, mixerPanel3, frameLayout7, effectsPanel3, linearLayout13, "X", null);
        inject$showPanel(sourcesPanel3, mixerPanel3, frameLayout7, effectsPanel3, linearLayout13, sourcesPanel4);
        LinearLayout linearLayout15 = new LinearLayout(editorActivity);
        linearLayout15.setOrientation(1);
        linearLayout15.setBackgroundColor(Color.rgb(15, 17, 22));
        linearLayout.addView(linearLayout15, new LinearLayout.LayoutParams(-1, 0, 0.09f));
        ScrollView scrollView5 = new ScrollView(editorActivity);
        LinearLayout linearLayout16 = new LinearLayout(editorActivity);
        linearLayout16.setOrientation(1);
        linearLayout16.setPadding(UI.INSTANCE.dp(editorActivity, 8), UI.INSTANCE.dp(editorActivity, 8), UI.INSTANCE.dp(editorActivity, 8), UI.INSTANCE.dp(editorActivity, 8));
        scrollView5.addView(linearLayout16);
        LinearLayout linearLayout17 = new LinearLayout(editorActivity);
        linearLayout17.setOrientation(0);
        linearLayout17.setGravity(16);
        SeekBar seekBar2 = new SeekBar(editorActivity);
        seekBar2.setProgressTintList(ColorStateList.valueOf(UI.INSTANCE.getACCENT()));
        seekBar2.setThumbTintList(ColorStateList.valueOf(UI.INSTANCE.getACCENT2()));
        Project proj3 = activity.getProj();
        seekBar2.setMax(proj3 != null ? RangesKt.coerceAtLeast((int) proj3.durationMs(), 1) : 1);
        seekBar2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        seekBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector$inject$seek$1$1
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(@Nullable SeekBar sb, int v, boolean fromUser) {
                if (fromUser) {
                    long j = v;
                    activity.getTimeLabel().setText(UI.INSTANCE.fmtTime(j));
                    if (activity.engineReady()) {
                        activity.getEngine().seekTo(j);
                    }
                }
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(@Nullable SeekBar sb) {
                activity.setScrubbing(true);
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(@Nullable SeekBar sb) {
                activity.setScrubbing(false);
                if (activity.engineReady()) {
                    activity.getEngine().refreshFrames();
                }
            }
        });
        activity.setSeek(seekBar2);
        linearLayout17.addView(seekBar2);
        linearLayout16.addView(linearLayout17);
        HorizontalScrollView horizontalScrollView2 = new HorizontalScrollView(editorActivity);
        horizontalScrollView2.setHorizontalScrollBarEnabled(false);
        LinearLayout linearLayout18 = new LinearLayout(editorActivity);
        linearLayout18.setOrientation(0);
        Project proj4 = activity.getProj();
        if (proj4 == null || (listEmptyList2 = proj4.getLayers()) == null) {
            listEmptyList2 = CollectionsKt.emptyList();
        }
        for (Layer layer2 : listEmptyList2) {
            TextView textView6 = new TextView(editorActivity);
            String name2 = layer2.getName();
            if (StringsKt.isBlank(name2)) {
                name2 = layer2.getType().getLabel();
            }
            textView6.setText(name2);
            textView6.setTextColor(-1);
            textView6.setTextSize(10.0f);
            textView6.setBackgroundColor(Color.rgb(30, 34, 48));
            textView6.setPadding(UI.INSTANCE.dp(editorActivity, 8), UI.INSTANCE.dp(editorActivity, 4), UI.INSTANCE.dp(editorActivity, 8), UI.INSTANCE.dp(editorActivity, 4));
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2);
            layoutParams3.setMarginEnd(UI.INSTANCE.dp(editorActivity, 4));
            linearLayout18.addView(textView6, layoutParams3);
        }
        horizontalScrollView2.addView(linearLayout18);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams4.topMargin = UI.INSTANCE.dp(editorActivity, 2);
        Unit unit2 = Unit.INSTANCE;
        linearLayout16.addView(horizontalScrollView2, layoutParams4);
        linearLayout15.addView(scrollView5, new LinearLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout19 = new LinearLayout(editorActivity);
        linearLayout19.setOrientation(0);
        linearLayout19.setGravity(16);
        linearLayout19.setBackgroundColor(Color.rgb(9, 10, 14));
        linearLayout.addView(linearLayout19, new LinearLayout.LayoutParams(-1, 0, 0.1f));
        activity.setTransportBar(linearLayout19);
        buildTransport(activity, linearLayout19);
        bindPanels(activity, sourcesPanel3, mixerPanel3, frameLayout8);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void inject$lambda$2$lambda$1(EditorActivity activity, View view) {
        Intrinsics.checkNotNullParameter(activity, "$activity");
        activity.onBackPressed();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void inject$lambda$4$lambda$3(EditorActivity activity, View view) {
        Intrinsics.checkNotNullParameter(activity, "$activity");
        activity.showAspectPicker();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void inject$lambda$6$lambda$5(EditorActivity activity, View view) {
        Intrinsics.checkNotNullParameter(activity, "$activity");
        activity.openDiagnostics();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void inject$lambda$8$lambda$7(Function0 action, View view) {
        Intrinsics.checkNotNullParameter(action, "$action");
        action.invoke();
    }

    private static final void inject$showPanel(SourcesPanel sourcesPanel, MixerPanel mixerPanel, FrameLayout frameLayout, EffectsPanel effectsPanel, LinearLayout linearLayout, View view) {
        sourcesPanel.setVisibility(8);
        mixerPanel.setVisibility(8);
        frameLayout.setVisibility(8);
        effectsPanel.setVisibility(8);
        view.setVisibility(0);
        if (linearLayout == null) {
            return;
        }
        linearLayout.setVisibility(0);
    }

    private static final void inject$hidePanels(SourcesPanel sourcesPanel, MixerPanel mixerPanel, FrameLayout frameLayout, EffectsPanel effectsPanel) {
        sourcesPanel.setVisibility(8);
        mixerPanel.setVisibility(8);
        frameLayout.setVisibility(8);
        effectsPanel.setVisibility(8);
    }

    private static final void inject$createTab(EditorActivity editorActivity, LinearLayout linearLayout, final SourcesPanel sourcesPanel, final MixerPanel mixerPanel, final FrameLayout frameLayout, final EffectsPanel effectsPanel, final LinearLayout linearLayout2, String str, final View view) {
        EditorActivity editorActivity2 = editorActivity;
        TextView textView = new TextView(editorActivity2);
        textView.setText(str);
        textView.setTextSize(10.0f);
        textView.setMaxLines(1);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setGravity(17);
        textView.setTextColor(Color.rgb(220, 224, 232));
        textView.setMinWidth(0);
        textView.setMinHeight(0);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(UI.INSTANCE.dpf(editorActivity2, 6.0f));
        gradientDrawable.setColor(Color.rgb(30, 34, 48));
        textView.setBackground(gradientDrawable);
        textView.setClickable(true);
        textView.setFocusable(true);
        textView.setPadding(UI.INSTANCE.dp(editorActivity2, 2), UI.INSTANCE.dp(editorActivity2, 6), UI.INSTANCE.dp(editorActivity2, 2), UI.INSTANCE.dp(editorActivity2, 6));
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$StudioLayoutInjector$crwAVzx7bkVjXxfobtnR6PG_ro8
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                StudioLayoutInjector.inject$createTab$lambda$12$lambda$11(view, sourcesPanel, mixerPanel, frameLayout, effectsPanel, linearLayout2, view2);
            }
        });
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams.setMarginStart(UI.INSTANCE.dp(editorActivity2, 2));
        layoutParams.setMarginEnd(UI.INSTANCE.dp(editorActivity2, 2));
        linearLayout.addView(textView, layoutParams);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void inject$createTab$lambda$12$lambda$11(View view, SourcesPanel sourcesPanel, MixerPanel mixerPanel, FrameLayout propertiesPanel, EffectsPanel effectsPanel, LinearLayout rightPanel, View view2) {
        Intrinsics.checkNotNullParameter(sourcesPanel, "$sourcesPanel");
        Intrinsics.checkNotNullParameter(mixerPanel, "$mixerPanel");
        Intrinsics.checkNotNullParameter(propertiesPanel, "$propertiesPanel");
        Intrinsics.checkNotNullParameter(effectsPanel, "$effectsPanel");
        Intrinsics.checkNotNullParameter(rightPanel, "$rightPanel");
        if (view == null) {
            inject$hidePanels(sourcesPanel, mixerPanel, propertiesPanel, effectsPanel);
        } else {
            inject$showPanel(sourcesPanel, mixerPanel, propertiesPanel, effectsPanel, rightPanel, view);
        }
    }

    private static final void inject$showPanel$19(SourcesPanel sourcesPanel, MixerPanel mixerPanel, FrameLayout frameLayout, EffectsPanel effectsPanel, LinearLayout linearLayout, View view) {
        sourcesPanel.setVisibility(8);
        mixerPanel.setVisibility(8);
        frameLayout.setVisibility(8);
        effectsPanel.setVisibility(8);
        view.setVisibility(0);
        linearLayout.setVisibility(0);
    }

    private static final void inject$createTab$23(EditorActivity editorActivity, LinearLayout linearLayout, final SourcesPanel sourcesPanel, final MixerPanel mixerPanel, final FrameLayout frameLayout, final EffectsPanel effectsPanel, final LinearLayout linearLayout2, String str, final View view) {
        EditorActivity editorActivity2 = editorActivity;
        TextView textView = new TextView(editorActivity2);
        textView.setText(str);
        textView.setTextSize(10.0f);
        textView.setMaxLines(1);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setGravity(17);
        textView.setTextColor(Color.rgb(220, 224, 232));
        textView.setMinWidth(0);
        textView.setMinHeight(0);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(UI.INSTANCE.dpf(editorActivity2, 6.0f));
        gradientDrawable.setColor(Color.rgb(30, 34, 48));
        textView.setBackground(gradientDrawable);
        textView.setClickable(true);
        textView.setFocusable(true);
        textView.setPadding(UI.INSTANCE.dp(editorActivity2, 2), UI.INSTANCE.dp(editorActivity2, 6), UI.INSTANCE.dp(editorActivity2, 2), UI.INSTANCE.dp(editorActivity2, 6));
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$StudioLayoutInjector$zJf-KMdR3pYEWhzTyT_yfAkxAJI
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                StudioLayoutInjector.inject$createTab$23$lambda$22$lambda$21(view, sourcesPanel, mixerPanel, frameLayout, effectsPanel, linearLayout2, view2);
            }
        });
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams.setMarginStart(UI.INSTANCE.dp(editorActivity2, 2));
        layoutParams.setMarginEnd(UI.INSTANCE.dp(editorActivity2, 2));
        linearLayout.addView(textView, layoutParams);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void inject$createTab$23$lambda$22$lambda$21(View view, SourcesPanel sourcesPanel, MixerPanel mixerPanel, FrameLayout propertiesPanel, EffectsPanel effectsPanel, LinearLayout contextPanel, View view2) {
        Intrinsics.checkNotNullParameter(sourcesPanel, "$sourcesPanel");
        Intrinsics.checkNotNullParameter(mixerPanel, "$mixerPanel");
        Intrinsics.checkNotNullParameter(propertiesPanel, "$propertiesPanel");
        Intrinsics.checkNotNullParameter(effectsPanel, "$effectsPanel");
        Intrinsics.checkNotNullParameter(contextPanel, "$contextPanel");
        if (view == null) {
            sourcesPanel.setVisibility(8);
            mixerPanel.setVisibility(8);
            propertiesPanel.setVisibility(8);
            effectsPanel.setVisibility(8);
            return;
        }
        inject$showPanel$19(sourcesPanel, mixerPanel, propertiesPanel, effectsPanel, contextPanel, view);
    }

    private final void bindPanels(final EditorActivity activity, final SourcesPanel sourcesPanel, MixerPanel mixerPanel, final View propertiesPanel) {
        sourcesPanel.setListener(new SourcesPanel.Listener() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector.bindPanels.1
            @Override // com.rehman.ahmedreactionstudio.editor.SourcesPanel.Listener
            public void onSelect(@NotNull String id) {
                Intrinsics.checkNotNullParameter(id, "id");
                activity.select(id);
            }

            @Override // com.rehman.ahmedreactionstudio.editor.SourcesPanel.Listener
            public void onToggleVisible(@NotNull String id) {
                Intrinsics.checkNotNullParameter(id, "id");
                activity.getCtrl().toggleVisible(id);
            }

            @Override // com.rehman.ahmedreactionstudio.editor.SourcesPanel.Listener
            public void onAdd() {
                activity.openAddSourceChooser();
            }

            @Override // com.rehman.ahmedreactionstudio.editor.SourcesPanel.Listener
            public void onAddVideo() {
                activity.pickMedia(true);
            }

            @Override // com.rehman.ahmedreactionstudio.editor.SourcesPanel.Listener
            public void onAddImage() {
                activity.pickMedia(false);
            }

            @Override // com.rehman.ahmedreactionstudio.editor.SourcesPanel.Listener
            public void onRemove() {
                activity.removeSelectedSource();
            }

            @Override // com.rehman.ahmedreactionstudio.editor.SourcesPanel.Listener
            public void onHide() {
                String selectedId = activity.getSelectedId();
                if (selectedId != null) {
                    activity.getCtrl().toggleVisible(selectedId);
                }
            }

            @Override // com.rehman.ahmedreactionstudio.editor.SourcesPanel.Listener
            public void onMoveUp(@NotNull String id) {
                Intrinsics.checkNotNullParameter(id, "id");
                activity.getCtrl().moveZ(id, "up");
            }

            @Override // com.rehman.ahmedreactionstudio.editor.SourcesPanel.Listener
            public void onMoveDown(@NotNull String id) {
                Intrinsics.checkNotNullParameter(id, "id");
                activity.getCtrl().moveZ(id, "down");
            }

            @Override // com.rehman.ahmedreactionstudio.editor.SourcesPanel.Listener
            public void onProperties() {
                EditorActivity editorActivity;
                Project proj;
                Layer layerLayerById;
                propertiesPanel.setVisibility(0);
                sourcesPanel.setVisibility(8);
                String selectedId = activity.getSelectedId();
                if (selectedId == null || (proj = (editorActivity = activity).getProj()) == null || (layerLayerById = proj.layerById(selectedId)) == null) {
                    return;
                }
                editorActivity.openAdvancedSheet(layerLayerById);
            }
        });
        mixerPanel.setListener(new MixerPanel.Listener() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector.bindPanels.2
            @Override // com.rehman.ahmedreactionstudio.editor.MixerPanel.Listener
            public void onSelect(@NotNull String id) {
                Intrinsics.checkNotNullParameter(id, "id");
                activity.select(id);
            }

            @Override // com.rehman.ahmedreactionstudio.editor.MixerPanel.Listener
            public void onMute(@NotNull String id) {
                Intrinsics.checkNotNullParameter(id, "id");
                activity.getCtrl().toggleMuted(id);
            }

            @Override // com.rehman.ahmedreactionstudio.editor.MixerPanel.Listener
            public void onSolo(@NotNull String id) {
                Intrinsics.checkNotNullParameter(id, "id");
                activity.getCtrl().toggleSolo(id);
            }

            @Override // com.rehman.ahmedreactionstudio.editor.MixerPanel.Listener
            public void onVolume(@NotNull String id, float v) {
                Layer layerLayerById;
                Intrinsics.checkNotNullParameter(id, "id");
                Project proj = activity.getProj();
                if (proj == null || (layerLayerById = proj.layerById(id)) == null) {
                    return;
                }
                activity.pushUndoLight();
                if (activity.engineReady()) {
                    activity.getEngine().setVolume(layerLayerById, v);
                } else {
                    layerLayerById.setVolume(v);
                }
                activity.markDirty();
            }
        });
    }

    private final void buildTransport(final EditorActivity activity, LinearLayout bar) {
        IconBtn iconBtn = new IconBtn(activity);
        iconBtn.setIcon(R.drawable.ic_play, -1, "Play");
        iconBtn.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$StudioLayoutInjector$H5zlUF4OK_0MH21LhvgRTwRUZEc
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                StudioLayoutInjector.buildTransport$lambda$30$lambda$29(activity, view);
            }
        });
        activity.setPlayBtn(iconBtn);
        EditorActivity editorActivity = activity;
        bar.addView(iconBtn, new LinearLayout.LayoutParams(UI.INSTANCE.dp(editorActivity, 44), UI.INSTANCE.dp(editorActivity, 44)));
        TextView textView = new TextView(editorActivity);
        activity.setRecordBtn(textView);
        textView.setText("● Record");
        textView.setTextSize(12.0f);
        textView.setTypeface(Typeface.create("sans-serif-medium", 1));
        textView.setGravity(17);
        textView.setIncludeFontPadding(false);
        textView.setTextColor(Color.argb(KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, 90, 90));
        textView.setPadding(UI.INSTANCE.dp(editorActivity, 12), 0, UI.INSTANCE.dp(editorActivity, 12), 0);
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$StudioLayoutInjector$dezN3cBA4TqnHR9ksxibF5QOaqg
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                StudioLayoutInjector.buildTransport$lambda$32$lambda$31(activity, view);
            }
        });
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(UI.INSTANCE.dpf(editorActivity, 17.0f));
        gradientDrawable.setColor(Color.argb(200, 200, 34, 34));
        textView.setBackground(gradientDrawable);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, UI.INSTANCE.dp(editorActivity, 34));
        layoutParams.setMargins(UI.INSTANCE.dp(editorActivity, 2), 0, UI.INSTANCE.dp(editorActivity, 2), 0);
        textView.setLayoutParams(layoutParams);
        bar.addView(textView);
        bar.addView(pillBtn(activity, "⏹ Stop", UI.INSTANCE.getFG(), Color.argb(150, 38, 42, 52), 34, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.StudioLayoutInjector$buildTransport$stopBtn$1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                activity.controlsStopTap();
            }
        }));
        TextView textView2 = new TextView(editorActivity);
        textView2.setText("00:00:00");
        textView2.setTextColor(-1);
        textView2.setPadding(UI.INSTANCE.dp(editorActivity, 10), 0, 0, 0);
        activity.setTimeLabel(textView2);
        bar.addView(textView2);
        TextView textView3 = new TextView(editorActivity);
        textView3.setText("/ 00:00:00");
        textView3.setTextColor(-7829368);
        textView3.setPadding(UI.INSTANCE.dp(editorActivity, 4), 0, 0, 0);
        activity.setDurationLabel(textView3);
        bar.addView(textView3);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildTransport$lambda$30$lambda$29(EditorActivity activity, View view) {
        Intrinsics.checkNotNullParameter(activity, "$activity");
        activity.togglePlay();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildTransport$lambda$32$lambda$31(EditorActivity activity, View view) {
        Intrinsics.checkNotNullParameter(activity, "$activity");
        activity.recordButtonTap();
    }
}
