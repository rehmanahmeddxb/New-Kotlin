package com.rehman.ahmedreactionstudio.editor;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.rehman.ahmedreactionstudio.R;
import com.rehman.ahmedreactionstudio.core.Layer;
import com.rehman.ahmedreactionstudio.core.LayerType;
import com.rehman.ahmedreactionstudio.core.MediaKit;
import com.rehman.ahmedreactionstudio.core.Project;
import com.rehman.ahmedreactionstudio.core.ProjectStore;
import com.rehman.ahmedreactionstudio.util.UI;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.KotlinVersion;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: SourceDock.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0090\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0015\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u0000 C2\u00020\u0001:\u0001CBß\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\u000e\u0010\t\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\u0007\u0012\u0014\u0010\u000b\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00010\n\u0012\u0004\u0012\u00020\r0\f\u0012\u0018\u0010\u000e\u001a\u0014\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\r0\u000f\u0012\u0012\u0010\u0011\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\r0\f\u0012\u0012\u0010\u0012\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\r0\f\u0012\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\r0\u0007\u00126\u0010\u0014\u001a2\u0012\u0013\u0012\u00110\u0015¢\u0006\f\b\u0016\u0012\b\b\u0017\u0012\u0004\b\b(\u0018\u0012\u0013\u0012\u00110\u0015¢\u0006\f\b\u0016\u0012\b\b\u0017\u0012\u0004\b\b(\u0019\u0012\u0004\u0012\u00020\r0\u000f\u0012\f\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\r0\u0007¢\u0006\u0002\u0010\u001bJ\u0010\u0010%\u001a\u00020\r2\u0006\u0010&\u001a\u00020'H\u0002J\u0018\u0010(\u001a\u00020)2\u0006\u0010*\u001a\u00020\n2\u0006\u0010+\u001a\u00020\u0015H\u0002J\u0010\u0010,\u001a\u00020\u00052\u0006\u0010-\u001a\u00020\u0010H\u0002J\u0010\u0010.\u001a\u00020/2\u0006\u0010-\u001a\u00020\u0010H\u0002J\u0010\u00100\u001a\u00020\n2\u0006\u00101\u001a\u000202H\u0002J \u00103\u001a\u0002042\u0006\u0010&\u001a\u00020'2\u0006\u00105\u001a\u00020\u00052\u0006\u0010-\u001a\u00020\u0010H\u0002J\n\u00106\u001a\u0004\u0018\u000107H\u0002J\u0018\u00108\u001a\u00020\r2\u0006\u0010-\u001a\u00020\u00102\u0006\u00109\u001a\u00020:H\u0002J\u0010\u0010;\u001a\u00020<2\u0006\u0010=\u001a\u00020>H\u0002J\u0010\u0010?\u001a\u0002042\u0006\u0010-\u001a\u00020\u0010H\u0002J\u0006\u0010@\u001a\u00020\rJ\u0010\u0010A\u001a\u00020\u00152\u0006\u0010-\u001a\u00020\u0010H\u0002J\u0010\u0010B\u001a\u00020\n2\u0006\u0010-\u001a\u00020\u0010H\u0002R\u000e\u0010\u001c\u001a\u00020\u0015X\u0082D¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u001d\u001a\u0004\u0018\u00010\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001e\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\u0012\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0011\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R \u0010\u000e\u001a\u0014\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\r0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R>\u0010\u0014\u001a2\u0012\u0013\u0012\u00110\u0015¢\u0006\f\b\u0016\u0012\b\b\u0017\u0012\u0004\b\b(\u0018\u0012\u0013\u0012\u00110\u0015¢\u0006\f\b\u0016\u0012\b\b\u0017\u0012\u0004\b\b(\u0019\u0012\u0004\u0012\u00020\r0\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\r0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\r0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\u000b\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00010\n\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\t\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u001b\u0010\u001f\u001a\u00020 8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b#\u0010$\u001a\u0004\b!\u0010\""}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/SourceDock;", "", "act", "Landroid/app/Activity;", "container", "Landroid/widget/LinearLayout;", "projectRef", "Lkotlin/Function0;", "Lcom/rehman/ahmedreactionstudio/core/Project;", "selectedId", "", "onSelect", "Lkotlin/Function1;", "", "onQuickToggle", "Lkotlin/Function2;", "Lcom/rehman/ahmedreactionstudio/core/Layer;", "onPlayToggle", "onLongPress", "onReorderStart", "onReorder", "", "Lkotlin/ParameterName;", "name", "fromLayerIdx", "toFinalLayerIdx", "onReorderEnd", "(Landroid/app/Activity;Landroid/widget/LinearLayout;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;)V", "ROW_DP", "dragLayer", "dragRow", "store", "Lcom/rehman/ahmedreactionstudio/core/ProjectStore;", "getStore", "()Lcom/rehman/ahmedreactionstudio/core/ProjectStore;", "store$delegate", "Lkotlin/Lazy;", "autoScroll", "ev", "Landroid/view/MotionEvent;", "badge", "Landroid/widget/TextView;", "text", "color", "buildRow", "l", "buildThumbTile", "Landroid/widget/FrameLayout;", "formatDur", "ms", "", "handleTouch", "", "row", "hostScroller", "Landroid/widget/ScrollView;", "loadThumb", "img", "Landroid/widget/ImageView;", "locationOf", "", "v", "Landroid/view/View;", "mutedBySolo", "rebuild", "statusColor", "statusOf", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nSourceDock.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SourceDock.kt\ncom/rehman/ahmedreactionstudio/editor/SourceDock\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,421:1\n1#2:422\n1747#3,3:423\n*S KotlinDebug\n*F\n+ 1 SourceDock.kt\ncom/rehman/ahmedreactionstudio/editor/SourceDock\n*L\n282#1:423,3\n*E\n"})
public final class SourceDock {

    @NotNull
    private static final ConcurrentHashMap<String, Bitmap> thumbCache = new ConcurrentHashMap<>();
    private final int ROW_DP;

    @NotNull
    private final Activity act;

    @NotNull
    private final LinearLayout container;

    @Nullable
    private Layer dragLayer;

    @Nullable
    private LinearLayout dragRow;

    @NotNull
    private final Function1<Layer, Unit> onLongPress;

    @NotNull
    private final Function1<Layer, Unit> onPlayToggle;

    @NotNull
    private final Function2<Layer, String, Unit> onQuickToggle;

    @NotNull
    private final Function2<Integer, Integer, Unit> onReorder;

    @NotNull
    private final Function0<Unit> onReorderEnd;

    @NotNull
    private final Function0<Unit> onReorderStart;

    @NotNull
    private final Function1<String, Unit> onSelect;

    @NotNull
    private final Function0<Project> projectRef;

    @NotNull
    private final Function0<String> selectedId;

    /* JADX INFO: renamed from: store$delegate, reason: from kotlin metadata */
    @NotNull
    private final Lazy store;

    /* JADX WARN: Multi-variable type inference failed */
    public SourceDock(@NotNull Activity act, @NotNull LinearLayout container, @NotNull Function0<Project> projectRef, @NotNull Function0<String> selectedId, @NotNull Function1<? super String, Unit> onSelect, @NotNull Function2<? super Layer, ? super String, Unit> onQuickToggle, @NotNull Function1<? super Layer, Unit> onPlayToggle, @NotNull Function1<? super Layer, Unit> onLongPress, @NotNull Function0<Unit> onReorderStart, @NotNull Function2<? super Integer, ? super Integer, Unit> onReorder, @NotNull Function0<Unit> onReorderEnd) {
        Intrinsics.checkNotNullParameter(act, "act");
        Intrinsics.checkNotNullParameter(container, "container");
        Intrinsics.checkNotNullParameter(projectRef, "projectRef");
        Intrinsics.checkNotNullParameter(selectedId, "selectedId");
        Intrinsics.checkNotNullParameter(onSelect, "onSelect");
        Intrinsics.checkNotNullParameter(onQuickToggle, "onQuickToggle");
        Intrinsics.checkNotNullParameter(onPlayToggle, "onPlayToggle");
        Intrinsics.checkNotNullParameter(onLongPress, "onLongPress");
        Intrinsics.checkNotNullParameter(onReorderStart, "onReorderStart");
        Intrinsics.checkNotNullParameter(onReorder, "onReorder");
        Intrinsics.checkNotNullParameter(onReorderEnd, "onReorderEnd");
        this.act = act;
        this.container = container;
        this.projectRef = projectRef;
        this.selectedId = selectedId;
        this.onSelect = onSelect;
        this.onQuickToggle = onQuickToggle;
        this.onPlayToggle = onPlayToggle;
        this.onLongPress = onLongPress;
        this.onReorderStart = onReorderStart;
        this.onReorder = onReorder;
        this.onReorderEnd = onReorderEnd;
        this.ROW_DP = 58;
        this.store = LazyKt.lazy(new Function0<ProjectStore>() { // from class: com.rehman.ahmedreactionstudio.editor.SourceDock$store$2
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final ProjectStore invoke() {
                return new ProjectStore(this.this$0.act);
            }
        });
    }

    private final ProjectStore getStore() {
        return (ProjectStore) this.store.getValue();
    }

    public final void rebuild() {
        this.container.removeAllViews();
        Project projectInvoke = this.projectRef.invoke();
        if (projectInvoke.getLayers().isEmpty()) {
            TextView textViewLabel = UI.INSTANCE.label(this.act, "No sources yet — tap Add to create one.", true, 12.5f);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.setMargins(UI.INSTANCE.dp(this.act, 14), UI.INSTANCE.dp(this.act, 10), UI.INSTANCE.dp(this.act, 14), UI.INSTANCE.dp(this.act, 10));
            textViewLabel.setLayoutParams(layoutParams);
            this.container.addView(textViewLabel);
            return;
        }
        int size = projectInvoke.getLayers().size() - 1;
        if (size < 0) {
            return;
        }
        while (true) {
            int i = size - 1;
            this.container.addView(buildRow(projectInvoke.getLayers().get(size)));
            if (i < 0) {
                return;
            } else {
                size = i;
            }
        }
    }

    private final LinearLayout buildRow(final Layer l) {
        StringBuilder sb;
        String str;
        StringBuilder sb2;
        String str2;
        StringBuilder sb3;
        String str3;
        boolean zAreEqual = Intrinsics.areEqual(l.getId(), this.selectedId.invoke());
        final LinearLayout linearLayout = new LinearLayout(this.act);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        linearLayout.setPadding(UI.INSTANCE.dp(this.act, 8), 0, UI.INSTANCE.dp(this.act, 8), 0);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(UI.INSTANCE.dpf(this.act, 14.0f));
        gradientDrawable.setColor(zAreEqual ? Color.argb(70, KotlinVersion.MAX_COMPONENT_VALUE, 90, 44) : Color.argb(120, 20, 23, 31));
        gradientDrawable.setStroke(UI.INSTANCE.dp(this.act, 1), zAreEqual ? Color.argb(KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, 130, 80) : Color.argb(40, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
        linearLayout.setBackground(gradientDrawable);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, UI.INSTANCE.dp(this.act, this.ROW_DP));
        layoutParams.setMargins(UI.INSTANCE.dp(this.act, 2), UI.INSTANCE.dp(this.act, 2), UI.INSTANCE.dp(this.act, 2), UI.INSTANCE.dp(this.act, 2));
        linearLayout.setLayoutParams(layoutParams);
        IconBtn iconBtn = new IconBtn(this.act);
        iconBtn.setLayoutParams(IconBtn.INSTANCE.sized(this.act, 44));
        int i = l.getVisible() ? R.drawable.ic_eye : R.drawable.ic_eye_off;
        int fg = l.getVisible() ? UI.INSTANCE.getFG() : Color.argb(120, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE);
        if (l.getVisible()) {
            sb = new StringBuilder();
            str = "Hide ";
        } else {
            sb = new StringBuilder();
            str = "Show ";
        }
        sb.append(str);
        sb.append(l.getName());
        iconBtn.setIcon(i, fg, sb.toString());
        iconBtn.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$SourceDock$6-LhFVh-Nbl4BSG4lgpv8OhC4JM
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                SourceDock.buildRow$lambda$0(this.f$0, l, view);
            }
        });
        linearLayout.addView(iconBtn);
        if (l.isClip() || l.isLive()) {
            IconBtn iconBtn2 = new IconBtn(this.act);
            iconBtn2.setLayoutParams(IconBtn.INSTANCE.sized(this.act, 44));
            boolean z = l.getMuted() || mutedBySolo(l);
            int i2 = z ? R.drawable.ic_volume_off : R.drawable.ic_volume;
            UI ui = UI.INSTANCE;
            int danger = z ? ui.getDANGER() : ui.getFG();
            if (z) {
                sb2 = new StringBuilder();
                str2 = "Unmute ";
            } else {
                sb2 = new StringBuilder();
                str2 = "Mute ";
            }
            sb2.append(str2);
            sb2.append(l.getName());
            iconBtn2.setIcon(i2, danger, sb2.toString());
            iconBtn2.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$SourceDock$XBuli8k_1oKOPrDohOp2LGw6a7M
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    SourceDock.buildRow$lambda$1(this.f$0, l, view);
                }
            });
            linearLayout.addView(iconBtn2);
        } else {
            linearLayout.addView(new View(this.act), new LinearLayout.LayoutParams(UI.INSTANCE.dp(this.act, 44), UI.INSTANCE.dp(this.act, 44)));
        }
        linearLayout.addView(buildThumbTile(l));
        LinearLayout linearLayout2 = new LinearLayout(this.act);
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView = new TextView(this.act);
        String name = l.getName();
        if (StringsKt.isBlank(name)) {
            name = l.getType().name();
        }
        textView.setText(name);
        textView.setTextColor(l.getVisible() ? -1 : Color.argb(150, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
        textView.setTextSize(13.0f);
        textView.setTypeface(Typeface.create("sans-serif-medium", 0));
        textView.setMaxLines(1);
        linearLayout2.addView(textView);
        TextView textView2 = new TextView(this.act);
        textView2.setText(statusOf(l));
        textView2.setTextSize(10.0f);
        textView2.setTextColor(statusColor(l));
        textView2.setMaxLines(1);
        if (l.isClip()) {
            textView2.setClickable(true);
            textView2.setFocusable(true);
            if (l.getPlaying()) {
                sb3 = new StringBuilder();
                str3 = "Pause ";
            } else {
                sb3 = new StringBuilder();
                str3 = "Play ";
            }
            sb3.append(str3);
            sb3.append(l.getName());
            textView2.setContentDescription(sb3.toString());
            textView2.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$SourceDock$EZ5DJKROPwLcg6cVpCw9T9_KtHg
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    SourceDock.buildRow$lambda$3(this.f$0, l, view);
                }
            });
        }
        linearLayout2.addView(textView2);
        linearLayout.addView(linearLayout2);
        if (l.isLive()) {
            linearLayout.addView(badge("LIVE", UI.INSTANCE.getOK()));
        }
        if (l.getSolo()) {
            linearLayout.addView(badge("SOLO", UI.INSTANCE.getACCENT2()));
        }
        if (l.getLoop() && l.isClip()) {
            linearLayout.addView(badge("LOOP", UI.INSTANCE.getOK()));
        }
        if (l.getLocked()) {
            linearLayout.addView(badge("LOCK", Color.argb(200, KotlinVersion.MAX_COMPONENT_VALUE, 200, 120)));
        }
        ImageView imageView = new ImageView(this.act);
        imageView.setImageDrawable(Ic.INSTANCE.get(this.act, R.drawable.ic_drag, Color.argb(170, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE)));
        imageView.setPadding(UI.INSTANCE.dp(this.act, 8), UI.INSTANCE.dp(this.act, 8), UI.INSTANCE.dp(this.act, 8), UI.INSTANCE.dp(this.act, 8));
        imageView.setContentDescription("Drag to reorder " + l.getName());
        imageView.setLayoutParams(new LinearLayout.LayoutParams(UI.INSTANCE.dp(this.act, 44), UI.INSTANCE.dp(this.act, 44)));
        imageView.setOnTouchListener(new View.OnTouchListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$SourceDock$QCVomuwx3mE1Q6zcRI_EA4Gjpos
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                return SourceDock.buildRow$lambda$4(this.f$0, linearLayout, l, view, motionEvent);
            }
        });
        linearLayout.addView(imageView);
        linearLayout.setContentDescription("Select " + l.getName() + ". " + statusOf(l));
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$SourceDock$imdyT44MBlApNDVbbJ39P03sEUA
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                SourceDock.buildRow$lambda$5(this.f$0, l, view);
            }
        });
        linearLayout.setOnLongClickListener(new View.OnLongClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$SourceDock$3tZN15fvWUmFoR6HP-CUCGRkRLM
            @Override // android.view.View.OnLongClickListener
            public final boolean onLongClick(View view) {
                return SourceDock.buildRow$lambda$6(this.f$0, l, view);
            }
        });
        return linearLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildRow$lambda$0(SourceDock this$0, Layer l, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(l, "$l");
        this$0.onQuickToggle.invoke(l, "vis");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildRow$lambda$1(SourceDock this$0, Layer l, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(l, "$l");
        this$0.onQuickToggle.invoke(l, "mute");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildRow$lambda$3(SourceDock this$0, Layer l, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(l, "$l");
        this$0.onPlayToggle.invoke(l);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean buildRow$lambda$4(SourceDock this$0, LinearLayout row, Layer l, View view, MotionEvent motionEvent) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(row, "$row");
        Intrinsics.checkNotNullParameter(l, "$l");
        Intrinsics.checkNotNull(motionEvent);
        return this$0.handleTouch(motionEvent, row, l);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildRow$lambda$5(SourceDock this$0, Layer l, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(l, "$l");
        this$0.onSelect.invoke(Intrinsics.areEqual(this$0.selectedId.invoke(), l.getId()) ? null : l.getId());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean buildRow$lambda$6(SourceDock this$0, Layer l, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(l, "$l");
        this$0.onLongPress.invoke(l);
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x00e2  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final android.widget.FrameLayout buildThumbTile(com.rehman.ahmedreactionstudio.core.Layer r13) {
        /*
            Method dump skipped, instruction units count: 620
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.editor.SourceDock.buildThumbTile(com.rehman.ahmedreactionstudio.core.Layer):android.widget.FrameLayout");
    }

    private final String formatDur(long ms) {
        long j = ms / ((long) 1000);
        long j2 = 60;
        long j3 = j / j2;
        long j4 = j % j2;
        StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
        Object[] objArr = {Long.valueOf(j3), Long.valueOf(j4)};
        String str = String.format("%d:%02d", Arrays.copyOf(objArr, objArr.length));
        Intrinsics.checkNotNullExpressionValue(str, "format(...)");
        return str;
    }

    private final void loadThumb(final Layer l, final ImageView img) {
        String relPath = l.getRelPath();
        if (relPath == null) {
            return;
        }
        final String absolutePath = new File(getStore().mediaDir(this.projectRef.invoke().getId()), relPath).getAbsolutePath();
        final String str = l.getId() + ':' + relPath;
        img.setTag(str);
        Bitmap bitmap = thumbCache.get(str);
        if (bitmap != null) {
            img.setImageBitmap(bitmap);
        } else {
            new Thread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$SourceDock$3v4S5zYHycO1qAF-9dnNsrgLxvU
                @Override // java.lang.Runnable
                public final void run() {
                    SourceDock.loadThumb$lambda$9(this.f$0, l, absolutePath, str, img);
                }
            }).start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadThumb$lambda$9(SourceDock this$0, Layer l, String str, final String key, final ImageView img) {
        final Bitmap bitmapVideoFrame;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(l, "$l");
        Intrinsics.checkNotNullParameter(key, "$key");
        Intrinsics.checkNotNullParameter(img, "$img");
        try {
            int iDp = UI.INSTANCE.dp(this$0.act, 96);
            if (l.getType() == LayerType.IMAGE) {
                MediaKit mediaKit = MediaKit.INSTANCE;
                Intrinsics.checkNotNull(str);
                bitmapVideoFrame = mediaKit.image(str, iDp);
            } else {
                MediaKit mediaKit2 = MediaKit.INSTANCE;
                Intrinsics.checkNotNull(str);
                bitmapVideoFrame = mediaKit2.videoFrame(str, 0L, iDp, true);
            }
            if (bitmapVideoFrame != null) {
                thumbCache.put(key, bitmapVideoFrame);
            }
            img.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$SourceDock$OrqGN6DatLU4e2ETRcPfZrk4ohs
                @Override // java.lang.Runnable
                public final void run() {
                    SourceDock.loadThumb$lambda$9$lambda$8(img, key, bitmapVideoFrame);
                }
            });
        } catch (Exception unused) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadThumb$lambda$9$lambda$8(ImageView img, String key, Bitmap bitmap) {
        Intrinsics.checkNotNullParameter(img, "$img");
        Intrinsics.checkNotNullParameter(key, "$key");
        if (!Intrinsics.areEqual(img.getTag(), key) || bitmap == null) {
            return;
        }
        img.setImageBitmap(bitmap);
    }

    private final boolean mutedBySolo(Layer l) {
        boolean z;
        List<Layer> layers = this.projectRef.invoke().getLayers();
        if ((layers instanceof Collection) && layers.isEmpty()) {
            z = false;
        } else {
            Iterator<T> it = layers.iterator();
            while (it.hasNext()) {
                if (((Layer) it.next()).getSolo()) {
                    z = true;
                    break;
                }
            }
            z = false;
        }
        return z && !l.getSolo();
    }

    private final String statusOf(Layer l) {
        ArrayList arrayList = new ArrayList();
        if (!l.getVisible()) {
            arrayList.add("HIDDEN");
        }
        if (l.isLive()) {
            arrayList.add("LIVE CAMERA ON CANVAS");
        }
        if (l.isLive()) {
            if (mutedBySolo(l) && !l.getMuted()) {
                arrayList.add("MIC MUTED BY SOLO");
            } else if (l.getMuted()) {
                arrayList.add("MIC MUTED");
            }
        }
        if (l.isClip()) {
            if (mutedBySolo(l) && !l.getMuted()) {
                arrayList.add("MUTED BY SOLO");
            } else if (l.getMuted()) {
                arrayList.add("MUTED");
            }
            if (!l.getPlaying()) {
                arrayList.add("PAUSED");
            }
        }
        if (l.getLocked()) {
            arrayList.add("LOCKED");
        }
        if (Intrinsics.areEqual(l.getFit(), Layer.FIT_FIT) && !l.isText()) {
            arrayList.add("FIT");
        }
        if (arrayList.isEmpty()) {
            return l.isLive() ? "Live camera · framing on the canvas" : l.isClip() ? "Visible · Sound on · Playing" : l.isText() ? "Text overlay" : "Visible";
        }
        return CollectionsKt.joinToString$default(arrayList, " · ", null, null, 0, null, null, 62, null);
    }

    private final int statusColor(Layer l) {
        if (!l.getVisible()) {
            return Color.argb(170, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE);
        }
        if (mutedBySolo(l) || l.getMuted()) {
            return UI.INSTANCE.getDANGER();
        }
        return (!l.isClip() || l.getPlaying()) ? Color.argb(140, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE) : UI.INSTANCE.getACCENT2();
    }

    private final TextView badge(String text, int color) {
        TextView textView = new TextView(this.act);
        textView.setText(text);
        textView.setTextSize(7.5f);
        textView.setTypeface(Typeface.create("sans-serif-medium", 1));
        textView.setTextColor(color);
        textView.setGravity(17);
        textView.setPadding(UI.INSTANCE.dp(this.act, 5), UI.INSTANCE.dp(this.act, 2), UI.INSTANCE.dp(this.act, 5), UI.INSTANCE.dp(this.act, 2));
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(UI.INSTANCE.dpf(this.act, 6.0f));
        gradientDrawable.setColor(Color.argb(60, Color.red(color), Color.green(color), Color.blue(color)));
        gradientDrawable.setStroke(1, Color.argb(140, Color.red(color), Color.green(color), Color.blue(color)));
        textView.setBackground(gradientDrawable);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.setMargins(UI.INSTANCE.dp(this.act, 3), 0, UI.INSTANCE.dp(this.act, 3), 0);
        textView.setLayoutParams(layoutParams);
        return textView;
    }

    private final boolean handleTouch(MotionEvent ev, LinearLayout row, Layer l) {
        Layer layer;
        int actionMasked = ev.getActionMasked();
        boolean z = false;
        if (actionMasked == 0) {
            this.dragRow = row;
            this.dragLayer = l;
            this.onReorderStart.invoke();
            ViewParent parent = row.getParent();
            if (parent != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
            row.performHapticFeedback(0);
            Drawable background = row.getBackground();
            GradientDrawable gradientDrawable = background instanceof GradientDrawable ? (GradientDrawable) background : null;
            if (gradientDrawable != null) {
                gradientDrawable.setColor(Color.argb(150, 40, 45, 60));
            }
            return true;
        }
        if (actionMasked != 1) {
            if (actionMasked == 2) {
                LinearLayout linearLayout = this.dragRow;
                if (linearLayout == null) {
                    return true;
                }
                autoScroll(ev);
                Project projectInvoke = this.projectRef.invoke();
                int size = projectInvoke.getLayers().size();
                if (size < 2) {
                    return true;
                }
                float fDp = UI.INSTANCE.dp(this.act, this.ROW_DP) + UI.INSTANCE.dp(this.act, 4);
                int i = size - 1;
                int iCoerceIn = RangesKt.coerceIn((int) (((ev.getRawY() - locationOf(this.container)[1]) - (fDp / 2.0f)) / fDp), 0, i);
                LinearLayout linearLayout2 = linearLayout;
                if (iCoerceIn != this.container.indexOfChild(linearLayout2)) {
                    if (iCoerceIn >= 0 && iCoerceIn < this.container.getChildCount()) {
                        z = true;
                    }
                    if (!z || (layer = this.dragLayer) == null) {
                        return true;
                    }
                    int iIndexOf = projectInvoke.getLayers().indexOf(layer);
                    int i2 = i - iCoerceIn;
                    if (iIndexOf >= 0 && i2 != iIndexOf) {
                        this.onReorder.invoke(Integer.valueOf(iIndexOf), Integer.valueOf(i2));
                        this.container.removeView(linearLayout2);
                        this.container.addView(linearLayout2, iCoerceIn);
                        linearLayout.performHapticFeedback(1);
                    }
                }
                return true;
            }
            if (actionMasked != 3) {
                return true;
            }
        }
        ViewParent parent2 = row.getParent();
        if (parent2 != null) {
            parent2.requestDisallowInterceptTouchEvent(false);
        }
        LinearLayout linearLayout3 = this.dragRow;
        if (linearLayout3 != null) {
            Drawable background2 = linearLayout3.getBackground();
            GradientDrawable gradientDrawable2 = background2 instanceof GradientDrawable ? (GradientDrawable) background2 : null;
            if (gradientDrawable2 != null) {
                gradientDrawable2.setColor(Color.argb(120, 20, 23, 31));
            }
        }
        if (ev.getActionMasked() == 1) {
            this.onReorderEnd.invoke();
        }
        this.dragRow = null;
        this.dragLayer = null;
        return true;
    }

    private final int[] locationOf(View v) {
        int[] iArr = new int[2];
        v.getLocationOnScreen(iArr);
        return iArr;
    }

    private final ScrollView hostScroller() {
        for (ViewParent parent = this.container.getParent(); parent != null; parent = parent.getParent()) {
            if (parent instanceof ScrollView) {
                return (ScrollView) parent;
            }
        }
        return null;
    }

    private final void autoScroll(MotionEvent ev) {
        ScrollView scrollViewHostScroller = hostScroller();
        if (scrollViewHostScroller == null) {
            return;
        }
        int[] iArrLocationOf = locationOf(scrollViewHostScroller);
        int iDp = UI.INSTANCE.dp(this.act, 64);
        int iDp2 = UI.INSTANCE.dp(this.act, 14);
        float rawY = ev.getRawY() - iArrLocationOf[1];
        if (rawY < iDp) {
            scrollViewHostScroller.smoothScrollBy(0, -iDp2);
        } else if (rawY > scrollViewHostScroller.getHeight() - iDp) {
            scrollViewHostScroller.smoothScrollBy(0, iDp2);
        }
    }
}
