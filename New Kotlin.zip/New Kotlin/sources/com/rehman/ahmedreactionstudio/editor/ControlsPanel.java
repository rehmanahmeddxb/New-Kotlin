package com.rehman.ahmedreactionstudio.editor;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.rehman.ahmedreactionstudio.R;
import com.rehman.ahmedreactionstudio.core.Layer;
import com.rehman.ahmedreactionstudio.util.UI;
import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: ControlsPanel.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\u0018\u00002\u00020\u0001:\u0001#B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\"\u0010\u0012\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00162\b\b\u0002\u0010\u0017\u001a\u00020\u0016H\u0002J&\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u00162\u0006\u0010\u001b\u001a\u00020\u00162\u0006\u0010\u001c\u001a\u00020\u00162\u0006\u0010\u001d\u001a\u00020\u0016J\b\u0010\u001e\u001a\u00020\u001fH\u0002J\u0010\u0010 \u001a\u00020\u001f2\u0006\u0010!\u001a\u00020\"H\u0002R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\b\u001a\u0004\u0018\u00010\tX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR\u000e\u0010\u000e\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/ControlsPanel;", "Landroid/widget/LinearLayout;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "exportBtn", "Landroid/widget/Button;", "flashBtn", "listener", "Lcom/rehman/ahmedreactionstudio/editor/ControlsPanel$Listener;", "getListener", "()Lcom/rehman/ahmedreactionstudio/editor/ControlsPanel$Listener;", "setListener", "(Lcom/rehman/ahmedreactionstudio/editor/ControlsPanel$Listener;)V", "pauseBtn", "recBtn", "saveBtn", "stopBtn", "actionBtn", "label", "", "accent", "", "danger", "bind", "", "recording", "playing", "flashOn", "recReady", "panelBg", "Landroid/graphics/drawable/GradientDrawable;", "pill", Layer.FIT_FILL, "", "Listener"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class ControlsPanel extends LinearLayout {

    @NotNull
    private final Button exportBtn;

    @NotNull
    private final Button flashBtn;

    @Nullable
    private Listener listener;

    @NotNull
    private final Button pauseBtn;

    @NotNull
    private final Button recBtn;

    @NotNull
    private final Button saveBtn;

    @NotNull
    private final Button stopBtn;

    /* JADX INFO: compiled from: ControlsPanel.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\bf\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H&J\b\u0010\u0004\u001a\u00020\u0003H&J\b\u0010\u0005\u001a\u00020\u0003H&J\b\u0010\u0006\u001a\u00020\u0003H&J\b\u0010\u0007\u001a\u00020\u0003H&J\b\u0010\b\u001a\u00020\u0003H&"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/ControlsPanel$Listener;", "", "onExport", "", "onFlashlight", "onPause", "onSave", "onStartRecording", "onStop"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public interface Listener {
        void onExport();

        void onFlashlight();

        void onPause();

        void onSave();

        void onStartRecording();

        void onStop();
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ControlsPanel(@NotNull Context context) {
        super(context);
        Intrinsics.checkNotNullParameter(context, "context");
        setOrientation(1);
        setPadding(UI.INSTANCE.dp(context, 12), UI.INSTANCE.dp(context, 10), UI.INSTANCE.dp(context, 12), UI.INSTANCE.dp(context, 10));
        setBackground(panelBg());
        TextView textView = new TextView(context);
        textView.setText("Controls");
        textView.setTextColor(-1);
        textView.setTextSize(16.0f);
        textView.setTypeface(textView.getTypeface(), 1);
        textView.setPadding(0, 0, 0, UI.INSTANCE.dp(context, 8));
        textView.setCompoundDrawablesRelativeWithIntrinsicBounds(Ic.INSTANCE.get(context, R.drawable.ic_video, -1), (Drawable) null, (Drawable) null, (Drawable) null);
        textView.setCompoundDrawablePadding(UI.INSTANCE.dp(context, 8));
        textView.setGravity(16);
        addView(textView);
        this.recBtn = actionBtn("●  Start Recording", true, false);
        this.recBtn.setContentDescription("Start recording the composition");
        this.recBtn.setMinHeight(UI.INSTANCE.dp(context, 48));
        this.recBtn.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$ControlsPanel$lwJwXXIW9ZRofdHSZvREWj5uSDc
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ControlsPanel._init_$lambda$1(this.f$0, view);
            }
        });
        Button button = this.recBtn;
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, UI.INSTANCE.dp(context, 48));
        layoutParams.bottomMargin = UI.INSTANCE.dp(context, 8);
        Unit unit = Unit.INSTANCE;
        addView(button, layoutParams);
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(17);
        this.pauseBtn = actionBtn$default(this, "Pause", false, false, 4, null);
        this.pauseBtn.setContentDescription("Pause or play preview");
        this.pauseBtn.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$ControlsPanel$RHroJLPEZNIj35A4porVeWn57XE
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ControlsPanel._init_$lambda$4(this.f$0, view);
            }
        });
        this.stopBtn = actionBtn$default(this, "Stop", false, false, 4, null);
        this.stopBtn.setContentDescription("Stop recording or playback");
        this.stopBtn.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$ControlsPanel$wrcDKdfDaNGtfqND1vt4vETcIjw
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ControlsPanel._init_$lambda$5(this.f$0, view);
            }
        });
        Button button2 = this.pauseBtn;
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, UI.INSTANCE.dp(context, 48), 1.0f);
        layoutParams2.setMarginEnd(UI.INSTANCE.dp(context, 4));
        Unit unit2 = Unit.INSTANCE;
        linearLayout.addView(button2, layoutParams2);
        Button button3 = this.stopBtn;
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(0, UI.INSTANCE.dp(context, 48), 1.0f);
        layoutParams3.setMarginStart(UI.INSTANCE.dp(context, 4));
        Unit unit3 = Unit.INSTANCE;
        linearLayout.addView(button3, layoutParams3);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams4.bottomMargin = UI.INSTANCE.dp(context, 6);
        Unit unit4 = Unit.INSTANCE;
        addView(linearLayout, layoutParams4);
        LinearLayout linearLayout2 = new LinearLayout(context);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(17);
        this.saveBtn = actionBtn$default(this, "Save", false, false, 4, null);
        this.saveBtn.setContentDescription("Save the project");
        this.saveBtn.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$ControlsPanel$aC8INHW37VzDnk1FEh2rIZ99x3g
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ControlsPanel._init_$lambda$10(this.f$0, view);
            }
        });
        this.flashBtn = actionBtn$default(this, "Flash", false, false, 4, null);
        this.flashBtn.setContentDescription("Toggle flashlight or screen light");
        this.flashBtn.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$ControlsPanel$TSV_RSs7v2f05XERKIpGPe4nfho
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ControlsPanel._init_$lambda$11(this.f$0, view);
            }
        });
        Button button4 = this.saveBtn;
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(0, UI.INSTANCE.dp(context, 48), 1.0f);
        layoutParams5.setMarginEnd(UI.INSTANCE.dp(context, 4));
        Unit unit5 = Unit.INSTANCE;
        linearLayout2.addView(button4, layoutParams5);
        Button button5 = this.flashBtn;
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(0, UI.INSTANCE.dp(context, 48), 1.0f);
        layoutParams6.setMarginStart(UI.INSTANCE.dp(context, 4));
        Unit unit6 = Unit.INSTANCE;
        linearLayout2.addView(button5, layoutParams6);
        LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams7.bottomMargin = UI.INSTANCE.dp(context, 6);
        Unit unit7 = Unit.INSTANCE;
        addView(linearLayout2, layoutParams7);
        this.exportBtn = actionBtn$default(this, "Export", false, false, 4, null);
        this.exportBtn.setContentDescription("Export the composition");
        this.exportBtn.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$ControlsPanel$jGry81EnOKZ_Elz4YVlq7O0GVYA
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ControlsPanel._init_$lambda$15(this.f$0, view);
            }
        });
        addView(this.exportBtn, new LinearLayout.LayoutParams(-1, UI.INSTANCE.dp(context, 48)));
    }

    @Nullable
    public final Listener getListener() {
        return this.listener;
    }

    public final void setListener(@Nullable Listener listener) {
        this.listener = listener;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$1(ControlsPanel this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Listener listener = this$0.listener;
        if (listener != null) {
            listener.onStartRecording();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$4(ControlsPanel this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Listener listener = this$0.listener;
        if (listener != null) {
            listener.onPause();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$5(ControlsPanel this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Listener listener = this$0.listener;
        if (listener != null) {
            listener.onStop();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$10(ControlsPanel this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Listener listener = this$0.listener;
        if (listener != null) {
            listener.onSave();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$11(ControlsPanel this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Listener listener = this$0.listener;
        if (listener != null) {
            listener.onFlashlight();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$15(ControlsPanel this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Listener listener = this$0.listener;
        if (listener != null) {
            listener.onExport();
        }
    }

    public final void bind(boolean recording, boolean playing, boolean flashOn, boolean recReady) {
        int iRgb;
        String str;
        this.recBtn.setText(recording ? "■  Stop & Save" : "●  Start Recording");
        this.recBtn.setContentDescription(recording ? "Stop recording and save" : "Start recording the composition");
        this.recBtn.setEnabled(true);
        this.recBtn.setAlpha((recording || recReady) ? 1.0f : 0.85f);
        Button button = this.recBtn;
        if (recording) {
            iRgb = Color.rgb(200, 34, 34);
        } else if (recReady) {
            iRgb = UI.INSTANCE.getACCENT();
        } else {
            iRgb = Color.rgb(30, 34, 48);
        }
        button.setBackground(pill(iRgb));
        this.pauseBtn.setText(playing ? "Pause" : "Play");
        Button button2 = this.pauseBtn;
        if (!recording) {
            str = playing ? "Pause preview" : "Play preview";
        }
        button2.setContentDescription(str);
        this.pauseBtn.setAlpha(recording ? 0.5f : 1.0f);
        this.pauseBtn.setBackground(pill((!playing || recording) ? Color.rgb(30, 34, 48) : Color.rgb(40, 90, 70)));
        this.stopBtn.setAlpha((recording || playing) ? 1.0f : 0.7f);
        this.stopBtn.setEnabled(true);
        this.flashBtn.setText(flashOn ? "Flash on" : "Flash");
        this.flashBtn.setBackground(pill(flashOn ? Color.rgb(180, 120, 20) : Color.rgb(30, 34, 48)));
        this.flashBtn.setTextColor(flashOn ? Color.rgb(KotlinVersion.MAX_COMPONENT_VALUE, 230, 140) : -1);
        this.exportBtn.setEnabled(!recording);
        this.exportBtn.setAlpha(recording ? 0.5f : 1.0f);
    }

    static /* synthetic */ Button actionBtn$default(ControlsPanel controlsPanel, String str, boolean z, boolean z2, int i, Object obj) {
        if ((i & 4) != 0) {
            z2 = false;
        }
        return controlsPanel.actionBtn(str, z, z2);
    }

    private final Button actionBtn(String label, boolean accent, boolean danger) {
        int iRgb;
        Button button = new Button(getContext());
        button.setText(label);
        button.setAllCaps(false);
        button.setTypeface(Typeface.create("sans-serif-medium", 1));
        button.setTextColor(-1);
        button.setTextSize(12.0f);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        UI ui = UI.INSTANCE;
        Context context = getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        int iDp = ui.dp(context, 6);
        UI ui2 = UI.INSTANCE;
        Context context2 = getContext();
        Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
        button.setPadding(iDp, 0, ui2.dp(context2, 6), 0);
        if (danger) {
            iRgb = Color.rgb(200, 34, 34);
        } else if (accent) {
            iRgb = UI.INSTANCE.getACCENT();
        } else {
            iRgb = Color.rgb(30, 34, 48);
        }
        button.setBackground(pill(iRgb));
        return button;
    }

    private final GradientDrawable panelBg() {
        GradientDrawable gradientDrawable = new GradientDrawable();
        UI ui = UI.INSTANCE;
        Context context = getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        gradientDrawable.setCornerRadius(ui.dpf(context, 14.0f));
        gradientDrawable.setColor(Color.rgb(18, 20, 26));
        UI ui2 = UI.INSTANCE;
        Context context2 = getContext();
        Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
        gradientDrawable.setStroke(ui2.dp(context2, 1), Color.argb(60, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
        return gradientDrawable;
    }

    private final GradientDrawable pill(int fill) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        UI ui = UI.INSTANCE;
        Context context = getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        gradientDrawable.setCornerRadius(ui.dpf(context, 10.0f));
        gradientDrawable.setColor(fill);
        UI ui2 = UI.INSTANCE;
        Context context2 = getContext();
        Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
        gradientDrawable.setStroke(ui2.dp(context2, 1), Color.rgb(80, 85, 100));
        return gradientDrawable;
    }
}
