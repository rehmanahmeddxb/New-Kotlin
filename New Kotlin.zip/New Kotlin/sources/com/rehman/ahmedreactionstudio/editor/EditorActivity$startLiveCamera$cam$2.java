package com.rehman.ahmedreactionstudio.editor;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.io.encoding.Base64;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: EditorActivity.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n¢\u0006\u0002\b\u0004"}, d2 = {"<anonymous>", "", "state", "", "invoke"}, k = Base64.bytesPerGroup, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nEditorActivity.kt\nKotlin\n*S Kotlin\n*F\n+ 1 EditorActivity.kt\ncom/rehman/ahmedreactionstudio/editor/EditorActivity$startLiveCamera$cam$2\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,2717:1\n1#2:2718\n*E\n"})
final class EditorActivity$startLiveCamera$cam$2 extends Lambda implements Function1<String, Unit> {
    final /* synthetic */ EditorActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    EditorActivity$startLiveCamera$cam$2(EditorActivity editorActivity) {
        super(1);
        this.this$0 = editorActivity;
    }

    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ Unit invoke(String str) {
        invoke2(str);
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
    public final void invoke2(@NotNull final String state) {
        Intrinsics.checkNotNullParameter(state, "state");
        final EditorActivity editorActivity = this.this$0;
        editorActivity.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$startLiveCamera$cam$2$5dIAE0MvqHqTlqIOn7DRMpgpWpI
            @Override // java.lang.Runnable
            public final void run() {
                EditorActivity$startLiveCamera$cam$2.invoke$lambda$1(state, editorActivity);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /* JADX WARN: Removed duplicated region for block: B:17:0x003e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final void invoke$lambda$1(java.lang.String r3, com.rehman.ahmedreactionstudio.editor.EditorActivity r4) {
        /*
            Method dump skipped, instruction units count: 344
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.editor.EditorActivity$startLiveCamera$cam$2.invoke$lambda$1(java.lang.String, com.rehman.ahmedreactionstudio.editor.EditorActivity):void");
    }
}
