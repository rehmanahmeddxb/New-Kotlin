package com.rehman.ahmedreactionstudio.editor;

import android.content.Context;
import android.graphics.Bitmap;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.util.Size;
import android.view.Surface;
import android.view.WindowManager;
import com.rehman.ahmedreactionstudio.camera.TorchController;
import java.io.File;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: LiveCamera.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u009c\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0015\n\u0000\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\f\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b)\u0018\u0000 \u0083\u00012\u00020\u0001:\u0002\u0083\u0001B5\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005\u0012\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u00070\u0005¢\u0006\u0002\u0010\nJ\u0010\u0010O\u001a\u00020\u00072\u0006\u0010P\u001a\u00020\u000fH\u0002J\b\u0010Q\u001a\u00020\u0007H\u0002J\u0006\u0010R\u001a\u00020\u000fJ\u0006\u0010S\u001a\u00020\u000fJ\u0006\u0010T\u001a\u00020\u000fJ\b\u0010U\u001a\u00020\u0007H\u0002J\b\u0010V\u001a\u00020WH\u0002J\u0012\u0010X\u001a\u0004\u0018\u00010\u00062\u0006\u0010Y\u001a\u00020ZH\u0002J\b\u0010[\u001a\u00020\u0007H\u0002J\b\u0010\\\u001a\u00020\u001bH\u0002J\u000e\u0010]\u001a\u00020\u000f2\u0006\u0010P\u001a\u00020\u000fJ\u0006\u0010^\u001a\u00020\u000fJ\u0006\u0010_\u001a\u00020\u000fJ\u0006\u0010`\u001a\u00020\u000fJ\u0006\u0010a\u001a\u00020\u000fJ\u0006\u0010b\u001a\u00020\u000fJ\u0006\u0010c\u001a\u00020\u000fJ\u0006\u0010d\u001a\u00020\u000fJ\u0006\u0010e\u001a\u00020\u000fJ\u0010\u0010f\u001a\u00020\u00072\u0006\u0010g\u001a\u00020\tH\u0002J\b\u0010h\u001a\u00020\u0007H\u0002J\n\u0010i\u001a\u0004\u0018\u00010\tH\u0002J\b\u0010j\u001a\u00020\u0007H\u0002J\b\u0010k\u001a\u00020\u0007H\u0002J\b\u0010l\u001a\u00020\u0007H\u0002J\u000e\u0010m\u001a\u00020\u000f2\u0006\u0010n\u001a\u00020\u000fJ\u000e\u0010o\u001a\u00020\u00072\u0006\u0010p\u001a\u00020\u000fJ\u000e\u0010I\u001a\u00020\u000f2\u0006\u0010n\u001a\u00020\u000fJ\u0016\u0010q\u001a\u00020\u000f2\u0006\u0010P\u001a\u00020\u000f2\u0006\u0010n\u001a\u00020\u000fJ\b\u0010r\u001a\u00020\u0007H\u0002J\u000e\u0010s\u001a\u00020\u00072\u0006\u0010P\u001a\u00020\u000fJ\"\u0010t\u001a\u00020\u00072\u0006\u0010u\u001a\u0002052\u0012\u0010v\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u00070\u0005J\u0010\u0010w\u001a\u00020\u000f2\u0006\u0010u\u001a\u000205H\u0002J\u0006\u0010x\u001a\u00020\u0007J\u001c\u0010y\u001a\u00020\u00072\u0014\u0010z\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u000105\u0012\u0004\u0012\u00020\u00070\u0005J\u0012\u0010{\u001a\u0004\u0018\u0001052\u0006\u0010|\u001a\u00020\u000fH\u0002J\u0006\u0010}\u001a\u00020\u0007J\u0006\u0010~\u001a\u00020\u000fJ\u0006\u0010\u007f\u001a\u00020\u000fJ\u0007\u0010\u0080\u0001\u001a\u00020\u000fJ\u0007\u0010\u0081\u0001\u001a\u00020\tJ\t\u0010\u0082\u0001\u001a\u00020\u0007H\u0002R\u0010\u0010\u000b\u001a\u0004\u0018\u00010\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u000e\u001a\u00020\u000f@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u000e\u0010\u0013\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0015\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0017\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0018\u001a\u0004\u0018\u00010\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\u001e\u001a\u00020\u000f2\u0006\u0010\u000e\u001a\u00020\u000f@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u0012R\u000e\u0010 \u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010!\u001a\u0004\u0018\u00010\"X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010#\u001a\u00020\u000f2\u0006\u0010\u000e\u001a\u00020\u000f@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b$\u0010\u0012R\u000e\u0010%\u001a\u00020&X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010,\u001a\u00020\u001b2\u0006\u0010\u000e\u001a\u00020\u001b@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b-\u0010.R\u001e\u0010/\u001a\u00020\u001b2\u0006\u0010\u000e\u001a\u00020\u001b@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b0\u0010.R\u0010\u00101\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u00102\u001a\u0004\u0018\u000103X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u00104\u001a\u0004\u0018\u000105X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u00106\u001a\u0004\u0018\u00010\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u00107\u001a\u0004\u0018\u000108X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u00109\u001a\u00020\u000f2\u0006\u0010\u000e\u001a\u00020\u000f@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b:\u0010\u0012R\u000e\u0010;\u001a\u00020<X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010=\u001a\u00020<X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010>\u001a\u00020<X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010?\u001a\u00020\u000f2\u0006\u0010\u000e\u001a\u00020\u000f@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b@\u0010\u0012R\u000e\u0010A\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010B\u001a\u0004\u0018\u00010CX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010D\u001a\u0004\u0018\u00010EX\u0082\u000e¢\u0006\u0002\n\u0000R$\u0010G\u001a\u00020\u000f2\u0006\u0010F\u001a\u00020\u000f8F@BX\u0086\u000e¢\u0006\f\u001a\u0004\bH\u0010\u0012\"\u0004\bI\u0010JR\u000e\u0010K\u001a\u00020LX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010M\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010N\u001a\u00020\u001bX\u0082\u000e¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/LiveCamera;", "", "ctx", "Landroid/content/Context;", "onFrame", "Lkotlin/Function1;", "Landroid/graphics/Bitmap;", "", "onState", "", "(Landroid/content/Context;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)V", "activeCameraId", "argb", "", "<set-?>", "", "backHasFlash", "getBackHasFlash", "()Z", "backTorch", "bothTorches", "bufA", "bufB", "bufC", "device", "Landroid/hardware/camera2/CameraDevice;", "facing", "", "feedSize", "Landroid/util/Size;", "frontHasFlash", "getFrontHasFlash", "frontTorch", "handler", "Landroid/os/Handler;", "hasFlashUnit", "getHasFlashUnit", "lastFrameAt", "", "lastOutH", "lastOutW", "lastTorchError", "mirror", "opening", "outH", "getOutH", "()I", "outW", "getOutW", "published", "reader", "Landroid/media/ImageReader;", "recordFile", "Ljava/io/File;", "recordSize", "recorder", "Landroid/media/MediaRecorder;", "recording", "getRecording", "rowU", "", "rowV", "rowY", "running", "getRunning", "sensorOrientation", "session", "Landroid/hardware/camera2/CameraCaptureSession;", "thread", "Landroid/os/HandlerThread;", "v", "torch", "getTorch", "setTorch", "(Z)V", "torchCtl", "Lcom/rehman/ahmedreactionstudio/camera/TorchController;", "torchViaRequest", "writeSlot", "applySide", "front", "applyTorch", "bothTorchesFullyOn", "bothTorchesMode", "bothTorchesOn", "closeCameraOnly", "cm", "Landroid/hardware/camera2/CameraManager;", "convert", "img", "Landroid/media/Image;", "createSession", "displayRotation", "flashAvailable", "hasFlashForBack", "hasFlashForFront", "hasPermission", "isFront", "isTorchLitForBack", "isTorchLitForFront", "isTorchOnForBack", "isTorchOnForFront", "noteTorchError", "msg", "openLocked", "pickCameraId", "refreshFlashCache", "releaseAll", "repeatRequest", "setBothTorches", "on", "setMirror", "m", "setTorchFor", "shutdownTorch", "start", "startRecording", "dir", "onStarted", "startRecordingLocked", "stop", "stopRecording", "onDone", "stopRecordingLocked", "discard", "switchFacing", "toggleBackTorch", "toggleFrontTorch", "toggleTorch", "torchLastError", "torchOff", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nLiveCamera.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LiveCamera.kt\ncom/rehman/ahmedreactionstudio/editor/LiveCamera\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,776:1\n1282#2,2:777\n3792#2:779\n4307#2,2:780\n3792#2:796\n4307#2,2:797\n2333#3,14:782\n2333#3,14:799\n1#4:813\n*S KotlinDebug\n*F\n+ 1 LiveCamera.kt\ncom/rehman/ahmedreactionstudio/editor/LiveCamera\n*L\n406#1:777,2\n426#1:779\n426#1:780,2\n433#1:796\n433#1:797,2\n427#1:782,14\n434#1:799,14\n*E\n"})
public final class LiveCamera {
    private static final long TARGET_FPS_MS = 42;

    @Nullable
    private String activeCameraId;

    @NotNull
    private int[] argb;
    private volatile boolean backHasFlash;
    private volatile boolean backTorch;
    private volatile boolean bothTorches;

    @Nullable
    private Bitmap bufA;

    @Nullable
    private Bitmap bufB;

    @Nullable
    private Bitmap bufC;

    @NotNull
    private final Context ctx;

    @Nullable
    private CameraDevice device;
    private volatile int facing;

    @NotNull
    private Size feedSize;
    private volatile boolean frontHasFlash;
    private volatile boolean frontTorch;

    @Nullable
    private Handler handler;
    private volatile boolean hasFlashUnit;
    private long lastFrameAt;
    private int lastOutH;
    private int lastOutW;

    @NotNull
    private volatile String lastTorchError;
    private volatile boolean mirror;

    @NotNull
    private final Function1<Bitmap, Unit> onFrame;

    @NotNull
    private final Function1<String, Unit> onState;
    private volatile boolean opening;
    private volatile int outH;
    private volatile int outW;

    @Nullable
    private volatile Bitmap published;

    @Nullable
    private ImageReader reader;

    @Nullable
    private File recordFile;

    @Nullable
    private Size recordSize;

    @Nullable
    private MediaRecorder recorder;
    private volatile boolean recording;

    @NotNull
    private byte[] rowU;

    @NotNull
    private byte[] rowV;

    @NotNull
    private byte[] rowY;
    private volatile boolean running;
    private int sensorOrientation;

    @Nullable
    private CameraCaptureSession session;

    @Nullable
    private HandlerThread thread;

    @NotNull
    private final TorchController torchCtl;
    private volatile boolean torchViaRequest;
    private int writeSlot;

    @NotNull
    private static final Size WANT = new Size(960, 540);

    /* JADX WARN: Multi-variable type inference failed */
    public LiveCamera(@NotNull Context ctx, @NotNull Function1<? super Bitmap, Unit> onFrame, @NotNull Function1<? super String, Unit> onState) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(onFrame, "onFrame");
        Intrinsics.checkNotNullParameter(onState, "onState");
        this.ctx = ctx;
        this.onFrame = onFrame;
        this.onState = onState;
        this.torchCtl = new TorchController(this.ctx);
        this.mirror = true;
        this.lastTorchError = "";
        this.sensorOrientation = 90;
        this.feedSize = WANT;
        this.argb = new int[0];
        this.rowY = new byte[0];
        this.rowU = new byte[0];
        this.rowV = new byte[0];
    }

    public final boolean getTorch() {
        return isFront() ? this.frontTorch : this.backTorch;
    }

    private final void setTorch(boolean z) {
        if (isFront()) {
            this.frontTorch = z;
        } else {
            this.backTorch = z;
        }
    }

    public final boolean getHasFlashUnit() {
        return this.hasFlashUnit;
    }

    public final boolean getFrontHasFlash() {
        return this.frontHasFlash;
    }

    public final boolean getBackHasFlash() {
        return this.backHasFlash;
    }

    public final boolean getRecording() {
        return this.recording;
    }

    public final boolean getRunning() {
        return this.running;
    }

    public final int getOutW() {
        return this.outW;
    }

    public final int getOutH() {
        return this.outH;
    }

    public final boolean hasPermission() {
        return this.ctx.checkSelfPermission("android.permission.CAMERA") == 0;
    }

    public final boolean isFront() {
        return this.facing == 0;
    }

    /* JADX INFO: renamed from: isTorchOnForFront, reason: from getter */
    public final boolean getFrontTorch() {
        return this.frontTorch;
    }

    /* JADX INFO: renamed from: isTorchOnForBack, reason: from getter */
    public final boolean getBackTorch() {
        return this.backTorch;
    }

    public final boolean hasFlashForFront() {
        return this.frontHasFlash;
    }

    public final boolean hasFlashForBack() {
        return this.backHasFlash;
    }

    public final boolean isTorchLitForFront() {
        return this.torchCtl.isTorchOn(true);
    }

    public final boolean isTorchLitForBack() {
        return this.torchCtl.isTorchOn(false);
    }

    /* JADX INFO: renamed from: bothTorchesMode, reason: from getter */
    public final boolean getBothTorches() {
        return this.bothTorches;
    }

    public final boolean setBothTorches(boolean on) {
        boolean z;
        refreshFlashCache();
        if (this.frontHasFlash) {
            this.frontTorch = on;
            z = true;
        } else {
            z = false;
        }
        if (this.backHasFlash) {
            this.backTorch = on;
            z = true;
        }
        if (!z) {
            return false;
        }
        this.bothTorches = on;
        Handler handler = this.handler;
        if (handler != null) {
            handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$LiveCamera$bM9Z12nXJILE8Lva2uJti-oJZZ4
                @Override // java.lang.Runnable
                public final void run() {
                    LiveCamera.setBothTorches$lambda$0(this.f$0);
                }
            });
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setBothTorches$lambda$0(LiveCamera this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.applyTorch();
    }

    public final boolean bothTorchesOn() {
        return (this.frontHasFlash && this.frontTorch) || (this.backHasFlash && this.backTorch);
    }

    public final boolean bothTorchesFullyOn() {
        return this.bothTorches && (this.frontHasFlash || this.backHasFlash) && ((!this.frontHasFlash || this.frontTorch) && (!this.backHasFlash || this.backTorch));
    }

    /* JADX INFO: renamed from: setTorch, reason: collision with other method in class */
    public final boolean m30setTorch(boolean on) {
        if (on && !this.hasFlashUnit) {
            return false;
        }
        if (isFront()) {
            this.frontTorch = on;
        } else {
            this.backTorch = on;
        }
        if (!on) {
            this.bothTorches = false;
        }
        Handler handler = this.handler;
        if (handler == null) {
            return true;
        }
        handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$LiveCamera$8UjiS8UiU5-gZjKHSZRTwTjuugg
            @Override // java.lang.Runnable
            public final void run() {
                LiveCamera.setTorch$lambda$1(this.f$0);
            }
        });
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setTorch$lambda$1(LiveCamera this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.applyTorch();
    }

    public final boolean setTorchFor(boolean front, boolean on) {
        refreshFlashCache();
        boolean z = front ? this.frontHasFlash : this.backHasFlash;
        if (on && !z) {
            return false;
        }
        if (front) {
            this.frontTorch = on;
        } else {
            this.backTorch = on;
        }
        if (!on) {
            this.bothTorches = false;
        }
        Handler handler = this.handler;
        if (handler == null) {
            return true;
        }
        handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$LiveCamera$LhLAibLVZ0PkiiNv_XOHFJl3FEI
            @Override // java.lang.Runnable
            public final void run() {
                LiveCamera.setTorchFor$lambda$2(this.f$0);
            }
        });
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setTorchFor$lambda$2(LiveCamera this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.applyTorch();
    }

    public final boolean toggleTorch() {
        return m30setTorch(!getTorch());
    }

    public final boolean toggleFrontTorch() {
        return setTorchFor(true, !this.frontTorch);
    }

    public final boolean toggleBackTorch() {
        return setTorchFor(false, !this.backTorch);
    }

    public final boolean flashAvailable(boolean front) {
        return this.torchCtl.hasFlash(front);
    }

    @NotNull
    public final String torchLastError() {
        return this.torchCtl.getLastFail() == TorchController.Fail.NONE ? "" : this.torchCtl.failureText();
    }

    public final void setMirror(boolean m) {
        this.mirror = m;
    }

    private final CameraManager cm() {
        Object systemService = this.ctx.getSystemService("camera");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.hardware.camera2.CameraManager");
        return (CameraManager) systemService;
    }

    private final void refreshFlashCache() {
        this.torchCtl.start();
        this.torchCtl.refresh();
        this.frontHasFlash = this.torchCtl.hasFlash(true);
        this.backHasFlash = this.torchCtl.hasFlash(false);
        this.hasFlashUnit = isFront() ? this.frontHasFlash : this.backHasFlash;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void applyTorch() {
        applySide(isFront());
        applySide(!isFront());
        repeatRequest();
    }

    private final void applySide(boolean front) {
        boolean z = front ? this.frontTorch : this.backTorch;
        boolean z2 = front == isFront();
        if (!z) {
            this.torchCtl.setTorch(front, false);
            if (z2) {
                this.torchViaRequest = false;
            }
            noteTorchError("");
            return;
        }
        boolean torch = this.torchCtl.setTorch(front, true);
        boolean z3 = front ? this.frontHasFlash : this.backHasFlash;
        if (z2) {
            this.torchViaRequest = !torch && z3;
        }
        if (torch) {
            noteTorchError("");
            return;
        }
        if (!torch && z3 && z2) {
            noteTorchError("");
            return;
        }
        noteTorchError(this.torchCtl.failureText());
        if (front) {
            this.frontTorch = false;
        } else {
            this.backTorch = false;
        }
    }

    private final void noteTorchError(String msg) {
        if (Intrinsics.areEqual(msg, this.lastTorchError)) {
            return;
        }
        this.lastTorchError = msg;
        if (msg.length() > 0) {
            this.onState.invoke("torcherror");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void torchOff() {
        this.torchCtl.releaseAll();
        this.frontTorch = false;
        this.backTorch = false;
        this.bothTorches = false;
        this.torchViaRequest = false;
    }

    public final void start(boolean front) {
        if (!hasPermission()) {
            this.onState.invoke("permission");
            return;
        }
        this.facing = !front ? 1 : 0;
        refreshFlashCache();
        if (this.thread == null) {
            HandlerThread handlerThread = new HandlerThread("live-cam");
            handlerThread.start();
            this.thread = handlerThread;
            this.handler = new Handler(handlerThread.getLooper());
        }
        this.running = true;
        Handler handler = this.handler;
        if (handler != null) {
            handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$LiveCamera$hR2MNA-_Me208VcLRA9Hn97P_6g
                @Override // java.lang.Runnable
                public final void run() {
                    LiveCamera.start$lambda$3(this.f$0);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void start$lambda$3(LiveCamera this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.openLocked();
    }

    public final void switchFacing() {
        if (this.recording) {
            this.onState.invoke("busy");
            return;
        }
        boolean zIsFront = isFront();
        if (!this.bothTorches) {
            this.torchCtl.setTorch(zIsFront, false);
            if (zIsFront) {
                this.frontTorch = false;
            } else {
                this.backTorch = false;
            }
        }
        boolean z = !zIsFront;
        this.facing = z ? 0 : 1;
        this.mirror = z;
        Handler handler = this.handler;
        if (handler != null) {
            handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$LiveCamera$N3P-6GmHya8zOClcEEDSiQXhD2o
                @Override // java.lang.Runnable
                public final void run() {
                    LiveCamera.switchFacing$lambda$4(this.f$0);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void switchFacing$lambda$4(LiveCamera this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.closeCameraOnly();
        this$0.openLocked();
    }

    public final void stop() {
        this.running = false;
        Handler handler = this.handler;
        if (handler == null) {
            releaseAll();
            shutdownTorch();
            return;
        }
        handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$LiveCamera$rHH8rGlStlK8Xr5xretcVXBwAZA
            @Override // java.lang.Runnable
            public final void run() {
                LiveCamera.stop$lambda$5(this.f$0);
            }
        });
        HandlerThread handlerThread = this.thread;
        if (handlerThread != null) {
            handlerThread.quitSafely();
        }
        this.thread = null;
        this.handler = null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void stop$lambda$5(LiveCamera this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.releaseAll();
        this$0.shutdownTorch();
    }

    private final void shutdownTorch() {
        try {
            this.torchCtl.shutdown();
        } catch (Exception unused) {
        }
    }

    private final void releaseAll() {
        torchOff();
        try {
            repeatRequest();
        } catch (Exception unused) {
        }
        stopRecordingLocked(true);
        closeCameraOnly();
        this.bufA = null;
        this.bufB = null;
        this.bufC = null;
        this.published = null;
        this.argb = new int[0];
    }

    private final void closeCameraOnly() {
        try {
            CameraCaptureSession cameraCaptureSession = this.session;
            if (cameraCaptureSession != null) {
                cameraCaptureSession.close();
            }
        } catch (Exception unused) {
        }
        this.session = null;
        try {
            CameraDevice cameraDevice = this.device;
            if (cameraDevice != null) {
                cameraDevice.close();
            }
        } catch (Exception unused2) {
        }
        this.device = null;
        this.activeCameraId = null;
        try {
            ImageReader imageReader = this.reader;
            if (imageReader != null) {
                imageReader.close();
            }
        } catch (Exception unused3) {
        }
        this.reader = null;
        this.opening = false;
        try {
            this.torchCtl.releaseAll();
        } catch (Exception unused4) {
        }
    }

    private final String pickCameraId() {
        String str;
        CameraManager cameraManagerCm = cm();
        try {
            String[] cameraIdList = cameraManagerCm.getCameraIdList();
            Intrinsics.checkNotNull(cameraIdList);
            int length = cameraIdList.length;
            int i = 0;
            while (true) {
                if (i >= length) {
                    str = null;
                    break;
                }
                str = cameraIdList[i];
                Integer num = (Integer) cameraManagerCm.getCameraCharacteristics(str).get(CameraCharacteristics.LENS_FACING);
                if (num != null && num.intValue() == this.facing) {
                    break;
                }
                i++;
            }
            return str == null ? (String) ArraysKt.firstOrNull(cameraIdList) : str;
        } catch (Exception unused) {
            return null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:48:0x00f4 A[Catch: Exception -> 0x01ab, TryCatch #0 {Exception -> 0x01ab, blocks: (B:14:0x0023, B:18:0x003c, B:20:0x005d, B:23:0x0065, B:25:0x0070, B:27:0x007a, B:32:0x0085, B:33:0x0088, B:34:0x008b, B:46:0x00f0, B:49:0x00f6, B:51:0x00fa, B:53:0x0102, B:55:0x010d, B:57:0x0117, B:62:0x0122, B:63:0x0125, B:64:0x0128, B:76:0x0176, B:78:0x017b, B:67:0x0138, B:70:0x0143, B:71:0x0157, B:74:0x0170, B:37:0x009b, B:40:0x00a6, B:41:0x00c4, B:44:0x00ea, B:48:0x00f4, B:17:0x0038), top: B:82:0x0023 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void openLocked() {
        /*
            Method dump skipped, instruction units count: 442
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.editor.LiveCamera.openLocked():void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void openLocked$lambda$12(LiveCamera this$0, ImageReader imageReader) {
        Image imageAcquireLatestImage;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            imageAcquireLatestImage = imageReader.acquireLatestImage();
        } catch (Exception unused) {
            imageAcquireLatestImage = null;
        }
        if (imageAcquireLatestImage == null) {
            return;
        }
        try {
            long jElapsedRealtime = SystemClock.elapsedRealtime();
            if (jElapsedRealtime - this$0.lastFrameAt >= TARGET_FPS_MS) {
                this$0.lastFrameAt = jElapsedRealtime;
                Bitmap bitmapConvert = this$0.convert(imageAcquireLatestImage);
                if (bitmapConvert != null) {
                    this$0.onFrame.invoke(bitmapConvert);
                }
            }
        } catch (Exception unused2) {
        } catch (Throwable th) {
            try {
                imageAcquireLatestImage.close();
            } catch (Exception unused3) {
            }
            throw th;
        }
        try {
            imageAcquireLatestImage.close();
        } catch (Exception unused4) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void createSession() {
        ImageReader imageReader;
        Surface surface;
        CameraDevice cameraDevice = this.device;
        if (cameraDevice == null || (imageReader = this.reader) == null) {
            return;
        }
        ArrayList arrayList = new ArrayList();
        arrayList.add(imageReader.getSurface());
        MediaRecorder mediaRecorder = this.recorder;
        if (mediaRecorder != null && (surface = mediaRecorder.getSurface()) != null) {
            arrayList.add(surface);
        }
        try {
            cameraDevice.createCaptureSession(arrayList, new CameraCaptureSession.StateCallback() { // from class: com.rehman.ahmedreactionstudio.editor.LiveCamera.createSession.2
                @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
                public void onConfigured(@NotNull CameraCaptureSession s) {
                    Intrinsics.checkNotNullParameter(s, "s");
                    LiveCamera.this.session = s;
                    LiveCamera.this.applyTorch();
                    LiveCamera.this.onState.invoke(LiveCamera.this.getRecording() ? "recording" : "live");
                }

                @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
                public void onConfigureFailed(@NotNull CameraCaptureSession s) {
                    Intrinsics.checkNotNullParameter(s, "s");
                    LiveCamera.this.onState.invoke("error");
                }
            }, this.handler);
        } catch (Exception unused) {
            this.onState.invoke("error");
        }
    }

    private final void repeatRequest() {
        CameraCaptureSession cameraCaptureSession;
        ImageReader imageReader;
        MediaRecorder mediaRecorder;
        Surface surface;
        CameraDevice cameraDevice = this.device;
        if (cameraDevice == null || (cameraCaptureSession = this.session) == null || (imageReader = this.reader) == null) {
            return;
        }
        try {
            CaptureRequest.Builder builderCreateCaptureRequest = cameraDevice.createCaptureRequest(this.recording ? 3 : 1);
            builderCreateCaptureRequest.addTarget(imageReader.getSurface());
            if (this.recording && (mediaRecorder = this.recorder) != null && (surface = mediaRecorder.getSurface()) != null) {
                builderCreateCaptureRequest.addTarget(surface);
            }
            builderCreateCaptureRequest.set(CaptureRequest.CONTROL_MODE, 1);
            boolean z = (isFront() ? this.frontTorch : this.backTorch) && this.hasFlashUnit && this.torchViaRequest;
            builderCreateCaptureRequest.set(CaptureRequest.FLASH_MODE, Integer.valueOf(z ? 2 : 0));
            if (z) {
                builderCreateCaptureRequest.set(CaptureRequest.CONTROL_AE_MODE, 1);
            }
            cameraCaptureSession.setRepeatingRequest(builderCreateCaptureRequest.build(), null, this.handler);
        } catch (Exception unused) {
        }
    }

    public final void startRecording(@NotNull final File dir, @NotNull final Function1<? super Boolean, Unit> onStarted) {
        Intrinsics.checkNotNullParameter(dir, "dir");
        Intrinsics.checkNotNullParameter(onStarted, "onStarted");
        Handler handler = this.handler;
        if (handler == null) {
            onStarted.invoke(false);
        } else {
            handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$LiveCamera$j3QsizjAJagDiJ-OXQbiuHz7n-A
                @Override // java.lang.Runnable
                public final void run() {
                    LiveCamera.startRecording$lambda$15(onStarted, this, dir);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startRecording$lambda$15(Function1 onStarted, LiveCamera this$0, File dir) {
        Intrinsics.checkNotNullParameter(onStarted, "$onStarted");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(dir, "$dir");
        onStarted.invoke(Boolean.valueOf(this$0.startRecordingLocked(dir)));
    }

    private final boolean startRecordingLocked(File dir) {
        int rotation;
        if (this.recording || this.device == null) {
            return false;
        }
        dir.mkdirs();
        File file = new File(dir, "cam_" + System.currentTimeMillis() + ".mp4");
        boolean z = this.ctx.checkSelfPermission("android.permission.RECORD_AUDIO") == 0;
        Size size = this.recordSize;
        if (size == null) {
            size = this.feedSize;
        }
        MediaRecorder mediaRecorder = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this.ctx) : new MediaRecorder();
        try {
            try {
                mediaRecorder.setVideoSource(2);
                if (z) {
                    mediaRecorder.setAudioSource(1);
                }
                mediaRecorder.setOutputFormat(2);
                mediaRecorder.setOutputFile(file.getAbsolutePath());
                mediaRecorder.setVideoEncodingBitRate(6000000);
                mediaRecorder.setVideoFrameRate(30);
                mediaRecorder.setVideoSize(size.getWidth(), size.getHeight());
                mediaRecorder.setVideoEncoder(2);
                if (z) {
                    mediaRecorder.setAudioEncoder(3);
                    mediaRecorder.setAudioEncodingBitRate(128000);
                    mediaRecorder.setAudioSamplingRate(44100);
                }
                try {
                    Object systemService = this.ctx.getSystemService("window");
                    Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.WindowManager");
                    rotation = ((WindowManager) systemService).getDefaultDisplay().getRotation();
                } catch (Exception unused) {
                }
                int i = rotation != 1 ? rotation != 2 ? rotation != 3 ? 0 : 270 : 180 : 90;
                mediaRecorder.setOrientationHint(isFront() ? ((this.sensorOrientation + i) + 180) % 360 : ((this.sensorOrientation - i) + 360) % 360);
                mediaRecorder.prepare();
                this.recorder = mediaRecorder;
                this.recordFile = file;
                try {
                    CameraCaptureSession cameraCaptureSession = this.session;
                    if (cameraCaptureSession != null) {
                        cameraCaptureSession.close();
                    }
                } catch (Exception unused2) {
                }
                this.session = null;
                this.recording = true;
                createSession();
                try {
                    mediaRecorder.start();
                    this.onState.invoke("recording");
                    return true;
                } catch (Exception unused3) {
                    this.recording = false;
                    try {
                        mediaRecorder.release();
                    } catch (Exception unused4) {
                    }
                    this.recorder = null;
                    this.recordFile = null;
                    try {
                        CameraCaptureSession cameraCaptureSession2 = this.session;
                        if (cameraCaptureSession2 != null) {
                            cameraCaptureSession2.close();
                        }
                    } catch (Exception unused5) {
                    }
                    this.session = null;
                    createSession();
                    this.onState.invoke("recfail");
                    return false;
                }
            } catch (Exception unused6) {
                this.onState.invoke("recfail");
                return false;
            }
        } catch (Exception unused7) {
            mediaRecorder.release();
            this.onState.invoke("recfail");
            return false;
        }
    }

    public final void stopRecording(@NotNull final Function1<? super File, Unit> onDone) {
        Intrinsics.checkNotNullParameter(onDone, "onDone");
        Handler handler = this.handler;
        if (handler == null) {
            onDone.invoke(null);
        } else {
            handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$LiveCamera$EPPz_WplXAtLwfeFgmvijp5D5eo
                @Override // java.lang.Runnable
                public final void run() {
                    LiveCamera.stopRecording$lambda$16(this.f$0, onDone);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void stopRecording$lambda$16(LiveCamera this$0, Function1 onDone) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(onDone, "$onDone");
        onDone.invoke(this$0.stopRecordingLocked(false));
    }

    private final File stopRecordingLocked(boolean discard) {
        MediaRecorder mediaRecorder = this.recorder;
        if (mediaRecorder == null) {
            return null;
        }
        boolean z = false;
        this.recording = false;
        torchOff();
        try {
            mediaRecorder.stop();
            z = true;
        } catch (Exception unused) {
        }
        try {
            mediaRecorder.release();
        } catch (Exception unused2) {
        }
        this.recorder = null;
        File file = this.recordFile;
        this.recordFile = null;
        try {
            CameraCaptureSession cameraCaptureSession = this.session;
            if (cameraCaptureSession != null) {
                cameraCaptureSession.close();
            }
        } catch (Exception unused3) {
        }
        this.session = null;
        if (this.device != null && this.running) {
            createSession();
        }
        if (!discard && z && file != null && file.exists() && file.length() >= 40000) {
            return file;
        }
        if (file != null) {
            try {
                file.delete();
            } catch (Exception unused4) {
            }
        }
        return null;
    }

    /* JADX WARN: Removed duplicated region for block: B:107:0x01eb  */
    /* JADX WARN: Removed duplicated region for block: B:117:0x0200  */
    /* JADX WARN: Removed duplicated region for block: B:118:0x0203  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final android.graphics.Bitmap convert(android.media.Image r26) {
        /*
            Method dump skipped, instruction units count: 544
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.editor.LiveCamera.convert(android.media.Image):android.graphics.Bitmap");
    }

    private final int displayRotation() {
        int i = 0;
        try {
            Object systemService = this.ctx.getSystemService("window");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.WindowManager");
            int rotation = ((WindowManager) systemService).getDefaultDisplay().getRotation();
            if (rotation == 1) {
                i = 90;
            } else if (rotation == 2) {
                i = 180;
            } else if (rotation == 3) {
                i = 270;
            }
        } catch (Exception unused) {
        }
        return isFront() ? ((this.sensorOrientation + i) + 360) % 360 : ((this.sensorOrientation - i) + 360) % 360;
    }
}
