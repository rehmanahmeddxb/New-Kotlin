package com.rehman.ahmedreactionstudio.editor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.DisplayCutout;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import com.rehman.ahmedreactionstudio.R;
import com.rehman.ahmedreactionstudio.camera.CameraActivity;
import com.rehman.ahmedreactionstudio.capture.ScreenCaptureService;
import com.rehman.ahmedreactionstudio.core.Aspect;
import com.rehman.ahmedreactionstudio.core.Compositor;
import com.rehman.ahmedreactionstudio.core.Layer;
import com.rehman.ahmedreactionstudio.core.LayerFit;
import com.rehman.ahmedreactionstudio.core.LayerType;
import com.rehman.ahmedreactionstudio.core.MediaInfo;
import com.rehman.ahmedreactionstudio.core.MediaKit;
import com.rehman.ahmedreactionstudio.core.Project;
import com.rehman.ahmedreactionstudio.core.ProjectStore;
import com.rehman.ahmedreactionstudio.core.SourceController;
import com.rehman.ahmedreactionstudio.core.UndoKt;
import com.rehman.ahmedreactionstudio.core.UndoStack;
import com.rehman.ahmedreactionstudio.editor.EditorActivity;
import com.rehman.ahmedreactionstudio.editor.RadialMenuView;
import com.rehman.ahmedreactionstudio.editor.RadialMenus;
import com.rehman.ahmedreactionstudio.editor.StageView;
import com.rehman.ahmedreactionstudio.export.AudioDecode;
import com.rehman.ahmedreactionstudio.export.ClipAudio;
import com.rehman.ahmedreactionstudio.export.CompositionRecorder;
import com.rehman.ahmedreactionstudio.export.DecodedClip;
import com.rehman.ahmedreactionstudio.export.EncoderConfig;
import com.rehman.ahmedreactionstudio.export.Exporter;
import com.rehman.ahmedreactionstudio.export.MediaSave;
import com.rehman.ahmedreactionstudio.export.PcmClip;
import com.rehman.ahmedreactionstudio.ui.DiagnosticsActivity;
import com.rehman.ahmedreactionstudio.util.UI;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.enums.EnumEntries;
import kotlin.io.CloseableKt;
import kotlin.io.encoding.Base64;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.RangesKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.Typography;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONObject;

/* JADX INFO: compiled from: EditorActivity.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000°\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\u001c\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0015\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0013\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0014\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\b\u0017\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0010\u0015\n\u0002\b\u001a\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b3\n\u0002\u0018\u0002\n\u0002\b+*\u0002\u009a\u0001\u0018\u0000 \u0093\u00042\u00020\u00012\u00020\u00022\u00020\u0003:\u0002\u0093\u0004B\u0005¢\u0006\u0002\u0010\u0004J\t\u0010ù\u0001\u001a\u00020tH\u0016J\t\u0010ú\u0001\u001a\u00020tH\u0016J\t\u0010û\u0001\u001a\u00020tH\u0016J\u0012\u0010ü\u0001\u001a\u00020t2\t\b\u0002\u0010ý\u0001\u001a\u00020\u0010J\t\u0010þ\u0001\u001a\u00020tH\u0016J\u0007\u0010ÿ\u0001\u001a\u00020tJ\t\u0010\u0080\u0002\u001a\u00020tH\u0016J\t\u0010\u0081\u0002\u001a\u00020tH\u0016J\t\u0010\u0082\u0002\u001a\u00020tH\u0002J\t\u0010\u0083\u0002\u001a\u00020\u0010H\u0016J\t\u0010\u0084\u0002\u001a\u00020tH\u0002J\u0013\u0010\u0085\u0002\u001a\u00020t2\b\u0010\u0086\u0002\u001a\u00030\u0087\u0002H\u0002J\t\u0010\u0088\u0002\u001a\u00020tH\u0002J+\u0010\u0089\u0002\u001a\u00020t2\u001a\u0010\u008a\u0002\u001a\u000e\u0012\t\b\u0001\u0012\u0005\u0018\u00010\u008c\u00020\u008b\u0002\"\u0005\u0018\u00010\u008c\u0002H\u0002¢\u0006\u0003\u0010\u008d\u0002J#\u0010\u008e\u0002\u001a\u00020t2\u000f\u0010\u008f\u0002\u001a\n\u0012\u0005\u0012\u00030\u0091\u00020\u0090\u00022\u0007\u0010\u0092\u0002\u001a\u00020\u0010H\u0002J\u001c\u0010\u0093\u0002\u001a\u00020t2\u0007\u0010\u0094\u0002\u001a\u00020\u000e2\b\u0010\u0095\u0002\u001a\u00030\u0096\u0002H\u0002J\t\u0010\u0097\u0002\u001a\u00020tH\u0002J\u0016\u0010\u0098\u0002\u001a\u0005\u0018\u00010\u0097\u00012\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0016J+\u0010\u009b\u0002\u001a\u00020t2\u001a\u0010\u008a\u0002\u001a\u000e\u0012\t\b\u0001\u0012\u0005\u0018\u00010\u008c\u00020\u008b\u0002\"\u0005\u0018\u00010\u008c\u0002H\u0002¢\u0006\u0003\u0010\u008d\u0002J+\u0010\u009c\u0002\u001a\u00020t2\u001a\u0010\u008a\u0002\u001a\u000e\u0012\t\b\u0001\u0012\u0005\u0018\u00010\u008c\u00020\u008b\u0002\"\u0005\u0018\u00010\u008c\u0002H\u0002¢\u0006\u0003\u0010\u008d\u0002J+\u0010\u009d\u0002\u001a\u00020t2\u001a\u0010\u008a\u0002\u001a\u000e\u0012\t\b\u0001\u0012\u0005\u0018\u00010\u008c\u00020\u008b\u0002\"\u0005\u0018\u00010\u008c\u0002H\u0002¢\u0006\u0003\u0010\u008d\u0002J\u0012\u0010\u009e\u0002\u001a\u00020t2\u0007\u0010\u009f\u0002\u001a\u00020vH\u0002J+\u0010 \u0002\u001a\u00020t2\u001a\u0010\u008a\u0002\u001a\u000e\u0012\t\b\u0001\u0012\u0005\u0018\u00010\u008c\u00020\u008b\u0002\"\u0005\u0018\u00010\u008c\u0002H\u0002¢\u0006\u0003\u0010\u008d\u0002J+\u0010¡\u0002\u001a\u00020t2\u001a\u0010\u008a\u0002\u001a\u000e\u0012\t\b\u0001\u0012\u0005\u0018\u00010\u008c\u00020\u008b\u0002\"\u0005\u0018\u00010\u008c\u0002H\u0002¢\u0006\u0003\u0010\u008d\u0002J\u0012\u0010¢\u0002\u001a\u00020t2\u0007\u0010\u009f\u0002\u001a\u00020vH\u0002J+\u0010£\u0002\u001a\u00020t2\u001a\u0010\u008a\u0002\u001a\u000e\u0012\t\b\u0001\u0012\u0005\u0018\u00010\u008c\u00020\u008b\u0002\"\u0005\u0018\u00010\u008c\u0002H\u0002¢\u0006\u0003\u0010\u008d\u0002J+\u0010¤\u0002\u001a\u00020t2\u001a\u0010\u008a\u0002\u001a\u000e\u0012\t\b\u0001\u0012\u0005\u0018\u00010\u008c\u00020\u008b\u0002\"\u0005\u0018\u00010\u008c\u0002H\u0002¢\u0006\u0003\u0010\u008d\u0002J+\u0010¥\u0002\u001a\u00020t2\u001a\u0010\u008a\u0002\u001a\u000e\u0012\t\b\u0001\u0012\u0005\u0018\u00010\u008c\u00020\u008b\u0002\"\u0005\u0018\u00010\u008c\u0002H\u0002¢\u0006\u0003\u0010\u008d\u0002J+\u0010¦\u0002\u001a\u00020t2\u001a\u0010\u008a\u0002\u001a\u000e\u0012\t\b\u0001\u0012\u0005\u0018\u00010\u008c\u00020\u008b\u0002\"\u0005\u0018\u00010\u008c\u0002H\u0002¢\u0006\u0003\u0010\u008d\u0002J\t\u0010§\u0002\u001a\u00020tH\u0002J\t\u0010¨\u0002\u001a\u00020\u000eH\u0002J\t\u0010©\u0002\u001a\u00020\u000eH\u0002J+\u0010ª\u0002\u001a\u00020t2\u001a\u0010\u008a\u0002\u001a\u000e\u0012\t\b\u0001\u0012\u0005\u0018\u00010\u008c\u00020\u008b\u0002\"\u0005\u0018\u00010\u008c\u0002H\u0002¢\u0006\u0003\u0010\u008d\u0002J\u0013\u0010«\u0002\u001a\u00020t2\b\u0010\u0086\u0002\u001a\u00030\u0087\u0002H\u0002J\t\u0010¬\u0002\u001a\u00020tH\u0016J/\u0010\u00ad\u0002\u001a\u00020t2\b\u0010®\u0002\u001a\u00030¯\u00022\u0007\u0010°\u0002\u001a\u00020G2\u0007\u0010±\u0002\u001a\u00020G2\b\u0010²\u0002\u001a\u00030³\u0002H\u0002J\u0007\u0010´\u0002\u001a\u00020tJ\u0007\u0010µ\u0002\u001a\u00020tJ\u0013\u0010¶\u0002\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0016J\t\u0010·\u0002\u001a\u00020tH\u0002J\u0007\u0010¸\u0002\u001a\u00020tJ\u0007\u0010¹\u0002\u001a\u00020tJG\u0010º\u0002\u001a\u00020(2\u0007\u0010»\u0002\u001a\u00020(2\u0007\u0010¼\u0002\u001a\u00020\u000e2\u0007\u0010½\u0002\u001a\u00020G2\u0007\u0010¾\u0002\u001a\u00020G2\t\b\u0002\u0010¿\u0002\u001a\u00020\u00102\r\u0010À\u0002\u001a\b\u0012\u0004\u0012\u00020t0sH\u0002J\u0013\u0010Á\u0002\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0002J\u0013\u0010Â\u0002\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0016J\u0013\u0010Ã\u0002\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0002J\u0014\u0010Ä\u0002\u001a\r Æ\u0002*\u0005\u0018\u00010Å\u00020Å\u0002H\u0002J\u0007\u0010Ç\u0002\u001a\u00020\u0010J\t\u0010È\u0002\u001a\u00020tH\u0016J/\u0010É\u0002\u001a\u0005\u0018\u0001HÊ\u0002\"\t\b\u0000\u0010Ê\u0002*\u00020[2\u0007\u0010\u009f\u0002\u001a\u00020[2\u0007\u0010Ë\u0002\u001a\u00020GH\u0002¢\u0006\u0003\u0010Ì\u0002J/\u0010Í\u0002\u001a\u00020t2\b\u0010®\u0002\u001a\u00030¯\u00022\u0007\u0010°\u0002\u001a\u00020G2\u0007\u0010±\u0002\u001a\u00020G2\b\u0010²\u0002\u001a\u00030³\u0002H\u0002J\t\u0010Î\u0002\u001a\u00020tH\u0016J\t\u0010Ï\u0002\u001a\u00020tH\u0002J\u0018\u0010Ð\u0002\u001a\u00020t2\r\u0010Ñ\u0002\u001a\b\u0012\u0004\u0012\u00020t0sH\u0002J\t\u0010Ò\u0002\u001a\u00020\u0010H\u0016J\t\u0010Ó\u0002\u001a\u00020\u0010H\u0016J\u0013\u0010Ô\u0002\u001a\u00020\u00102\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0016J\u001c\u0010Õ\u0002\u001a\u00020t2\b\u0010Ö\u0002\u001a\u00030×\u00022\u0007\u0010Ø\u0002\u001a\u00020\u0010H\u0002J\t\u0010Ù\u0002\u001a\u00020\u0010H\u0016J\t\u0010Ú\u0002\u001a\u00020\u0010H\u0016J\u0013\u0010Û\u0002\u001a\u00020\u00102\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0016J\t\u0010Ü\u0002\u001a\u00020\u0010H\u0016J\t\u0010Ý\u0002\u001a\u00020\u0010H\u0002J\t\u0010Þ\u0002\u001a\u00020\u0010H\u0016J\t\u0010ß\u0002\u001a\u00020\u0010H\u0016J\u0013\u0010à\u0002\u001a\u00020\u00102\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0016J\t\u0010á\u0002\u001a\u00020tH\u0002J\u0007\u0010â\u0002\u001a\u00020tJ\u0016\u0010ã\u0002\u001a\u00020t2\r\u0010Ñ\u0002\u001a\b\u0012\u0004\u0012\u00020t0sJ\u0012\u0010ä\u0002\u001a\u00020\u000e2\u0007\u0010å\u0002\u001a\u00020\u000eH\u0002J\u0012\u0010æ\u0002\u001a\u00020t2\u0007\u0010ç\u0002\u001a\u00020EH\u0016J'\u0010è\u0002\u001a\u00020t2\u0007\u0010é\u0002\u001a\u00020\u000e2\u0007\u0010ê\u0002\u001a\u00020\u000e2\n\u0010\u0095\u0002\u001a\u0005\u0018\u00010\u0096\u0002H\u0014J\t\u0010ë\u0002\u001a\u00020tH\u0016J\t\u0010ì\u0002\u001a\u00020tH\u0016J\u0013\u0010í\u0002\u001a\u00020t2\b\u0010î\u0002\u001a\u00030ï\u0002H\u0016J\u0015\u0010ð\u0002\u001a\u00020t2\n\u0010ñ\u0002\u001a\u0005\u0018\u00010ò\u0002H\u0014J\t\u0010ó\u0002\u001a\u00020tH\u0014J\u0013\u0010ô\u0002\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0016J\u0013\u0010õ\u0002\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0016J)\u0010ö\u0002\u001a\u00020t2\n\u0010\u0099\u0002\u001a\u0005\u0018\u00010\u009a\u00022\b\u0010÷\u0002\u001a\u00030ø\u00022\b\u0010ù\u0002\u001a\u00030ø\u0002H\u0016J\t\u0010ú\u0002\u001a\u00020tH\u0014J4\u0010û\u0002\u001a\u00020t2\u0007\u0010ü\u0002\u001a\u00020\u000e2\u0010\u0010ý\u0002\u001a\u000b\u0012\u0006\b\u0001\u0012\u00020G0\u008b\u00022\b\u0010ê\u0002\u001a\u00030þ\u0002H\u0016¢\u0006\u0003\u0010ÿ\u0002J\t\u0010\u0080\u0003\u001a\u00020tH\u0014J\u0013\u0010\u0081\u0003\u001a\u00020t2\b\u0010\u0082\u0003\u001a\u00030ò\u0002H\u0014J\t\u0010\u0083\u0003\u001a\u00020tH\u0002J\t\u0010\u0084\u0003\u001a\u00020tH\u0014J\t\u0010\u0085\u0003\u001a\u00020tH\u0016J\u0012\u0010\u0086\u0003\u001a\u00020t2\u0007\u0010ç\u0002\u001a\u00020EH\u0002J\t\u0010\u0087\u0003\u001a\u00020tH\u0016J\u0012\u0010\u0088\u0003\u001a\u00020t2\u0007\u0010\u0089\u0003\u001a\u00020\u0010H\u0016J\u0007\u0010\u008a\u0003\u001a\u00020tJ\u0013\u0010\u008b\u0003\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0016J\u0011\u0010\u008c\u0003\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002J\t\u0010\u008d\u0003\u001a\u00020tH\u0002J\t\u0010\u008e\u0003\u001a\u00020tH\u0016J\t\u0010\u008f\u0003\u001a\u00020tH\u0016J\t\u0010\u0090\u0003\u001a\u00020tH\u0016J\u0013\u0010\u0091\u0003\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0016J\u0007\u0010\u0092\u0003\u001a\u00020tJ\t\u0010\u0093\u0003\u001a\u00020tH\u0016J\t\u0010\u0094\u0003\u001a\u00020tH\u0002J\u001c\u0010\u0095\u0003\u001a\u00020t2\u0007\u0010\u0096\u0003\u001a\u00020[2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0002J%\u0010\u0097\u0003\u001a\u00020t2\b\u0010\u0098\u0003\u001a\u00030\u0099\u00032\b\u0010\u009a\u0003\u001a\u00030ø\u00022\b\u0010\u009b\u0003\u001a\u00030ø\u0002JT\u0010\u009c\u0003\u001a\u00020t2\u0007\u0010\u009d\u0003\u001a\u00020(2:\u0010\u009e\u0003\u001a\u001e\u0012\u0019\b\u0001\u0012\u0015\u0012\u0004\u0012\u00020G\u0012\n\u0012\b\u0012\u0004\u0012\u00020t0s0\u009f\u00030\u008b\u0002\"\u0015\u0012\u0004\u0012\u00020G\u0012\n\u0012\b\u0012\u0004\u0012\u00020t0s0\u009f\u0003H\u0002¢\u0006\u0003\u0010 \u0003J\u0010\u0010¡\u0003\u001a\u00020t2\u0007\u0010¢\u0003\u001a\u00020\u0010J\u001c\u0010£\u0003\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u00022\u0007\u0010¤\u0003\u001a\u00020yH\u0002J\u001c\u0010¥\u0003\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u00022\u0007\u0010¤\u0003\u001a\u00020yH\u0002J\t\u0010¦\u0003\u001a\u00020GH\u0002J<\u0010§\u0003\u001a\u00020t2\b\u0010®\u0002\u001a\u00030¯\u00022\u0007\u0010±\u0002\u001a\u00020G2\u0007\u0010¨\u0003\u001a\u00020G2\u0007\u0010©\u0003\u001a\u00020G2\f\b\u0002\u0010ª\u0003\u001a\u0005\u0018\u00010«\u0003H\u0002J\t\u0010¬\u0003\u001a\u00020tH\u0002J\u0007\u0010\u00ad\u0003\u001a\u00020tJ\t\u0010®\u0003\u001a\u00020tH\u0016J\u001c\u0010¯\u0003\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u00022\u0007\u0010°\u0003\u001a\u00020GH\u0002J\t\u0010±\u0003\u001a\u00020\u000eH\u0002J\u0013\u0010²\u0003\u001a\u00020t2\b\u0010³\u0003\u001a\u00030´\u0003H\u0002J\t\u0010µ\u0003\u001a\u00020tH\u0002J\t\u0010¶\u0003\u001a\u00020tH\u0002J\t\u0010·\u0003\u001a\u00020tH\u0002J\t\u0010¸\u0003\u001a\u00020tH\u0002J\u0007\u0010¹\u0003\u001a\u00020tJ\u0016\u0010º\u0003\u001a\u0005\u0018\u00010\u0097\u00012\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0002J\t\u0010»\u0003\u001a\u00020tH\u0016J\t\u0010¼\u0003\u001a\u00020tH\u0002J\t\u0010½\u0003\u001a\u00020tH\u0002J+\u0010¾\u0003\u001a\u00020t2\u001a\u0010\u008a\u0002\u001a\u000e\u0012\t\b\u0001\u0012\u0005\u0018\u00010\u008c\u00020\u008b\u0002\"\u0005\u0018\u00010\u008c\u0002H\u0002¢\u0006\u0003\u0010\u008d\u0002J\t\u0010¿\u0003\u001a\u00020tH\u0002J+\u0010À\u0003\u001a\u00020t2\u001a\u0010\u008a\u0002\u001a\u000e\u0012\t\b\u0001\u0012\u0005\u0018\u00010\u008c\u00020\u008b\u0002\"\u0005\u0018\u00010\u008c\u0002H\u0002¢\u0006\u0003\u0010\u008d\u0002J\t\u0010Á\u0003\u001a\u00020tH\u0002J\u0007\u0010Â\u0003\u001a\u00020tJ\u0013\u0010Ã\u0003\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0002J\t\u0010Ä\u0003\u001a\u00020tH\u0016J\t\u0010Å\u0003\u001a\u00020tH\u0016J.\u0010Æ\u0003\u001a\u00020t2\u0007\u0010Ç\u0003\u001a\u00020\u000e2\u0007\u0010È\u0003\u001a\u00020\u000e2\u0007\u0010É\u0003\u001a\u00020\u000e2\b\u0010ª\u0003\u001a\u00030«\u0003H\u0002J-\u0010Ê\u0003\u001a\u00020t2\u0007\u0010Ë\u0003\u001a\u00020G2\u0007\u0010Ç\u0003\u001a\u00020\u000e2\u0007\u0010È\u0003\u001a\u00020\u000e2\u0007\u0010É\u0003\u001a\u00020\u000eH\u0002J\t\u0010Ì\u0003\u001a\u00020tH\u0016J\u001c\u0010Í\u0003\u001a\u00020t2\b\u0010®\u0002\u001a\u00030¯\u00022\u0007\u0010Î\u0003\u001a\u00020\u0010H\u0002J\u0012\u0010Ï\u0003\u001a\u00020t2\u0007\u0010©\u0003\u001a\u00020GH\u0002J\u0014\u0010Ð\u0003\u001a\u00020t2\t\u0010Ñ\u0003\u001a\u0004\u0018\u00010GH\u0016J\u0014\u0010Ò\u0003\u001a\u00020t2\t\u0010Ñ\u0003\u001a\u0004\u0018\u00010GH\u0016J\f\u0010Ó\u0003\u001a\u0005\u0018\u00010\u009a\u0002H\u0016J\u000b\u0010³\u0001\u001a\u0004\u0018\u00010GH\u0016J\u0013\u0010Ô\u0003\u001a\u00020t2\b\u0010\u0086\u0002\u001a\u00030\u0087\u0002H\u0016J\u0012\u0010Õ\u0003\u001a\u00020t2\u0007\u0010Ö\u0003\u001a\u00020\u000eH\u0016J\u0012\u0010×\u0003\u001a\u00020t2\u0007\u0010å\u0002\u001a\u00020\u000eH\u0002J\u0012\u0010Ø\u0003\u001a\u00020t2\u0007\u0010Ù\u0003\u001a\u00020\u0010H\u0002J\u0012\u0010º\u0001\u001a\u00020t2\t\u0010Ú\u0003\u001a\u0004\u0018\u00010GJ\t\u0010Û\u0003\u001a\u00020\u0010H\u0002J\u0007\u0010Ü\u0003\u001a\u00020tJ\u0013\u0010Ý\u0003\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0002J7\u0010Þ\u0003\u001a\u00020t2\u0007\u0010©\u0003\u001a\u00020G2\u0007\u0010ß\u0003\u001a\u00020G2\u0007\u0010à\u0003\u001a\u00020\u00102\u0011\b\u0002\u0010á\u0003\u001a\n\u0012\u0004\u0012\u00020t\u0018\u00010sH\u0002J2\u0010â\u0003\u001a\u00020t2\u0007\u0010ß\u0003\u001a\u00020G2\u000b\b\u0002\u0010ã\u0003\u001a\u0004\u0018\u00010G2\u0011\b\u0002\u0010ä\u0003\u001a\n\u0012\u0004\u0012\u00020t\u0018\u00010sH\u0002J\u0012\u0010å\u0003\u001a\u00020t2\u0007\u0010ß\u0003\u001a\u00020GH\u0002J/\u0010æ\u0003\u001a\u00020(2\u0007\u0010½\u0002\u001a\u00020G2\u0007\u0010ç\u0003\u001a\u00020\u000e2\u0014\u0010Ù\u0003\u001a\u000f\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020t0è\u0003J\t\u0010é\u0003\u001a\u00020tH\u0016J\t\u0010ê\u0003\u001a\u00020tH\u0002J\t\u0010ë\u0003\u001a\u00020tH\u0002J\t\u0010ì\u0003\u001a\u00020tH\u0002J\u0012\u0010í\u0003\u001a\u00020t2\u0007\u0010î\u0003\u001a\u00020\u000eH\u0002J\u0014\u0010ï\u0003\u001a\u00020t2\t\b\u0002\u0010Î\u0003\u001a\u00020\u0010H\u0002J\u0012\u0010ð\u0003\u001a\u00020t2\u0007\u0010ñ\u0003\u001a\u00020\u0010H\u0002J\t\u0010ò\u0003\u001a\u00020tH\u0002J\u001d\u0010ó\u0003\u001a\u00020t2\b\u0010ô\u0003\u001a\u00030\u009a\u00022\b\u0010Ñ\u0002\u001a\u00030¯\u0002H\u0002J\u0013\u0010õ\u0003\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0016J\t\u0010ö\u0003\u001a\u00020tH\u0002J\u0013\u0010÷\u0003\u001a\u00020G2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0016J\u0012\u0010ø\u0003\u001a\u00020t2\u0007\u0010ß\u0003\u001a\u00020GH\u0016J\t\u0010ù\u0003\u001a\u00020tH\u0016J\t\u0010ú\u0003\u001a\u00020tH\u0016J\u0013\u0010û\u0003\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0016J\u0013\u0010ü\u0003\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0016J\t\u0010ý\u0003\u001a\u00020tH\u0016J\u0013\u0010þ\u0003\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0002J\t\u0010ÿ\u0003\u001a\u00020tH\u0016J\u0007\u0010\u0080\u0004\u001a\u00020tJ\t\u0010\u0081\u0004\u001a\u00020tH\u0016J\u0013\u0010\u0082\u0004\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0016J\t\u0010\u0083\u0004\u001a\u00020tH\u0016J\u0013\u0010\u0084\u0004\u001a\u00020t2\b\u0010\u0099\u0002\u001a\u00030\u009a\u0002H\u0016J\t\u0010\u0085\u0004\u001a\u00020\u0010H\u0002J\t\u0010ð\u0001\u001a\u00020tH\u0016J\u0007\u0010\u0086\u0004\u001a\u00020tJ+\u0010\u0087\u0004\u001a\u00020t2\u001a\u0010\u008a\u0002\u001a\u000e\u0012\t\b\u0001\u0012\u0005\u0018\u00010\u008c\u00020\u008b\u0002\"\u0005\u0018\u00010\u008c\u0002H\u0002¢\u0006\u0003\u0010\u008d\u0002J+\u0010\u0088\u0004\u001a\u00020t2\u001a\u0010\u008a\u0002\u001a\u000e\u0012\t\b\u0001\u0012\u0005\u0018\u00010\u008c\u00020\u008b\u0002\"\u0005\u0018\u00010\u008c\u0002H\u0002¢\u0006\u0003\u0010\u008d\u0002J\t\u0010\u0089\u0004\u001a\u00020tH\u0002J\u001b\u0010\u008a\u0004\u001a\u00020t2\u0007\u0010\u008b\u0004\u001a\u00020\u000e2\u0007\u0010ß\u0003\u001a\u00020GH\u0002J\t\u0010\u008c\u0004\u001a\u00020tH\u0002J+\u0010\u008d\u0004\u001a\u00020t2\u001a\u0010\u008a\u0002\u001a\u000e\u0012\t\b\u0001\u0012\u0005\u0018\u00010\u008c\u00020\u008b\u0002\"\u0005\u0018\u00010\u008c\u0002H\u0002¢\u0006\u0003\u0010\u008d\u0002J\t\u0010\u008e\u0004\u001a\u00020tH\u0002J+\u0010\u008f\u0004\u001a\u00020t2\n\u0010Ö\u0002\u001a\u0005\u0018\u00010×\u00022\t\u0010\u0090\u0004\u001a\u0004\u0018\u00010G2\t\b\u0002\u0010¨\u0003\u001a\u00020GH\u0002J\t\u0010\u0091\u0004\u001a\u00020\u0010H\u0002J\t\u0010\u0092\u0004\u001a\u00020\u0010H\u0002R\u001a\u0010\u0005\u001a\u00020\u0006X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\nR\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u0011\u001a\u0004\u0018\u00010\u0010X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u0012R\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010\u0015\u001a\u0004\u0018\u00010\u0016X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0017\u0010\u0018\"\u0004\b\u0019\u0010\u001aR\u001a\u0010\u001b\u001a\u00020\u001cX\u0096.¢\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u001e\"\u0004\b\u001f\u0010 R\u001a\u0010!\u001a\u00020\"X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b#\u0010$\"\u0004\b%\u0010&R\u001a\u0010'\u001a\u00020(X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b)\u0010*\"\u0004\b+\u0010,R\u001a\u0010-\u001a\u00020\u0006X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b.\u0010\b\"\u0004\b/\u0010\nR\u001a\u00100\u001a\u00020(X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b1\u0010*\"\u0004\b2\u0010,R\u001a\u00103\u001a\u000204X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b5\u00106\"\u0004\b7\u00108R\u000e\u00109\u001a\u00020:X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010;\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010<\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010=\u001a\u00020\u0006X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b>\u0010\b\"\u0004\b?\u0010\nR\u001a\u0010@\u001a\u00020\u0006X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\bA\u0010\b\"\u0004\bB\u0010\nR\u000e\u0010C\u001a\u00020\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010D\u001a\u00020EX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010F\u001a\u00020GX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010H\u001a\u0004\u0018\u00010GX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010I\u001a\u00020EX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010J\u001a\u00020EX\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010K\u001a\u00020(X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\bL\u0010*\"\u0004\bM\u0010,R\u0010\u0010N\u001a\u0004\u0018\u00010OX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010P\u001a\u0004\u0018\u00010GX\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010Q\u001a\u0004\u0018\u00010RX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bS\u0010T\"\u0004\bU\u0010VR\u001a\u0010W\u001a\u00020(X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\bX\u0010*\"\u0004\bY\u0010,R\u001a\u0010Z\u001a\u00020[X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\\\u0010]\"\u0004\b^\u0010_R\u001a\u0010`\u001a\u00020aX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\bb\u0010c\"\u0004\bd\u0010eR\u000e\u0010f\u001a\u00020GX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010g\u001a\u00020GX\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010h\u001a\u00020iX\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\bj\u0010k\"\u0004\bl\u0010mR\u0010\u0010n\u001a\u0004\u0018\u00010oX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010p\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010q\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010r\u001a\n\u0012\u0004\u0012\u00020t\u0018\u00010sX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010u\u001a\u0004\u0018\u00010vX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010w\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u001c\u0010x\u001a\u0004\u0018\u00010yX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bz\u0010{\"\u0004\b|\u0010}R\u0014\u0010~\u001a\u00020y8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u007f\u0010{R\u000f\u0010\u0080\u0001\u001a\u00020GX\u0082\u000e¢\u0006\u0002\n\u0000R\u001d\u0010\u0081\u0001\u001a\u00020(X\u0086.¢\u0006\u0010\n\u0000\u001a\u0005\b\u0082\u0001\u0010*\"\u0005\b\u0083\u0001\u0010,R \u0010\u0084\u0001\u001a\u00030\u0085\u0001X\u0086.¢\u0006\u0012\n\u0000\u001a\u0006\b\u0086\u0001\u0010\u0087\u0001\"\u0006\b\u0088\u0001\u0010\u0089\u0001R\u001d\u0010\u008a\u0001\u001a\u00020(X\u0086.¢\u0006\u0010\n\u0000\u001a\u0005\b\u008b\u0001\u0010*\"\u0005\b\u008c\u0001\u0010,R\u001d\u0010\u008d\u0001\u001a\u00020\u0006X\u0086.¢\u0006\u0010\n\u0000\u001a\u0005\b\u008e\u0001\u0010\b\"\u0005\b\u008f\u0001\u0010\nR\u001d\u0010\u0090\u0001\u001a\u00020\u0006X\u0086.¢\u0006\u0010\n\u0000\u001a\u0005\b\u0091\u0001\u0010\b\"\u0005\b\u0092\u0001\u0010\nR\u0010\u0010\u0093\u0001\u001a\u00030\u0094\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R/\u0010\u0095\u0001\u001a\"\u0012\u0004\u0012\u00020G\u0012\u0005\u0012\u00030\u0097\u00010\u0096\u0001j\u0010\u0012\u0004\u0012\u00020G\u0012\u0005\u0012\u00030\u0097\u0001`\u0098\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u0013\u0010\u0099\u0001\u001a\u00030\u009a\u0001X\u0082\u0004¢\u0006\u0005\n\u0003\u0010\u009b\u0001R\u0012\u0010\u009c\u0001\u001a\u0005\u0018\u00010\u009d\u0001X\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010\u009e\u0001\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u001f\u0010\u009f\u0001\u001a\u00020vX\u0086.¢\u0006\u0012\n\u0000\u001a\u0006\b \u0001\u0010¡\u0001\"\u0006\b¢\u0001\u0010£\u0001R\u000f\u0010¤\u0001\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010¥\u0001\u001a\u00030\u0094\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u000f\u0010¦\u0001\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010§\u0001\u001a\u0004\u0018\u00010[X\u0082\u000e¢\u0006\u0002\n\u0000R\u001f\u0010¨\u0001\u001a\u00020\u0010X\u0086\u000e¢\u0006\u0012\n\u0000\u001a\u0006\b©\u0001\u0010ª\u0001\"\u0006\b«\u0001\u0010¬\u0001R \u0010\u00ad\u0001\u001a\u00030®\u0001X\u0086.¢\u0006\u0012\n\u0000\u001a\u0006\b¯\u0001\u0010°\u0001\"\u0006\b±\u0001\u0010²\u0001R!\u0010³\u0001\u001a\u0004\u0018\u00010GX\u0086\u000e¢\u0006\u0012\n\u0000\u001a\u0006\b´\u0001\u0010µ\u0001\"\u0006\b¶\u0001\u0010·\u0001R\u001d\u0010¸\u0001\u001a\u00020(X\u0086.¢\u0006\u0010\n\u0000\u001a\u0005\b¹\u0001\u0010*\"\u0005\bº\u0001\u0010,R\u0011\u0010»\u0001\u001a\u0004\u0018\u00010GX\u0082\u000e¢\u0006\u0002\n\u0000R\u001d\u0010¼\u0001\u001a\u00020aX\u0086.¢\u0006\u0010\n\u0000\u001a\u0005\b½\u0001\u0010c\"\u0005\b¾\u0001\u0010eR\u0011\u0010¿\u0001\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010À\u0001\u001a\u0004\u0018\u00010(X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010Á\u0001\u001a\u00030\u0094\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u000f\u0010Â\u0001\u001a\u00020\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010Ã\u0001\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u001d\u0010Ä\u0001\u001a\u00020(X\u0086.¢\u0006\u0010\n\u0000\u001a\u0005\bÅ\u0001\u0010*\"\u0005\bÆ\u0001\u0010,R \u0010Ç\u0001\u001a\u00030\u0085\u0001X\u0086.¢\u0006\u0012\n\u0000\u001a\u0006\bÈ\u0001\u0010\u0087\u0001\"\u0006\bÉ\u0001\u0010\u0089\u0001R\"\u0010Ê\u0001\u001a\u0005\u0018\u00010Ë\u0001X\u0086\u000e¢\u0006\u0012\n\u0000\u001a\u0006\bÌ\u0001\u0010Í\u0001\"\u0006\bÎ\u0001\u0010Ï\u0001R\u000f\u0010Ð\u0001\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R \u0010Ñ\u0001\u001a\u00030Ò\u0001X\u0086.¢\u0006\u0012\n\u0000\u001a\u0006\bÓ\u0001\u0010Ô\u0001\"\u0006\bÕ\u0001\u0010Ö\u0001R\u001d\u0010×\u0001\u001a\u00020\u0006X\u0086.¢\u0006\u0010\n\u0000\u001a\u0005\bØ\u0001\u0010\b\"\u0005\bÙ\u0001\u0010\nR\u0010\u0010Ú\u0001\u001a\u00030Û\u0001X\u0082.¢\u0006\u0002\n\u0000R\u001d\u0010Ü\u0001\u001a\u00020iX\u0086.¢\u0006\u0010\n\u0000\u001a\u0005\bÝ\u0001\u0010k\"\u0005\bÞ\u0001\u0010mR\u000f\u0010ß\u0001\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010à\u0001\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010á\u0001\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000f\u0010â\u0001\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u001d\u0010ã\u0001\u001a\u00020(X\u0086.¢\u0006\u0010\n\u0000\u001a\u0005\bä\u0001\u0010*\"\u0005\bå\u0001\u0010,R-\u0010æ\u0001\u001a \u0012\u0004\u0012\u00020G\u0012\u0004\u0012\u00020[0\u0096\u0001j\u000f\u0012\u0004\u0012\u00020G\u0012\u0004\u0012\u00020[`\u0098\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010ç\u0001\u001a\u00020\u0006X\u0086.¢\u0006\u0010\n\u0000\u001a\u0005\bè\u0001\u0010\b\"\u0005\bé\u0001\u0010\nR\u001d\u0010ê\u0001\u001a\u00020(X\u0086.¢\u0006\u0010\n\u0000\u001a\u0005\bë\u0001\u0010*\"\u0005\bì\u0001\u0010,R\u001d\u0010í\u0001\u001a\u00020(X\u0086.¢\u0006\u0010\n\u0000\u001a\u0005\bî\u0001\u0010*\"\u0005\bï\u0001\u0010,R\u0010\u0010ð\u0001\u001a\u00030ñ\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R \u0010ò\u0001\u001a\u00030ó\u0001X\u0086.¢\u0006\u0012\n\u0000\u001a\u0006\bô\u0001\u0010õ\u0001\"\u0006\bö\u0001\u0010÷\u0001R\u0011\u0010ø\u0001\u001a\u0004\u0018\u00010iX\u0082\u000e¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/EditorActivity;", "Landroid/app/Activity;", "Lcom/rehman/ahmedreactionstudio/editor/StageView$Host;", "Lcom/rehman/ahmedreactionstudio/editor/RadialMenus$Host;", "()V", "aspectChip", "Landroid/widget/TextView;", "getAspectChip", "()Landroid/widget/TextView;", "setAspectChip", "(Landroid/widget/TextView;)V", "autosave", "Ljava/lang/Runnable;", "camWaitTries", "", "cameraFallbackShown", "", "chromeLandscape", "Ljava/lang/Boolean;", "chromeLayoutListener", "Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;", "controlsPanel", "Lcom/rehman/ahmedreactionstudio/editor/ControlsPanel;", "getControlsPanel", "()Lcom/rehman/ahmedreactionstudio/editor/ControlsPanel;", "setControlsPanel", "(Lcom/rehman/ahmedreactionstudio/editor/ControlsPanel;)V", "ctrl", "Lcom/rehman/ahmedreactionstudio/core/SourceController;", "getCtrl", "()Lcom/rehman/ahmedreactionstudio/core/SourceController;", "setCtrl", "(Lcom/rehman/ahmedreactionstudio/core/SourceController;)V", "dock", "Lcom/rehman/ahmedreactionstudio/editor/SourceDock;", "getDock", "()Lcom/rehman/ahmedreactionstudio/editor/SourceDock;", "setDock", "(Lcom/rehman/ahmedreactionstudio/editor/SourceDock;)V", "dockContainer", "Landroid/widget/LinearLayout;", "getDockContainer", "()Landroid/widget/LinearLayout;", "setDockContainer", "(Landroid/widget/LinearLayout;)V", "durationLabel", "getDurationLabel", "setDurationLabel", "emptyOverlay", "getEmptyOverlay", "setEmptyOverlay", "engine", "Lcom/rehman/ahmedreactionstudio/editor/PreviewEngine;", "getEngine", "()Lcom/rehman/ahmedreactionstudio/editor/PreviewEngine;", "setEngine", "(Lcom/rehman/ahmedreactionstudio/editor/PreviewEngine;)V", "exportCancel", "Ljava/util/concurrent/atomic/AtomicBoolean;", "exportRunning", "fullCanvas", "fullExitBtn", "getFullExitBtn", "setFullExitBtn", "hiddenPill", "getHiddenPill", "setHiddenPill", "insetsSync", "lastHudMs", "", "lastPlayingSig", "", "lastRecordingNote", "lastUiTickMs", "lastUndoPush", "launchRow", "getLaunchRow", "setLaunchRow", "liveCam", "Lcom/rehman/ahmedreactionstudio/editor/LiveCamera;", "liveCamLayerId", "mixerPanel", "Lcom/rehman/ahmedreactionstudio/editor/MixerPanel;", "getMixerPanel", "()Lcom/rehman/ahmedreactionstudio/editor/MixerPanel;", "setMixerPanel", "(Lcom/rehman/ahmedreactionstudio/editor/MixerPanel;)V", "panelContent", "getPanelContent", "setPanelContent", "panelDivider", "Landroid/view/View;", "getPanelDivider", "()Landroid/view/View;", "setPanelDivider", "(Landroid/view/View;)V", "panelScroll", "Landroid/widget/ScrollView;", "getPanelScroll", "()Landroid/widget/ScrollView;", "setPanelScroll", "(Landroid/widget/ScrollView;)V", "pendingCameraRole", "pendingRole", "playBtn", "Lcom/rehman/ahmedreactionstudio/editor/IconBtn;", "getPlayBtn", "()Lcom/rehman/ahmedreactionstudio/editor/IconBtn;", "setPlayBtn", "(Lcom/rehman/ahmedreactionstudio/editor/IconBtn;)V", "progBar", "Landroid/widget/ProgressBar;", "progCancel", "progMsg", "progOnCancel", "Lkotlin/Function0;", "", "progOverlay", "Landroid/widget/FrameLayout;", "progTitle", "proj", "Lcom/rehman/ahmedreactionstudio/core/Project;", "getProj", "()Lcom/rehman/ahmedreactionstudio/core/Project;", "setProj", "(Lcom/rehman/ahmedreactionstudio/core/Project;)V", "project", "getProject", "projectId", "quickBar", "getQuickBar", "setQuickBar", "quickWrap", "Landroid/widget/HorizontalScrollView;", "getQuickWrap", "()Landroid/widget/HorizontalScrollView;", "setQuickWrap", "(Landroid/widget/HorizontalScrollView;)V", "railContent", "getRailContent", "setRailContent", "recChip", "getRecChip", "setRecChip", "recordBtn", "getRecordBtn", "setRecordBtn", "recordHandler", "Landroid/os/Handler;", "recordImageCache", "Ljava/util/HashMap;", "Landroid/graphics/Bitmap;", "Lkotlin/collections/HashMap;", "recordTick", "com/rehman/ahmedreactionstudio/editor/EditorActivity$recordTick$1", "Lcom/rehman/ahmedreactionstudio/editor/EditorActivity$recordTick$1;", "recorder", "Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder;", "recording", "rootFrame", "getRootFrame", "()Landroid/widget/FrameLayout;", "setRootFrame", "(Landroid/widget/FrameLayout;)V", "saveDirty", "saveHandler", "screenLight", "screenLightView", "scrubbing", "getScrubbing", "()Z", "setScrubbing", "(Z)V", "seek", "Landroid/widget/SeekBar;", "getSeek", "()Landroid/widget/SeekBar;", "setSeek", "(Landroid/widget/SeekBar;)V", "selectedId", "getSelectedId", "()Ljava/lang/String;", "setSelectedId", "(Ljava/lang/String;)V", "sheet", "getSheet", "setSheet", "sheetTab", "sideRail", "getSideRail", "setSideRail", "snackAction", "snackBar", "snackHandler", "snackHide", "snackMsg", "sourceStrip", "getSourceStrip", "setSourceStrip", "sourceStripWrap", "getSourceStripWrap", "setSourceStripWrap", "sourcesPanel", "Lcom/rehman/ahmedreactionstudio/editor/SourcesPanel;", "getSourcesPanel", "()Lcom/rehman/ahmedreactionstudio/editor/SourcesPanel;", "setSourcesPanel", "(Lcom/rehman/ahmedreactionstudio/editor/SourcesPanel;)V", "srcDockExpanded", "stage", "Lcom/rehman/ahmedreactionstudio/editor/StageView;", "getStage", "()Lcom/rehman/ahmedreactionstudio/editor/StageView;", "setStage", "(Lcom/rehman/ahmedreactionstudio/editor/StageView;)V", "statsHud", "getStatsHud", "setStatsHud", "store", "Lcom/rehman/ahmedreactionstudio/core/ProjectStore;", "studioBtn", "getStudioBtn", "setStudioBtn", "sysB", "sysL", "sysR", "sysT", "tabBar", "getTabBar", "setTabBar", "tabViews", "timeLabel", "getTimeLabel", "setTimeLabel", "topBar", "getTopBar", "setTopBar", "transportBar", "getTransportBar", "setTransportBar", "undo", "Lcom/rehman/ahmedreactionstudio/core/UndoStack;", "wheel", "Lcom/rehman/ahmedreactionstudio/editor/RadialMenuView;", "getWheel", "()Lcom/rehman/ahmedreactionstudio/editor/RadialMenuView;", "setWheel", "(Lcom/rehman/ahmedreactionstudio/editor/RadialMenuView;)V", "wheelBtn", "addCameraLive", "addCameraTake", "addImage", "addLiveCamera", "front", "addScreen", "addText", "addTextSource", "addVideo", "afterStructureChange", "anyPlaying", "applyEditorImmersive", "applyOrientationFor", "a", "Lcom/rehman/ahmedreactionstudio/core/Aspect;", "applyScreenLight", "applyViewportInsets", "args", "", "", "([Ljava/lang/Object;)V", "beginCompositeRecording", "decoded", "", "Lcom/rehman/ahmedreactionstudio/export/DecodedClip;", "micEnabled", "beginScreenService", "resultCode", ScreenCaptureService.EXTRA_RESULT_DATA, "Landroid/content/Intent;", "bindSidePanels", "bitmapOf", "l", "Lcom/rehman/ahmedreactionstudio/core/Layer;", "buildExportPanel", "buildFullCanvasExit", "buildMixerPanel", "buildProgOverlay", "root", "buildSheet", "buildSideRail", "buildSnackBar", "buildSourcesPanel", "buildTabBar", "buildTopBar", "buildTransportBar", "buildUi", "cam0H", "cam0W", "capPanelHeight", "changeAspect", "closeProject", "consumeMediaFile", "src", "Ljava/io/File;", CameraActivity.EXTRA_ROLE, "name", "type", "Lcom/rehman/ahmedreactionstudio/core/LayerType;", "controlsFlashTap", "controlsStopTap", "cycleTextColor", "dismissProgress", "doRedo", "doUndo", "dockBtn", "parent", "icon", "label", "desc", "active", "fn", "duplicateLayer", "editText", "editTextLayer", "editorPrefs", "Landroid/content/SharedPreferences;", "kotlin.jvm.PlatformType", "engineReady", "enterFullCanvas", "findTagged", "T", "tag", "(Landroid/view/View;Ljava/lang/String;)Landroid/view/View;", "finishAddSource", "fitAllSources", "flushSave", "guardRecording", "f", "hasBackTorch", "hasFrontTorch", "hasTorch", "importFromUri", "uri", "Landroid/net/Uri;", "isVideo", "isBackTorchOn", "isBothTorchOn", "isCameraRecording", "isFrontTorchOn", "isLandscape", "isScreenLightOn", "isStatsHudOn", "isTorchOn", "launchProjection", "markDirty", "mutateThen", "nextColor", "c", "nudge", "ms", "onActivityResult", "req", "res", "onBackPressed", "onChanged", "onConfigurationChanged", "newConfig", "Landroid/content/res/Configuration;", "onCreate", "b", "Landroid/os/Bundle;", "onDestroy", "onDoubleTap", "onLockedTap", "onLongPressCanvas", "x", "", "y", "onPause", "onRequestPermissionsResult", "code", "perms", "", "(I[Ljava/lang/String;[I)V", "onResume", "onSaveInstanceState", "out", "onSourceChanged", "onStop", "onTapEmpty", "onTick", "onTransform", "onWindowFocusChanged", "hasFocus", "openAddSourceChooser", "openAdvanced", "openAdvancedSheet", "openCamera", "openDiagnostics", "openDockPanel", "openExportPanel", "openFlashRing", "openLightMenuFromToolbar", "openMixerPanel", "openRootWheel", "openWheel", "anchor", "openWheelLevel", "level", "Lcom/rehman/ahmedreactionstudio/editor/RadialMenuView$Level;", "ax", "ay", "panelButtonRow", "container", "items", "Lkotlin/Pair;", "(Landroid/widget/LinearLayout;[Lkotlin/Pair;)V", "pickMedia", "video", "placeMain", "p", "placePip", "playingSignature", "publishAndReport", "mime", "title", "codec", "Lcom/rehman/ahmedreactionstudio/export/Exporter$Codec;", "pushUndo", "pushUndoLight", "quickExport", "quickToggle", "what", "railWidthPx", "readSystemInsets", "insets", "Landroid/view/WindowInsets;", "rebindDock", "rebuildDock", "rebuildSourceDock", "reconcileLiveCamera", "recordButtonTap", "recordFrameOf", "redo", "refreshAll", "refreshContextBar", "refreshQuickBar", "refreshTabBar", "relayoutChrome", "removeLiveCameraLayer", "removeSelectedSource", "renameLayer", "renameProject", "restart", "runExport", "quality", "maxDim", "fps", "saveExportPrefs", "codecName", "saveNow", "saveRecordingToPublic", "showUi", "section", "select", "id", "selectId", "selected", "setAspect", "setBg", "color", "setBgColor", "setFullCanvas", "on", "tab", "sheetReady", "showAspectPicker", "showHideFeedback", "showProgress", "msg", "determinate", "onCancel", "showSnack", "actionLabel", "action", "showUndoSnack", "sliderRow", "value", "Lkotlin/Function1;", "snapshotFrame", "startCompositeRecording", "startLiveCamera", "startScreenCapture", "stepSelection", "dir", "stopCompositeRecording", "stopLiveCamera", "evict", "stopScreenCapture", "swapLiveCameraToClip", "live", "switchCameraFacing", "syncPreviewTarget", "textOf", "toast", "toggleBackTorch", "toggleBothTorch", "toggleCameraMirror", "toggleCameraRecord", "toggleFrontTorch", "toggleLiveCameraRecord", "toggleMasterPlay", "togglePlay", "toggleScreenLight", "toggleSourcePlay", "toggleStatsHud", "toggleTorch", "transportReady", "updateAspectChip", "updateEmptyState", "updateHiddenPill", "updateName", "updateProgress", "pct", "updateRecordButton", "updateSourceStrip", "updateStageInsets", "viewRecording", "path", "warnLiveBeforeExport", "wheelReady", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nEditorActivity.kt\nKotlin\n*S Kotlin\n*F\n+ 1 EditorActivity.kt\ncom/rehman/ahmedreactionstudio/editor/EditorActivity\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n*L\n1#1,2717:1\n1#2:2718\n350#3,7:2719\n1549#3:2726\n1620#3,3:2727\n288#3,2:2732\n1747#3,3:2734\n1747#3,3:2737\n288#3,2:2740\n1747#3,3:2744\n1747#3,3:2747\n1747#3,3:2750\n1747#3,3:2753\n1747#3,3:2756\n1747#3,3:2759\n288#3,2:2762\n288#3,2:2764\n1747#3,3:2766\n288#3,2:2769\n288#3,2:2771\n288#3,2:2773\n288#3,2:2775\n288#3,2:2777\n37#4,2:2730\n37#4,2:2742\n*S KotlinDebug\n*F\n+ 1 EditorActivity.kt\ncom/rehman/ahmedreactionstudio/editor/EditorActivity\n*L\n817#1:2719,7\n904#1:2726\n904#1:2727,3\n1323#1:2732,2\n1358#1:2734,3\n1359#1:2737,3\n1392#1:2740,2\n1930#1:2744,3\n1931#1:2747,3\n1959#1:2750,3\n1960#1:2753,3\n1992#1:2756,3\n1993#1:2759,3\n1994#1:2762,2\n2068#1:2764,2\n2070#1:2766,3\n2474#1:2769,2\n2484#1:2771,2\n2696#1:2773,2\n2496#1:2775,2\n2497#1:2777,2\n914#1:2730,2\n1535#1:2742,2\n*E\n"})
public final class EditorActivity extends Activity implements StageView.Host, RadialMenus.Host {

    @NotNull
    public static final String EXTRA_PROJECT_ASPECT = "paspect";

    @NotNull
    public static final String EXTRA_PROJECT_ID = "pid";

    @NotNull
    public static final String EXTRA_PROJECT_NAME = "pname";

    @NotNull
    public static final String PREFS_EDITOR = "editor";

    @NotNull
    public static final String PREF_EXP_CODEC = "exp_codec";

    @NotNull
    public static final String PREF_EXP_FPS = "exp_fps";

    @NotNull
    public static final String PREF_EXP_MAXDIM = "exp_maxdim";

    @NotNull
    public static final String PREF_EXP_QUALITY = "exp_quality";

    @NotNull
    public static final String PREF_HAD_EXPORT = "had_export";

    @NotNull
    public static final String PREF_STATS_HUD = "stats_hud";
    public static final int REQ_APP_PERMS = 45;
    public static final int REQ_CAMERA = 43;
    public static final int REQ_CAMERA_PERM = 46;
    public static final int REQ_PICK_IMAGE = 42;
    public static final int REQ_PICK_VIDEO = 41;
    public static final int REQ_RECORD_PERM = 47;
    public static final int REQ_SCREEN_CAPTURE = 44;
    public TextView aspectChip;
    private int camWaitTries;
    private boolean cameraFallbackShown;

    @Nullable
    private Boolean chromeLandscape;

    @Nullable
    private ViewTreeObserver.OnGlobalLayoutListener chromeLayoutListener;

    @Nullable
    private ControlsPanel controlsPanel;
    public SourceController ctrl;
    public SourceDock dock;
    public LinearLayout dockContainer;
    public TextView durationLabel;
    public LinearLayout emptyOverlay;
    public PreviewEngine engine;
    private boolean exportRunning;
    private boolean fullCanvas;
    public TextView fullExitBtn;
    public TextView hiddenPill;
    private long lastHudMs;

    @Nullable
    private String lastRecordingNote;
    private long lastUiTickMs;
    private long lastUndoPush;
    public LinearLayout launchRow;

    @Nullable
    private LiveCamera liveCam;

    @Nullable
    private String liveCamLayerId;

    @Nullable
    private MixerPanel mixerPanel;
    public LinearLayout panelContent;
    public View panelDivider;
    public ScrollView panelScroll;
    public IconBtn playBtn;

    @Nullable
    private ProgressBar progBar;

    @Nullable
    private TextView progCancel;

    @Nullable
    private TextView progMsg;

    @Nullable
    private Function0<Unit> progOnCancel;

    @Nullable
    private FrameLayout progOverlay;

    @Nullable
    private TextView progTitle;

    @Nullable
    private Project proj;
    public LinearLayout quickBar;
    public HorizontalScrollView quickWrap;
    public LinearLayout railContent;
    public TextView recChip;
    public TextView recordBtn;

    @Nullable
    private CompositionRecorder recorder;
    private boolean recording;
    public FrameLayout rootFrame;
    private boolean saveDirty;
    private boolean screenLight;

    @Nullable
    private View screenLightView;
    private boolean scrubbing;
    public SeekBar seek;

    @Nullable
    private String selectedId;
    public LinearLayout sheet;

    @Nullable
    private String sheetTab;
    public ScrollView sideRail;

    @Nullable
    private TextView snackAction;

    @Nullable
    private LinearLayout snackBar;

    @Nullable
    private TextView snackMsg;
    public LinearLayout sourceStrip;
    public HorizontalScrollView sourceStripWrap;

    @Nullable
    private SourcesPanel sourcesPanel;
    private boolean srcDockExpanded;
    public StageView stage;
    public TextView statsHud;
    private ProjectStore store;
    public IconBtn studioBtn;
    private int sysB;
    private int sysL;
    private int sysR;
    private int sysT;
    public LinearLayout tabBar;
    public TextView timeLabel;
    public LinearLayout topBar;
    public LinearLayout transportBar;
    public RadialMenuView wheel;

    @Nullable
    private IconBtn wheelBtn;

    @NotNull
    private String projectId = "";

    @NotNull
    private final HashMap<String, View> tabViews = new HashMap<>();

    @NotNull
    private final Runnable insetsSync = new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$X7NSMGSbZgE8gx1iaCWdXt9c8Gg
        @Override // java.lang.Runnable
        public final void run() {
            EditorActivity.insetsSync$lambda$0(this.f$0);
        }
    };

    @NotNull
    private final Handler snackHandler = new Handler(Looper.getMainLooper());

    @NotNull
    private final Runnable snackHide = new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$P8LkyoUAx7RpoywPMqlx4iMdBf0
        @Override // java.lang.Runnable
        public final void run() {
            EditorActivity.snackHide$lambda$1(this.f$0);
        }
    };

    @NotNull
    private final UndoStack undo = new UndoStack(0, 1, null);

    @NotNull
    private final Handler saveHandler = new Handler(Looper.getMainLooper());

    @NotNull
    private final Runnable autosave = new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$4OJcXfjozuesAqhAL4VCm76n__c
        @Override // java.lang.Runnable
        public final void run() {
            EditorActivity.autosave$lambda$2(this.f$0);
        }
    };

    @NotNull
    private String lastPlayingSig = "";

    @NotNull
    private final AtomicBoolean exportCancel = new AtomicBoolean(false);

    @NotNull
    private final Handler recordHandler = new Handler(Looper.getMainLooper());

    @NotNull
    private final EditorActivity$recordTick$1 recordTick = new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity$recordTick$1
        @Override // java.lang.Runnable
        public void run() {
            if (this.this$0.recording) {
                CompositionRecorder compositionRecorder = this.this$0.recorder;
                if (compositionRecorder != null) {
                    compositionRecorder.renderAndSubmit();
                }
                this.this$0.recordHandler.postDelayed(this, 33L);
            }
        }
    };

    @NotNull
    private final HashMap<String, Bitmap> recordImageCache = new HashMap<>();

    @NotNull
    private String pendingRole = "main";

    @NotNull
    private String pendingCameraRole = "main";

    /* JADX INFO: compiled from: EditorActivity.kt */
    @Metadata(k = Base64.bytesPerGroup, mv = {1, 9, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[Aspect.values().length];
            try {
                iArr[Aspect.R169.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[Aspect.R916.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[Aspect.R11.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    private final void applyViewportInsets(Object... args) {
    }

    private final void buildExportPanel(Object... args) {
    }

    private final void buildFullCanvasExit(Object... args) {
    }

    private final void buildMixerPanel(Object... args) {
    }

    private final void buildSheet(Object... args) {
    }

    private final void buildSideRail(Object... args) {
    }

    private final void buildSourcesPanel(Object... args) {
    }

    private final void buildTabBar(Object... args) {
    }

    private final void buildTopBar(Object... args) {
    }

    private final void buildTransportBar(Object... args) {
    }

    private final void capPanelHeight(Object... args) {
    }

    private final void refreshQuickBar(Object... args) {
    }

    private final void updateEmptyState(Object... args) {
    }

    private final void updateHiddenPill(Object... args) {
    }

    private final void updateSourceStrip(Object... args) {
    }

    private final SharedPreferences editorPrefs() {
        return getSharedPreferences(PREFS_EDITOR, 0);
    }

    @Nullable
    public final Project getProj() {
        return this.proj;
    }

    public final void setProj(@Nullable Project project) {
        this.proj = project;
    }

    @Nullable
    public final String getSelectedId() {
        return this.selectedId;
    }

    public final void setSelectedId(@Nullable String str) {
        this.selectedId = str;
    }

    @NotNull
    public final StageView getStage() {
        StageView stageView = this.stage;
        if (stageView != null) {
            return stageView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("stage");
        return null;
    }

    public final void setStage(@NotNull StageView stageView) {
        Intrinsics.checkNotNullParameter(stageView, "<set-?>");
        this.stage = stageView;
    }

    @NotNull
    public final LinearLayout getEmptyOverlay() {
        LinearLayout linearLayout = this.emptyOverlay;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("emptyOverlay");
        return null;
    }

    public final void setEmptyOverlay(@NotNull LinearLayout linearLayout) {
        Intrinsics.checkNotNullParameter(linearLayout, "<set-?>");
        this.emptyOverlay = linearLayout;
    }

    @NotNull
    public final IconBtn getPlayBtn() {
        IconBtn iconBtn = this.playBtn;
        if (iconBtn != null) {
            return iconBtn;
        }
        Intrinsics.throwUninitializedPropertyAccessException("playBtn");
        return null;
    }

    public final void setPlayBtn(@NotNull IconBtn iconBtn) {
        Intrinsics.checkNotNullParameter(iconBtn, "<set-?>");
        this.playBtn = iconBtn;
    }

    @NotNull
    public final TextView getTimeLabel() {
        TextView textView = this.timeLabel;
        if (textView != null) {
            return textView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("timeLabel");
        return null;
    }

    public final void setTimeLabel(@NotNull TextView textView) {
        Intrinsics.checkNotNullParameter(textView, "<set-?>");
        this.timeLabel = textView;
    }

    @NotNull
    public final TextView getDurationLabel() {
        TextView textView = this.durationLabel;
        if (textView != null) {
            return textView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("durationLabel");
        return null;
    }

    public final void setDurationLabel(@NotNull TextView textView) {
        Intrinsics.checkNotNullParameter(textView, "<set-?>");
        this.durationLabel = textView;
    }

    @NotNull
    public final SeekBar getSeek() {
        SeekBar seekBar = this.seek;
        if (seekBar != null) {
            return seekBar;
        }
        Intrinsics.throwUninitializedPropertyAccessException("seek");
        return null;
    }

    public final void setSeek(@NotNull SeekBar seekBar) {
        Intrinsics.checkNotNullParameter(seekBar, "<set-?>");
        this.seek = seekBar;
    }

    @NotNull
    public final TextView getAspectChip() {
        TextView textView = this.aspectChip;
        if (textView != null) {
            return textView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("aspectChip");
        return null;
    }

    public final void setAspectChip(@NotNull TextView textView) {
        Intrinsics.checkNotNullParameter(textView, "<set-?>");
        this.aspectChip = textView;
    }

    @NotNull
    public final LinearLayout getQuickBar() {
        LinearLayout linearLayout = this.quickBar;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("quickBar");
        return null;
    }

    public final void setQuickBar(@NotNull LinearLayout linearLayout) {
        Intrinsics.checkNotNullParameter(linearLayout, "<set-?>");
        this.quickBar = linearLayout;
    }

    @NotNull
    public final View getPanelDivider() {
        View view = this.panelDivider;
        if (view != null) {
            return view;
        }
        Intrinsics.throwUninitializedPropertyAccessException("panelDivider");
        return null;
    }

    public final void setPanelDivider(@NotNull View view) {
        Intrinsics.checkNotNullParameter(view, "<set-?>");
        this.panelDivider = view;
    }

    @NotNull
    public final LinearLayout getPanelContent() {
        LinearLayout linearLayout = this.panelContent;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("panelContent");
        return null;
    }

    public final void setPanelContent(@NotNull LinearLayout linearLayout) {
        Intrinsics.checkNotNullParameter(linearLayout, "<set-?>");
        this.panelContent = linearLayout;
    }

    @NotNull
    public final LinearLayout getSheet() {
        LinearLayout linearLayout = this.sheet;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("sheet");
        return null;
    }

    public final void setSheet(@NotNull LinearLayout linearLayout) {
        Intrinsics.checkNotNullParameter(linearLayout, "<set-?>");
        this.sheet = linearLayout;
    }

    @NotNull
    public final LinearLayout getDockContainer() {
        LinearLayout linearLayout = this.dockContainer;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("dockContainer");
        return null;
    }

    public final void setDockContainer(@NotNull LinearLayout linearLayout) {
        Intrinsics.checkNotNullParameter(linearLayout, "<set-?>");
        this.dockContainer = linearLayout;
    }

    @NotNull
    public final TextView getRecChip() {
        TextView textView = this.recChip;
        if (textView != null) {
            return textView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("recChip");
        return null;
    }

    public final void setRecChip(@NotNull TextView textView) {
        Intrinsics.checkNotNullParameter(textView, "<set-?>");
        this.recChip = textView;
    }

    @NotNull
    public final TextView getStatsHud() {
        TextView textView = this.statsHud;
        if (textView != null) {
            return textView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("statsHud");
        return null;
    }

    public final void setStatsHud(@NotNull TextView textView) {
        Intrinsics.checkNotNullParameter(textView, "<set-?>");
        this.statsHud = textView;
    }

    @NotNull
    public final TextView getHiddenPill() {
        TextView textView = this.hiddenPill;
        if (textView != null) {
            return textView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("hiddenPill");
        return null;
    }

    public final void setHiddenPill(@NotNull TextView textView) {
        Intrinsics.checkNotNullParameter(textView, "<set-?>");
        this.hiddenPill = textView;
    }

    @NotNull
    public final RadialMenuView getWheel() {
        RadialMenuView radialMenuView = this.wheel;
        if (radialMenuView != null) {
            return radialMenuView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("wheel");
        return null;
    }

    public final void setWheel(@NotNull RadialMenuView radialMenuView) {
        Intrinsics.checkNotNullParameter(radialMenuView, "<set-?>");
        this.wheel = radialMenuView;
    }

    @NotNull
    public final SourceDock getDock() {
        SourceDock sourceDock = this.dock;
        if (sourceDock != null) {
            return sourceDock;
        }
        Intrinsics.throwUninitializedPropertyAccessException("dock");
        return null;
    }

    public final void setDock(@NotNull SourceDock sourceDock) {
        Intrinsics.checkNotNullParameter(sourceDock, "<set-?>");
        this.dock = sourceDock;
    }

    @Nullable
    public final SourcesPanel getSourcesPanel() {
        return this.sourcesPanel;
    }

    public final void setSourcesPanel(@Nullable SourcesPanel sourcesPanel) {
        this.sourcesPanel = sourcesPanel;
    }

    @Nullable
    public final ControlsPanel getControlsPanel() {
        return this.controlsPanel;
    }

    public final void setControlsPanel(@Nullable ControlsPanel controlsPanel) {
        this.controlsPanel = controlsPanel;
    }

    @Nullable
    public final MixerPanel getMixerPanel() {
        return this.mixerPanel;
    }

    public final void setMixerPanel(@Nullable MixerPanel mixerPanel) {
        this.mixerPanel = mixerPanel;
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    @NotNull
    public SourceController getCtrl() {
        SourceController sourceController = this.ctrl;
        if (sourceController != null) {
            return sourceController;
        }
        Intrinsics.throwUninitializedPropertyAccessException("ctrl");
        return null;
    }

    public void setCtrl(@NotNull SourceController sourceController) {
        Intrinsics.checkNotNullParameter(sourceController, "<set-?>");
        this.ctrl = sourceController;
    }

    @NotNull
    public final FrameLayout getRootFrame() {
        FrameLayout frameLayout = this.rootFrame;
        if (frameLayout != null) {
            return frameLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("rootFrame");
        return null;
    }

    public final void setRootFrame(@NotNull FrameLayout frameLayout) {
        Intrinsics.checkNotNullParameter(frameLayout, "<set-?>");
        this.rootFrame = frameLayout;
    }

    @NotNull
    public final IconBtn getStudioBtn() {
        IconBtn iconBtn = this.studioBtn;
        if (iconBtn != null) {
            return iconBtn;
        }
        Intrinsics.throwUninitializedPropertyAccessException("studioBtn");
        return null;
    }

    public final void setStudioBtn(@NotNull IconBtn iconBtn) {
        Intrinsics.checkNotNullParameter(iconBtn, "<set-?>");
        this.studioBtn = iconBtn;
    }

    @NotNull
    public final LinearLayout getTabBar() {
        LinearLayout linearLayout = this.tabBar;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("tabBar");
        return null;
    }

    public final void setTabBar(@NotNull LinearLayout linearLayout) {
        Intrinsics.checkNotNullParameter(linearLayout, "<set-?>");
        this.tabBar = linearLayout;
    }

    @NotNull
    public final LinearLayout getTransportBar() {
        LinearLayout linearLayout = this.transportBar;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("transportBar");
        return null;
    }

    public final void setTransportBar(@NotNull LinearLayout linearLayout) {
        Intrinsics.checkNotNullParameter(linearLayout, "<set-?>");
        this.transportBar = linearLayout;
    }

    @NotNull
    public final HorizontalScrollView getSourceStripWrap() {
        HorizontalScrollView horizontalScrollView = this.sourceStripWrap;
        if (horizontalScrollView != null) {
            return horizontalScrollView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("sourceStripWrap");
        return null;
    }

    public final void setSourceStripWrap(@NotNull HorizontalScrollView horizontalScrollView) {
        Intrinsics.checkNotNullParameter(horizontalScrollView, "<set-?>");
        this.sourceStripWrap = horizontalScrollView;
    }

    @NotNull
    public final LinearLayout getSourceStrip() {
        LinearLayout linearLayout = this.sourceStrip;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("sourceStrip");
        return null;
    }

    public final void setSourceStrip(@NotNull LinearLayout linearLayout) {
        Intrinsics.checkNotNullParameter(linearLayout, "<set-?>");
        this.sourceStrip = linearLayout;
    }

    @NotNull
    public final LinearLayout getTopBar() {
        LinearLayout linearLayout = this.topBar;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("topBar");
        return null;
    }

    public final void setTopBar(@NotNull LinearLayout linearLayout) {
        Intrinsics.checkNotNullParameter(linearLayout, "<set-?>");
        this.topBar = linearLayout;
    }

    @NotNull
    public final HorizontalScrollView getQuickWrap() {
        HorizontalScrollView horizontalScrollView = this.quickWrap;
        if (horizontalScrollView != null) {
            return horizontalScrollView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("quickWrap");
        return null;
    }

    public final void setQuickWrap(@NotNull HorizontalScrollView horizontalScrollView) {
        Intrinsics.checkNotNullParameter(horizontalScrollView, "<set-?>");
        this.quickWrap = horizontalScrollView;
    }

    @NotNull
    public final TextView getFullExitBtn() {
        TextView textView = this.fullExitBtn;
        if (textView != null) {
            return textView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("fullExitBtn");
        return null;
    }

    public final void setFullExitBtn(@NotNull TextView textView) {
        Intrinsics.checkNotNullParameter(textView, "<set-?>");
        this.fullExitBtn = textView;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void insetsSync$lambda$0(EditorActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.applyViewportInsets(new Object[0]);
    }

    @NotNull
    public final ScrollView getPanelScroll() {
        ScrollView scrollView = this.panelScroll;
        if (scrollView != null) {
            return scrollView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("panelScroll");
        return null;
    }

    public final void setPanelScroll(@NotNull ScrollView scrollView) {
        Intrinsics.checkNotNullParameter(scrollView, "<set-?>");
        this.panelScroll = scrollView;
    }

    @NotNull
    public final LinearLayout getLaunchRow() {
        LinearLayout linearLayout = this.launchRow;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("launchRow");
        return null;
    }

    public final void setLaunchRow(@NotNull LinearLayout linearLayout) {
        Intrinsics.checkNotNullParameter(linearLayout, "<set-?>");
        this.launchRow = linearLayout;
    }

    @NotNull
    public final ScrollView getSideRail() {
        ScrollView scrollView = this.sideRail;
        if (scrollView != null) {
            return scrollView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("sideRail");
        return null;
    }

    public final void setSideRail(@NotNull ScrollView scrollView) {
        Intrinsics.checkNotNullParameter(scrollView, "<set-?>");
        this.sideRail = scrollView;
    }

    @NotNull
    public final LinearLayout getRailContent() {
        LinearLayout linearLayout = this.railContent;
        if (linearLayout != null) {
            return linearLayout;
        }
        Intrinsics.throwUninitializedPropertyAccessException("railContent");
        return null;
    }

    public final void setRailContent(@NotNull LinearLayout linearLayout) {
        Intrinsics.checkNotNullParameter(linearLayout, "<set-?>");
        this.railContent = linearLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void snackHide$lambda$1(EditorActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        LinearLayout linearLayout = this$0.snackBar;
        if (linearLayout == null) {
            return;
        }
        linearLayout.setVisibility(8);
    }

    @NotNull
    public final PreviewEngine getEngine() {
        PreviewEngine previewEngine = this.engine;
        if (previewEngine != null) {
            return previewEngine;
        }
        Intrinsics.throwUninitializedPropertyAccessException("engine");
        return null;
    }

    public final void setEngine(@NotNull PreviewEngine previewEngine) {
        Intrinsics.checkNotNullParameter(previewEngine, "<set-?>");
        this.engine = previewEngine;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void autosave$lambda$2(EditorActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.flushSave();
    }

    public final boolean getScrubbing() {
        return this.scrubbing;
    }

    public final void setScrubbing(boolean z) {
        this.scrubbing = z;
    }

    @NotNull
    public final TextView getRecordBtn() {
        TextView textView = this.recordBtn;
        if (textView != null) {
            return textView;
        }
        Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
        return null;
    }

    public final void setRecordBtn(@NotNull TextView textView) {
        Intrinsics.checkNotNullParameter(textView, "<set-?>");
        this.recordBtn = textView;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v17, types: [T, com.rehman.ahmedreactionstudio.core.Project] */
    /* JADX WARN: Type inference failed for: r4v4, types: [T, com.rehman.ahmedreactionstudio.core.Project] */
    @Override // android.app.Activity
    protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        ProjectStore projectStore = null;
        UI.styleWindow$default(UI.INSTANCE, this, false, 2, null);
        applyEditorImmersive();
        EditorActivity editorActivity = this;
        this.store = new ProjectStore(editorActivity);
        String stringExtra = getIntent().getStringExtra("pid");
        if (stringExtra == null) {
            stringExtra = b != null ? b.getString("pid") : null;
            if (stringExtra == null) {
                ProjectStore projectStore2 = this.store;
                if (projectStore2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("store");
                    projectStore2 = null;
                }
                stringExtra = (String) CollectionsKt.firstOrNull((List) projectStore2.listIds());
                if (stringExtra == null) {
                    finish();
                    return;
                }
            }
        }
        this.projectId = stringExtra;
        Ref.ObjectRef objectRef = new Ref.ObjectRef();
        ProjectStore projectStore3 = this.store;
        if (projectStore3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore3 = null;
        }
        objectRef.element = projectStore3.load(this.projectId);
        if (objectRef.element == 0) {
            ProjectStore projectStore4 = this.store;
            if (projectStore4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("store");
                projectStore4 = null;
            }
            objectRef.element = projectStore4.loadSnapshot(this.projectId);
        }
        if (objectRef.element == 0) {
            UI.INSTANCE.toast(editorActivity, "Project file missing");
            finish();
            return;
        }
        this.proj = (Project) objectRef.element;
        this.selectedId = b != null ? b.getString("sel") : null;
        ProjectStore projectStore5 = this.store;
        if (projectStore5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore5 = null;
        }
        projectStore5.markOpen(this.projectId);
        setCtrl(new SourceController(new Function0<Project>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.onCreate.2
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final Project invoke() {
                Project proj = EditorActivity.this.getProj();
                Intrinsics.checkNotNull(proj);
                return proj;
            }
        }, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.onCreate.3
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.pushUndo();
            }
        }, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.onCreate.4
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.onSourceChanged();
            }
        }));
        applyOrientationFor(((Project) objectRef.element).getAspect());
        Function0<Project> function0 = new Function0<Project>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.onCreate.5
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final Project invoke() {
                Project proj = EditorActivity.this.getProj();
                Intrinsics.checkNotNull(proj);
                return proj;
            }
        };
        ProjectStore projectStore6 = this.store;
        if (projectStore6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
        } else {
            projectStore = projectStore6;
        }
        setEngine(new PreviewEngine(editorActivity, function0, projectStore, new Function1<Long, Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.onCreate.6
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Long l) {
                invoke(l.longValue());
                return Unit.INSTANCE;
            }

            public final void invoke(long j) {
                EditorActivity.this.onTick(j);
            }
        }));
        getEngine().attach(this.projectId);
        ScreenCaptureService.INSTANCE.setOnStopped(new AnonymousClass7(objectRef));
        buildUi();
        rebindDock();
        rebuildDock();
        rebuildSourceDock();
        refreshContextBar();
        updateName();
        getEngine().refreshFrames();
        updateEmptyState(new Object[0]);
        updateRecordButton();
        bindSidePanels();
    }

    /* JADX INFO: renamed from: com.rehman.ahmedreactionstudio.editor.EditorActivity$onCreate$7, reason: invalid class name */
    /* JADX INFO: compiled from: EditorActivity.kt */
    @Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u00012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003H\n¢\u0006\u0002\b\u0004"}, d2 = {"<anonymous>", "", "f", "Ljava/io/File;", "invoke"}, k = Base64.bytesPerGroup, mv = {1, 9, 0}, xi = 48)
    static final class AnonymousClass7 extends Lambda implements Function1<File, Unit> {
        final /* synthetic */ Ref.ObjectRef<Project> $p;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass7(Ref.ObjectRef<Project> objectRef) {
            super(1);
            this.$p = objectRef;
        }

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(File file) {
            invoke2(file);
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2(@Nullable final File file) {
            final EditorActivity editorActivity = EditorActivity.this;
            final Ref.ObjectRef<Project> objectRef = this.$p;
            editorActivity.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$onCreate$7$ZdIHc-wufI0T2TY5cx5hc__uBJQ
                @Override // java.lang.Runnable
                public final void run() {
                    EditorActivity.AnonymousClass7.invoke$lambda$0(editorActivity, file, objectRef);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* JADX WARN: Multi-variable type inference failed */
        public static final void invoke$lambda$0(EditorActivity this$0, File file, Ref.ObjectRef p) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(p, "$p");
            this$0.getRecChip().setVisibility(8);
            if (file != null) {
                this$0.consumeMediaFile(file, ((Project) p.element).getLayers().isEmpty() ? "main" : "pip", "Screen record", LayerType.SCREEN);
            } else {
                UI.INSTANCE.toast(this$0, "Screen recording was empty");
            }
        }
    }

    private final void applyEditorImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController insetsController = getWindow().getInsetsController();
            if (insetsController == null) {
                return;
            }
            insetsController.setSystemBarsBehavior(2);
            insetsController.hide(WindowInsets.Type.systemBars());
            return;
        }
        getWindow().getDecorView().setSystemUiVisibility(5894);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            applyEditorImmersive();
        }
    }

    private final void applyOrientationFor(Aspect a) {
        int i;
        int i2 = WhenMappings.$EnumSwitchMapping$0[a.ordinal()];
        if (i2 == 1) {
            i = 6;
        } else if (i2 == 2) {
            i = 7;
        } else {
            if (i2 != 3) {
                throw new NoWhenBranchMatchedException();
            }
            i = -1;
        }
        if (getRequestedOrientation() != i) {
            setRequestedOrientation(i);
        }
    }

    @Override // android.app.Activity
    protected void onSaveInstanceState(@NotNull Bundle out) {
        Intrinsics.checkNotNullParameter(out, "out");
        out.putString("pid", this.projectId);
        out.putString("sel", this.selectedId);
        super.onSaveInstanceState(out);
    }

    public final boolean engineReady() {
        return this.engine != null;
    }

    private final boolean transportReady() {
        return (this.seek == null || this.durationLabel == null) ? false : true;
    }

    private final boolean sheetReady() {
        return (this.sheet == null || this.panelScroll == null || this.panelContent == null || this.panelDivider == null) ? false : true;
    }

    private final boolean wheelReady() {
        return this.wheel != null;
    }

    @Override // android.app.Activity
    protected void onResume() {
        List<Layer> layers;
        super.onResume();
        applyEditorImmersive();
        File pendingFile = ScreenCaptureService.INSTANCE.getPendingFile();
        boolean z = false;
        if (pendingFile != null && pendingFile.exists()) {
            ScreenCaptureService.INSTANCE.setPendingFile(null);
            Project project = this.proj;
            consumeMediaFile(pendingFile, project != null && (layers = project.getLayers()) != null && layers.isEmpty() ? "main" : "pip", "Screen record", LayerType.SCREEN);
        }
        if (getRecChip().getVisibility() == 0 && !ScreenCaptureService.INSTANCE.getRunning()) {
            LiveCamera liveCamera = this.liveCam;
            if (liveCamera != null && liveCamera.getRecording()) {
                z = true;
            }
            if (!z) {
                getRecChip().setVisibility(8);
            }
        }
        reconcileLiveCamera();
        if (engineReady()) {
            getEngine().refreshFrames();
        }
    }

    @Override // android.app.Activity
    protected void onPause() {
        flushSave();
        super.onPause();
    }

    @Override // android.app.Activity
    protected void onStop() {
        if (this.recording) {
            stopCompositeRecording(false);
        }
        if (engineReady()) {
            getEngine().stopSnapshots();
        }
        LiveCamera liveCamera = this.liveCam;
        if (!(liveCamera != null && liveCamera.getRecording())) {
            stopLiveCamera(false);
        }
        if (this.screenLight) {
            this.screenLight = false;
            applyScreenLight();
        }
        super.onStop();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener;
        if (this.rootFrame != null && (onGlobalLayoutListener = this.chromeLayoutListener) != null) {
            try {
                getRootFrame().getViewTreeObserver().removeOnGlobalLayoutListener(onGlobalLayoutListener);
            } catch (Exception unused) {
            }
        }
        ProjectStore projectStore = null;
        this.chromeLayoutListener = null;
        if (this.rootFrame != null) {
            getRootFrame().removeCallbacks(this.insetsSync);
        }
        CompositionRecorder compositionRecorder = this.recorder;
        if (compositionRecorder != null) {
            compositionRecorder.abort();
        }
        this.recorder = null;
        this.recordHandler.removeCallbacksAndMessages(null);
        Iterator<Bitmap> it = this.recordImageCache.values().iterator();
        while (it.hasNext()) {
            try {
                it.next().recycle();
            } catch (Exception unused2) {
            }
        }
        this.recordImageCache.clear();
        stopLiveCamera(true);
        this.saveHandler.removeCallbacksAndMessages(null);
        flushSave();
        if (engineReady()) {
            getEngine().release();
        }
        if (ScreenCaptureService.INSTANCE.getOnStopped() != null) {
            ScreenCaptureService.INSTANCE.setOnStopped(null);
        }
        ProjectStore projectStore2 = this.store;
        if (projectStore2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
        } else {
            projectStore = projectStore2;
        }
        projectStore.clearOpen(this.projectId);
        super.onDestroy();
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        if (wheelReady() && getWheel().getOpen()) {
            getWheel().pop();
            return;
        }
        if (this.fullCanvas) {
            setFullCanvas(false);
            return;
        }
        if (this.sheetTab != null) {
            setSheet((String) null);
            return;
        }
        flushSave();
        ProjectStore projectStore = this.store;
        if (projectStore == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore = null;
        }
        projectStore.clearOpen(this.projectId);
        super.onBackPressed();
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(@NotNull Configuration newConfig) {
        Intrinsics.checkNotNullParameter(newConfig, "newConfig");
        super.onConfigurationChanged(newConfig);
        applyEditorImmersive();
        getRootFrame().removeAllViews();
        StudioLayoutInjector.INSTANCE.inject(this, getRootFrame());
        rebindDock();
        rebuildDock();
        rebuildSourceDock();
        refreshContextBar();
        updateRecordButton();
        getStage().post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$cgWpnGawRv3UPCHHyIP4uDOoYMQ
            @Override // java.lang.Runnable
            public final void run() {
                EditorActivity.onConfigurationChanged$lambda$5(this.f$0);
            }
        });
        getStage().refresh();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onConfigurationChanged$lambda$5(EditorActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.syncPreviewTarget();
    }

    private final void buildUi() {
        FrameLayout frameLayout = new FrameLayout(this);
        setRootFrame(frameLayout);
        frameLayout.setBackgroundColor(UI.INSTANCE.getBLACK());
        StudioLayoutInjector.INSTANCE.inject(this, frameLayout);
        setContentView(frameLayout);
    }

    private final void updateStageInsets() {
        applyViewportInsets(new Object[0]);
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    private final void refreshTabBar() {
        for (Map.Entry<String, View> entry : this.tabViews.entrySet()) {
            String key = entry.getKey();
            View value = entry.getValue();
            boolean zAreEqual = Intrinsics.areEqual(this.sheetTab, key);
            Intrinsics.checkNotNull(value, "null cannot be cast to non-null type android.widget.LinearLayout");
            LinearLayout linearLayout = (LinearLayout) value;
            linearLayout.setSelected(zAreEqual);
            View childAt = linearLayout.getChildAt(0);
            Intrinsics.checkNotNull(childAt, "null cannot be cast to non-null type android.widget.ImageView");
            ImageView imageView = (ImageView) childAt;
            View childAt2 = linearLayout.getChildAt(1);
            Intrinsics.checkNotNull(childAt2, "null cannot be cast to non-null type android.widget.TextView");
            TextView textView = (TextView) childAt2;
            int iHashCode = key.hashCode();
            int i = R.drawable.ic_layers;
            switch (iHashCode) {
                case -2021876808:
                    key.equals("sources");
                    break;
                case -1289153612:
                    if (key.equals("export")) {
                        i = R.drawable.ic_export;
                    }
                    break;
                case 96417:
                    if (key.equals("add")) {
                        i = R.drawable.ic_add;
                    }
                    break;
                case 3556653:
                    if (key.equals("text")) {
                        i = R.drawable.ic_text;
                    }
                    break;
                case 103910409:
                    if (key.equals("mixer")) {
                        i = R.drawable.ic_volume;
                    }
                    break;
            }
            Ic ic = Ic.INSTANCE;
            EditorActivity editorActivity = this;
            UI ui = UI.INSTANCE;
            imageView.setImageDrawable(ic.get(editorActivity, i, zAreEqual ? ui.getACCENT() : ui.getFG2()));
            UI ui2 = UI.INSTANCE;
            textView.setTextColor(zAreEqual ? ui2.getACCENT() : ui2.getFG2());
            Drawable background = linearLayout.getBackground();
            GradientDrawable gradientDrawable = background instanceof GradientDrawable ? (GradientDrawable) background : null;
            if (gradientDrawable != null) {
                gradientDrawable.setColor(zAreEqual ? Color.argb(55, KotlinVersion.MAX_COMPONENT_VALUE, 90, 44) : 0);
            }
            if (zAreEqual) {
                if (gradientDrawable != null) {
                    gradientDrawable.setStroke(UI.INSTANCE.dp(editorActivity, 1), Color.argb(90, KotlinVersion.MAX_COMPONENT_VALUE, 90, 44));
                }
            } else if (gradientDrawable != null) {
                gradientDrawable.setStroke(0, 0);
            }
        }
    }

    private final boolean isLandscape() {
        return getResources().getConfiguration().orientation == 2;
    }

    private final int railWidthPx() {
        EditorActivity editorActivity = this;
        return RangesKt.coerceIn((int) (getResources().getDisplayMetrics().widthPixels * 0.4f), UI.INSTANCE.dp(editorActivity, 220), UI.INSTANCE.dp(editorActivity, 340));
    }

    private final void relayoutChrome(Object... args) {
        getRootFrame().removeAllViews();
        StudioLayoutInjector.INSTANCE.inject(this, getRootFrame());
        rebindDock();
        rebuildDock();
        rebuildSourceDock();
    }

    static /* synthetic */ LinearLayout dockBtn$default(EditorActivity editorActivity, LinearLayout linearLayout, int i, String str, String str2, boolean z, Function0 function0, int i2, Object obj) {
        if ((i2 & 16) != 0) {
            z = false;
        }
        return editorActivity.dockBtn(linearLayout, i, str, str2, z, function0);
    }

    private final LinearLayout dockBtn(LinearLayout parent, int icon, String label, String desc, boolean active, final Function0<Unit> fn) {
        EditorActivity editorActivity = this;
        final LinearLayout linearLayout = new LinearLayout(editorActivity);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        linearLayout.setClickable(true);
        linearLayout.setFocusable(true);
        linearLayout.setContentDescription(desc);
        linearLayout.setPadding(UI.INSTANCE.dp(editorActivity, 6), UI.INSTANCE.dp(editorActivity, 4), UI.INSTANCE.dp(editorActivity, 6), UI.INSTANCE.dp(editorActivity, 3));
        linearLayout.setBackground(Ic.INSTANCE.pill(editorActivity, active ? Color.argb(70, KotlinVersion.MAX_COMPONENT_VALUE, 90, 44) : Color.argb(40, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE), 14.0f, active ? Color.argb(200, KotlinVersion.MAX_COMPONENT_VALUE, 90, 44) : Color.argb(50, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE)));
        ImageView imageView = new ImageView(editorActivity);
        Ic ic = Ic.INSTANCE;
        UI ui = UI.INSTANCE;
        imageView.setImageDrawable(ic.get(editorActivity, icon, active ? ui.getACCENT2() : ui.getFG()));
        imageView.setLayoutParams(new LinearLayout.LayoutParams(UI.INSTANCE.dp(editorActivity, 22), UI.INSTANCE.dp(editorActivity, 22)));
        linearLayout.addView(imageView);
        TextView textView = new TextView(editorActivity);
        textView.setText(label);
        textView.setTextSize(9.5f);
        textView.setMaxLines(1);
        UI ui2 = UI.INSTANCE;
        textView.setTextColor(active ? ui2.getACCENT2() : ui2.getFG2());
        textView.setTypeface(Typeface.create("sans-serif-medium", 0));
        linearLayout.addView(textView);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, UI.INSTANCE.dp(editorActivity, 48));
        layoutParams.setMargins(UI.INSTANCE.dp(editorActivity, 2), 0, UI.INSTANCE.dp(editorActivity, 2), 0);
        linearLayout.setMinimumWidth(UI.INSTANCE.dp(editorActivity, 56));
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$Ng9xp-WQ3E7VynP8K-kiO88KmdY
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                EditorActivity.dockBtn$lambda$6(linearLayout, fn, view);
            }
        });
        parent.addView(linearLayout);
        return linearLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void dockBtn$lambda$6(LinearLayout b, Function0 fn, View view) {
        Intrinsics.checkNotNullParameter(b, "$b");
        Intrinsics.checkNotNullParameter(fn, "$fn");
        b.performHapticFeedback(1);
        fn.invoke();
    }

    private final void rebuildSourceDock() {
        updateSourceStrip(new Object[0]);
    }

    private final void refreshContextBar() {
        refreshQuickBar(new Object[0]);
    }

    /* JADX WARN: Removed duplicated region for block: B:49:0x00a5  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void setFullCanvas(boolean r8) {
        /*
            Method dump skipped, instruction units count: 305
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.editor.EditorActivity.setFullCanvas(boolean):void");
    }

    private final void readSystemInsets(WindowInsets insets) {
        DisplayCutout displayCutout;
        if (Build.VERSION.SDK_INT >= 30) {
            Insets insets2 = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            this.sysL = insets2.left;
            this.sysT = insets2.top;
            this.sysR = insets2.right;
            this.sysB = insets2.bottom;
            return;
        }
        EditorActivity editorActivity = this;
        editorActivity.sysL = insets.getSystemWindowInsetLeft();
        editorActivity.sysT = insets.getSystemWindowInsetTop();
        editorActivity.sysR = insets.getSystemWindowInsetRight();
        editorActivity.sysB = insets.getSystemWindowInsetBottom();
        if (Build.VERSION.SDK_INT < 28 || (displayCutout = insets.getDisplayCutout()) == null) {
            return;
        }
        this.sysL = Math.max(this.sysL, displayCutout.getSafeInsetLeft());
        this.sysT = Math.max(this.sysT, displayCutout.getSafeInsetTop());
        this.sysR = Math.max(this.sysR, displayCutout.getSafeInsetRight());
        this.sysB = Math.max(this.sysB, displayCutout.getSafeInsetBottom());
    }

    private final void buildSnackBar(FrameLayout root) {
        EditorActivity editorActivity = this;
        LinearLayout linearLayout = new LinearLayout(editorActivity);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        linearLayout.setPadding(UI.INSTANCE.dp(editorActivity, 16), UI.INSTANCE.dp(editorActivity, 10), UI.INSTANCE.dp(editorActivity, 8), UI.INSTANCE.dp(editorActivity, 10));
        linearLayout.setBackground(Ic.INSTANCE.pill(editorActivity, Color.argb(242, 18, 20, 27), 14.0f, Color.argb(110, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE)));
        linearLayout.setVisibility(8);
        this.snackMsg = new TextView(editorActivity);
        TextView textView = this.snackMsg;
        Intrinsics.checkNotNull(textView);
        textView.setTextColor(-1);
        TextView textView2 = this.snackMsg;
        Intrinsics.checkNotNull(textView2);
        textView2.setTextSize(12.5f);
        TextView textView3 = this.snackMsg;
        Intrinsics.checkNotNull(textView3);
        textView3.setMaxLines(2);
        TextView textView4 = this.snackMsg;
        Intrinsics.checkNotNull(textView4);
        textView4.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout.addView(this.snackMsg);
        this.snackAction = new TextView(editorActivity);
        TextView textView5 = this.snackAction;
        Intrinsics.checkNotNull(textView5);
        textView5.setTextColor(UI.INSTANCE.getACCENT2());
        TextView textView6 = this.snackAction;
        Intrinsics.checkNotNull(textView6);
        textView6.setTextSize(12.5f);
        TextView textView7 = this.snackAction;
        Intrinsics.checkNotNull(textView7);
        textView7.setTypeface(Typeface.create("sans-serif-medium", 1));
        TextView textView8 = this.snackAction;
        Intrinsics.checkNotNull(textView8);
        textView8.setPadding(UI.INSTANCE.dp(editorActivity, 12), UI.INSTANCE.dp(editorActivity, 6), UI.INSTANCE.dp(editorActivity, 12), UI.INSTANCE.dp(editorActivity, 6));
        linearLayout.addView(this.snackAction);
        this.snackBar = linearLayout;
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -2, 80);
        layoutParams.setMargins(UI.INSTANCE.dp(editorActivity, 14), 0, UI.INSTANCE.dp(editorActivity, 14), UI.INSTANCE.dp(editorActivity, 208));
        root.addView(linearLayout, layoutParams);
    }

    /* JADX WARN: Multi-variable type inference failed */
    static /* synthetic */ void showSnack$default(EditorActivity editorActivity, String str, String str2, Function0 function0, int i, Object obj) {
        if ((i & 2) != 0) {
            str2 = null;
        }
        if ((i & 4) != 0) {
            function0 = null;
        }
        editorActivity.showSnack(str, str2, function0);
    }

    private final void showSnack(String msg, String actionLabel, final Function0<Unit> action) {
        final LinearLayout linearLayout = this.snackBar;
        if (linearLayout == null) {
            return;
        }
        this.snackHandler.removeCallbacks(this.snackHide);
        TextView textView = this.snackMsg;
        if (textView != null) {
            textView.setText(msg);
        }
        if (actionLabel != null && action != null) {
            TextView textView2 = this.snackAction;
            if (textView2 != null) {
                textView2.setVisibility(0);
            }
            TextView textView3 = this.snackAction;
            if (textView3 != null) {
                textView3.setText(actionLabel);
            }
            TextView textView4 = this.snackAction;
            if (textView4 != null) {
                textView4.setContentDescription(actionLabel);
            }
            TextView textView5 = this.snackAction;
            if (textView5 != null) {
                textView5.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$v466eO9etvT7EyUfBa-FZnC21Us
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        EditorActivity.showSnack$lambda$9(linearLayout, action, view);
                    }
                });
            }
        } else {
            TextView textView6 = this.snackAction;
            if (textView6 != null) {
                textView6.setVisibility(8);
            }
        }
        linearLayout.setVisibility(0);
        linearLayout.setAlpha(0.0f);
        linearLayout.setTranslationY(UI.INSTANCE.dpf(this, 12.0f));
        linearLayout.animate().alpha(1.0f).translationY(0.0f).setDuration(200L).start();
        linearLayout.setContentDescription(msg);
        this.snackHandler.postDelayed(this.snackHide, 3500L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showSnack$lambda$9(LinearLayout bar, Function0 function0, View view) {
        Intrinsics.checkNotNullParameter(bar, "$bar");
        bar.setVisibility(8);
        function0.invoke();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void showUndoSnack(String msg) {
        showSnack(msg, "UNDO", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.showUndoSnack.1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.doUndo();
            }
        });
    }

    private final void buildProgOverlay(FrameLayout root) {
        EditorActivity editorActivity = this;
        FrameLayout frameLayout = new FrameLayout(editorActivity);
        frameLayout.setBackgroundColor(Color.argb(150, 0, 0, 0));
        frameLayout.setVisibility(8);
        frameLayout.setClickable(true);
        LinearLayout linearLayout = new LinearLayout(editorActivity);
        linearLayout.setOrientation(1);
        linearLayout.setPadding(UI.INSTANCE.dp(editorActivity, 20), UI.INSTANCE.dp(editorActivity, 18), UI.INSTANCE.dp(editorActivity, 20), UI.INSTANCE.dp(editorActivity, 16));
        linearLayout.setBackground(Ic.INSTANCE.pill(editorActivity, Color.argb(250, 20, 23, 31), 16.0f, Color.argb(100, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE)));
        this.progTitle = new TextView(editorActivity);
        TextView textView = this.progTitle;
        Intrinsics.checkNotNull(textView);
        textView.setTextColor(-1);
        TextView textView2 = this.progTitle;
        Intrinsics.checkNotNull(textView2);
        textView2.setTextSize(14.0f);
        TextView textView3 = this.progTitle;
        Intrinsics.checkNotNull(textView3);
        textView3.setTypeface(Typeface.create("sans-serif-medium", 1));
        linearLayout.addView(this.progTitle);
        this.progMsg = new TextView(editorActivity);
        TextView textView4 = this.progMsg;
        Intrinsics.checkNotNull(textView4);
        textView4.setTextColor(Color.argb(210, 235, 238, 245));
        TextView textView5 = this.progMsg;
        Intrinsics.checkNotNull(textView5);
        textView5.setTextSize(12.0f);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.topMargin = UI.INSTANCE.dp(editorActivity, 4);
        TextView textView6 = this.progMsg;
        Intrinsics.checkNotNull(textView6);
        textView6.setLayoutParams(layoutParams);
        linearLayout.addView(this.progMsg);
        this.progBar = new ProgressBar(editorActivity, null, android.R.attr.progressBarStyleHorizontal);
        ProgressBar progressBar = this.progBar;
        Intrinsics.checkNotNull(progressBar);
        progressBar.setMax(100);
        ProgressBar progressBar2 = this.progBar;
        Intrinsics.checkNotNull(progressBar2);
        progressBar2.setProgressTintList(ColorStateList.valueOf(UI.INSTANCE.getACCENT()));
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = UI.INSTANCE.dp(editorActivity, 12);
        ProgressBar progressBar3 = this.progBar;
        Intrinsics.checkNotNull(progressBar3);
        progressBar3.setLayoutParams(layoutParams2);
        linearLayout.addView(this.progBar);
        this.progCancel = new TextView(editorActivity);
        TextView textView7 = this.progCancel;
        Intrinsics.checkNotNull(textView7);
        textView7.setText("Cancel");
        TextView textView8 = this.progCancel;
        Intrinsics.checkNotNull(textView8);
        textView8.setGravity(17);
        TextView textView9 = this.progCancel;
        Intrinsics.checkNotNull(textView9);
        textView9.setTextColor(UI.INSTANCE.getDANGER());
        TextView textView10 = this.progCancel;
        Intrinsics.checkNotNull(textView10);
        textView10.setTextSize(13.0f);
        TextView textView11 = this.progCancel;
        Intrinsics.checkNotNull(textView11);
        textView11.setTypeface(Typeface.create("sans-serif-medium", 1));
        TextView textView12 = this.progCancel;
        Intrinsics.checkNotNull(textView12);
        textView12.setPadding(0, UI.INSTANCE.dp(editorActivity, 10), 0, UI.INSTANCE.dp(editorActivity, 2));
        TextView textView13 = this.progCancel;
        Intrinsics.checkNotNull(textView13);
        textView13.setContentDescription("Cancel");
        TextView textView14 = this.progCancel;
        Intrinsics.checkNotNull(textView14);
        textView14.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$0KuqhJyoBF5cYk31ib-D6kGAfmE
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                EditorActivity.buildProgOverlay$lambda$10(this.f$0, view);
            }
        });
        linearLayout.addView(this.progCancel);
        FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(-1, -2, 17);
        layoutParams3.setMargins(UI.INSTANCE.dp(editorActivity, 36), 0, UI.INSTANCE.dp(editorActivity, 36), 0);
        frameLayout.addView(linearLayout, layoutParams3);
        this.progOverlay = frameLayout;
        root.addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildProgOverlay$lambda$10(EditorActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Function0<Unit> function0 = this$0.progOnCancel;
        if (function0 != null) {
            function0.invoke();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    static /* synthetic */ void showProgress$default(EditorActivity editorActivity, String str, String str2, boolean z, Function0 function0, int i, Object obj) {
        if ((i & 8) != 0) {
            function0 = null;
        }
        editorActivity.showProgress(str, str2, z, function0);
    }

    private final void showProgress(String title, String msg, boolean determinate, Function0<Unit> onCancel) {
        TextView textView = this.progTitle;
        if (textView != null) {
            textView.setText(title);
        }
        TextView textView2 = this.progMsg;
        if (textView2 != null) {
            textView2.setText(msg);
        }
        ProgressBar progressBar = this.progBar;
        if (progressBar != null) {
            progressBar.setIndeterminate(!determinate);
        }
        ProgressBar progressBar2 = this.progBar;
        if (progressBar2 != null) {
            progressBar2.setProgress(0);
        }
        ProgressBar progressBar3 = this.progBar;
        if (progressBar3 != null) {
            progressBar3.setVisibility(0);
        }
        this.progOnCancel = onCancel;
        TextView textView3 = this.progCancel;
        if (textView3 != null) {
            textView3.setVisibility(onCancel != null ? 0 : 8);
        }
        FrameLayout frameLayout = this.progOverlay;
        if (frameLayout == null) {
            return;
        }
        frameLayout.setVisibility(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void updateProgress(int pct, String msg) {
        ProgressBar progressBar = this.progBar;
        if (progressBar != null) {
            progressBar.setProgress(RangesKt.coerceIn(pct, 0, 100));
        }
        TextView textView = this.progMsg;
        if (textView == null) {
            return;
        }
        textView.setText(msg);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void dismissProgress() {
        FrameLayout frameLayout = this.progOverlay;
        if (frameLayout != null) {
            frameLayout.setVisibility(8);
        }
        this.progOnCancel = null;
    }

    private final void openRootWheel() {
        if (wheelReady()) {
            setSheet((String) null);
            int[] iArr = new int[2];
            int[] iArr2 = new int[2];
            if (this.studioBtn != null) {
                getStudioBtn().getLocationOnScreen(iArr);
                getRootFrame().getLocationOnScreen(iArr2);
                getWheel().show(RadialMenus.INSTANCE.root(this), (iArr[0] + (getStudioBtn().getWidth() / 2.0f)) - iArr2[0], ((iArr[1] + (getStudioBtn().getHeight() / 2.0f)) - iArr2[1]) - UI.INSTANCE.dpf(this, 28.0f));
                return;
            }
            getWheel().show(RadialMenus.INSTANCE.root(this), -1.0f, -1.0f);
        }
    }

    public final void openWheelLevel(@NotNull RadialMenuView.Level level, float ax, float ay) {
        Intrinsics.checkNotNullParameter(level, "level");
        if (wheelReady()) {
            setSheet((String) null);
            getWheel().show(level, ax, ay);
        }
    }

    public final void setSheet(@Nullable String tab) {
        String str;
        String str2;
        if (!sheetReady()) {
            this.sheetTab = tab;
            return;
        }
        if (tab != null && this.fullCanvas) {
            setFullCanvas(false);
        }
        this.sheetTab = tab;
        final ScrollView panelScroll = getPanelScroll();
        View panelDivider = getPanelDivider();
        if (tab == null) {
            panelScroll.setVisibility(8);
            panelDivider.setVisibility(8);
            refreshTabBar();
            updateSourceStrip(new Object[0]);
            getSheet().post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$KSBUQb-iVG9FS9BpQodjKNCok7k
                @Override // java.lang.Runnable
                public final void run() {
                    EditorActivity.setSheet$lambda$11(this.f$0);
                }
            });
            return;
        }
        final int scrollY = panelScroll.getScrollY();
        getPanelContent().removeAllViews();
        EditorActivity editorActivity = this;
        LinearLayout linearLayout = new LinearLayout(editorActivity);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        linearLayout.setPadding(UI.INSTANCE.dp(editorActivity, 14), UI.INSTANCE.dp(editorActivity, 6), UI.INSTANCE.dp(editorActivity, 6), 0);
        TextView textView = new TextView(editorActivity);
        int iHashCode = tab.hashCode();
        if (iHashCode == -2021876808) {
            if (tab.equals("sources")) {
                str = "Layers";
                str2 = str;
            }
            str2 = tab;
        } else if (iHashCode != -1289153612) {
            if (iHashCode == 103910409 && tab.equals("mixer")) {
                str = "Audio mixer";
                str2 = str;
            }
            str2 = tab;
        } else {
            if (tab.equals("export")) {
                str = "Export";
                str2 = str;
            }
            str2 = tab;
        }
        textView.setText(str2);
        textView.setTextColor(UI.INSTANCE.getFG());
        textView.setTextSize(13.0f);
        textView.setTypeface(Typeface.create("sans-serif-medium", 1));
        textView.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout.addView(textView);
        IconBtn iconBtn = new IconBtn(editorActivity);
        iconBtn.setLayoutParams(IconBtn.INSTANCE.sized(editorActivity, 48));
        iconBtn.setIcon(R.drawable.ic_close, UI.INSTANCE.getFG(), "Close panel");
        iconBtn.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$GdSUU3q1V1GOC8Ba3x2tI3F85gg
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                EditorActivity.setSheet$lambda$12(this.f$0, view);
            }
        });
        linearLayout.addView(iconBtn);
        getPanelContent().addView(linearLayout);
        int iHashCode2 = tab.hashCode();
        if (iHashCode2 != -2021876808) {
            if (iHashCode2 != -1289153612) {
                if (iHashCode2 == 103910409 && tab.equals("mixer")) {
                    buildMixerPanel(new Object[0]);
                }
            } else if (tab.equals("export")) {
                buildExportPanel(new Object[0]);
            }
        } else if (tab.equals("sources")) {
            buildSourcesPanel(new Object[0]);
        }
        panelScroll.setVisibility(0);
        panelDivider.setVisibility(0);
        refreshTabBar();
        updateSourceStrip(new Object[0]);
        if (scrollY > 0) {
            panelScroll.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$EYlp1lDPYhciOYQSTxCuE-EjE6M
                @Override // java.lang.Runnable
                public final void run() {
                    EditorActivity.setSheet$lambda$13(panelScroll, scrollY);
                }
            });
        }
        getPanelContent().setAlpha(0.0f);
        getPanelContent().setTranslationY(UI.INSTANCE.dpf(editorActivity, 22.0f));
        getPanelContent().animate().alpha(1.0f).translationY(0.0f).setDuration(220L).setInterpolator(new OvershootInterpolator(1.15f)).start();
        getSheet().post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$2grT7Uz5jjS-SrYbF18p37gDe4s
            @Override // java.lang.Runnable
            public final void run() {
                EditorActivity.setSheet$lambda$14(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setSheet$lambda$11(EditorActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.updateStageInsets();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setSheet$lambda$12(EditorActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.setSheet((String) null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setSheet$lambda$13(ScrollView sv, int i) {
        Intrinsics.checkNotNullParameter(sv, "$sv");
        sv.scrollTo(0, i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setSheet$lambda$14(EditorActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.updateStageInsets();
    }

    private final void stepSelection(int dir) {
        Project project = this.proj;
        if (project == null || project.getLayers().isEmpty()) {
            return;
        }
        Iterator<Layer> it = project.getLayers().iterator();
        int i = 0;
        while (true) {
            if (!it.hasNext()) {
                i = -1;
                break;
            } else if (Intrinsics.areEqual(it.next().getId(), this.selectedId)) {
                break;
            } else {
                i++;
            }
        }
        select(project.getLayers().get((((i >= 0 ? i + dir : 0) % project.getLayers().size()) + project.getLayers().size()) % project.getLayers().size()).getId());
    }

    private final void rebindDock() {
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        setDockContainer(linearLayout);
        setDock(new SourceDock(this, linearLayout, new Function0<Project>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.rebindDock.1
            {
                super(0);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final Project invoke() {
                Project proj = EditorActivity.this.getProj();
                Intrinsics.checkNotNull(proj);
                return proj;
            }
        }, new Function0<String>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.rebindDock.2
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            @Nullable
            public final String invoke() {
                return EditorActivity.this.getSelectedId();
            }
        }, new Function1<String, Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.rebindDock.3
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(String str) {
                invoke2(str);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@Nullable String str) {
                EditorActivity.this.select(str);
            }
        }, new Function2<Layer, String, Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.rebindDock.4
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer, String str) {
                invoke2(layer, str);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer l, @NotNull String what) {
                Intrinsics.checkNotNullParameter(l, "l");
                Intrinsics.checkNotNullParameter(what, "what");
                EditorActivity.this.quickToggle(l, what);
            }
        }, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.rebindDock.5
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer l) {
                Intrinsics.checkNotNullParameter(l, "l");
                EditorActivity.this.getEngine().toggleLayerPlay(l);
                EditorActivity.this.markDirty();
                EditorActivity.this.refreshAll();
            }
        }, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.rebindDock.6
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer l) {
                Intrinsics.checkNotNullParameter(l, "l");
                EditorActivity.this.openAdvancedSheet(l);
            }
        }, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.rebindDock.7
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.pushUndo();
            }
        }, new Function2<Integer, Integer, Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.rebindDock.8
            {
                super(2);
            }

            @Override // kotlin.jvm.functions.Function2
            public /* bridge */ /* synthetic */ Unit invoke(Integer num, Integer num2) {
                invoke(num.intValue(), num2.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(int i, int i2) {
                EditorActivity.this.getCtrl().reorderLive(i, i2);
                EditorActivity.this.getStage().refresh();
            }
        }, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.rebindDock.9
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.markDirty();
                EditorActivity.this.refreshAll();
            }
        }));
    }

    private final void rebuildDock() {
        if (this.dock != null) {
            getDock().rebuild();
        }
    }

    private final void section(String title) {
        if (this.panelContent == null) {
            return;
        }
        EditorActivity editorActivity = this;
        TextView textView = new TextView(editorActivity);
        textView.setText(title);
        textView.setTextColor(UI.INSTANCE.getACCENT2());
        textView.setTextSize(10.0f);
        textView.setTypeface(Typeface.create("sans-serif-medium", 1));
        textView.setLetterSpacing(0.06f);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.setMargins(UI.INSTANCE.dp(editorActivity, 14), UI.INSTANCE.dp(editorActivity, 12), UI.INSTANCE.dp(editorActivity, 14), UI.INSTANCE.dp(editorActivity, 6));
        textView.setLayoutParams(layoutParams);
        getPanelContent().addView(textView);
        View view = new View(editorActivity);
        view.setBackgroundColor(Color.argb(35, KotlinVersion.MAX_COMPONENT_VALUE, 160, 44));
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, UI.INSTANCE.dp(editorActivity, 1));
        layoutParams2.setMargins(UI.INSTANCE.dp(editorActivity, 14), 0, UI.INSTANCE.dp(editorActivity, 14), UI.INSTANCE.dp(editorActivity, 4));
        view.setLayoutParams(layoutParams2);
        getPanelContent().addView(view);
    }

    private final void panelButtonRow(LinearLayout container, Pair<String, ? extends Function0<Unit>>... items) {
        EditorActivity editorActivity = this;
        LinearLayout linearLayout = new LinearLayout(editorActivity);
        linearLayout.setOrientation(0);
        linearLayout.setPadding(UI.INSTANCE.dp(editorActivity, 8), 0, UI.INSTANCE.dp(editorActivity, 8), 0);
        for (Pair<String, ? extends Function0<Unit>> pair : items) {
            String strComponent1 = pair.component1();
            final Function0<Unit> function0Component2 = pair.component2();
            Button buttonBtn = UI.INSTANCE.btn(editorActivity, strComponent1, false, true);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
            layoutParams.setMargins(UI.INSTANCE.dp(editorActivity, 4), UI.INSTANCE.dp(editorActivity, 3), UI.INSTANCE.dp(editorActivity, 4), UI.INSTANCE.dp(editorActivity, 3));
            buttonBtn.setLayoutParams(layoutParams);
            buttonBtn.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$SMbJhTSYSLnSHObYu0mVfIdDMiY
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    EditorActivity.panelButtonRow$lambda$16(function0Component2, view);
                }
            });
            linearLayout.addView(buttonBtn);
        }
        container.addView(linearLayout);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void panelButtonRow$lambda$16(Function0 fn, View view) {
        Intrinsics.checkNotNullParameter(fn, "$fn");
        fn.invoke();
    }

    private final void setBgColor(int c) {
        pushUndo();
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        project.setBgColor(c);
        markDirty();
        getStage().refresh();
    }

    public final void showAspectPicker() {
        String str;
        if (this.exportRunning) {
            UI.INSTANCE.toast(this, "Stop the export first");
            return;
        }
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        final Aspect aspect = project.getAspect();
        EnumEntries<Aspect> entries = Aspect.getEntries();
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(entries, 10));
        Iterator<Aspect> it = entries.iterator();
        while (it.hasNext()) {
            Aspect next = it.next();
            int i = WhenMappings.$EnumSwitchMapping$0[next.ordinal()];
            if (i == 1) {
                str = "YouTube · landscape";
            } else if (i == 2) {
                str = "Reels · Shorts · TikTok";
            } else {
                if (i != 3) {
                    throw new NoWhenBranchMatchedException();
                }
                str = "Square posts";
            }
            StringBuilder sb = new StringBuilder();
            sb.append(next.getCode());
            sb.append("  —  ");
            sb.append(str);
            sb.append(next == aspect ? "  ✓" : "");
            arrayList.add(sb.toString());
        }
        new AlertDialog.Builder(this).setTitle("Canvas aspect ratio").setItems((CharSequence[]) arrayList.toArray(new String[0]), new DialogInterface.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$1DpdhYcb6lNrKq2BEggqqRKxvqI
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                EditorActivity.showAspectPicker$lambda$19(aspect, this, dialogInterface, i2);
            }
        }).setNegativeButton("Cancel", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showAspectPicker$lambda$19(Aspect cur, final EditorActivity this$0, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(cur, "$cur");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        final Aspect aspect = Aspect.getEntries().get(i);
        if (aspect == cur) {
            return;
        }
        if (this$0.aspectChip != null) {
            this$0.getAspectChip().animate().cancel();
            this$0.getAspectChip().animate().scaleX(0.8f).scaleY(0.8f).setDuration(80L).withEndAction(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$qn4ed7CXUs58K3Fg0bvPZ-9za_c
                @Override // java.lang.Runnable
                public final void run() {
                    EditorActivity.showAspectPicker$lambda$19$lambda$18(this.f$0, aspect);
                }
            }).start();
        } else {
            this$0.changeAspect(aspect);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showAspectPicker$lambda$19$lambda$18(EditorActivity this$0, Aspect next) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(next, "$next");
        this$0.changeAspect(next);
        this$0.getAspectChip().animate().scaleX(1.0f).scaleY(1.0f).setDuration(260L).setInterpolator(new OvershootInterpolator(2.0f)).start();
    }

    private final void changeAspect(Aspect a) {
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        if (project.getAspect() == a) {
            return;
        }
        if (this.exportRunning) {
            UI.INSTANCE.toast(this, "Stop the export first");
            return;
        }
        pushUndo();
        project.setAspect(a);
        applyOrientationFor(a);
        updateAspectChip();
        markDirty();
        getStage().post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$NQcQGUnak1IucrIFqYWwrgbYw_M
            @Override // java.lang.Runnable
            public final void run() {
                EditorActivity.changeAspect$lambda$20(this.f$0);
            }
        });
        getStage().refresh();
        showUndoSnack("Canvas " + a.getCode() + " — every source keeps its own frame ratio");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void changeAspect$lambda$20(EditorActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.syncPreviewTarget();
    }

    public final void updateAspectChip() {
        if (this.aspectChip == null) {
            return;
        }
        TextView aspectChip = getAspectChip();
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        aspectChip.setText(project.getAspect().getCode());
    }

    private final void saveExportPrefs(String codecName, int quality, int maxDim, int fps) {
        editorPrefs().edit().putString(PREF_EXP_CODEC, codecName).putInt(PREF_EXP_QUALITY, quality).putInt(PREF_EXP_MAXDIM, maxDim).putInt(PREF_EXP_FPS, fps).putBoolean(PREF_HAD_EXPORT, true).apply();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void showHideFeedback(Layer l) {
        if (l.getVisible()) {
            showUndoSnack(l.getName() + " visible");
            return;
        }
        showUndoSnack(l.getName() + " hidden — audio still plays");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void quickToggle(Layer l, String what) {
        StringBuilder sb;
        String str;
        if (Intrinsics.areEqual(what, "vis")) {
            getCtrl().toggleVisible(l.getId());
            showHideFeedback(l);
            return;
        }
        if (Intrinsics.areEqual(what, "mute")) {
            getCtrl().toggleMuted(l.getId());
            if (l.getMuted()) {
                sb = new StringBuilder();
                sb.append(l.getName());
                str = " muted";
            } else {
                sb = new StringBuilder();
                sb.append(l.getName());
                str = " unmuted";
            }
            sb.append(str);
            showUndoSnack(sb.toString());
        }
    }

    private final void openWheel(View anchor, Layer l) {
        anchor.getLocationOnScreen(new int[2]);
        getRootFrame().getLocationOnScreen(new int[2]);
        openWheelLevel(RadialMenus.INSTANCE.source(this, l.getId()), (r1[0] + (anchor.getWidth() / 2.0f)) - r0[0], (r1[1] + (anchor.getHeight() / 2.0f)) - r0[1]);
    }

    private final void guardRecording(Function0<Unit> f) {
        if (this.exportRunning) {
            UI.INSTANCE.toast(this, "Locked while exporting");
        } else {
            f.invoke();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void duplicateLayer(Layer l) {
        if (l.isLive()) {
            UI.INSTANCE.toast(this, "The live camera can't be duplicated — record a take first");
            return;
        }
        this.selectedId = getCtrl().duplicate(l.getId());
        refreshAll();
        showUndoSnack("Duplicated " + l.getName());
    }

    public final void openAdvancedSheet(@NotNull final Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        if (!sheetReady()) {
            this.selectedId = l.getId();
            refreshContextBar();
            rebuildDock();
            rebuildSourceDock();
            if (this.stage != null) {
                getStage().refresh();
                return;
            }
            return;
        }
        if (this.fullCanvas) {
            setFullCanvas(false);
        }
        setSheet((String) null);
        this.selectedId = l.getId();
        refreshContextBar();
        rebuildDock();
        rebuildSourceDock();
        getStage().refresh();
        getPanelContent().removeAllViews();
        EditorActivity editorActivity = this;
        LinearLayout linearLayout = new LinearLayout(editorActivity);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        linearLayout.setPadding(UI.INSTANCE.dp(editorActivity, 14), UI.INSTANCE.dp(editorActivity, 10), UI.INSTANCE.dp(editorActivity, 10), UI.INSTANCE.dp(editorActivity, 4));
        ImageView imageView = new ImageView(editorActivity);
        imageView.setImageDrawable(Ic.INSTANCE.get(editorActivity, Ic.INSTANCE.typeIcon(l.getType()), UI.INSTANCE.getACCENT2()));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(UI.INSTANCE.dp(editorActivity, 20), UI.INSTANCE.dp(editorActivity, 20));
        layoutParams.setMargins(0, 0, UI.INSTANCE.dp(editorActivity, 10), 0);
        imageView.setLayoutParams(layoutParams);
        linearLayout.addView(imageView);
        TextView textView = new TextView(editorActivity);
        String name = l.getName();
        if (StringsKt.isBlank(name)) {
            name = l.getType().name();
        }
        textView.setText(name);
        textView.setTextColor(-1);
        textView.setTextSize(14.0f);
        textView.setTypeface(Typeface.create("sans-serif-medium", 1));
        linearLayout.addView(textView, new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textViewChip = UI.INSTANCE.chip(editorActivity, "Rename");
        textViewChip.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$CO0zrEuItNF2BUaj7yDSNOa53Yg
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                EditorActivity.openAdvancedSheet$lambda$22(this.f$0, l, view);
            }
        });
        linearLayout.addView(textViewChip);
        getPanelContent().addView(linearLayout);
        section("APPEARANCE");
        if (!l.isText()) {
            LinearLayout panelContent = getPanelContent();
            Pair<String, ? extends Function0<Unit>>[] pairArr = new Pair[2];
            pairArr[0] = TuplesKt.to(Intrinsics.areEqual(l.getFit(), Layer.FIT_FIT) ? "Fit: whole frame" : "Fill: crop to box", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.3
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    EditorActivity.this.getCtrl().toggleFit(l.getId());
                    EditorActivity.this.openAdvancedSheet(l);
                }
            });
            pairArr[1] = TuplesKt.to(l.getVisible() ? "Hide" : "Show", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.4
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    EditorActivity.this.getCtrl().toggleVisible(l.getId());
                    EditorActivity.this.showHideFeedback(l);
                    EditorActivity.this.openAdvancedSheet(l);
                }
            });
            panelButtonRow(panelContent, pairArr);
        } else {
            LinearLayout panelContent2 = getPanelContent();
            Pair<String, ? extends Function0<Unit>>[] pairArr2 = new Pair[2];
            pairArr2[0] = TuplesKt.to(l.getVisible() ? "Hide" : "Show", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.5
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    EditorActivity.this.getCtrl().toggleVisible(l.getId());
                    EditorActivity.this.showHideFeedback(l);
                    EditorActivity.this.openAdvancedSheet(l);
                }
            });
            pairArr2[1] = TuplesKt.to(l.getLocked() ? "Unlock" : "Lock", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.6
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    EditorActivity.this.getCtrl().toggleLocked(l.getId());
                    EditorActivity.this.openAdvancedSheet(l);
                }
            });
            panelButtonRow(panelContent2, pairArr2);
        }
        if (!l.isText()) {
            LinearLayout panelContent3 = getPanelContent();
            Pair<String, ? extends Function0<Unit>>[] pairArr3 = new Pair[1];
            pairArr3[0] = TuplesKt.to(l.getLocked() ? "Unlock" : "Lock", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.7
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    EditorActivity.this.getCtrl().toggleLocked(l.getId());
                    EditorActivity.this.openAdvancedSheet(l);
                }
            });
            panelButtonRow(panelContent3, pairArr3);
        }
        LinearLayout panelContent4 = getPanelContent();
        StringBuilder sb = new StringBuilder();
        sb.append("Opacity  ");
        float f = 100;
        sb.append((int) (l.getOpacity() * f));
        sb.append('%');
        panelContent4.addView(sliderRow(sb.toString(), (int) (l.getOpacity() * f), new Function1<Integer, Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.8
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Integer num) {
                invoke(num.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(int i) {
                EditorActivity.this.pushUndoLight();
                l.setOpacity(i / 100.0f);
                EditorActivity.this.markDirty();
                EditorActivity.this.getStage().refresh();
            }
        }));
        if (l.isClip()) {
            section("PLAYBACK & AUDIO");
            LinearLayout panelContent5 = getPanelContent();
            Pair<String, ? extends Function0<Unit>>[] pairArr4 = new Pair[2];
            pairArr4[0] = TuplesKt.to(l.getPlaying() ? "Pause source" : "Play source", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.9
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    EditorActivity.this.getEngine().toggleLayerPlay(l);
                    EditorActivity.this.markDirty();
                    EditorActivity.this.openAdvancedSheet(l);
                }
            });
            pairArr4[1] = TuplesKt.to(l.getLoop() ? "Loop: on" : "Loop: off", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.10
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    EditorActivity.this.getCtrl().toggleLoop(l.getId());
                    EditorActivity.this.openAdvancedSheet(l);
                }
            });
            panelButtonRow(panelContent5, pairArr4);
            LinearLayout panelContent6 = getPanelContent();
            Pair<String, ? extends Function0<Unit>>[] pairArr5 = new Pair[2];
            pairArr5[0] = TuplesKt.to(l.getMuted() ? "Unmute" : "Mute", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.11
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    EditorActivity.this.getCtrl().toggleMuted(l.getId());
                    EditorActivity.this.openAdvancedSheet(l);
                }
            });
            pairArr5[1] = TuplesKt.to(l.getSolo() ? "Solo: on" : "Solo: off", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.12
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    EditorActivity.this.getCtrl().toggleSolo(l.getId());
                    EditorActivity.this.openAdvancedSheet(l);
                }
            });
            panelButtonRow(panelContent6, pairArr5);
            getPanelContent().addView(sliderRow("Volume  " + ((int) (l.getVolume() * f)) + '%', (int) (l.getVolume() * f), new Function1<Integer, Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.13
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(1);
                }

                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(Integer num) {
                    invoke(num.intValue());
                    return Unit.INSTANCE;
                }

                public final void invoke(int i) {
                    EditorActivity.this.pushUndoLight();
                    EditorActivity.this.getEngine().setVolume(l, i / 100.0f);
                    EditorActivity.this.markDirty();
                }
            }));
            TextView textViewLabel = UI.INSTANCE.label(editorActivity, "Solo = only soloed sources are heard (nothing else is changed or lost).", true, 9.5f);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams2.setMargins(UI.INSTANCE.dp(editorActivity, 16), 0, UI.INSTANCE.dp(editorActivity, 14), UI.INSTANCE.dp(editorActivity, 4));
            textViewLabel.setLayoutParams(layoutParams2);
            getPanelContent().addView(textViewLabel);
        }
        if (l.isText()) {
            section("TEXT");
            panelButtonRow(getPanelContent(), TuplesKt.to("Edit text", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.14
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    EditorActivity.this.editTextLayer(l);
                }
            }), TuplesKt.to("Change color", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.15
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    EditorActivity.this.cycleTextColor(l);
                    EditorActivity.this.openAdvancedSheet(l);
                }
            }));
            getPanelContent().addView(sliderRow("Text size", RangesKt.coerceIn((int) (l.getFontSizeN() * 1000), 10, 300), new Function1<Integer, Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.16
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(1);
                }

                @Override // kotlin.jvm.functions.Function1
                public /* bridge */ /* synthetic */ Unit invoke(Integer num) {
                    invoke(num.intValue());
                    return Unit.INSTANCE;
                }

                public final void invoke(int i) {
                    EditorActivity.this.pushUndoLight();
                    l.setFontSizeN(i / 1000.0f);
                    EditorActivity.this.markDirty();
                    EditorActivity.this.getStage().refresh();
                }
            }));
            LinearLayout panelContent7 = getPanelContent();
            Pair<String, ? extends Function0<Unit>>[] pairArr6 = new Pair[1];
            pairArr6[0] = TuplesKt.to(l.getShadow() ? "Shadow: on" : "Shadow: off", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.17
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    EditorActivity.this.pushUndo();
                    l.setShadow(!r0.getShadow());
                    EditorActivity.this.markDirty();
                    EditorActivity.this.getStage().refresh();
                    EditorActivity.this.openAdvancedSheet(l);
                }
            });
            panelButtonRow(panelContent7, pairArr6);
        }
        section("ARRANGE — z-order (top of the list = front)");
        panelButtonRow(getPanelContent(), TuplesKt.to("Bring forward", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.18
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.getCtrl().moveZ(l.getId(), "up");
                EditorActivity.this.openAdvancedSheet(l);
            }
        }), TuplesKt.to("Send backward", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.19
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.getCtrl().moveZ(l.getId(), "down");
                EditorActivity.this.openAdvancedSheet(l);
            }
        }));
        panelButtonRow(getPanelContent(), TuplesKt.to("To front", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.20
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.getCtrl().moveZ(l.getId(), "front");
                EditorActivity.this.openAdvancedSheet(l);
            }
        }), TuplesKt.to("To back", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.21
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.getCtrl().moveZ(l.getId(), "back");
                EditorActivity.this.openAdvancedSheet(l);
            }
        }));
        panelButtonRow(getPanelContent(), TuplesKt.to("Top-left", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.22
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.getCtrl().anchor(l.getId(), "tl");
            }
        }), TuplesKt.to("Top", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.23
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.getCtrl().anchor(l.getId(), "tc");
            }
        }), TuplesKt.to("Top-right", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.24
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.getCtrl().anchor(l.getId(), "tr");
            }
        }));
        panelButtonRow(getPanelContent(), TuplesKt.to("Bottom-left", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.25
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.getCtrl().anchor(l.getId(), "bl");
            }
        }), TuplesKt.to("Bottom", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.26
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.getCtrl().anchor(l.getId(), "bc");
            }
        }), TuplesKt.to("Bottom-right", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.27
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.getCtrl().anchor(l.getId(), "br");
            }
        }));
        panelButtonRow(getPanelContent(), TuplesKt.to("Center", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.28
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.getCtrl().center(l.getId());
            }
        }), TuplesKt.to("Reset position", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.29
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.getCtrl().resetGeometry(l.getId());
            }
        }));
        if (!l.isText()) {
            panelButtonRow(getPanelContent(), TuplesKt.to("Set as background", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.30
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    EditorActivity.this.getCtrl().setAsCanvasBackground(l.getId());
                }
            }), TuplesKt.to("Duplicate", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.31
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    EditorActivity.this.duplicateLayer(l);
                }
            }));
        } else {
            panelButtonRow(getPanelContent(), TuplesKt.to("Duplicate", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.openAdvancedSheet.32
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    EditorActivity.this.duplicateLayer(l);
                }
            }));
        }
        section("DANGER");
        Button buttonBtn = UI.INSTANCE.btn(editorActivity, "Delete source", false, false);
        buttonBtn.setTextColor(UI.INSTANCE.getDANGER());
        buttonBtn.setContentDescription("Delete " + l.getName());
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, UI.INSTANCE.dp(editorActivity, 44));
        layoutParams3.setMargins(UI.INSTANCE.dp(editorActivity, 12), UI.INSTANCE.dp(editorActivity, 2), UI.INSTANCE.dp(editorActivity, 12), UI.INSTANCE.dp(editorActivity, 14));
        buttonBtn.setLayoutParams(layoutParams3);
        buttonBtn.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$bydmbKbc_ZH1pUc_euQjLsGP98Y
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                EditorActivity.openAdvancedSheet$lambda$23(this.f$0, l, view);
            }
        });
        getPanelContent().addView(buttonBtn);
        getPanelScroll().setVisibility(0);
        getSheet().post(this.insetsSync);
        getPanelContent().setAlpha(0.0f);
        getPanelContent().setTranslationY(UI.INSTANCE.dpf(editorActivity, 26.0f));
        getPanelContent().animate().alpha(1.0f).translationY(0.0f).setDuration(230L).setInterpolator(new OvershootInterpolator(1.2f)).start();
        this.sheetTab = "adv";
        getPanelDivider().setVisibility(0);
        refreshTabBar();
        rebuildSourceDock();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void openAdvancedSheet$lambda$22(EditorActivity this$0, Layer l, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(l, "$l");
        this$0.renameLayer(l);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void openAdvancedSheet$lambda$23(final EditorActivity this$0, final Layer l, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(l, "$l");
        this$0.guardRecording(new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity$openAdvancedSheet$33$1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                String name = l.getName();
                this$0.getCtrl().delete(l.getId());
                this$0.setSelectedId(null);
                this$0.getEngine().evict(l.getId());
                this$0.setSheet((String) null);
                this$0.refreshAll();
                this$0.showUndoSnack("Deleted " + name);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void onTick(long ms) {
        String strStats;
        int max;
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        if (!this.scrubbing && jElapsedRealtime - this.lastUiTickMs >= 50) {
            this.lastUiTickMs = jElapsedRealtime;
            if (this.timeLabel != null) {
                getTimeLabel().setText(UI.INSTANCE.fmtTime(ms));
            }
            if (this.seek != null && (max = getSeek().getMax()) > 0) {
                getSeek().setProgress(RangesKt.coerceAtMost((int) ms, max));
            }
        }
        if (this.statsHud != null && jElapsedRealtime - this.lastHudMs >= 500) {
            this.lastHudMs = jElapsedRealtime;
            boolean z = true;
            if (this.fullCanvas || !editorPrefs().getBoolean(PREF_STATS_HUD, true) || (!getEngine().anyPlaying() && !this.recording)) {
                z = false;
            }
            if (z) {
                CompositionRecorder compositionRecorder = this.recorder;
                TextView statsHud = getStatsHud();
                if (!this.recording || compositionRecorder == null) {
                    strStats = getEngine().stats();
                } else {
                    strStats = getEngine().stats() + '\n' + compositionRecorder.stats();
                }
                statsHud.setText(strStats);
                getStatsHud().setVisibility(0);
            } else if (getStatsHud().getVisibility() != 8) {
                getStatsHud().setVisibility(8);
            }
        }
        String strPlayingSignature = playingSignature();
        if (!Intrinsics.areEqual(strPlayingSignature, this.lastPlayingSig)) {
            this.lastPlayingSig = strPlayingSignature;
            boolean zAnyPlaying = getEngine().anyPlaying();
            if (this.playBtn != null) {
                getPlayBtn().setIcon(zAnyPlaying ? R.drawable.ic_pause : R.drawable.ic_play, -1, zAnyPlaying ? "Pause" : "Play");
            }
            refreshAll();
        }
        if (engineReady() && getEngine().consumeNewFrames() && this.stage != null) {
            getStage().refresh();
        }
    }

    private final String playingSignature() {
        StringBuilder sb = new StringBuilder();
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        for (Layer layer : project.getLayers()) {
            if (layer.isClip()) {
                sb.append(layer.getPlaying() ? '1' : '0');
            }
        }
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        return string;
    }

    private final void syncPreviewTarget() {
        if (this.stage == null || !engineReady()) {
            return;
        }
        getEngine().setTargetMaxPx(RangesKt.coerceIn(Math.max(getStage().getCanvasW(), getStage().getCanvasH()), 480, 960));
        getEngine().setLayerTargetPx(new Function1<Layer, Integer>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.syncPreviewTarget.1
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            @NotNull
            public final Integer invoke(@NotNull Layer l) {
                Intrinsics.checkNotNullParameter(l, "l");
                return Integer.valueOf(RangesKt.coerceIn((int) (EditorActivity.this.getStage().visibleFrameMaxPx(l) * 1.25f), 240, 1440));
            }
        });
    }

    public final void togglePlay() {
        if (getEngine().anyPlaying()) {
            getEngine().pauseAll();
            getEngine().stopSnapshots();
        } else {
            getEngine().playAll();
            getEngine().startSnapshots();
        }
        refreshAll();
        onTick(getEngine().getMasterMs());
    }

    @Override // com.rehman.ahmedreactionstudio.editor.StageView.Host, com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    @NotNull
    public Project getProject() {
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        return project;
    }

    @Override // com.rehman.ahmedreactionstudio.editor.StageView.Host
    @Nullable
    public String selectedId() {
        return this.selectedId;
    }

    @Override // com.rehman.ahmedreactionstudio.editor.StageView.Host
    public void select(@Nullable String id) {
        this.selectedId = id;
        refreshContextBar();
        rebuildDock();
        rebuildSourceDock();
        getStage().refresh();
        bindSidePanels();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.StageView.Host
    @Nullable
    public Bitmap bitmapOf(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        return getEngine().frameOf(l);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.StageView.Host
    @NotNull
    public String textOf(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        return l.getText();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.StageView.Host
    public void onTransform() {
        markDirty();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.StageView.Host
    public void onTapEmpty() {
        select(null);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.StageView.Host
    public void onChanged() {
        pushUndo();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.StageView.Host
    public void onDoubleTap(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        if (l.isText()) {
            editTextLayer(l);
        }
    }

    @Override // com.rehman.ahmedreactionstudio.editor.StageView.Host
    public void onLockedTap(@NotNull final Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        showSnack(l.getName() + " is locked — gestures are off", "UNLOCK", new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.onLockedTap.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.getCtrl().toggleLocked(l.getId());
            }
        });
    }

    @Override // com.rehman.ahmedreactionstudio.editor.StageView.Host
    public void onLongPressCanvas(@Nullable Layer l, float x, float y) {
        getStage().getLocationOnScreen(new int[2]);
        getRootFrame().getLocationOnScreen(new int[2]);
        float f = (x + r1[0]) - r0[0];
        float f2 = (y + r1[1]) - r0[1];
        if (l != null) {
            select(l.getId());
            openWheelLevel(RadialMenus.INSTANCE.source(this, l.getId()), f, f2);
        } else {
            openWheelLevel(RadialMenus.INSTANCE.root(this), f, f2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void onSourceChanged() {
        reconcileLiveCamera();
        getStage().refresh();
        refreshAll();
        markDirty();
        getEngine().refreshFrames();
    }

    private final void reconcileLiveCamera() {
        Object next;
        Project project = this.proj;
        if (project == null) {
            return;
        }
        Iterator<T> it = project.getLayers().iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            } else {
                next = it.next();
                if (((Layer) next).isLive()) {
                    break;
                }
            }
        }
        Layer layer = (Layer) next;
        if (layer == null) {
            if (this.liveCam == null && this.liveCamLayerId == null) {
                return;
            }
            stopLiveCamera(true);
            this.liveCamLayerId = null;
            return;
        }
        if (!Intrinsics.areEqual(this.liveCamLayerId, layer.getId())) {
            stopLiveCamera(true);
            this.liveCamLayerId = layer.getId();
        }
        if (this.liveCam == null && !isFinishing() && checkSelfPermission("android.permission.CAMERA") == 0) {
            startLiveCamera();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void refreshAll() {
        refreshContextBar();
        rebuildDock();
        rebuildSourceDock();
        updateEmptyState(new Object[0]);
        updateName();
        updateRecordButton();
        updateHiddenPill(new Object[0]);
        refreshTabBar();
        bindSidePanels();
    }

    /* JADX WARN: Removed duplicated region for block: B:25:0x004b  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x004d  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x0082  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x00a8  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void bindSidePanels() {
        /*
            Method dump skipped, instruction units count: 225
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.editor.EditorActivity.bindSidePanels():void");
    }

    public final void removeSelectedSource() {
        Layer layerLayerById;
        String str = this.selectedId;
        if (str == null) {
            UI.INSTANCE.toast(this, "Select a source first");
            return;
        }
        Project project = this.proj;
        if (project == null || (layerLayerById = project.layerById(str)) == null) {
            return;
        }
        if (layerLayerById.isLive()) {
            removeLiveCameraLayer();
            return;
        }
        if (engineReady()) {
            getEngine().evict(str);
        }
        this.selectedId = null;
        getCtrl().delete(str);
    }

    public final void controlsStopTap() {
        if (this.recording) {
            stopCompositeRecording$default(this, false, 1, null);
            return;
        }
        if (engineReady() && getEngine().anyPlaying()) {
            getEngine().pauseAll();
            getEngine().stopSnapshots();
            refreshAll();
            return;
        }
        UI.INSTANCE.toast(this, "Nothing is playing");
    }

    public final void controlsFlashTap() {
        LiveCamera liveCamera;
        List<Layer> layers;
        Project project = this.proj;
        Layer layer = null;
        Object obj = null;
        layer = null;
        if (project != null && (layers = project.getLayers()) != null) {
            Iterator<T> it = layers.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (((Layer) next).isLive()) {
                    obj = next;
                    break;
                }
            }
            layer = (Layer) obj;
        }
        if (layer != null && (liveCamera = this.liveCam) != null) {
            Intrinsics.checkNotNull(liveCamera);
            if (liveCamera.getHasFlashUnit()) {
                toggleTorch(layer);
                return;
            }
        }
        toggleScreenLight();
    }

    public final void markDirty() {
        this.saveDirty = true;
        updateName();
        this.saveHandler.removeCallbacks(this.autosave);
        this.saveHandler.postDelayed(this.autosave, 600L);
    }

    private final void flushSave() {
        Project project = this.proj;
        if (project == null) {
            return;
        }
        project.setUpdatedAt(System.currentTimeMillis());
        ProjectStore projectStore = this.store;
        if (projectStore == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore = null;
        }
        projectStore.save(project, true);
        this.saveDirty = false;
        try {
            updateName();
        } catch (Exception unused) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void pushUndo() {
        UndoStack undoStack = this.undo;
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        UndoStack.pushSnapshot$default(undoStack, UndoKt.layersJsonOf(project), false, 2, null);
    }

    public final void pushUndoLight() {
        if (System.currentTimeMillis() - this.lastUndoPush > 350) {
            pushUndo();
        }
        this.lastUndoPush = System.currentTimeMillis();
    }

    public final void doUndo() {
        JSONObject jSONObjectPopUndo = this.undo.popUndo(new Function0<JSONObject>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity$doUndo$snap$1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final JSONObject invoke() {
                Project proj = this.this$0.getProj();
                Intrinsics.checkNotNull(proj);
                return UndoKt.layersJsonOf(proj);
            }
        });
        if (jSONObjectPopUndo == null) {
            return;
        }
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        UndoKt.applyLayersJson(project, jSONObjectPopUndo);
        this.selectedId = null;
        afterStructureChange();
    }

    public final void doRedo() {
        JSONObject jSONObjectPopRedo = this.undo.popRedo(new Function0<JSONObject>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity$doRedo$snap$1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final JSONObject invoke() {
                Project proj = this.this$0.getProj();
                Intrinsics.checkNotNull(proj);
                return UndoKt.layersJsonOf(proj);
            }
        });
        if (jSONObjectPopRedo == null) {
            return;
        }
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        UndoKt.applyLayersJson(project, jSONObjectPopRedo);
        this.selectedId = null;
        afterStructureChange();
    }

    private final void afterStructureChange() {
        if (engineReady()) {
            getEngine().attach(this.projectId);
        }
        reconcileLiveCamera();
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        applyOrientationFor(project.getAspect());
        if (this.aspectChip != null) {
            updateAspectChip();
        }
        if (this.stage != null) {
            getStage().post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$Fj0Gg0blur82DRpjGWZ_o9J7fpo
                @Override // java.lang.Runnable
                public final void run() {
                    EditorActivity.afterStructureChange$lambda$29(this.f$0);
                }
            });
        }
        refreshAll();
        Project project2 = this.proj;
        Intrinsics.checkNotNull(project2);
        int iCoerceAtLeast = RangesKt.coerceAtLeast((int) project2.durationMs(), 1);
        if (transportReady()) {
            getSeek().setMax(iCoerceAtLeast);
            getDurationLabel().setText("/ " + UI.INSTANCE.fmtTime(iCoerceAtLeast));
        }
        if (this.stage != null) {
            getStage().refresh();
        }
        if (engineReady()) {
            getEngine().refreshFrames();
            if (getEngine().anyPlaying()) {
                getEngine().startSnapshots();
            }
        }
        markDirty();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void afterStructureChange$lambda$29(EditorActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.syncPreviewTarget();
    }

    public final void mutateThen(@NotNull Function0<Unit> f) {
        Intrinsics.checkNotNullParameter(f, "f");
        pushUndo();
        f.invoke();
        afterStructureChange();
    }

    public final void openAddSourceChooser() {
        new AlertDialog.Builder(this).setTitle("Add source").setItems(new String[]{"Camera — Back", "Camera — Front", "Video from device", "Photo from device", "Screen recording (whole screen)", "Text overlay"}, new DialogInterface.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$dbB9bcIpVWUQjh_FvePMvs9W4us
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                EditorActivity.openAddSourceChooser$lambda$30(this.f$0, dialogInterface, i);
            }
        }).setNegativeButton("Cancel", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void openAddSourceChooser$lambda$30(EditorActivity this$0, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (i == 0) {
            this$0.addLiveCamera(false);
            return;
        }
        if (i == 1) {
            this$0.addLiveCamera(true);
            return;
        }
        if (i == 2) {
            this$0.pickMedia(true);
            return;
        }
        if (i == 3) {
            this$0.pickMedia(false);
        } else if (i == 4) {
            this$0.addScreen();
        } else {
            if (i != 5) {
                return;
            }
            this$0.addTextSource();
        }
    }

    public final void pickMedia(boolean video) {
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        this.pendingRole = project.getLayers().isEmpty() ? "main" : "pip";
        Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT");
        intent.addCategory("android.intent.category.OPENABLE");
        if (video) {
            intent.setType("video/*");
            intent.putExtra("android.intent.extra.MIME_TYPES", new String[]{"video/*", "video/mp4", "video/avi", "video/x-msvideo", "video/webm", "video/x-matroska", "video/3gpp", "video/quicktime", "application/x-matroska", "application/avi"});
        } else {
            intent.setType("image/*");
        }
        try {
            startActivityForResult(Intent.createChooser(intent, video ? "Choose video (MP4 / AVI / WebM / MKV)" : "Choose image"), video ? 41 : 42);
        } catch (Exception unused) {
            UI.INSTANCE.toast(this, "No file picker available");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void openCamera() {
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        this.pendingCameraRole = project.getLayers().isEmpty() ? "main" : "pip";
        Intent intent = new Intent(this, (Class<?>) CameraActivity.class);
        intent.putExtra("pid", this.projectId);
        intent.putExtra(CameraActivity.EXTRA_ROLE, this.pendingCameraRole);
        startActivityForResult(intent, 43);
    }

    private final void startScreenCapture() {
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        this.pendingRole = project.getLayers().isEmpty() ? "main" : "pip";
        ArrayList arrayList = new ArrayList();
        if (checkSelfPermission("android.permission.RECORD_AUDIO") != 0) {
            arrayList.add("android.permission.RECORD_AUDIO");
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0) {
            arrayList.add("android.permission.POST_NOTIFICATIONS");
        }
        ArrayList arrayList2 = arrayList;
        if (!arrayList2.isEmpty()) {
            requestPermissions((String[]) arrayList2.toArray(new String[0]), 45);
        } else {
            launchProjection();
        }
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int code, @NotNull String[] perms, @NotNull int[] res) {
        Intrinsics.checkNotNullParameter(perms, "perms");
        Intrinsics.checkNotNullParameter(res, "res");
        super.onRequestPermissionsResult(code, perms, res);
        if (isFinishing() || isDestroyed()) {
            return;
        }
        if (code == 45) {
            launchProjection();
        }
        if (code == 46) {
            if (checkSelfPermission("android.permission.CAMERA") == 0) {
                addLiveCamera$default(this, false, 1, null);
            } else {
                UI.INSTANCE.toast(this, "Camera permission is needed to put the camera on the canvas");
            }
        }
        if (code == 47) {
            if (checkSelfPermission("android.permission.RECORD_AUDIO") == 0) {
                startCompositeRecording();
            } else {
                UI.INSTANCE.toast(this, "Mic permission denied — recording will mix the clip audio only");
            }
        }
    }

    private final void launchProjection() {
        if (ScreenCaptureService.INSTANCE.getRunning()) {
            UI.INSTANCE.toast(this, "Screen recording already running");
            return;
        }
        Object systemService = getSystemService("media_projection");
        MediaProjectionManager mediaProjectionManager = systemService instanceof MediaProjectionManager ? (MediaProjectionManager) systemService : null;
        if (mediaProjectionManager == null) {
            UI.INSTANCE.toast(this, "Screen capture not supported on this device");
            return;
        }
        try {
            startActivityForResult(mediaProjectionManager.createScreenCaptureIntent(), 44);
        } catch (Exception e) {
            UI.INSTANCE.toast(this, "Screen capture unavailable: " + e.getMessage());
        }
    }

    @Override // android.app.Activity
    protected void onActivityResult(int req, int res, @Nullable Intent data) {
        super.onActivityResult(req, res, data);
        ProjectStore projectStore = null;
        switch (req) {
            case REQ_PICK_VIDEO /* 41 */:
            case REQ_PICK_IMAGE /* 42 */:
                if (res == -1) {
                    Uri data2 = data != null ? data.getData() : null;
                    if (data2 != null) {
                        importFromUri(data2, req == 41);
                        break;
                    }
                }
                break;
            case REQ_CAMERA /* 43 */:
                if (res == -1) {
                    String stringExtra = data != null ? data.getStringExtra(CameraActivity.EXTRA_RESULT_REL) : null;
                    if (stringExtra != null) {
                        String stringExtra2 = data.getStringExtra(CameraActivity.EXTRA_ROLE);
                        if (stringExtra2 == null) {
                            stringExtra2 = this.pendingCameraRole;
                        }
                        ProjectStore projectStore2 = this.store;
                        if (projectStore2 == null) {
                            Intrinsics.throwUninitializedPropertyAccessException("store");
                        } else {
                            projectStore = projectStore2;
                        }
                        File file = new File(projectStore.projectDir(this.projectId), stringExtra);
                        if (!file.exists()) {
                            UI.INSTANCE.toast(this, "Camera take missing");
                        } else {
                            consumeMediaFile(file, stringExtra2, "Camera take", LayerType.CAMERA);
                        }
                        break;
                    }
                }
                break;
            case REQ_SCREEN_CAPTURE /* 44 */:
                if (res != -1 || data == null) {
                    UI.INSTANCE.toast(this, "Screen recording permission denied");
                } else {
                    beginScreenService(res, data);
                }
                break;
        }
    }

    private final void beginScreenService(int resultCode, Intent data) {
        EditorActivity editorActivity = this;
        Intent intent = new Intent(editorActivity, (Class<?>) ScreenCaptureService.class);
        intent.setAction(ScreenCaptureService.ACTION_START);
        intent.putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode);
        intent.putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data);
        ProjectStore projectStore = this.store;
        if (projectStore == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore = null;
        }
        intent.putExtra(ScreenCaptureService.EXTRA_PROJECT_DIR, projectStore.projectDir(this.projectId).getAbsolutePath());
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
            getRecChip().setVisibility(this.fullCanvas ? 8 : 0);
            setSheet((String) null);
            UI.INSTANCE.toast(this, "Recording screen — tap the top chip to stop");
        } catch (Exception e) {
            UI.INSTANCE.toast(editorActivity, "Could not start screen recording: " + e.getMessage());
        }
    }

    private final void stopScreenCapture() {
        Intent intent = new Intent(this, (Class<?>) ScreenCaptureService.class);
        intent.setAction(ScreenCaptureService.ACTION_STOP);
        try {
            startService(intent);
        } catch (Exception unused) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final void importFromUri(final Uri uri, final boolean isVideo) {
        int columnIndex;
        T t;
        final Ref.ObjectRef objectRef = new Ref.ObjectRef();
        objectRef.element = "imported";
        try {
            Cursor cursorQuery = getContentResolver().query(uri, null, null, null, null);
            if (cursorQuery != null) {
                Cursor cursor = cursorQuery;
                try {
                    Cursor cursor2 = cursor;
                    if (cursor2.moveToFirst() && (columnIndex = cursor2.getColumnIndex("_display_name")) >= 0) {
                        String string = cursor2.getString(columnIndex);
                        if (string == null) {
                            t = (String) objectRef.element;
                        } else {
                            Intrinsics.checkNotNull(string);
                            t = string;
                        }
                        objectRef.element = t;
                    }
                    Unit unit = Unit.INSTANCE;
                    CloseableKt.closeFinally(cursor, null);
                } finally {
                }
            }
        } catch (Exception unused) {
        }
        String strReplace = new Regex("[^A-Za-z0-9._-]").replace((CharSequence) objectRef.element, "_");
        final File file = new File(getCacheDir(), "import_" + System.currentTimeMillis() + '_' + strReplace);
        StringBuilder sb = new StringBuilder();
        sb.append("Copying ");
        sb.append((String) objectRef.element);
        sb.append(Typography.ellipsis);
        showProgress$default(this, "Importing media", sb.toString(), false, null, 8, null);
        new Thread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$1zUA4mje0Nkp9ns2sUZgrTrLQHE
            @Override // java.lang.Runnable
            public final void run() {
                EditorActivity.importFromUri$lambda$35(this.f$0, uri, file, isVideo, objectRef);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void importFromUri$lambda$35(final EditorActivity this$0, Uri uri, final File tmp, final boolean z, final Ref.ObjectRef displayName) {
        MediaInfo mediaInfoProbe;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(uri, "$uri");
        Intrinsics.checkNotNullParameter(tmp, "$tmp");
        Intrinsics.checkNotNullParameter(displayName, "$displayName");
        final boolean zCopyContentToFile = MediaKit.INSTANCE.copyContentToFile(this$0, uri, tmp);
        if (zCopyContentToFile) {
            MediaKit mediaKit = MediaKit.INSTANCE;
            String absolutePath = tmp.getAbsolutePath();
            Intrinsics.checkNotNullExpressionValue(absolutePath, "getAbsolutePath(...)");
            mediaInfoProbe = mediaKit.probe(absolutePath);
        } else {
            mediaInfoProbe = null;
        }
        final MediaInfo mediaInfo = mediaInfoProbe;
        this$0.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$rXhhaavU_FwMXnQ-8UQZHLXGSfI
            @Override // java.lang.Runnable
            public final void run() {
                EditorActivity.importFromUri$lambda$35$lambda$34(this.f$0, zCopyContentToFile, mediaInfo, z, tmp, displayName);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public static final void importFromUri$lambda$35$lambda$34(EditorActivity this$0, boolean z, MediaInfo mediaInfo, boolean z2, File tmp, Ref.ObjectRef displayName) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(tmp, "$tmp");
        Intrinsics.checkNotNullParameter(displayName, "$displayName");
        this$0.dismissProgress();
        if (!z || mediaInfo == null) {
            UI.INSTANCE.toast(this$0, "Import failed or file unreadable");
            return;
        }
        if (z2 && mediaInfo.getWidth() == 0 && mediaInfo.getDurMs() == 0) {
            UI.INSTANCE.toast(this$0, "This video format can't be decoded on this device");
            tmp.delete();
        } else {
            this$0.consumeMediaFile(tmp, this$0.pendingRole, (String) displayName.element, z2 ? LayerType.VIDEO : LayerType.IMAGE);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void consumeMediaFile(final File src, final String role, final String name, final LayerType type) {
        final String str = this.projectId;
        ProjectStore projectStore = this.store;
        if (projectStore == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore = null;
        }
        String absolutePath = projectStore.mediaDir(str).getAbsolutePath();
        File parentFile = src.getParentFile();
        final boolean zAreEqual = Intrinsics.areEqual(parentFile != null ? parentFile.getAbsolutePath() : null, absolutePath);
        new Thread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$9IxKx9GzZv8YV1954p7p0e7xzt0
            @Override // java.lang.Runnable
            public final void run() {
                EditorActivity.consumeMediaFile$lambda$37(src, type, zAreEqual, this, str, name, role);
            }
        }, "add-source").start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v11, types: [T, com.rehman.ahmedreactionstudio.core.MediaInfo] */
    /* JADX WARN: Type inference failed for: r0v6, types: [T, com.rehman.ahmedreactionstudio.core.MediaInfo] */
    /* JADX WARN: Type inference failed for: r2v11, types: [T, com.rehman.ahmedreactionstudio.core.MediaInfo] */
    public static final void consumeMediaFile$lambda$37(final File src, final LayerType type, final boolean z, final EditorActivity this$0, final String pid, final String name, final String role) {
        final String str;
        String strCopyIntoMedia;
        Intrinsics.checkNotNullParameter(src, "$src");
        Intrinsics.checkNotNullParameter(type, "$type");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(pid, "$pid");
        Intrinsics.checkNotNullParameter(name, "$name");
        Intrinsics.checkNotNullParameter(role, "$role");
        final Ref.ObjectRef objectRef = new Ref.ObjectRef();
        objectRef.element = new MediaInfo(0L, 0, 0, 0, null);
        final Ref.ObjectRef objectRef2 = new Ref.ObjectRef();
        try {
            MediaKit mediaKit = MediaKit.INSTANCE;
            String absolutePath = src.getAbsolutePath();
            Intrinsics.checkNotNullExpressionValue(absolutePath, "getAbsolutePath(...)");
            objectRef.element = mediaKit.probe(absolutePath);
            if (type == LayerType.IMAGE && (((MediaInfo) objectRef.element).getWidth() <= 0 || ((MediaInfo) objectRef.element).getHeight() <= 0)) {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(src.getAbsolutePath(), options);
                if (options.outWidth > 0 && options.outHeight > 0) {
                    objectRef.element = new MediaInfo(0L, options.outWidth, options.outHeight, 0, null);
                }
            }
            if (z) {
                strCopyIntoMedia = "media/" + src.getName();
            } else {
                ProjectStore projectStore = this$0.store;
                if (projectStore == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("store");
                    projectStore = null;
                }
                strCopyIntoMedia = projectStore.copyIntoMedia(pid, src);
            }
            str = strCopyIntoMedia;
        } catch (Exception e) {
            String message = e.getMessage();
            T simpleName = message;
            if (message == null) {
                simpleName = e.getClass().getSimpleName();
            }
            objectRef2.element = simpleName;
            str = null;
        }
        this$0.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$bEiNdfl7DKMGMQU9QzOeC-1LZho
            @Override // java.lang.Runnable
            public final void run() {
                EditorActivity.consumeMediaFile$lambda$37$lambda$36(this.f$0, pid, str, name, objectRef2, z, src, role, type, objectRef);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public static final void consumeMediaFile$lambda$37$lambda$36(final EditorActivity this$0, String pid, final String str, final String name, Ref.ObjectRef err, boolean z, File src, final String role, final LayerType type, final Ref.ObjectRef info) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(pid, "$pid");
        Intrinsics.checkNotNullParameter(name, "$name");
        Intrinsics.checkNotNullParameter(err, "$err");
        Intrinsics.checkNotNullParameter(src, "$src");
        Intrinsics.checkNotNullParameter(role, "$role");
        Intrinsics.checkNotNullParameter(type, "$type");
        Intrinsics.checkNotNullParameter(info, "$info");
        if (this$0.isFinishing() || this$0.isDestroyed() || !Intrinsics.areEqual(this$0.projectId, pid)) {
            return;
        }
        if (str == null) {
            StringBuilder sb = new StringBuilder();
            sb.append("Could not add \"");
            sb.append(name);
            sb.append("\": ");
            String str2 = (String) err.element;
            if (str2 == null) {
                str2 = "unreadable file";
            }
            sb.append(str2);
            showSnack$default(this$0, sb.toString(), null, null, 6, null);
            return;
        }
        this$0.mutateThen(new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity$consumeMediaFile$1$1$1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                Layer layer;
                Project proj = this.this$0.getProj();
                Intrinsics.checkNotNull(proj);
                if (type == LayerType.IMAGE) {
                    layer = new Layer(null, type, name, str, 0L, info.element.getWidth(), info.element.getHeight(), 0, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, false, false, false, false, false, null, 0.0f, 0.0f, false, 0L, 0.0f, false, 0, false, null, 0, 0.0f, false, 0L, -111, null);
                } else {
                    layer = new Layer(null, type, name, str, info.element.getDurMs(), info.element.getWidth(), info.element.getHeight(), info.element.getRotation(), 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, false, false, false, false, false, null, 0.0f, 0.0f, false, 0L, 0.0f, false, 0, false, null, 0, 0.0f, false, 0L, -2097407, null);
                }
                proj.getLayers().add(layer);
                if (Intrinsics.areEqual(role, "main") || proj.getLayers().size() == 1) {
                    this.this$0.placeMain(layer, proj);
                } else {
                    this.this$0.placePip(layer, proj);
                }
                this.this$0.setSelectedId(layer.getId());
            }
        });
        if (!z) {
            try {
                src.delete();
            } catch (Exception unused) {
            }
        }
        this$0.finishAddSource(src, role, name, type);
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x0023  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void finishAddSource(java.io.File r7, java.lang.String r8, java.lang.String r9, com.rehman.ahmedreactionstudio.core.LayerType r10) {
        /*
            r6 = this;
            r7 = 0
            r6.setSheet(r7)
            java.lang.String r7 = "main"
            boolean r7 = kotlin.jvm.internal.Intrinsics.areEqual(r8, r7)
            r8 = 0
            r0 = 1
            if (r7 != 0) goto L23
            com.rehman.ahmedreactionstudio.core.Project r7 = r6.proj
            if (r7 == 0) goto L20
            java.util.List r7 = r7.getLayers()
            if (r7 == 0) goto L20
            int r7 = r7.size()
            if (r7 != r0) goto L20
            r7 = r0
            goto L21
        L20:
            r7 = r8
        L21:
            if (r7 == 0) goto L24
        L23:
            r8 = r0
        L24:
            r7 = 34
            if (r8 == 0) goto L3d
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            r8.append(r7)
            r8.append(r9)
            java.lang.String r7 = "\" fills the canvas — later additions become layers."
            r8.append(r7)
            java.lang.String r7 = r8.toString()
            goto L51
        L3d:
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            r8.append(r7)
            r8.append(r9)
            java.lang.String r7 = "\" added as a layer. Drag, resize, or tap Layers to reorder."
            r8.append(r7)
            java.lang.String r7 = r8.toString()
        L51:
            r1 = r7
            r2 = 0
            r3 = 0
            r4 = 6
            r5 = 0
            r0 = r6
            showSnack$default(r0, r1, r2, r3, r4, r5)
            com.rehman.ahmedreactionstudio.core.LayerType r7 = com.rehman.ahmedreactionstudio.core.LayerType.IMAGE
            if (r10 == r7) goto L72
            boolean r7 = r6.engineReady()
            if (r7 == 0) goto L72
            com.rehman.ahmedreactionstudio.editor.PreviewEngine r7 = r6.getEngine()
            r7.startSnapshots()
            com.rehman.ahmedreactionstudio.editor.PreviewEngine r7 = r6.getEngine()
            r7.refreshFrames()
        L72:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.editor.EditorActivity.finishAddSource(java.io.File, java.lang.String, java.lang.String, com.rehman.ahmedreactionstudio.core.LayerType):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void placeMain(Layer l, Project p) {
        LayerFit.INSTANCE.fill(l);
        l.setFit(l.getType() == LayerType.CAMERA ? Layer.FIT_FIT : Layer.FIT_FILL);
        p.getLayers().remove(l);
        p.getLayers().add(0, l);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void placePip(Layer l, Project p) {
        if (l.getType() == LayerType.TEXT) {
            l.setWN(0.86f);
            l.setHN(0.28f);
            l.setCx(0.5f);
            l.setCy(0.5f);
            return;
        }
        l.setFit(Layer.FIT_FIT);
        LayerFit.INSTANCE.placeNewPip(l, p.getLayers(), p.getAspect().getCanvasW(), p.getAspect().getCanvasH());
    }

    public final void addText() {
        EditorActivity editorActivity = this;
        final EditText editText = new EditText(editorActivity);
        editText.setHint("Text");
        editText.setTextColor(UI.INSTANCE.getFG());
        editText.setHintTextColor(Color.argb(150, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
        new AlertDialog.Builder(editorActivity).setTitle("Add text source").setView(editText).setPositiveButton("Add", new DialogInterface.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$qjEmMAUedm0rUmWNikZFAQ-zB5s
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                EditorActivity.addText$lambda$38(editText, this, dialogInterface, i);
            }
        }).setNegativeButton("Cancel", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void addText$lambda$38(EditText input, final EditorActivity this$0, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(input, "$input");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        final String string = input.getText().toString();
        this$0.mutateThen(new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity$addText$1$1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                Layer layer = new Layer(null, LayerType.TEXT, "Text", null, 0L, 0, 0, 0, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, false, false, false, false, false, null, 0.0f, 0.0f, false, 0L, 0.0f, false, 0, false, null, 0, 0.0f, false, 0L, -7, null);
                layer.setText(StringsKt.isBlank(string) ? "Ahmed Studio" : string);
                layer.setWN(0.86f);
                layer.setHN(0.28f);
                layer.setCx(0.5f);
                layer.setCy(0.5f);
                Project proj = this$0.getProj();
                Intrinsics.checkNotNull(proj);
                proj.getLayers().add(layer);
                this$0.setSelectedId(layer.getId());
            }
        });
        this$0.setSheet((String) null);
    }

    @NotNull
    public final LinearLayout sliderRow(@NotNull String label, int value, @NotNull final Function1<? super Integer, Unit> on) {
        Intrinsics.checkNotNullParameter(label, "label");
        Intrinsics.checkNotNullParameter(on, "on");
        EditorActivity editorActivity = this;
        LinearLayout linearLayout = new LinearLayout(editorActivity);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        linearLayout.setPadding(UI.INSTANCE.dp(editorActivity, 14), UI.INSTANCE.dp(editorActivity, 2), UI.INSTANCE.dp(editorActivity, 14), UI.INSTANCE.dp(editorActivity, 2));
        TextView textViewLabel = UI.INSTANCE.label(editorActivity, label, true, 12.0f);
        linearLayout.addView(textViewLabel);
        UI.INSTANCE.margin(textViewLabel, 0, 0, 8, 0, editorActivity);
        SeekBar seekBar = new SeekBar(editorActivity);
        seekBar.setMax(100);
        seekBar.setProgress(value);
        seekBar.setProgressTintList(ColorStateList.valueOf(UI.INSTANCE.getACCENT()));
        seekBar.setThumbTintList(ColorStateList.valueOf(UI.INSTANCE.getACCENT2()));
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.sliderRow.1
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(@Nullable SeekBar s) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(@Nullable SeekBar s) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(@Nullable SeekBar s, int v, boolean u) {
                if (u) {
                    on.invoke(Integer.valueOf(v));
                }
            }
        });
        linearLayout.addView(seekBar);
        return linearLayout;
    }

    private final void renameLayer(final Layer l) {
        EditorActivity editorActivity = this;
        final EditText editText = new EditText(editorActivity);
        editText.setText(l.getName());
        editText.setTextColor(UI.INSTANCE.getFG());
        editText.setHintTextColor(Color.argb(150, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
        new AlertDialog.Builder(editorActivity).setTitle("Rename source").setView(editText).setPositiveButton("OK", new DialogInterface.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$HVW6STxmgmoSruaqTXx1WE-EbDM
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                EditorActivity.renameLayer$lambda$39(this.f$0, l, editText, dialogInterface, i);
            }
        }).setNegativeButton("Cancel", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void renameLayer$lambda$39(EditorActivity this$0, Layer l, EditText input, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(l, "$l");
        Intrinsics.checkNotNullParameter(input, "$input");
        this$0.getCtrl().setName(l.getId(), input.getText().toString());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void editTextLayer(final Layer l) {
        EditorActivity editorActivity = this;
        final EditText editText = new EditText(editorActivity);
        editText.setText(l.getText());
        editText.setTextColor(UI.INSTANCE.getFG());
        editText.setHintTextColor(Color.argb(150, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
        new AlertDialog.Builder(editorActivity).setTitle("Text").setView(editText).setPositiveButton("OK", new DialogInterface.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$VUyqadrX0dIwIpSOY6zegoe12uY
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                EditorActivity.editTextLayer$lambda$40(this.f$0, l, editText, dialogInterface, i);
            }
        }).setNegativeButton("Cancel", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void editTextLayer$lambda$40(EditorActivity this$0, Layer l, EditText input, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(l, "$l");
        Intrinsics.checkNotNullParameter(input, "$input");
        this$0.pushUndo();
        l.setText(input.getText().toString());
        this$0.markDirty();
        this$0.getStage().refresh();
    }

    private final int nextColor(int c) {
        List listListOf = CollectionsKt.listOf((Object[]) new Integer[]{-1, -44462, -16121, -9834322, -12532481, -16777216});
        return ((Number) listListOf.get((listListOf.indexOf(Integer.valueOf(c)) + 1) % listListOf.size())).intValue();
    }

    private final void updateName() {
        List<Layer> layers;
        View decorView = getWindow().getDecorView();
        Intrinsics.checkNotNull(decorView, "null cannot be cast to non-null type android.view.ViewGroup");
        ViewGroup viewGroup = (ViewGroup) decorView;
        TextView textView = (TextView) findTagged(viewGroup, "name");
        TextView textView2 = (TextView) findTagged(viewGroup, "meta");
        if (textView != null) {
            Project project = this.proj;
            textView.setText(project != null ? project.getName() : null);
        }
        Project project2 = this.proj;
        int size = (project2 == null || (layers = project2.getLayers()) == null) ? 0 : layers.size();
        String str = this.saveDirty ? "● Saving…" : "✓ Saved";
        if (textView2 == null) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        Project project3 = this.proj;
        Intrinsics.checkNotNull(project3);
        sb.append(project3.getAspect().getCode());
        sb.append(" canvas · ");
        sb.append(size);
        sb.append(" source");
        sb.append(size == 1 ? "" : "s");
        sb.append(" · ");
        sb.append(str);
        textView2.setText(sb.toString());
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final <T extends View> T findTagged(View root, String tag) {
        if (Intrinsics.areEqual(root.getTag(), tag)) {
            if (root instanceof View) {
                return root;
            }
            return null;
        }
        if (root instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) root;
            int childCount = viewGroup.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = viewGroup.getChildAt(i);
                Intrinsics.checkNotNullExpressionValue(childAt, "getChildAt(...)");
                T t = (T) findTagged(childAt, tag);
                if (t != null) {
                    return t;
                }
            }
        }
        return null;
    }

    private final void runExport(int quality, int maxDim, int fps, Exporter.Codec codec) {
        ProjectStore projectStore;
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        if (this.exportRunning) {
            UI.INSTANCE.toast(this, "An export is already running");
            return;
        }
        String str = "AhmedReaction_" + StringsKt.replace$default(project.getName(), " ", "_", false, 4, (Object) null) + '_' + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + '.' + codec.getExt();
        File file = new File(getCacheDir(), str);
        String strMimeFor = MediaSave.INSTANCE.mimeFor(codec.getExt());
        flushSave();
        this.exportRunning = true;
        this.exportCancel.set(false);
        showProgress("Exporting → " + codec.getLabel(), "Preparing…", true, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.runExport.1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                EditorActivity.this.exportCancel.set(true);
            }
        });
        HashMap map = new HashMap();
        Iterator<Layer> it = project.getLayers().iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            Layer next = it.next();
            if (next.isLive()) {
                Bitmap bitmapFrameOf = engineReady() ? getEngine().frameOf(next) : null;
                if (bitmapFrameOf != null && !bitmapFrameOf.isRecycled()) {
                    try {
                        String id = next.getId();
                        Bitmap bitmapCopy = bitmapFrameOf.copy(Bitmap.Config.ARGB_8888, false);
                        Intrinsics.checkNotNullExpressionValue(bitmapCopy, "copy(...)");
                        map.put(id, bitmapCopy);
                    } catch (Exception unused) {
                    }
                }
            }
        }
        if (engineReady()) {
            getEngine().pauseAll();
            getEngine().stopSnapshots();
        }
        Exporter exporter = Exporter.INSTANCE;
        ProjectStore projectStore2 = this.store;
        if (projectStore2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore = null;
        } else {
            projectStore = projectStore2;
        }
        exporter.export(project, projectStore, new Exporter.Options(fps, maxDim, quality, codec, file, false, map, 32, null), this.exportCancel, new C00392(), new C00403(map, str, strMimeFor, codec));
    }

    /* JADX INFO: renamed from: com.rehman.ahmedreactionstudio.editor.EditorActivity$runExport$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: EditorActivity.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\n¢\u0006\u0002\b\u0006"}, d2 = {"<anonymous>", "", "prog", "", "msg", "", "invoke"}, k = Base64.bytesPerGroup, mv = {1, 9, 0}, xi = 48)
    static final class C00392 extends Lambda implements Function2<Integer, String, Unit> {
        C00392() {
            super(2);
        }

        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ Unit invoke(Integer num, String str) {
            invoke(num.intValue(), str);
            return Unit.INSTANCE;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$0(EditorActivity this$0, int i, String msg) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(msg, "$msg");
            this$0.updateProgress(i, msg);
        }

        public final void invoke(final int i, @NotNull final String msg) {
            Intrinsics.checkNotNullParameter(msg, "msg");
            final EditorActivity editorActivity = EditorActivity.this;
            editorActivity.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$runExport$2$k_p38c21Ujxr3mXs12L2Z5IFW9I
                @Override // java.lang.Runnable
                public final void run() {
                    EditorActivity.C00392.invoke$lambda$0(editorActivity, i, msg);
                }
            });
        }
    }

    /* JADX INFO: renamed from: com.rehman.ahmedreactionstudio.editor.EditorActivity$runExport$3, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: EditorActivity.kt */
    @Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n¢\u0006\u0002\b\u0004"}, d2 = {"<anonymous>", "", "res", "Lcom/rehman/ahmedreactionstudio/export/Exporter$Result;", "invoke"}, k = Base64.bytesPerGroup, mv = {1, 9, 0}, xi = 48)
    static final class C00403 extends Lambda implements Function1<Exporter.Result, Unit> {
        final /* synthetic */ Exporter.Codec $codec;
        final /* synthetic */ String $fileName;
        final /* synthetic */ HashMap<String, Bitmap> $live;
        final /* synthetic */ String $mime;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C00403(HashMap<String, Bitmap> map, String str, String str2, Exporter.Codec codec) {
            super(1);
            this.$live = map;
            this.$fileName = str;
            this.$mime = str2;
            this.$codec = codec;
        }

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(Exporter.Result result) {
            invoke2(result);
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2(@NotNull final Exporter.Result res) {
            Intrinsics.checkNotNullParameter(res, "res");
            final EditorActivity editorActivity = EditorActivity.this;
            final HashMap<String, Bitmap> map = this.$live;
            final String str = this.$fileName;
            final String str2 = this.$mime;
            final Exporter.Codec codec = this.$codec;
            editorActivity.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$runExport$3$pilE2NqpYPbRbfN5XLa25802Suk
                @Override // java.lang.Runnable
                public final void run() {
                    EditorActivity.C00403.invoke$lambda$0(editorActivity, map, res, str, str2, codec);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$0(EditorActivity this$0, HashMap live, Exporter.Result res, String fileName, String mime, Exporter.Codec codec) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(live, "$live");
            Intrinsics.checkNotNullParameter(res, "$res");
            Intrinsics.checkNotNullParameter(fileName, "$fileName");
            Intrinsics.checkNotNullParameter(mime, "$mime");
            Intrinsics.checkNotNullParameter(codec, "$codec");
            this$0.exportRunning = false;
            this$0.dismissProgress();
            Iterator it = live.values().iterator();
            while (it.hasNext()) {
                try {
                    ((Bitmap) it.next()).recycle();
                } catch (Exception unused) {
                }
            }
            if (res.getOk() && res.getFile() != null) {
                this$0.publishAndReport(res.getFile(), fileName, mime, "Export complete", codec);
            } else {
                EditorActivity.showSnack$default(this$0, res.getMessage(), null, null, 6, null);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:25:0x0052  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x005c  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x006b A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:34:0x006e  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x007e  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0083  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00b0  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x00da  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00f4  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void updateRecordButton() {
        /*
            Method dump skipped, instruction units count: 313
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.editor.EditorActivity.updateRecordButton():void");
    }

    public final void recordButtonTap() {
        boolean z;
        boolean z2 = false;
        if (this.recording) {
            stopCompositeRecording$default(this, false, 1, null);
            return;
        }
        Project project = this.proj;
        if (project == null) {
            return;
        }
        List<Layer> layers = project.getLayers();
        if ((layers instanceof Collection) && layers.isEmpty()) {
            z = false;
        } else {
            Iterator<T> it = layers.iterator();
            while (it.hasNext()) {
                if (((Layer) it.next()).isLive()) {
                    z = true;
                    break;
                }
            }
            z = false;
        }
        List<Layer> layers2 = project.getLayers();
        if (!(layers2 instanceof Collection) || !layers2.isEmpty()) {
            Iterator<T> it2 = layers2.iterator();
            while (true) {
                if (!it2.hasNext()) {
                    break;
                } else if (((Layer) it2.next()).isClip()) {
                    z2 = true;
                    break;
                }
            }
        }
        if (z && z2) {
            startCompositeRecording();
            return;
        }
        String str = (z || z2) ? !z ? "a live camera" : "a video" : "a live camera and a video";
        new AlertDialog.Builder(this).setTitle("Set up the reaction first").setMessage("Recording captures your live camera together with a playing video. Add " + str + " to the canvas, frame them, then hit record.").setPositiveButton("Add now", new DialogInterface.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$wfmZTeHRT4bcs9G6HZJ07WzqU1o
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                EditorActivity.recordButtonTap$lambda$45(this.f$0, dialogInterface, i);
            }
        }).setNegativeButton("Not now", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void recordButtonTap$lambda$45(EditorActivity this$0, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.openWheelLevel(RadialMenus.INSTANCE.add(this$0), -1.0f, -1.0f);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Bitmap recordFrameOf(Layer l) {
        if (l.getType() != LayerType.IMAGE) {
            return getEngine().frameOf(l);
        }
        Bitmap bitmap = this.recordImageCache.get(l.getId());
        if (bitmap != null) {
            return bitmap;
        }
        String relPath = l.getRelPath();
        if (relPath == null) {
            return null;
        }
        MediaKit mediaKit = MediaKit.INSTANCE;
        ProjectStore projectStore = this.store;
        if (projectStore == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore = null;
        }
        String absolutePath = new File(projectStore.projectDir(this.projectId), relPath).getAbsolutePath();
        Intrinsics.checkNotNullExpressionValue(absolutePath, "getAbsolutePath(...)");
        Bitmap bitmapImage$default = MediaKit.image$default(mediaKit, absolutePath, 0, 2, null);
        if (bitmapImage$default == null) {
            return null;
        }
        this.recordImageCache.put(l.getId(), bitmapImage$default);
        return bitmapImage$default;
    }

    private final void startCompositeRecording() {
        boolean z;
        boolean z2;
        Object next;
        if (this.recording) {
            return;
        }
        if (this.exportRunning) {
            UI.INSTANCE.toast(this, "Locked while exporting");
            return;
        }
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        List<Layer> layers = project.getLayers();
        final boolean z3 = true;
        if ((layers instanceof Collection) && layers.isEmpty()) {
            z = false;
        } else {
            Iterator<T> it = layers.iterator();
            while (it.hasNext()) {
                if (((Layer) it.next()).isLive()) {
                    z = true;
                    break;
                }
            }
            z = false;
        }
        if (!z) {
            UI.INSTANCE.toast(this, "Add the live camera first");
            return;
        }
        List<Layer> layers2 = project.getLayers();
        if ((layers2 instanceof Collection) && layers2.isEmpty()) {
            z2 = false;
        } else {
            Iterator<T> it2 = layers2.iterator();
            while (it2.hasNext()) {
                if (((Layer) it2.next()).isClip()) {
                    z2 = true;
                    break;
                }
            }
            z2 = false;
        }
        if (!z2) {
            UI.INSTANCE.toast(this, "Add a local video first");
            return;
        }
        Iterator<T> it3 = project.getLayers().iterator();
        while (true) {
            if (it3.hasNext()) {
                next = it3.next();
                if (((Layer) next).isLive()) {
                    break;
                }
            } else {
                next = null;
                break;
            }
        }
        Layer layer = (Layer) next;
        if (layer != null && getEngine().frameOf(layer) == null) {
            int i = this.camWaitTries;
            this.camWaitTries = i + 1;
            if (i >= 20) {
                this.camWaitTries = 0;
                UI.INSTANCE.toast(this, "Camera has not produced a frame yet — check permissions");
                return;
            } else {
                showSnack$default(this, "Waiting for the camera…", null, null, 6, null);
                this.recordHandler.postDelayed(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$LZVeIBNUG7L2NwOV--tQnSC4B1M
                    @Override // java.lang.Runnable
                    public final void run() {
                        EditorActivity.startCompositeRecording$lambda$50(this.f$0);
                    }
                }, 250L);
                return;
            }
        }
        this.camWaitTries = 0;
        if (checkSelfPermission("android.permission.RECORD_AUDIO") != 0) {
            requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, 47);
            return;
        }
        LiveCamera liveCamera = this.liveCam;
        if (liveCamera != null && liveCamera.getRecording()) {
            UI.INSTANCE.toast(this, "Stop the camera take first — it is using the microphone");
            return;
        }
        final ArrayList arrayList = new ArrayList();
        for (Layer layer2 : project.getLayers()) {
            if (layer2.isClip()) {
                String relPath = layer2.getRelPath();
                if (!(relPath == null || StringsKt.isBlank(relPath))) {
                    ProjectStore projectStore = this.store;
                    if (projectStore == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("store");
                        projectStore = null;
                    }
                    File fileProjectDir = projectStore.projectDir(this.projectId);
                    String relPath2 = layer2.getRelPath();
                    Intrinsics.checkNotNull(relPath2);
                    File file = new File(fileProjectDir, relPath2);
                    if (file.exists()) {
                        String absolutePath = file.getAbsolutePath();
                        Intrinsics.checkNotNullExpressionValue(absolutePath, "getAbsolutePath(...)");
                        arrayList.add(new ClipAudio(absolutePath, layer2.getVolume(), layer2.getLoop(), layer2.getDurMs(), layer2.getId(), layer2.getSpeed()));
                    }
                }
            }
        }
        showProgress$default(this, "Preparing audio", "Decoding the clip sound…", false, null, 8, null);
        new Thread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$O-HSd8q22AgibZSR9x8N0oET9g8
            @Override // java.lang.Runnable
            public final void run() {
                EditorActivity.startCompositeRecording$lambda$52(arrayList, this, z3);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startCompositeRecording$lambda$50(EditorActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.recording) {
            return;
        }
        this$0.startCompositeRecording();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startCompositeRecording$lambda$52(ArrayList audio, final EditorActivity this$0, final boolean z) {
        PcmClip pcmMono;
        Intrinsics.checkNotNullParameter(audio, "$audio");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        final ArrayList arrayList = new ArrayList();
        final ArrayList arrayList2 = new ArrayList();
        Iterator it = audio.iterator();
        while (it.hasNext()) {
            ClipAudio clipAudio = (ClipAudio) it.next();
            try {
                pcmMono = AudioDecode.INSTANCE.toPcmMono(clipAudio.getPath());
            } catch (Throwable unused) {
                arrayList2.add(new File(clipAudio.getPath()).getName());
            }
            if (pcmMono != null) {
                if (!(pcmMono.getData().length == 0)) {
                    Intrinsics.checkNotNull(clipAudio);
                    arrayList.add(new DecodedClip(clipAudio, pcmMono.getData()));
                }
            }
            arrayList2.add(new File(clipAudio.getPath()).getName());
        }
        this$0.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$2f4g0myr0hoRxd-ETA0Jf13saac
            @Override // java.lang.Runnable
            public final void run() {
                EditorActivity.startCompositeRecording$lambda$52$lambda$51(this.f$0, arrayList2, arrayList, z);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startCompositeRecording$lambda$52$lambda$51(EditorActivity this$0, ArrayList failed, ArrayList decoded, boolean z) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(failed, "$failed");
        Intrinsics.checkNotNullParameter(decoded, "$decoded");
        this$0.dismissProgress();
        if (!failed.isEmpty()) {
            showSnack$default(this$0, "No audio track decoded for " + CollectionsKt.joinToString$default(failed, null, null, null, 0, null, null, 63, null) + " — recording without it", null, null, 6, null);
        }
        this$0.beginCompositeRecording(decoded, z);
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x00e0  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void beginCompositeRecording(java.util.List<com.rehman.ahmedreactionstudio.export.DecodedClip> r16, boolean r17) {
        /*
            Method dump skipped, instruction units count: 371
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.editor.EditorActivity.beginCompositeRecording(java.util.List, boolean):void");
    }

    static /* synthetic */ void stopCompositeRecording$default(EditorActivity editorActivity, boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            z = true;
        }
        editorActivity.stopCompositeRecording(z);
    }

    private final void stopCompositeRecording(boolean showUi) {
        if (this.recording) {
            this.recording = false;
            this.recordHandler.removeCallbacks(this.recordTick);
            getEngine().pauseAll();
            getEngine().stopSnapshots();
            CompositionRecorder compositionRecorder = this.recorder;
            this.recorder = null;
            updateRecordButton();
            if (showUi) {
                showProgress$default(this, "Finishing recording", "Draining audio and video…", false, null, 8, null);
            }
            if (compositionRecorder != null) {
                compositionRecorder.finish(new C00441(showUi));
            }
        }
    }

    /* JADX INFO: renamed from: com.rehman.ahmedreactionstudio.editor.EditorActivity$stopCompositeRecording$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: EditorActivity.kt */
    @Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n¢\u0006\u0002\b\u0004"}, d2 = {"<anonymous>", "", "res", "Lcom/rehman/ahmedreactionstudio/export/CompositionRecorder$Result;", "invoke"}, k = Base64.bytesPerGroup, mv = {1, 9, 0}, xi = 48)
    static final class C00441 extends Lambda implements Function1<CompositionRecorder.Result, Unit> {
        final /* synthetic */ boolean $showUi;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C00441(boolean z) {
            super(1);
            this.$showUi = z;
        }

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(CompositionRecorder.Result result) {
            invoke2(result);
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2(@NotNull final CompositionRecorder.Result res) {
            Intrinsics.checkNotNullParameter(res, "res");
            final EditorActivity editorActivity = EditorActivity.this;
            final boolean z = this.$showUi;
            editorActivity.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$stopCompositeRecording$1$jPI7exaL9eo3HDJzBNC8hoqScoo
                @Override // java.lang.Runnable
                public final void run() {
                    EditorActivity.C00441.invoke$lambda$0(editorActivity, res, z);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$0(EditorActivity this$0, CompositionRecorder.Result res, boolean z) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(res, "$res");
            this$0.dismissProgress();
            this$0.getEngine().setMonitorMuted(false);
            this$0.recordImageCache.clear();
            File file = res.getFile();
            if (file != null && file.exists() && file.length() > 0) {
                this$0.lastRecordingNote = res.getMessage();
                Log.i("AhmedRecorder", "take ok: " + res.getStats());
                this$0.saveRecordingToPublic(file, z);
                return;
            }
            if (z) {
                AlertDialog.Builder title = new AlertDialog.Builder(this$0).setTitle("Recording failed");
                StringBuilder sb = new StringBuilder();
                String message = res.getMessage();
                if (message == null) {
                    message = "The take was too short or could not be written.";
                }
                sb.append(message);
                sb.append("\n\n");
                sb.append(res.getStats());
                title.setMessage(sb.toString()).setPositiveButton("OK", (DialogInterface.OnClickListener) null).show();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void saveRecordingToPublic(File src, boolean showUi) {
        String strReplace$default;
        String name;
        Project project = this.proj;
        String str = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        StringBuilder sb = new StringBuilder();
        sb.append("AhmedReaction_");
        if (project == null || (name = project.getName()) == null || (strReplace$default = StringsKt.replace$default(name, " ", "_", false, 4, (Object) null)) == null) {
            strReplace$default = "project";
        }
        sb.append(strReplace$default);
        sb.append('_');
        sb.append(str);
        sb.append(".mp4");
        String string = sb.toString();
        if (showUi) {
            publishAndReport$default(this, src, string, "video/mp4", "Recording saved", null, 16, null);
        } else {
            MediaSave.INSTANCE.publishVideo(this, src, string, "video/mp4");
        }
    }

    static /* synthetic */ void publishAndReport$default(EditorActivity editorActivity, File file, String str, String str2, String str3, Exporter.Codec codec, int i, Object obj) {
        if ((i & 16) != 0) {
            codec = null;
        }
        editorActivity.publishAndReport(file, str, str2, str3, codec);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void publishAndReport(final File src, final String name, final String mime, final String title, final Exporter.Codec codec) {
        showProgress$default(this, "Saving", "Saving to your phone…", false, null, 8, null);
        new Thread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$5GVtyeKkao_58e8AgMuM9eVj5QM
            @Override // java.lang.Runnable
            public final void run() {
                EditorActivity.publishAndReport$lambda$61(this.f$0, src, name, mime, codec, title);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void publishAndReport$lambda$61(final EditorActivity this$0, File src, String name, final String mime, final Exporter.Codec codec, final String title) {
        MediaSave.Saved savedPublishVideo;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(src, "$src");
        Intrinsics.checkNotNullParameter(name, "$name");
        Intrinsics.checkNotNullParameter(mime, "$mime");
        Intrinsics.checkNotNullParameter(title, "$title");
        try {
            savedPublishVideo = MediaSave.INSTANCE.publishVideo(this$0, src, name, mime);
        } catch (Throwable unused) {
            savedPublishVideo = null;
        }
        final MediaSave.Saved saved = savedPublishVideo;
        this$0.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$qDoxkLSToLM4MYucOEdzeBpzyHI
            @Override // java.lang.Runnable
            public final void run() {
                EditorActivity.publishAndReport$lambda$61$lambda$60(this.f$0, saved, codec, title, mime);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void publishAndReport$lambda$61$lambda$60(final EditorActivity this$0, final MediaSave.Saved saved, Exporter.Codec codec, String title, final String mime) {
        String str;
        String str2;
        String label;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(title, "$title");
        Intrinsics.checkNotNullParameter(mime, "$mime");
        this$0.dismissProgress();
        if (saved == null) {
            new AlertDialog.Builder(this$0).setTitle("Could not save the video").setMessage("The video was encoded but no writable public folder accepted it. Free some storage and try again — nothing was lost until you close this dialog.").setPositiveButton("OK", (DialogInterface.OnClickListener) null).show();
            return;
        }
        if (saved.getPubliclyVisible()) {
            str = "Saved to " + saved.getLocation();
        } else {
            str = "Public folders were unavailable, so it was saved inside the app folder:\n" + saved.getLocation();
        }
        StringBuilder sb = new StringBuilder();
        String str3 = "";
        if (codec == null || codec == Exporter.Codec.H264) {
            str2 = "";
        } else {
            str2 = "\n\nNote: " + codec.getLabel() + " won't play in some apps — re-export as H.264 if needed.";
        }
        sb.append(str2);
        String str4 = this$0.lastRecordingNote;
        if (str4 != null) {
            String str5 = "\n\nAudio: " + str4;
            if (str5 != null) {
                str3 = str5;
            }
        }
        sb.append(str3);
        String string = sb.toString();
        this$0.lastRecordingNote = null;
        AlertDialog.Builder title2 = new AlertDialog.Builder(this$0).setTitle(title);
        StringBuilder sb2 = new StringBuilder();
        sb2.append(str);
        sb2.append("\n\n");
        sb2.append(UI.INSTANCE.niceBytes(saved.getBytes()));
        sb2.append(" · ");
        if (codec == null || (label = codec.getLabel()) == null) {
            label = "H.264 / AVC";
        }
        sb2.append(label);
        sb2.append(string);
        title2.setMessage(sb2.toString()).setPositiveButton("View", new DialogInterface.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$JLZM8pr_j3L2znqS2kAz66qYDMs
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                EditorActivity.publishAndReport$lambda$61$lambda$60$lambda$57(this.f$0, saved, mime, dialogInterface, i);
            }
        }).setNeutralButton("Share", new DialogInterface.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$sgWILMLF4e5X2weUlUmkufig7C8
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                EditorActivity.publishAndReport$lambda$61$lambda$60$lambda$59(saved, this$0, mime, dialogInterface, i);
            }
        }).setNegativeButton("Close", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void publishAndReport$lambda$61$lambda$60$lambda$57(EditorActivity this$0, MediaSave.Saved saved, String mime, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(mime, "$mime");
        this$0.viewRecording(saved.getUri(), saved.getPath(), mime);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void publishAndReport$lambda$61$lambda$60$lambda$59(MediaSave.Saved saved, EditorActivity this$0, String mime, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(mime, "$mime");
        Uri uri = saved.getUri();
        if (uri == null) {
            String path = saved.getPath();
            uri = path != null ? Uri.fromFile(new File(path)) : null;
        }
        if (uri != null) {
            UI.INSTANCE.shareUri(this$0, uri, mime);
        } else {
            UI.INSTANCE.toast(this$0, saved.getLocation());
        }
    }

    static /* synthetic */ void viewRecording$default(EditorActivity editorActivity, Uri uri, String str, String str2, int i, Object obj) {
        if ((i & 4) != 0) {
            str2 = "video/mp4";
        }
        editorActivity.viewRecording(uri, str, str2);
    }

    private final void viewRecording(Uri uri, String path, String mime) {
        if (uri == null) {
            if (path != null) {
                try {
                    uri = Uri.fromFile(new File(path));
                } catch (Exception unused) {
                    UI ui = UI.INSTANCE;
                    EditorActivity editorActivity = this;
                    StringBuilder sb = new StringBuilder();
                    sb.append("No video player found — the file is saved at ");
                    if (path == null) {
                        path = "Movies/AhmedReactionStudio";
                    }
                    sb.append(path);
                    ui.toast(editorActivity, sb.toString());
                    return;
                }
            } else {
                uri = null;
            }
            if (uri == null) {
                return;
            }
        }
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setDataAndType(uri, mime);
        intent.addFlags(1);
        startActivity(intent);
    }

    public static /* synthetic */ void addLiveCamera$default(EditorActivity editorActivity, boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            z = true;
        }
        editorActivity.addLiveCamera(z);
    }

    public final void addLiveCamera(final boolean front) {
        Project project;
        if (isFinishing() || isDestroyed() || (project = this.proj) == null) {
            return;
        }
        if (this.liveCamLayerId != null) {
            Intrinsics.checkNotNull(project);
            String str = this.liveCamLayerId;
            Intrinsics.checkNotNull(str);
            Layer layerLayerById = project.layerById(str);
            if (layerLayerById != null) {
                if (front != (layerLayerById.getCamFacing() != 1)) {
                    switchCameraFacing(layerLayerById);
                } else {
                    UI.INSTANCE.toast(this, "The live camera is already on the canvas");
                }
                select(layerLayerById.getId());
                return;
            }
        }
        if (checkSelfPermission("android.permission.CAMERA") != 0) {
            requestPermissions(new String[]{"android.permission.CAMERA", "android.permission.RECORD_AUDIO"}, 46);
            return;
        }
        final Project project2 = this.proj;
        Intrinsics.checkNotNull(project2);
        final boolean zIsEmpty = project2.getLayers().isEmpty();
        mutateThen(new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.addLiveCamera.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                Layer layer = new Layer(null, LayerType.CAMERA, "Camera (live)", null, 0L, 0, 0, 0, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, false, false, false, false, false, null, 0.0f, 0.0f, false, 0L, 0.0f, false, 0, false, null, 0, 0.0f, false, 0L, -7, null);
                layer.setLive(true);
                layer.setCamFacing(1 ^ (front ? 1 : 0));
                layer.setMirror(front);
                layer.setSrcW(1280);
                layer.setSrcH(720);
                layer.setFit(Layer.FIT_FIT);
                project2.getLayers().add(layer);
                if (zIsEmpty) {
                    this.placeMain(layer, project2);
                } else {
                    this.placePip(layer, project2);
                }
                this.setSelectedId(layer.getId());
                this.liveCamLayerId = layer.getId();
            }
        });
        startLiveCamera();
    }

    private final void startLiveCamera() {
        Layer layerLayerById;
        String str = this.liveCamLayerId;
        if (str != null && this.liveCam == null) {
            EditorActivity editorActivity = this;
            LiveCamera liveCamera = new LiveCamera(editorActivity, new EditorActivity$startLiveCamera$cam$1(this, str), new EditorActivity$startLiveCamera$cam$2(this));
            this.liveCam = liveCamera;
            Project project = this.proj;
            boolean z = false;
            if (project != null && (layerLayerById = project.layerById(str)) != null && layerLayerById.getCamFacing() == 1) {
                z = true;
            }
            liveCamera.start(!z);
            UI.INSTANCE.toast(editorActivity, "Live camera on the canvas — drag, resize and record from ◉ Studio");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final int cam0W() {
        LiveCamera liveCamera = this.liveCam;
        if (liveCamera != null) {
            return liveCamera.getOutW();
        }
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final int cam0H() {
        LiveCamera liveCamera = this.liveCam;
        if (liveCamera != null) {
            return liveCamera.getOutH();
        }
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void stopLiveCamera(boolean evict) {
        LiveCamera liveCamera = this.liveCam;
        if (liveCamera == null) {
            return;
        }
        this.liveCam = null;
        liveCamera.stop();
        String str = this.liveCamLayerId;
        if (!evict || str == null) {
            return;
        }
        getEngine().clearExternal(str);
    }

    private final void removeLiveCameraLayer() {
        String str = this.liveCamLayerId;
        if (str == null) {
            return;
        }
        stopLiveCamera(true);
        this.liveCamLayerId = null;
        getCtrl().delete(str);
        if (Intrinsics.areEqual(this.selectedId, str)) {
            this.selectedId = null;
        }
        refreshAll();
    }

    private final void toggleLiveCameraRecord(Layer l) {
        LiveCamera liveCamera = this.liveCam;
        if (liveCamera == null) {
            UI.INSTANCE.toast(this, "The live camera is not running");
            return;
        }
        if (this.recording && !liveCamera.getRecording()) {
            UI.INSTANCE.toast(this, "Stop the composite recording first — it is using the microphone");
            return;
        }
        if (liveCamera.getRecording()) {
            liveCamera.stopRecording(new C00461(l));
            return;
        }
        ProjectStore projectStore = this.store;
        if (projectStore == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore = null;
        }
        liveCamera.startRecording(projectStore.mediaDir(this.projectId), new C00472());
    }

    /* JADX INFO: renamed from: com.rehman.ahmedreactionstudio.editor.EditorActivity$toggleLiveCameraRecord$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: EditorActivity.kt */
    @Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u00012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003H\n¢\u0006\u0002\b\u0004"}, d2 = {"<anonymous>", "", "f", "Ljava/io/File;", "invoke"}, k = Base64.bytesPerGroup, mv = {1, 9, 0}, xi = 48)
    static final class C00461 extends Lambda implements Function1<File, Unit> {
        final /* synthetic */ Layer $l;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C00461(Layer layer) {
            super(1);
            this.$l = layer;
        }

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(File file) {
            invoke2(file);
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2(@Nullable final File file) {
            final EditorActivity editorActivity = EditorActivity.this;
            final Layer layer = this.$l;
            editorActivity.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$toggleLiveCameraRecord$1$Pw0biZFaV5AsTZfCjxXmVqoUTLs
                @Override // java.lang.Runnable
                public final void run() {
                    EditorActivity.C00461.invoke$lambda$0(editorActivity, file, layer);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$0(EditorActivity this$0, File file, Layer l) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(l, "$l");
            this$0.getRecChip().setVisibility(8);
            if (file != null && file.exists()) {
                this$0.swapLiveCameraToClip(l, file);
            } else {
                UI.INSTANCE.toast(this$0, "Take was too short or failed");
                this$0.refreshAll();
            }
        }
    }

    /* JADX INFO: renamed from: com.rehman.ahmedreactionstudio.editor.EditorActivity$toggleLiveCameraRecord$2, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: EditorActivity.kt */
    @Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n¢\u0006\u0002\b\u0004"}, d2 = {"<anonymous>", "", "ok", "", "invoke"}, k = Base64.bytesPerGroup, mv = {1, 9, 0}, xi = 48)
    static final class C00472 extends Lambda implements Function1<Boolean, Unit> {
        C00472() {
            super(1);
        }

        @Override // kotlin.jvm.functions.Function1
        public /* bridge */ /* synthetic */ Unit invoke(Boolean bool) {
            invoke(bool.booleanValue());
            return Unit.INSTANCE;
        }

        public final void invoke(final boolean z) {
            final EditorActivity editorActivity = EditorActivity.this;
            editorActivity.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$toggleLiveCameraRecord$2$qlmJhOW0xKrvgAZG6otgOe4wehk
                @Override // java.lang.Runnable
                public final void run() {
                    EditorActivity.C00472.invoke$lambda$0(z, editorActivity);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$0(boolean z, EditorActivity this$0) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            if (z) {
                this$0.getRecChip().setText("● STOP CAMERA TAKE");
                this$0.getRecChip().setContentDescription("Stop the camera take");
                this$0.getRecChip().setVisibility(this$0.fullCanvas ? 8 : 0);
                UI.INSTANCE.toast(this$0, "Recording the camera take");
            } else {
                UI.INSTANCE.toast(this$0, "Could not start the take");
            }
            this$0.refreshAll();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void swapLiveCameraToClip(Layer live, File f) {
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        MediaKit mediaKit = MediaKit.INSTANCE;
        String absolutePath = f.getAbsolutePath();
        Intrinsics.checkNotNullExpressionValue(absolutePath, "getAbsolutePath(...)");
        MediaInfo mediaInfoProbe = mediaKit.probe(absolutePath);
        pushUndo();
        int iCoerceAtLeast = RangesKt.coerceAtLeast(project.getLayers().indexOf(live), 0);
        stopLiveCamera(true);
        this.liveCamLayerId = null;
        Layer layer = new Layer(null, LayerType.CAMERA, "Camera take", "media/" + f.getName(), mediaInfoProbe.getDurMs(), mediaInfoProbe.getWidth(), mediaInfoProbe.getHeight(), mediaInfoProbe.getRotation(), 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, false, false, false, false, false, null, 0.0f, 0.0f, false, 0L, 0.0f, false, 0, false, null, 0, 0.0f, false, 0L, -255, null);
        layer.setCx(live.getCx());
        layer.setCy(live.getCy());
        layer.setWN(live.getWN());
        layer.setHN(live.getHN());
        layer.setRotDeg(live.getRotDeg());
        layer.setFit(live.getFit());
        layer.setOpacity(live.getOpacity());
        layer.setVisible(live.getVisible());
        project.getLayers().remove(live);
        project.getLayers().add(RangesKt.coerceAtMost(iCoerceAtLeast, project.getLayers().size()), layer);
        this.selectedId = layer.getId();
        afterStructureChange();
        UI.INSTANCE.toast(this, "Take added as a clip — " + UI.INSTANCE.fmtTime(mediaInfoProbe.getDurMs()));
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    @Nullable
    public Layer selected() {
        String str = this.selectedId;
        if (str == null) {
            return null;
        }
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        return project.layerById(str);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void selectId(@Nullable String id) {
        select(id);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void addVideo() {
        pickMedia(true);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void addImage() {
        pickMedia(false);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void addCameraLive() {
        addLiveCamera$default(this, false, 1, null);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void addCameraTake() {
        openCamera();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void addScreen() {
        startScreenCapture();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void addTextSource() {
        addText();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public boolean anyPlaying() {
        return engineReady() && getEngine().anyPlaying();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void toggleMasterPlay() {
        togglePlay();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void restart() {
        getEngine().seekTo(0L);
        if (this.seek != null) {
            getSeek().setProgress(0);
        }
        onTick(0L);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void nudge(long ms) {
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        long jCoerceIn = RangesKt.coerceIn(getEngine().getMasterMs() + ms, 0L, project.durationMs());
        getEngine().seekTo(jCoerceIn);
        if (this.seek != null) {
            getSeek().setProgress(RangesKt.coerceAtMost((int) jCoerceIn, getSeek().getMax()));
        }
        onTick(jCoerceIn);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void toggleSourcePlay(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        getEngine().toggleLayerPlay(l);
        markDirty();
        refreshAll();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void snapshotFrame() {
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        try {
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(project.getAspect().getCanvasW() / 2, project.getAspect().getCanvasH() / 2, Bitmap.Config.ARGB_8888);
            Compositor.INSTANCE.draw(new Compositor.Ctx(), new Canvas(bitmapCreateBitmap), bitmapCreateBitmap.getWidth(), bitmapCreateBitmap.getHeight(), project, new Function1<Layer, Bitmap>() { // from class: com.rehman.ahmedreactionstudio.editor.EditorActivity.snapshotFrame.1
                {
                    super(1);
                }

                @Override // kotlin.jvm.functions.Function1
                @Nullable
                public final Bitmap invoke(@NotNull Layer it) {
                    Intrinsics.checkNotNullParameter(it, "it");
                    return EditorActivity.this.getEngine().frameOf(it);
                }
            }, getEngine().getMasterMs(), (256 & 128) != 0 ? null : null, (256 & 256) != 0 ? MapsKt.emptyMap() : null);
            ProjectStore projectStore = this.store;
            if (projectStore == null) {
                Intrinsics.throwUninitializedPropertyAccessException("store");
                projectStore = null;
            }
            File fileMediaDir = projectStore.mediaDir(this.projectId);
            fileMediaDir.mkdirs();
            File file = new File(fileMediaDir, "snap_" + System.currentTimeMillis() + ".png");
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            try {
                bitmapCreateBitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                CloseableKt.closeFinally(fileOutputStream, null);
                bitmapCreateBitmap.recycle();
                consumeMediaFile(file, "pip", "Snapshot", LayerType.IMAGE);
            } finally {
            }
        } catch (Exception e) {
            UI.INSTANCE.toast(this, "Snapshot failed: " + e.getMessage());
        }
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void undo() {
        doUndo();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void redo() {
        doRedo();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void enterFullCanvas() {
        setFullCanvas(true);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void openDockPanel() {
        setSheet("sources");
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void openMixerPanel() {
        setSheet("mixer");
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void openExportPanel() {
        setSheet("export");
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void openAdvanced(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        openAdvancedSheet(l);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void quickExport() {
        Object next;
        List<Exporter.Codec> listAvailable = Exporter.Codec.INSTANCE.available();
        if (listAvailable.isEmpty()) {
            listAvailable = CollectionsKt.listOf(Exporter.Codec.H264);
        }
        List<Exporter.Codec> list = listAvailable;
        Iterator<T> it = list.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            } else {
                next = it.next();
                if (((Exporter.Codec) next) == Exporter.Codec.H264) {
                    break;
                }
            }
        }
        Exporter.Codec codec = (Exporter.Codec) next;
        if (codec == null) {
            codec = list.get(0);
        }
        if (warnLiveBeforeExport()) {
            return;
        }
        runExport(1, 720, 30, codec);
    }

    private final boolean warnLiveBeforeExport() {
        boolean z;
        Object next;
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        Iterator<T> it = project.getLayers().iterator();
        while (true) {
            z = false;
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            Layer layer = (Layer) next;
            if (layer.isLive() && layer.getVisible()) {
                break;
            }
        }
        Layer layer2 = (Layer) next;
        if (layer2 == null) {
            return false;
        }
        if (engineReady() && getEngine().frameOf(layer2) != null) {
            z = true;
        }
        AlertDialog.Builder title = new AlertDialog.Builder(this).setTitle("Live camera on the canvas");
        StringBuilder sb = new StringBuilder();
        sb.append(Typography.quote);
        sb.append(layer2.getName());
        sb.append("\" is a live feed. Tap START RECORDING to capture camera + video as they play.\n\nOffline export can only freeze the ");
        sb.append(z ? "current camera frame" : "camera as an empty box until a frame arrives");
        sb.append(" — it cannot play the live camera forward.");
        title.setMessage(sb.toString()).setPositiveButton("Start recording", new DialogInterface.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$O3n4vPG1KvzypZLMndv7X7Old7Q
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                EditorActivity.warnLiveBeforeExport$lambda$69(this.f$0, dialogInterface, i);
            }
        }).setNegativeButton(z ? "Export frozen frame" : "Export anyway", new DialogInterface.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$yjHXR30MEBVEpeYSArLWdvlolbs
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                EditorActivity.warnLiveBeforeExport$lambda$75(this.f$0, dialogInterface, i);
            }
        }).setNeutralButton("Cancel", (DialogInterface.OnClickListener) null).show();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void warnLiveBeforeExport$lambda$69(EditorActivity this$0, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.recordButtonTap();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void warnLiveBeforeExport$lambda$75(EditorActivity this$0, DialogInterface dialogInterface, int i) {
        Object next;
        Object next2;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        SharedPreferences sharedPreferencesEditorPrefs = this$0.editorPrefs();
        List<Exporter.Codec> listAvailable = Exporter.Codec.INSTANCE.available();
        if (listAvailable.isEmpty()) {
            listAvailable = CollectionsKt.listOf(Exporter.Codec.H264);
        }
        List<Exporter.Codec> list = listAvailable;
        List<Exporter.Codec> list2 = list;
        Iterator<T> it = list2.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            } else {
                next = it.next();
                if (Intrinsics.areEqual(((Exporter.Codec) next).name(), sharedPreferencesEditorPrefs.getString(PREF_EXP_CODEC, "H264"))) {
                    break;
                }
            }
        }
        Exporter.Codec codec = (Exporter.Codec) next;
        if (codec == null) {
            Iterator<T> it2 = list2.iterator();
            while (true) {
                if (!it2.hasNext()) {
                    next2 = null;
                    break;
                } else {
                    next2 = it2.next();
                    if (((Exporter.Codec) next2) == Exporter.Codec.H264) {
                        break;
                    }
                }
            }
            Exporter.Codec codec2 = (Exporter.Codec) next2;
            codec = codec2 == null ? list.get(0) : codec2;
        }
        int i2 = sharedPreferencesEditorPrefs.getInt(PREF_EXP_QUALITY, EncoderConfig.Quality.BALANCED.ordinal());
        int i3 = 720;
        int i4 = sharedPreferencesEditorPrefs.getInt(PREF_EXP_MAXDIM, 720);
        if (i4 <= 480) {
            i3 = 480;
        } else if (i4 >= 1080) {
            i3 = 1080;
        }
        int i5 = 30;
        int i6 = sharedPreferencesEditorPrefs.getInt(PREF_EXP_FPS, 30);
        if (i6 == 24) {
            i5 = 24;
        } else if (i6 == 60) {
            i5 = 60;
        }
        this$0.runExport(i2, i3, i5, codec);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void setAspect(@NotNull Aspect a) {
        Intrinsics.checkNotNullParameter(a, "a");
        changeAspect(a);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void setBg(int color) {
        setBgColor(color);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void fitAllSources() {
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        pushUndo();
        for (Layer layer : project.getLayers()) {
            if (!layer.isText()) {
                layer.setFit(Layer.FIT_FIT);
            }
        }
        markDirty();
        getStage().refresh();
        refreshAll();
        UI.INSTANCE.toast(this, "Every source shows its whole frame");
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void renameProject() {
        EditorActivity editorActivity = this;
        final EditText editText = new EditText(editorActivity);
        Project project = this.proj;
        Intrinsics.checkNotNull(project);
        editText.setText(project.getName());
        editText.setTextColor(UI.INSTANCE.getFG());
        new AlertDialog.Builder(editorActivity).setTitle("Rename project").setView(editText).setPositiveButton("OK", new DialogInterface.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$XKD4IFJtIK8vncUZ1HIjUp1JEXg
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                EditorActivity.renameProject$lambda$76(editText, this, dialogInterface, i);
            }
        }).setNegativeButton("Cancel", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void renameProject$lambda$76(EditText input, EditorActivity this$0, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(input, "$input");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        String string = StringsKt.trim((CharSequence) input.getText().toString()).toString();
        if (string.length() > 0) {
            Project project = this$0.proj;
            Intrinsics.checkNotNull(project);
            project.setName(string);
            this$0.markDirty();
            this$0.updateName();
        }
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void saveNow() {
        flushSave();
        UI.INSTANCE.toast(this, "Project saved");
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void openDiagnostics() {
        startActivity(new Intent(this, (Class<?>) DiagnosticsActivity.class));
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void closeProject() {
        onBackPressed();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void editText(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        editTextLayer(l);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void cycleTextColor(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        pushUndo();
        l.setTextColor(nextColor(l.getTextColor()));
        markDirty();
        getStage().refresh();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public boolean isCameraRecording(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        if (Intrinsics.areEqual(l.getId(), this.liveCamLayerId)) {
            LiveCamera liveCamera = this.liveCam;
            if (liveCamera != null && liveCamera.getRecording()) {
                return true;
            }
        }
        return false;
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void toggleCameraRecord(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        toggleLiveCameraRecord(l);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void switchCameraFacing(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        LiveCamera liveCamera = this.liveCam;
        if (liveCamera == null) {
            return;
        }
        liveCamera.switchFacing();
        l.setCamFacing(!liveCamera.isFront() ? 1 : 0);
        l.setMirror(liveCamera.isFront());
        markDirty();
        refreshAll();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void toggleCameraMirror(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        l.setMirror(!l.getMirror());
        LiveCamera liveCamera = this.liveCam;
        if (liveCamera != null) {
            liveCamera.setMirror(l.getMirror());
        }
        markDirty();
        refreshAll();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public boolean isTorchOn(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        if (Intrinsics.areEqual(l.getId(), this.liveCamLayerId)) {
            LiveCamera liveCamera = this.liveCam;
            if (liveCamera != null && liveCamera.getTorch()) {
                return true;
            }
        }
        return false;
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public boolean hasTorch(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        if (Intrinsics.areEqual(l.getId(), this.liveCamLayerId)) {
            LiveCamera liveCamera = this.liveCam;
            if (liveCamera != null && liveCamera.getHasFlashUnit()) {
                return true;
            }
        }
        return false;
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public boolean hasFrontTorch() {
        LiveCamera liveCamera = this.liveCam;
        return liveCamera != null && liveCamera.getFrontHasFlash();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public boolean hasBackTorch() {
        LiveCamera liveCamera = this.liveCam;
        return liveCamera != null && liveCamera.getBackHasFlash();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public boolean isFrontTorchOn() {
        LiveCamera liveCamera = this.liveCam;
        return liveCamera != null && liveCamera.getFrontTorch();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public boolean isBackTorchOn() {
        LiveCamera liveCamera = this.liveCam;
        return liveCamera != null && liveCamera.getBackTorch();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public boolean isBothTorchOn() {
        LiveCamera liveCamera = this.liveCam;
        return liveCamera != null && liveCamera.bothTorchesFullyOn();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void toggleTorch(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        LiveCamera liveCamera = this.liveCam;
        if (liveCamera == null || !Intrinsics.areEqual(l.getId(), this.liveCamLayerId)) {
            UI.INSTANCE.toast(this, "The live camera is not running");
            return;
        }
        if (!liveCamera.getHasFlashUnit()) {
            UI.INSTANCE.toast(this, liveCamera.isFront() ? "Front camera has no LED — use the screen light" : "This device has no rear flash");
            return;
        }
        if (!liveCamera.toggleTorch() && !liveCamera.getTorch()) {
            UI ui = UI.INSTANCE;
            EditorActivity editorActivity = this;
            String str = liveCamera.torchLastError();
            if (!(!StringsKt.isBlank(str))) {
                str = null;
            }
            if (str == null) {
                str = "This camera has no flash — try the screen light";
            }
            ui.toast(editorActivity, str);
            return;
        }
        UI.INSTANCE.toast(this, liveCamera.getTorch() ? "Flashlight on" : "Flashlight off");
        refreshAll();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void toggleFrontTorch() {
        LiveCamera liveCamera = this.liveCam;
        if (liveCamera == null) {
            UI.INSTANCE.toast(this, "Live camera not running");
            return;
        }
        if (!liveCamera.hasFlashForFront()) {
            UI.INSTANCE.toast(this, "Front camera has no LED — use the screen light");
            return;
        }
        if (!liveCamera.toggleFrontTorch() && !liveCamera.getFrontTorch()) {
            UI ui = UI.INSTANCE;
            EditorActivity editorActivity = this;
            String str = liveCamera.torchLastError();
            if (!(!StringsKt.isBlank(str))) {
                str = null;
            }
            if (str == null) {
                str = "Front flash unavailable";
            }
            ui.toast(editorActivity, str);
            return;
        }
        UI.INSTANCE.toast(this, liveCamera.getFrontTorch() ? "Front flash on" : "Front flash off");
        refreshAll();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void toggleBackTorch() {
        LiveCamera liveCamera = this.liveCam;
        if (liveCamera == null) {
            UI.INSTANCE.toast(this, "Live camera not running");
            return;
        }
        if (!liveCamera.hasFlashForBack()) {
            UI.INSTANCE.toast(this, "This device has no rear flash");
            return;
        }
        if (!liveCamera.toggleBackTorch() && !liveCamera.getBackTorch()) {
            UI ui = UI.INSTANCE;
            EditorActivity editorActivity = this;
            String str = liveCamera.torchLastError();
            if (!(!StringsKt.isBlank(str))) {
                str = null;
            }
            if (str == null) {
                str = "Rear flash unavailable";
            }
            ui.toast(editorActivity, str);
            return;
        }
        UI.INSTANCE.toast(this, liveCamera.getBackTorch() ? "Rear flash on (LED)" : "Rear flash off");
        refreshAll();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void toggleBothTorch() {
        LiveCamera liveCamera = this.liveCam;
        if (liveCamera == null) {
            UI.INSTANCE.toast(this, "Live camera not running");
            return;
        }
        if (!liveCamera.hasFlashForFront() && !liveCamera.hasFlashForBack()) {
            UI.INSTANCE.toast(this, "This device has no camera flash — use the screen light");
            return;
        }
        boolean z = !liveCamera.bothTorchesFullyOn();
        if (z && !liveCamera.setBothTorches(true)) {
            UI.INSTANCE.toast(this, "No camera flash is available");
            return;
        }
        if (!z) {
            liveCamera.setBothTorches(false);
        }
        UI.INSTANCE.toast(this, z ? "Both flashes on" : "Both flashes off");
        refreshAll();
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    /* JADX INFO: renamed from: isScreenLightOn, reason: from getter */
    public boolean getScreenLight() {
        return this.screenLight;
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void toggleScreenLight() {
        this.screenLight = !this.screenLight;
        applyScreenLight();
        UI.INSTANCE.toast(this, this.screenLight ? "Screen light on" : "Screen light off");
        refreshAll();
    }

    private final void applyScreenLight() {
        try {
            WindowManager.LayoutParams attributes = getWindow().getAttributes();
            attributes.screenBrightness = this.screenLight ? 1.0f : -1.0f;
            getWindow().setAttributes(attributes);
        } catch (Exception unused) {
        }
        if (this.screenLight) {
            if (this.screenLightView == null) {
                View view = new View(this);
                view.setBackgroundColor(Color.argb(242, KotlinVersion.MAX_COMPONENT_VALUE, 246, 232));
                view.setClickable(false);
                view.setFocusable(false);
                getRootFrame().addView(view, 0, new FrameLayout.LayoutParams(-1, -1));
                this.screenLightView = view;
            }
            View view2 = this.screenLightView;
            if (view2 != null) {
                view2.setVisibility(0);
            }
            if (this.stage != null) {
                getStage().bringToFront();
            }
            getEmptyOverlay().bringToFront();
            if (this.wheel != null) {
                getWheel().bringToFront();
            }
            if (this.sheet != null) {
                getSheet().bringToFront();
                return;
            }
            return;
        }
        View view3 = this.screenLightView;
        if (view3 == null) {
            return;
        }
        view3.setVisibility(8);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void openFlashRing(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        openWheelLevel(RadialMenus.INSTANCE.flash(this, l.getId()), -1.0f, -1.0f);
    }

    public final void openLightMenuFromToolbar() {
        List<Layer> layers;
        Project project = this.proj;
        Layer layer = null;
        Object obj = null;
        layer = null;
        if (project != null && (layers = project.getLayers()) != null) {
            Iterator<T> it = layers.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                Object next = it.next();
                if (((Layer) next).isLive()) {
                    obj = next;
                    break;
                }
            }
            layer = (Layer) obj;
        }
        if (layer != null) {
            openFlashRing(layer);
        } else {
            openWheelLevel(RadialMenus.INSTANCE.lightRoot(this), -1.0f, -1.0f);
        }
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public boolean isStatsHudOn() {
        return editorPrefs().getBoolean(PREF_STATS_HUD, true);
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void toggleStatsHud() {
        boolean z = !isStatsHudOn();
        editorPrefs().edit().putBoolean(PREF_STATS_HUD, z).apply();
        if (z && this.statsHud != null && engineReady() && (getEngine().anyPlaying() || this.recording)) {
            getStatsHud().setText(getEngine().stats());
            getStatsHud().setVisibility(0);
        } else if (this.statsHud != null) {
            getStatsHud().setVisibility(8);
        }
    }

    @Override // com.rehman.ahmedreactionstudio.editor.RadialMenus.Host
    public void toast(@NotNull String msg) {
        Intrinsics.checkNotNullParameter(msg, "msg");
        UI.INSTANCE.toast(this, msg);
    }
}
