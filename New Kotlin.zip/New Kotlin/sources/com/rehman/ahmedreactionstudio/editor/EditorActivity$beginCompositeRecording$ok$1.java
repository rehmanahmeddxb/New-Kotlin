package com.rehman.ahmedreactionstudio.editor;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.io.encoding.Base64;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: EditorActivity.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n¢\u0006\u0002\b\u0004"}, d2 = {"<anonymous>", "", "err", "", "invoke"}, k = Base64.bytesPerGroup, mv = {1, 9, 0}, xi = 48)
final class EditorActivity$beginCompositeRecording$ok$1 extends Lambda implements Function1<String, Unit> {
    final /* synthetic */ EditorActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    EditorActivity$beginCompositeRecording$ok$1(EditorActivity editorActivity) {
        super(1);
        this.this$0 = editorActivity;
    }

    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ Unit invoke(String str) {
        invoke2(str);
        return Unit.INSTANCE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void invoke$lambda$0(EditorActivity this$0, String err) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(err, "$err");
        EditorActivity.showSnack$default(this$0, "Recording audio: " + err, null, null, 6, null);
    }

    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
    public final void invoke2(@NotNull final String err) {
        Intrinsics.checkNotNullParameter(err, "err");
        final EditorActivity editorActivity = this.this$0;
        editorActivity.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$beginCompositeRecording$ok$1$mptMQm6bZ1Eh0dwm4qArjVSd3kk
            @Override // java.lang.Runnable
            public final void run() {
                EditorActivity$beginCompositeRecording$ok$1.invoke$lambda$0(editorActivity, err);
            }
        });
    }
}
