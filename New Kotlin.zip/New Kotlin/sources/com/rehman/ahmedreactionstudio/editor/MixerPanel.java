package com.rehman.ahmedreactionstudio.editor;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import com.rehman.ahmedreactionstudio.R;
import com.rehman.ahmedreactionstudio.core.Layer;
import com.rehman.ahmedreactionstudio.editor.MixerPanel;
import com.rehman.ahmedreactionstudio.util.UI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: MixerPanel.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010 \n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001:\u0001 B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J \u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0011H\u0002J\u001e\u0010\u0013\u001a\u00020\r2\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u000f0\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0017J.\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u00172\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u00172\f\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\r0\u001fH\u0002R\u000e\u0010\u0005\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\b\u0010\t\"\u0004\b\n\u0010\u000b"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/MixerPanel;", "Landroid/widget/LinearLayout;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "list", "listener", "Lcom/rehman/ahmedreactionstudio/editor/MixerPanel$Listener;", "getListener", "()Lcom/rehman/ahmedreactionstudio/editor/MixerPanel$Listener;", "setListener", "(Lcom/rehman/ahmedreactionstudio/editor/MixerPanel$Listener;)V", "addStrip", "", "l", "Lcom/rehman/ahmedreactionstudio/core/Layer;", "selected", "", "anySolo", "bind", "layers", "", "selectedId", "", "chip", "Landroid/widget/Button;", "label", Layer.FIT_FILL, "", "desc", "onTap", "Lkotlin/Function0;", "Listener"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nMixerPanel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MixerPanel.kt\ncom/rehman/ahmedreactionstudio/editor/MixerPanel\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,207:1\n1#2:208\n766#3:209\n857#3,2:210\n1747#3,3:212\n*S KotlinDebug\n*F\n+ 1 MixerPanel.kt\ncom/rehman/ahmedreactionstudio/editor/MixerPanel\n*L\n72#1:209\n72#1:210,2\n82#1:212,3\n*E\n"})
public final class MixerPanel extends LinearLayout {

    @NotNull
    private final LinearLayout list;

    @Nullable
    private Listener listener;

    /* JADX INFO: compiled from: MixerPanel.kt */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u0007\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\u0010\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\u0010\u0010\u0007\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\u0018\u0010\b\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\nH&"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/MixerPanel$Listener;", "", "onMute", "", "id", "", "onSelect", "onSolo", "onVolume", "v", ""}, k = 1, mv = {1, 9, 0}, xi = 48)
    public interface Listener {
        void onMute(@NotNull String id);

        void onSelect(@NotNull String id);

        void onSolo(@NotNull String id);

        void onVolume(@NotNull String id, float v);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MixerPanel(@NotNull Context context) {
        super(context);
        Intrinsics.checkNotNullParameter(context, "context");
        setOrientation(1);
        setPadding(UI.INSTANCE.dp(context, 12), UI.INSTANCE.dp(context, 10), UI.INSTANCE.dp(context, 12), UI.INSTANCE.dp(context, 10));
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(UI.INSTANCE.dpf(context, 14.0f));
        gradientDrawable.setColor(Color.rgb(18, 20, 26));
        gradientDrawable.setStroke(UI.INSTANCE.dp(context, 1), Color.argb(60, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
        setBackground(gradientDrawable);
        TextView textView = new TextView(context);
        textView.setText("Audio Mixer");
        textView.setTextColor(-1);
        textView.setTextSize(16.0f);
        textView.setTypeface(textView.getTypeface(), 1);
        textView.setPadding(0, 0, 0, UI.INSTANCE.dp(context, 8));
        textView.setCompoundDrawablesRelativeWithIntrinsicBounds(Ic.INSTANCE.get(context, R.drawable.ic_volume, -1), (Drawable) null, (Drawable) null, (Drawable) null);
        textView.setCompoundDrawablePadding(UI.INSTANCE.dp(context, 8));
        textView.setGravity(16);
        addView(textView);
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        this.list = linearLayout;
        ScrollView scrollView = new ScrollView(context);
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(true);
        scrollView.addView(this.list, new FrameLayout.LayoutParams(-1, -2));
        addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        bind(CollectionsKt.emptyList(), null);
    }

    @Nullable
    public final Listener getListener() {
        return this.listener;
    }

    public final void setListener(@Nullable Listener listener) {
        this.listener = listener;
    }

    public final void bind(@NotNull List<Layer> layers, @Nullable String selectedId) {
        boolean z;
        Intrinsics.checkNotNullParameter(layers, "layers");
        this.list.removeAllViews();
        List<Layer> list = layers;
        ArrayList arrayList = new ArrayList();
        Iterator<T> it = list.iterator();
        while (true) {
            boolean z2 = true;
            z = false;
            if (!it.hasNext()) {
                break;
            }
            Object next = it.next();
            Layer layer = (Layer) next;
            if (!layer.isClip() && !layer.isLive()) {
                z2 = false;
            }
            if (z2) {
                arrayList.add(next);
            }
        }
        ArrayList arrayList2 = arrayList;
        if (arrayList2.isEmpty()) {
            TextView textView = new TextView(getContext());
            textView.setText("Add a video to mix its audio. Camera mic is captured when you record.");
            textView.setTextColor(Color.rgb(140, 148, 162));
            textView.setTextSize(12.0f);
            this.list.addView(textView);
            return;
        }
        if (!(list instanceof Collection) || !list.isEmpty()) {
            Iterator<T> it2 = list.iterator();
            while (true) {
                if (it2.hasNext()) {
                    if (((Layer) it2.next()).getSolo()) {
                        z = true;
                        break;
                    }
                } else {
                    break;
                }
            }
        }
        for (Layer layer2 : CollectionsKt.asReversed(arrayList2)) {
            addStrip(layer2, Intrinsics.areEqual(layer2.getId(), selectedId), z);
        }
    }

    private final void addStrip(final Layer l, boolean selected, boolean anySolo) {
        StringBuilder sb;
        String str;
        int i;
        int i2;
        StringBuilder sb2;
        String str2;
        LinearLayout linearLayout = new LinearLayout(getContext());
        boolean z = true;
        linearLayout.setOrientation(1);
        UI ui = UI.INSTANCE;
        Context context = linearLayout.getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        int iDp = ui.dp(context, 4);
        UI ui2 = UI.INSTANCE;
        Context context2 = linearLayout.getContext();
        Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
        int iDp2 = ui2.dp(context2, 6);
        UI ui3 = UI.INSTANCE;
        Context context3 = linearLayout.getContext();
        Intrinsics.checkNotNullExpressionValue(context3, "getContext(...)");
        int iDp3 = ui3.dp(context3, 4);
        UI ui4 = UI.INSTANCE;
        Context context4 = linearLayout.getContext();
        Intrinsics.checkNotNullExpressionValue(context4, "getContext(...)");
        linearLayout.setPadding(iDp, iDp2, iDp3, ui4.dp(context4, 6));
        GradientDrawable gradientDrawable = new GradientDrawable();
        UI ui5 = UI.INSTANCE;
        Context context5 = linearLayout.getContext();
        Intrinsics.checkNotNullExpressionValue(context5, "getContext(...)");
        gradientDrawable.setCornerRadius(ui5.dpf(context5, 8.0f));
        gradientDrawable.setColor(selected ? Color.rgb(36, 72, 120) : 0);
        linearLayout.setBackground(gradientDrawable);
        LinearLayout linearLayout2 = new LinearLayout(getContext());
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        linearLayout2.setClickable(true);
        linearLayout2.setFocusable(true);
        UI ui6 = UI.INSTANCE;
        Context context6 = linearLayout2.getContext();
        Intrinsics.checkNotNullExpressionValue(context6, "getContext(...)");
        linearLayout2.setMinimumHeight(ui6.dp(context6, 36));
        StringBuilder sb3 = new StringBuilder();
        sb3.append("Select ");
        String name = l.getName();
        if (StringsKt.isBlank(name)) {
            name = l.getType().getLabel();
        }
        sb3.append(name);
        linearLayout2.setContentDescription(sb3.toString());
        linearLayout2.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$MixerPanel$LQFaV0fndvIrp62Qm87syYkH-P0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MixerPanel.addStrip$lambda$11$lambda$10(this.f$0, l, view);
            }
        });
        int iTypeIcon = (l.isClip() || l.isLive()) ? Ic.INSTANCE.typeIcon(l.getType()) : R.drawable.ic_volume;
        ImageView imageView = new ImageView(getContext());
        Ic ic = Ic.INSTANCE;
        Context context7 = imageView.getContext();
        Intrinsics.checkNotNullExpressionValue(context7, "getContext(...)");
        imageView.setImageDrawable(ic.get(context7, iTypeIcon, Color.rgb(200, 210, 230)));
        UI ui7 = UI.INSTANCE;
        Context context8 = getContext();
        Intrinsics.checkNotNullExpressionValue(context8, "getContext(...)");
        int iDp4 = ui7.dp(context8, 18);
        UI ui8 = UI.INSTANCE;
        Context context9 = getContext();
        Intrinsics.checkNotNullExpressionValue(context9, "getContext(...)");
        linearLayout2.addView(imageView, new LinearLayout.LayoutParams(iDp4, ui8.dp(context9, 18)));
        TextView textView = new TextView(getContext());
        StringBuilder sb4 = new StringBuilder();
        String name2 = l.getName();
        if (StringsKt.isBlank(name2)) {
            name2 = l.getType().getLabel();
        }
        sb4.append(name2);
        sb4.append(l.isLive() ? " (mic)" : "");
        textView.setText(sb4.toString());
        textView.setTextColor(Color.rgb(230, 232, 238));
        textView.setTextSize(12.0f);
        textView.setMaxLines(1);
        UI ui9 = UI.INSTANCE;
        Context context10 = textView.getContext();
        Intrinsics.checkNotNullExpressionValue(context10, "getContext(...)");
        int iDp5 = ui9.dp(context10, 6);
        UI ui10 = UI.INSTANCE;
        Context context11 = textView.getContext();
        Intrinsics.checkNotNullExpressionValue(context11, "getContext(...)");
        textView.setPadding(iDp5, 0, ui10.dp(context11, 4), 0);
        linearLayout2.addView(textView, new LinearLayout.LayoutParams(0, -2, 1.0f));
        if (!l.getMuted() && (!anySolo || l.getSolo())) {
            z = false;
        }
        int i3 = 30;
        int iRgb = z ? Color.rgb(140, 30, 30) : Color.rgb(30, 34, 48);
        if (l.getMuted()) {
            sb = new StringBuilder();
            str = "Unmute ";
        } else {
            sb = new StringBuilder();
            str = "Mute ";
        }
        sb.append(str);
        sb.append(l.getName());
        linearLayout2.addView(chip("M", iRgb, sb.toString(), new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.MixerPanel.addStrip.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                Listener listener = MixerPanel.this.getListener();
                if (listener != null) {
                    listener.onMute(l.getId());
                }
            }
        }));
        if (l.getSolo()) {
            i3 = 180;
            i = 110;
            i2 = 20;
        } else {
            i = 34;
            i2 = 48;
        }
        int iRgb2 = Color.rgb(i3, i, i2);
        if (l.getSolo()) {
            sb2 = new StringBuilder();
            str2 = "Unsolo ";
        } else {
            sb2 = new StringBuilder();
            str2 = "Solo ";
        }
        sb2.append(str2);
        sb2.append(l.getName());
        linearLayout2.addView(chip("S", iRgb2, sb2.toString(), new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.MixerPanel.addStrip.2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                Listener listener = MixerPanel.this.getListener();
                if (listener != null) {
                    listener.onSolo(l.getId());
                }
            }
        }));
        linearLayout.addView(linearLayout2);
        if (z && !l.getMuted()) {
            TextView textView2 = new TextView(getContext());
            textView2.setText("Silent — another source is soloed");
            textView2.setTextColor(Color.rgb(200, 160, 80));
            textView2.setTextSize(10.0f);
            UI ui11 = UI.INSTANCE;
            Context context12 = textView2.getContext();
            Intrinsics.checkNotNullExpressionValue(context12, "getContext(...)");
            textView2.setPadding(ui11.dp(context12, 24), 0, 0, 0);
            linearLayout.addView(textView2);
        }
        LinearLayout linearLayout3 = new LinearLayout(getContext());
        linearLayout3.setOrientation(0);
        linearLayout3.setGravity(16);
        UI ui12 = UI.INSTANCE;
        Context context13 = linearLayout3.getContext();
        Intrinsics.checkNotNullExpressionValue(context13, "getContext(...)");
        linearLayout3.setPadding(0, ui12.dp(context13, 2), 0, 0);
        int iCoerceIn = RangesKt.coerceIn((int) (l.getVolume() * 100), 0, 100);
        final TextView textView3 = new TextView(getContext());
        StringBuilder sb5 = new StringBuilder();
        sb5.append(iCoerceIn);
        sb5.append('%');
        textView3.setText(sb5.toString());
        textView3.setTextColor(Color.rgb(180, 186, 198));
        textView3.setTextSize(10.0f);
        UI ui13 = UI.INSTANCE;
        Context context14 = textView3.getContext();
        Intrinsics.checkNotNullExpressionValue(context14, "getContext(...)");
        textView3.setMinWidth(ui13.dp(context14, 32));
        linearLayout3.addView(textView3);
        SeekBar seekBar = new SeekBar(getContext());
        seekBar.setMax(100);
        seekBar.setProgress(iCoerceIn);
        seekBar.setContentDescription("Volume of " + l.getName());
        seekBar.setProgressTintList(ColorStateList.valueOf(UI.INSTANCE.getACCENT()));
        seekBar.setThumbTintList(ColorStateList.valueOf(UI.INSTANCE.getACCENT2()));
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: com.rehman.ahmedreactionstudio.editor.MixerPanel$addStrip$sb$1$1
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(@Nullable SeekBar s) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(@Nullable SeekBar s) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(@Nullable SeekBar s, int v, boolean fromUser) {
                if (fromUser) {
                    TextView textView4 = textView3;
                    StringBuilder sb6 = new StringBuilder();
                    sb6.append(v);
                    sb6.append('%');
                    textView4.setText(sb6.toString());
                    MixerPanel.Listener listener = this.getListener();
                    if (listener != null) {
                        listener.onVolume(l.getId(), v / 100.0f);
                    }
                }
            }
        });
        linearLayout3.addView(seekBar, new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout.addView(linearLayout3);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        UI ui14 = UI.INSTANCE;
        Context context15 = getContext();
        Intrinsics.checkNotNullExpressionValue(context15, "getContext(...)");
        layoutParams.bottomMargin = ui14.dp(context15, 4);
        Unit unit = Unit.INSTANCE;
        this.list.addView(linearLayout, layoutParams);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void addStrip$lambda$11$lambda$10(MixerPanel this$0, Layer l, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(l, "$l");
        Listener listener = this$0.listener;
        if (listener != null) {
            listener.onSelect(l.getId());
        }
    }

    private final Button chip(String label, int fill, String desc, final Function0<Unit> onTap) {
        Button button = new Button(getContext());
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(11.0f);
        button.setTextColor(-1);
        button.setContentDescription(desc);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(0, 0, 0, 0);
        GradientDrawable gradientDrawable = new GradientDrawable();
        UI ui = UI.INSTANCE;
        Context context = getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        gradientDrawable.setCornerRadius(ui.dpf(context, 8.0f));
        gradientDrawable.setColor(fill);
        UI ui2 = UI.INSTANCE;
        Context context2 = getContext();
        Intrinsics.checkNotNullExpressionValue(context2, "getContext(...)");
        gradientDrawable.setStroke(ui2.dp(context2, 1), Color.rgb(80, 85, 100));
        button.setBackground(gradientDrawable);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$MixerPanel$BkE-pO-EpbLRfFhtM-hSUgBqoTc
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MixerPanel.chip$lambda$21(onTap, view);
            }
        });
        UI ui3 = UI.INSTANCE;
        Context context3 = getContext();
        Intrinsics.checkNotNullExpressionValue(context3, "getContext(...)");
        int iDp = ui3.dp(context3, 36);
        UI ui4 = UI.INSTANCE;
        Context context4 = getContext();
        Intrinsics.checkNotNullExpressionValue(context4, "getContext(...)");
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(iDp, ui4.dp(context4, 32));
        UI ui5 = UI.INSTANCE;
        Context context5 = getContext();
        Intrinsics.checkNotNullExpressionValue(context5, "getContext(...)");
        layoutParams.setMarginStart(ui5.dp(context5, 4));
        button.setLayoutParams(layoutParams);
        return button;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void chip$lambda$21(Function0 onTap, View view) {
        Intrinsics.checkNotNullParameter(onTap, "$onTap");
        onTap.invoke();
    }
}
