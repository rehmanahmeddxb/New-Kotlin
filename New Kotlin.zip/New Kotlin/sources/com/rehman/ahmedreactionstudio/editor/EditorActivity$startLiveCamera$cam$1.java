package com.rehman.ahmedreactionstudio.editor;

import android.graphics.Bitmap;
import com.rehman.ahmedreactionstudio.core.Layer;
import com.rehman.ahmedreactionstudio.core.LayerFit;
import com.rehman.ahmedreactionstudio.core.Project;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.io.encoding.Base64;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: EditorActivity.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n¢\u0006\u0002\b\u0004"}, d2 = {"<anonymous>", "", "bmp", "Landroid/graphics/Bitmap;", "invoke"}, k = Base64.bytesPerGroup, mv = {1, 9, 0}, xi = 48)
final class EditorActivity$startLiveCamera$cam$1 extends Lambda implements Function1<Bitmap, Unit> {
    final /* synthetic */ String $id;
    final /* synthetic */ EditorActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    EditorActivity$startLiveCamera$cam$1(EditorActivity editorActivity, String str) {
        super(1);
        this.this$0 = editorActivity;
        this.$id = str;
    }

    @Override // kotlin.jvm.functions.Function1
    public /* bridge */ /* synthetic */ Unit invoke(Bitmap bitmap) {
        invoke2(bitmap);
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
    public final void invoke2(@NotNull final Bitmap bmp) {
        Intrinsics.checkNotNullParameter(bmp, "bmp");
        final EditorActivity editorActivity = this.this$0;
        final String str = this.$id;
        editorActivity.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$EditorActivity$startLiveCamera$cam$1$C7WEKtu2sSvnYaQctvcnknYj8ks
            @Override // java.lang.Runnable
            public final void run() {
                EditorActivity$startLiveCamera$cam$1.invoke$lambda$0(editorActivity, str, bmp);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void invoke$lambda$0(EditorActivity this$0, String id, Bitmap bmp) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(id, "$id");
        Intrinsics.checkNotNullParameter(bmp, "$bmp");
        Project proj = this$0.getProj();
        Layer layerLayerById = proj != null ? proj.layerById(id) : null;
        if (layerLayerById == null) {
            this$0.stopLiveCamera(true);
            return;
        }
        int iCam0W = this$0.cam0W();
        int iCam0H = this$0.cam0H();
        if (iCam0W > 0 && iCam0H > 0 && (layerLayerById.getSrcW() != iCam0W || layerLayerById.getSrcH() != iCam0H)) {
            layerLayerById.setSrcW(iCam0W);
            layerLayerById.setSrcH(iCam0H);
            if (!LayerFit.INSTANCE.isFullBleed(layerLayerById)) {
                float cx = layerLayerById.getCx();
                float cy = layerLayerById.getCy();
                float rotDeg = layerLayerById.getRotDeg();
                LayerFit layerFit = LayerFit.INSTANCE;
                Project proj2 = this$0.getProj();
                Intrinsics.checkNotNull(proj2);
                int canvasW = proj2.getAspect().getCanvasW();
                Project proj3 = this$0.getProj();
                Intrinsics.checkNotNull(proj3);
                LayerFit.pip$default(layerFit, layerLayerById, canvasW, proj3.getAspect().getCanvasH(), "br", 0.0f, 0.0f, 0.0f, 112, null);
                layerLayerById.setCx(cx);
                layerLayerById.setCy(cy);
                layerLayerById.setRotDeg(rotDeg);
                LayerFit.clampInside$default(LayerFit.INSTANCE, layerLayerById, 0.0f, 2, null);
            }
        }
        this$0.getEngine().setFrame(layerLayerById, bmp);
        this$0.getStage().refresh();
    }
}
