package com.rehman.ahmedreactionstudio.editor;

import com.rehman.ahmedreactionstudio.R;
import com.rehman.ahmedreactionstudio.core.Aspect;
import com.rehman.ahmedreactionstudio.core.Layer;
import com.rehman.ahmedreactionstudio.core.LayerType;
import com.rehman.ahmedreactionstudio.core.Project;
import com.rehman.ahmedreactionstudio.core.SourceController;
import com.rehman.ahmedreactionstudio.editor.RadialMenuView;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.IntIterator;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.IntProgression;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: RadialMenus.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0006\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001(B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006J\u0016\u0010\u0007\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\tJ\u000e\u0010\n\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006J\u001a\u0010\u000b\u001a\u0004\u0018\u00010\t2\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\f\u001a\u00020\rH\u0002J\u000e\u0010\u000e\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006J\u000e\u0010\u000f\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006J\u0016\u0010\u0010\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\tJ\u001e\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00130\u00122\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\f\u001a\u00020\rH\u0002J2\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\t2\n\b\u0002\u0010\u0018\u001a\u0004\u0018\u00010\t2\f\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u00040\u001aH\u0002JZ\u0010\u001b\u001a\u00020\u00132\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\t2\b\b\u0002\u0010\u001c\u001a\u00020\u001d2\b\b\u0002\u0010\u001e\u001a\u00020\u001d2\n\b\u0002\u0010\u0018\u001a\u0004\u0018\u00010\t2\b\b\u0002\u0010\u001f\u001a\u00020\u001d2\b\b\u0002\u0010 \u001a\u00020\u001d2\f\u0010!\u001a\b\u0012\u0004\u0012\u00020\"0\u001aH\u0002J\u000e\u0010#\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006J\u000e\u0010$\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006J\u000e\u0010%\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006J\u0016\u0010&\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\tJ\u000e\u0010'\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/RadialMenus;", "", "()V", "add", "Lcom/rehman/ahmedreactionstudio/editor/RadialMenuView$Level;", "h", "Lcom/rehman/ahmedreactionstudio/editor/RadialMenus$Host;", "arrange", "id", "", "background", "badgeOf", "l", "Lcom/rehman/ahmedreactionstudio/core/Layer;", "canvas", "export", "flash", "flashItems", "", "Lcom/rehman/ahmedreactionstudio/editor/RadialMenuView$Item;", "folder", "icon", "", "label", "badge", "sub", "Lkotlin/Function0;", "item", "active", "", "danger", "keepOpen", "enabled", "action", "", "lightRoot", "project", "root", "source", "sources", "Host"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nRadialMenus.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RadialMenus.kt\ncom/rehman/ahmedreactionstudio/editor/RadialMenus\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,394:1\n1#2:395\n*E\n"})
public final class RadialMenus {

    @NotNull
    public static final RadialMenus INSTANCE = new RadialMenus();

    /* JADX INFO: compiled from: RadialMenus.kt */
    @Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0010\t\n\u0002\b\r\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u000f\bf\u0018\u00002\u00020\u0001J\b\u0010\n\u001a\u00020\u000bH&J\b\u0010\f\u001a\u00020\u000bH&J\b\u0010\r\u001a\u00020\u000bH&J\b\u0010\u000e\u001a\u00020\u000bH&J\b\u0010\u000f\u001a\u00020\u000bH&J\b\u0010\u0010\u001a\u00020\u000bH&J\b\u0010\u0011\u001a\u00020\u0012H&J\b\u0010\u0013\u001a\u00020\u000bH&J\u0010\u0010\u0014\u001a\u00020\u000b2\u0006\u0010\u0015\u001a\u00020\u0016H&J\u0010\u0010\u0017\u001a\u00020\u000b2\u0006\u0010\u0015\u001a\u00020\u0016H&J\b\u0010\u0018\u001a\u00020\u000bH&J\b\u0010\u0019\u001a\u00020\u000bH&J\b\u0010\u001a\u001a\u00020\u0012H&J\b\u0010\u001b\u001a\u00020\u0012H&J\u0010\u0010\u001c\u001a\u00020\u00122\u0006\u0010\u0015\u001a\u00020\u0016H&J\b\u0010\u001d\u001a\u00020\u0012H&J\b\u0010\u001e\u001a\u00020\u0012H&J\u0010\u0010\u001f\u001a\u00020\u00122\u0006\u0010\u0015\u001a\u00020\u0016H&J\b\u0010 \u001a\u00020\u0012H&J\b\u0010!\u001a\u00020\u0012H&J\b\u0010\"\u001a\u00020\u0012H&J\u0010\u0010#\u001a\u00020\u00122\u0006\u0010\u0015\u001a\u00020\u0016H&J\u0010\u0010$\u001a\u00020\u000b2\u0006\u0010%\u001a\u00020&H&J\u0010\u0010'\u001a\u00020\u000b2\u0006\u0010\u0015\u001a\u00020\u0016H&J\b\u0010(\u001a\u00020\u000bH&J\b\u0010)\u001a\u00020\u000bH&J\b\u0010*\u001a\u00020\u000bH&J\u0010\u0010+\u001a\u00020\u000b2\u0006\u0010\u0015\u001a\u00020\u0016H&J\b\u0010,\u001a\u00020\u000bH&J\b\u0010-\u001a\u00020\u000bH&J\b\u0010.\u001a\u00020\u000bH&J\b\u0010/\u001a\u00020\u000bH&J\b\u00100\u001a\u00020\u000bH&J\b\u00101\u001a\u00020\u000bH&J\u0012\u00102\u001a\u00020\u000b2\b\u00103\u001a\u0004\u0018\u000104H&J\n\u00105\u001a\u0004\u0018\u00010\u0016H&J\u0010\u00106\u001a\u00020\u000b2\u0006\u00107\u001a\u000208H&J\u0010\u00109\u001a\u00020\u000b2\u0006\u0010:\u001a\u00020;H&J\b\u0010<\u001a\u00020\u000bH&J\u0010\u0010=\u001a\u00020\u000b2\u0006\u0010\u0015\u001a\u00020\u0016H&J\u0010\u0010>\u001a\u00020\u000b2\u0006\u0010?\u001a\u000204H&J\b\u0010@\u001a\u00020\u000bH&J\b\u0010A\u001a\u00020\u000bH&J\u0010\u0010B\u001a\u00020\u000b2\u0006\u0010\u0015\u001a\u00020\u0016H&J\u0010\u0010C\u001a\u00020\u000b2\u0006\u0010\u0015\u001a\u00020\u0016H&J\b\u0010D\u001a\u00020\u000bH&J\b\u0010E\u001a\u00020\u000bH&J\b\u0010F\u001a\u00020\u000bH&J\u0010\u0010G\u001a\u00020\u000b2\u0006\u0010\u0015\u001a\u00020\u0016H&J\b\u0010H\u001a\u00020\u000bH&J\u0010\u0010I\u001a\u00020\u000b2\u0006\u0010\u0015\u001a\u00020\u0016H&J\b\u0010J\u001a\u00020\u000bH&R\u0012\u0010\u0002\u001a\u00020\u0003X¦\u0004¢\u0006\u0006\u001a\u0004\b\u0004\u0010\u0005R\u0012\u0010\u0006\u001a\u00020\u0007X¦\u0004¢\u0006\u0006\u001a\u0004\b\b\u0010\t"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/RadialMenus$Host;", "", "ctrl", "Lcom/rehman/ahmedreactionstudio/core/SourceController;", "getCtrl", "()Lcom/rehman/ahmedreactionstudio/core/SourceController;", "project", "Lcom/rehman/ahmedreactionstudio/core/Project;", "getProject", "()Lcom/rehman/ahmedreactionstudio/core/Project;", "addCameraLive", "", "addCameraTake", "addImage", "addScreen", "addTextSource", "addVideo", "anyPlaying", "", "closeProject", "cycleTextColor", "l", "Lcom/rehman/ahmedreactionstudio/core/Layer;", "editText", "enterFullCanvas", "fitAllSources", "hasBackTorch", "hasFrontTorch", "hasTorch", "isBackTorchOn", "isBothTorchOn", "isCameraRecording", "isFrontTorchOn", "isScreenLightOn", "isStatsHudOn", "isTorchOn", "nudge", "ms", "", "openAdvanced", "openDiagnostics", "openDockPanel", "openExportPanel", "openFlashRing", "openMixerPanel", "quickExport", "redo", "renameProject", "restart", "saveNow", "selectId", "id", "", "selected", "setAspect", "a", "Lcom/rehman/ahmedreactionstudio/core/Aspect;", "setBg", "color", "", "snapshotFrame", "switchCameraFacing", "toast", "msg", "toggleBackTorch", "toggleBothTorch", "toggleCameraMirror", "toggleCameraRecord", "toggleFrontTorch", "toggleMasterPlay", "toggleScreenLight", "toggleSourcePlay", "toggleStatsHud", "toggleTorch", "undo"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public interface Host {
        void addCameraLive();

        void addCameraTake();

        void addImage();

        void addScreen();

        void addTextSource();

        void addVideo();

        boolean anyPlaying();

        void closeProject();

        void cycleTextColor(@NotNull Layer l);

        void editText(@NotNull Layer l);

        void enterFullCanvas();

        void fitAllSources();

        @NotNull
        SourceController getCtrl();

        @NotNull
        Project getProject();

        boolean hasBackTorch();

        boolean hasFrontTorch();

        boolean hasTorch(@NotNull Layer l);

        boolean isBackTorchOn();

        boolean isBothTorchOn();

        boolean isCameraRecording(@NotNull Layer l);

        boolean isFrontTorchOn();

        /* JADX INFO: renamed from: isScreenLightOn */
        boolean getScreenLight();

        boolean isStatsHudOn();

        boolean isTorchOn(@NotNull Layer l);

        void nudge(long ms);

        void openAdvanced(@NotNull Layer l);

        void openDiagnostics();

        void openDockPanel();

        void openExportPanel();

        void openFlashRing(@NotNull Layer l);

        void openMixerPanel();

        void quickExport();

        void redo();

        void renameProject();

        void restart();

        void saveNow();

        void selectId(@Nullable String id);

        @Nullable
        Layer selected();

        void setAspect(@NotNull Aspect a);

        void setBg(int color);

        void snapshotFrame();

        void switchCameraFacing(@NotNull Layer l);

        void toast(@NotNull String msg);

        void toggleBackTorch();

        void toggleBothTorch();

        void toggleCameraMirror(@NotNull Layer l);

        void toggleCameraRecord(@NotNull Layer l);

        void toggleFrontTorch();

        void toggleMasterPlay();

        void toggleScreenLight();

        void toggleSourcePlay(@NotNull Layer l);

        void toggleStatsHud();

        void toggleTorch(@NotNull Layer l);

        void undo();
    }

    private RadialMenus() {
    }

    static /* synthetic */ RadialMenuView.Item item$default(RadialMenus radialMenus, int i, String str, boolean z, boolean z2, String str2, boolean z3, boolean z4, Function0 function0, int i2, Object obj) {
        return radialMenus.item(i, str, (i2 & 4) != 0 ? false : z, (i2 & 8) != 0 ? false : z2, (i2 & 16) != 0 ? null : str2, (i2 & 32) != 0 ? false : z3, (i2 & 64) != 0 ? true : z4, function0);
    }

    private final RadialMenuView.Item item(int icon, String label, boolean active, boolean danger, String badge, boolean keepOpen, boolean enabled, Function0<Unit> action) {
        return new RadialMenuView.Item(icon, label, active, danger, badge, null, keepOpen, enabled, action);
    }

    static /* synthetic */ RadialMenuView.Item folder$default(RadialMenus radialMenus, int i, String str, String str2, Function0 function0, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            str2 = null;
        }
        return radialMenus.folder(i, str, str2, function0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final RadialMenuView.Item folder(int icon, String label, String badge, Function0<RadialMenuView.Level> sub) {
        return new RadialMenuView.Item(icon, label, false, false, badge, sub, false, true, null);
    }

    @NotNull
    public final RadialMenuView.Level root(@NotNull final Host h) {
        Intrinsics.checkNotNullParameter(h, "h");
        return new RadialMenuView.Level(R.drawable.ic_wheel, "Studio", "tap a petal · tap the hub to close", new Function0<List<? extends RadialMenuView.Item>>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.root.1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final List<? extends RadialMenuView.Item> invoke() {
                Object next;
                int i;
                int size = h.getProject().getLayers().size();
                Iterator<T> it = h.getProject().getLayers().iterator();
                while (true) {
                    if (!it.hasNext()) {
                        next = null;
                        break;
                    }
                    next = it.next();
                    if (((Layer) next).isLive()) {
                        break;
                    }
                }
                Layer layer = (Layer) next;
                String str = (h.getScreenLight() || (layer != null && (h.isTorchOn(layer) || h.isFrontTorchOn() || h.isBackTorchOn())) || h.isBothTorchOn()) ? "ON" : null;
                List<Layer> layers = h.getProject().getLayers();
                if ((layers instanceof Collection) && layers.isEmpty()) {
                    i = 0;
                } else {
                    Iterator<T> it2 = layers.iterator();
                    i = 0;
                    while (it2.hasNext()) {
                        if (((Layer) it2.next()).isClip() && (i = i + 1) < 0) {
                            CollectionsKt.throwCountOverflow();
                        }
                    }
                }
                RadialMenuView.Item[] itemArr = new RadialMenuView.Item[7];
                RadialMenus radialMenus = RadialMenus.INSTANCE;
                String strValueOf = size > 0 ? String.valueOf(size) : null;
                final Host host = h;
                itemArr[0] = radialMenus.folder(R.drawable.ic_layers, "Sources", strValueOf, new Function0<RadialMenuView.Level>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.root.1.1
                    {
                        super(0);
                    }

                    /* JADX WARN: Can't rename method to resolve collision */
                    @Override // kotlin.jvm.functions.Function0
                    @NotNull
                    public final RadialMenuView.Level invoke() {
                        return RadialMenus.INSTANCE.sources(host);
                    }
                });
                RadialMenus radialMenus2 = RadialMenus.INSTANCE;
                final Host host2 = h;
                itemArr[1] = RadialMenus.folder$default(radialMenus2, R.drawable.ic_add, "Add", null, new Function0<RadialMenuView.Level>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.root.1.2
                    {
                        super(0);
                    }

                    /* JADX WARN: Can't rename method to resolve collision */
                    @Override // kotlin.jvm.functions.Function0
                    @NotNull
                    public final RadialMenuView.Level invoke() {
                        return RadialMenus.INSTANCE.add(host2);
                    }
                }, 4, null);
                RadialMenus radialMenus3 = RadialMenus.INSTANCE;
                String strValueOf2 = i > 0 ? String.valueOf(i) : null;
                final Host host3 = h;
                itemArr[2] = RadialMenus.item$default(radialMenus3, R.drawable.ic_volume, "Audio", false, false, strValueOf2, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.root.1.3
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host3.openMixerPanel();
                    }
                }, 108, null);
                RadialMenus radialMenus4 = RadialMenus.INSTANCE;
                final Host host4 = h;
                itemArr[3] = radialMenus4.folder(R.drawable.ic_flash, "Light", str, new Function0<RadialMenuView.Level>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.root.1.4
                    {
                        super(0);
                    }

                    /* JADX WARN: Can't rename method to resolve collision */
                    @Override // kotlin.jvm.functions.Function0
                    @NotNull
                    public final RadialMenuView.Level invoke() {
                        return RadialMenus.INSTANCE.lightRoot(host4);
                    }
                });
                RadialMenus radialMenus5 = RadialMenus.INSTANCE;
                final Host host5 = h;
                itemArr[4] = RadialMenus.folder$default(radialMenus5, R.drawable.ic_aspect, "Canvas", null, new Function0<RadialMenuView.Level>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.root.1.5
                    {
                        super(0);
                    }

                    /* JADX WARN: Can't rename method to resolve collision */
                    @Override // kotlin.jvm.functions.Function0
                    @NotNull
                    public final RadialMenuView.Level invoke() {
                        return RadialMenus.INSTANCE.canvas(host5);
                    }
                }, 4, null);
                RadialMenus radialMenus6 = RadialMenus.INSTANCE;
                final Host host6 = h;
                itemArr[5] = RadialMenus.folder$default(radialMenus6, R.drawable.ic_export, "Export", null, new Function0<RadialMenuView.Level>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.root.1.6
                    {
                        super(0);
                    }

                    /* JADX WARN: Can't rename method to resolve collision */
                    @Override // kotlin.jvm.functions.Function0
                    @NotNull
                    public final RadialMenuView.Level invoke() {
                        return RadialMenus.INSTANCE.export(host6);
                    }
                }, 4, null);
                RadialMenus radialMenus7 = RadialMenus.INSTANCE;
                final Host host7 = h;
                itemArr[6] = RadialMenus.folder$default(radialMenus7, R.drawable.ic_settings, "Project", null, new Function0<RadialMenuView.Level>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.root.1.7
                    {
                        super(0);
                    }

                    /* JADX WARN: Can't rename method to resolve collision */
                    @Override // kotlin.jvm.functions.Function0
                    @NotNull
                    public final RadialMenuView.Level invoke() {
                        return RadialMenus.INSTANCE.project(host7);
                    }
                }, 4, null);
                return CollectionsKt.listOf((Object[]) itemArr);
            }
        });
    }

    @NotNull
    public final RadialMenuView.Level lightRoot(@NotNull final Host h) {
        Intrinsics.checkNotNullParameter(h, "h");
        return new RadialMenuView.Level(R.drawable.ic_flash, "Light", "front · back · both · screen flash", new Function0<List<? extends RadialMenuView.Item>>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.lightRoot.1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final List<? extends RadialMenuView.Item> invoke() {
                Object next;
                Iterator<T> it = h.getProject().getLayers().iterator();
                while (true) {
                    if (!it.hasNext()) {
                        next = null;
                        break;
                    }
                    next = it.next();
                    if (((Layer) next).isLive()) {
                        break;
                    }
                }
                Layer layer = (Layer) next;
                ArrayList arrayList = new ArrayList();
                if (layer != null) {
                    arrayList.addAll(RadialMenus.INSTANCE.flashItems(h, layer));
                } else {
                    RadialMenus radialMenus = RadialMenus.INSTANCE;
                    final Host host = h;
                    arrayList.add(RadialMenus.item$default(radialMenus, R.drawable.ic_camera, "Add live camera first", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.lightRoot.1.1
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            host.addCameraLive();
                        }
                    }, 124, null));
                    boolean screenLight = h.getScreenLight();
                    RadialMenus radialMenus2 = RadialMenus.INSTANCE;
                    String str = screenLight ? "Screen light: on" : "Screen light: off";
                    final Host host2 = h;
                    arrayList.add(RadialMenus.item$default(radialMenus2, R.drawable.ic_eye, str, screenLight, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.lightRoot.1.2
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            host2.toggleScreenLight();
                        }
                    }, 88, null));
                }
                return arrayList;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final List<RadialMenuView.Item> flashItems(final Host h, final Layer l) {
        ArrayList arrayList = new ArrayList();
        boolean zHasFrontTorch = h.hasFrontTorch();
        boolean zHasBackTorch = h.hasBackTorch();
        boolean zIsFrontTorchOn = h.isFrontTorchOn();
        boolean zIsBackTorchOn = h.isBackTorchOn();
        boolean zIsBothTorchOn = h.isBothTorchOn();
        boolean screenLight = h.getScreenLight();
        if (zHasFrontTorch) {
            arrayList.add(item$default(this, R.drawable.ic_flash, zIsFrontTorchOn ? "Front flash: on" : "Front flash: off", zIsFrontTorchOn, false, zIsFrontTorchOn ? "LED" : null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.flashItems.1
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    h.toggleFrontTorch();
                }
            }, 72, null));
        } else {
            arrayList.add(item$default(this, R.drawable.ic_flash, "Front: no LED — use screen light", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.flashItems.2
                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }
            }, 60, null));
        }
        if (zHasBackTorch) {
            arrayList.add(item$default(this, R.drawable.ic_flash, zIsBackTorchOn ? "Back flash: on" : "Back flash: off", zIsBackTorchOn, false, zIsBackTorchOn ? "LED" : null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.flashItems.3
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    h.toggleBackTorch();
                }
            }, 72, null));
        } else {
            arrayList.add(item$default(this, R.drawable.ic_flash, "Back: no LED", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.flashItems.4
                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }
            }, 60, null));
        }
        if (zHasFrontTorch && zHasBackTorch) {
            arrayList.add(item$default(this, R.drawable.ic_flash, zIsBothTorchOn ? "Both flashes: on" : "Both flashes: off", zIsBothTorchOn, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.flashItems.5
                {
                    super(0);
                }

                @Override // kotlin.jvm.functions.Function0
                public /* bridge */ /* synthetic */ Unit invoke() {
                    invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                public final void invoke2() {
                    h.toggleBothTorch();
                }
            }, 88, null));
        }
        arrayList.add(item$default(this, R.drawable.ic_eye, screenLight ? "Screen light: on" : "Screen light: off", screenLight, false, screenLight ? "BRIGHT" : null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.flashItems.6
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                h.toggleScreenLight();
            }
        }, 72, null));
        arrayList.add(item$default(this, R.drawable.ic_switch, l.getCamFacing() == 0 ? "Switch to back cam" : "Switch to front cam", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.flashItems.7
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                h.switchCameraFacing(l);
            }
        }, 92, null));
        return arrayList;
    }

    @NotNull
    public final RadialMenuView.Level sources(@NotNull final Host h) {
        Intrinsics.checkNotNullParameter(h, "h");
        return new RadialMenuView.Level(R.drawable.ic_layers, "Sources", "every source · tap for its controls", new Function0<List<? extends RadialMenuView.Item>>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.sources.1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final List<? extends RadialMenuView.Item> invoke() {
                Project project = h.getProject();
                if (project.getLayers().isEmpty()) {
                    RadialMenus radialMenus = RadialMenus.INSTANCE;
                    final Host host = h;
                    return CollectionsKt.listOf(RadialMenus.folder$default(radialMenus, R.drawable.ic_add, "Add the first source", null, new Function0<RadialMenuView.Level>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.sources.1.1
                        {
                            super(0);
                        }

                        /* JADX WARN: Can't rename method to resolve collision */
                        @Override // kotlin.jvm.functions.Function0
                        @NotNull
                        public final RadialMenuView.Level invoke() {
                            return RadialMenus.INSTANCE.add(host);
                        }
                    }, 4, null));
                }
                IntProgression intProgressionReversed = RangesKt.reversed(CollectionsKt.getIndices(project.getLayers()));
                final Host host2 = h;
                ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(intProgressionReversed, 10));
                Iterator<Integer> it = intProgressionReversed.iterator();
                while (it.hasNext()) {
                    final Layer layer = project.getLayers().get(((IntIterator) it).nextInt());
                    RadialMenus radialMenus2 = RadialMenus.INSTANCE;
                    int iTypeIcon = Ic.INSTANCE.typeIcon(layer.getType());
                    String name = layer.getName();
                    if (StringsKt.isBlank(name)) {
                        name = layer.getType().getLabel();
                    }
                    arrayList.add(radialMenus2.folder(iTypeIcon, name, RadialMenus.INSTANCE.badgeOf(host2, layer), new Function0<RadialMenuView.Level>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus$sources$1$2$2
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(0);
                        }

                        /* JADX WARN: Can't rename method to resolve collision */
                        @Override // kotlin.jvm.functions.Function0
                        @NotNull
                        public final RadialMenuView.Level invoke() {
                            return RadialMenus.INSTANCE.source(host2, layer.getId());
                        }
                    }));
                }
                return arrayList;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String badgeOf(Host h, Layer l) {
        if (l.isLive() && h.isCameraRecording(l)) {
            return "REC";
        }
        if (l.isLive()) {
            return "LIVE";
        }
        if (!l.getVisible()) {
            return "HIDDEN";
        }
        if (l.getLocked()) {
            return "LOCK";
        }
        if (l.getSolo()) {
            return "SOLO";
        }
        if (l.isClip() && h.getCtrl().effectiveMuted(l)) {
            return "MUTED";
        }
        if (!l.isClip() || l.getPlaying()) {
            return null;
        }
        return "PAUSED";
    }

    @NotNull
    public final RadialMenuView.Level source(@NotNull final Host h, @NotNull final String id) {
        LayerType type;
        String name;
        Intrinsics.checkNotNullParameter(h, "h");
        Intrinsics.checkNotNullParameter(id, "id");
        Ic ic = Ic.INSTANCE;
        Layer layerLayerById = h.getProject().layerById(id);
        if (layerLayerById == null || (type = layerLayerById.getType()) == null) {
            type = LayerType.VIDEO;
        }
        int iTypeIcon = ic.typeIcon(type);
        Layer layerLayerById2 = h.getProject().layerById(id);
        String str = "Source";
        if (layerLayerById2 != null && (name = layerLayerById2.getName()) != null) {
            String str2 = name;
            if (StringsKt.isBlank(str2)) {
                str2 = "Source";
            }
            str = str2;
        }
        return new RadialMenuView.Level(iTypeIcon, str, "controls for this source", new Function0<List<? extends RadialMenuView.Item>>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final List<? extends RadialMenuView.Item> invoke() {
                final Layer layerLayerById3 = h.getProject().layerById(id);
                if (layerLayerById3 == null) {
                    return CollectionsKt.emptyList();
                }
                ArrayList arrayList = new ArrayList();
                RadialMenus radialMenus = RadialMenus.INSTANCE;
                Layer layerSelected = h.selected();
                boolean zAreEqual = Intrinsics.areEqual(layerSelected != null ? layerSelected.getId() : null, layerLayerById3.getId());
                final Host host = h;
                arrayList.add(RadialMenus.item$default(radialMenus, R.drawable.ic_check, "Select on canvas", zAreEqual, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host.selectId(layerLayerById3.getId());
                    }
                }, 120, null));
                RadialMenus radialMenus2 = RadialMenus.INSTANCE;
                int i = layerLayerById3.getVisible() ? R.drawable.ic_eye_off : R.drawable.ic_eye;
                String str3 = layerLayerById3.getVisible() ? "Hide" : "Show";
                boolean z = !layerLayerById3.getVisible();
                final Host host2 = h;
                arrayList.add(RadialMenus.item$default(radialMenus2, i, str3, z, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.2
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host2.getCtrl().toggleVisible(layerLayerById3.getId());
                    }
                }, 88, null));
                if (layerLayerById3.isLive()) {
                    boolean zIsCameraRecording = h.isCameraRecording(layerLayerById3);
                    RadialMenus radialMenus3 = RadialMenus.INSTANCE;
                    int i2 = zIsCameraRecording ? R.drawable.ic_stop : R.drawable.ic_camera;
                    String str4 = zIsCameraRecording ? "Stop take" : "Record take";
                    final Host host3 = h;
                    arrayList.add(RadialMenus.item$default(radialMenus3, i2, str4, zIsCameraRecording, zIsCameraRecording, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.3
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            host3.toggleCameraRecord(layerLayerById3);
                        }
                    }, 112, null));
                    RadialMenus radialMenus4 = RadialMenus.INSTANCE;
                    final Host host4 = h;
                    arrayList.add(RadialMenus.item$default(radialMenus4, R.drawable.ic_switch, "Switch cam", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.4
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            host4.switchCameraFacing(layerLayerById3);
                        }
                    }, 92, null));
                    RadialMenus radialMenus5 = RadialMenus.INSTANCE;
                    String str5 = layerLayerById3.getMirror() ? "Mirror: on" : "Mirror: off";
                    boolean mirror = layerLayerById3.getMirror();
                    final Host host5 = h;
                    arrayList.add(RadialMenus.item$default(radialMenus5, R.drawable.ic_loop, str5, mirror, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.5
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            host5.toggleCameraMirror(layerLayerById3);
                        }
                    }, 88, null));
                    RadialMenus radialMenus6 = RadialMenus.INSTANCE;
                    String str6 = (h.isTorchOn(layerLayerById3) || h.getScreenLight()) ? "ON" : null;
                    final Host host6 = h;
                    arrayList.add(radialMenus6.folder(R.drawable.ic_flash, "Light", str6, new Function0<RadialMenuView.Level>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.6
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(0);
                        }

                        /* JADX WARN: Can't rename method to resolve collision */
                        @Override // kotlin.jvm.functions.Function0
                        @NotNull
                        public final RadialMenuView.Level invoke() {
                            return RadialMenus.INSTANCE.flash(host6, layerLayerById3.getId());
                        }
                    }));
                } else if (layerLayerById3.isClip()) {
                    RadialMenus radialMenus7 = RadialMenus.INSTANCE;
                    int i3 = layerLayerById3.getPlaying() ? R.drawable.ic_pause : R.drawable.ic_play;
                    String str7 = layerLayerById3.getPlaying() ? "Pause" : "Play";
                    boolean z2 = !layerLayerById3.getPlaying();
                    final Host host7 = h;
                    arrayList.add(RadialMenus.item$default(radialMenus7, i3, str7, z2, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.7
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            host7.toggleSourcePlay(layerLayerById3);
                        }
                    }, 88, null));
                    boolean zEffectiveMuted = h.getCtrl().effectiveMuted(layerLayerById3);
                    RadialMenus radialMenus8 = RadialMenus.INSTANCE;
                    int i4 = zEffectiveMuted ? R.drawable.ic_volume_off : R.drawable.ic_volume;
                    String str8 = zEffectiveMuted ? "Unmute" : "Mute";
                    final Host host8 = h;
                    arrayList.add(RadialMenus.item$default(radialMenus8, i4, str8, zEffectiveMuted, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.8
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            host8.getCtrl().toggleMuted(layerLayerById3.getId());
                        }
                    }, 88, null));
                    RadialMenus radialMenus9 = RadialMenus.INSTANCE;
                    String str9 = layerLayerById3.getLoop() ? "Loop: on" : "Loop: off";
                    boolean loop = layerLayerById3.getLoop();
                    final Host host9 = h;
                    arrayList.add(RadialMenus.item$default(radialMenus9, R.drawable.ic_loop, str9, loop, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.9
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            host9.getCtrl().toggleLoop(layerLayerById3.getId());
                        }
                    }, 88, null));
                    RadialMenus radialMenus10 = RadialMenus.INSTANCE;
                    String str10 = layerLayerById3.getSolo() ? "Solo: on" : "Solo";
                    boolean solo = layerLayerById3.getSolo();
                    final Host host10 = h;
                    arrayList.add(RadialMenus.item$default(radialMenus10, R.drawable.ic_star, str10, solo, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.10
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            host10.getCtrl().toggleSolo(layerLayerById3.getId());
                        }
                    }, 88, null));
                }
                if (layerLayerById3.isText()) {
                    RadialMenus radialMenus11 = RadialMenus.INSTANCE;
                    final Host host11 = h;
                    arrayList.add(RadialMenus.item$default(radialMenus11, R.drawable.ic_edit, "Edit text", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.11
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            host11.editText(layerLayerById3);
                        }
                    }, 124, null));
                    RadialMenus radialMenus12 = RadialMenus.INSTANCE;
                    final Host host12 = h;
                    arrayList.add(RadialMenus.item$default(radialMenus12, R.drawable.ic_palette, "Colour", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.12
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            host12.cycleTextColor(layerLayerById3);
                        }
                    }, 92, null));
                } else {
                    RadialMenus radialMenus13 = RadialMenus.INSTANCE;
                    int i5 = Intrinsics.areEqual(layerLayerById3.getFit(), Layer.FIT_FIT) ? R.drawable.ic_fit : R.drawable.ic_fill;
                    String str11 = Intrinsics.areEqual(layerLayerById3.getFit(), Layer.FIT_FIT) ? "Fit: whole frame" : "Fill: crop to box";
                    boolean zAreEqual2 = Intrinsics.areEqual(layerLayerById3.getFit(), Layer.FIT_FIT);
                    final Host host13 = h;
                    arrayList.add(RadialMenus.item$default(radialMenus13, i5, str11, zAreEqual2, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.13
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            host13.getCtrl().toggleFit(layerLayerById3.getId());
                        }
                    }, 88, null));
                }
                RadialMenus radialMenus14 = RadialMenus.INSTANCE;
                int i6 = layerLayerById3.getLocked() ? R.drawable.ic_lock : R.drawable.ic_lock_open;
                String str12 = layerLayerById3.getLocked() ? "Unlock" : "Lock";
                boolean locked = layerLayerById3.getLocked();
                final Host host14 = h;
                arrayList.add(RadialMenus.item$default(radialMenus14, i6, str12, locked, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.14
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host14.getCtrl().toggleLocked(layerLayerById3.getId());
                    }
                }, 88, null));
                RadialMenus radialMenus15 = RadialMenus.INSTANCE;
                final Host host15 = h;
                arrayList.add(RadialMenus.folder$default(radialMenus15, R.drawable.ic_drag, "Arrange", null, new Function0<RadialMenuView.Level>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.15
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    /* JADX WARN: Can't rename method to resolve collision */
                    @Override // kotlin.jvm.functions.Function0
                    @NotNull
                    public final RadialMenuView.Level invoke() {
                        return RadialMenus.INSTANCE.arrange(host15, layerLayerById3.getId());
                    }
                }, 4, null));
                RadialMenus radialMenus16 = RadialMenus.INSTANCE;
                final Host host16 = h;
                arrayList.add(RadialMenus.item$default(radialMenus16, R.drawable.ic_settings, "Advanced…", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.16
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host16.openAdvanced(layerLayerById3);
                    }
                }, 124, null));
                if (!layerLayerById3.isLive()) {
                    RadialMenus radialMenus17 = RadialMenus.INSTANCE;
                    final Host host17 = h;
                    arrayList.add(RadialMenus.item$default(radialMenus17, R.drawable.ic_copy, "Duplicate", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.17
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            host17.getCtrl().duplicate(layerLayerById3.getId());
                        }
                    }, 124, null));
                }
                RadialMenus radialMenus18 = RadialMenus.INSTANCE;
                final Host host18 = h;
                arrayList.add(RadialMenus.item$default(radialMenus18, R.drawable.ic_delete, "Delete", false, true, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.source.2.18
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host18.getCtrl().delete(layerLayerById3.getId());
                    }
                }, 116, null));
                return arrayList;
            }
        });
    }

    @NotNull
    public final RadialMenuView.Level flash(@NotNull final Host h, @NotNull final String id) {
        Intrinsics.checkNotNullParameter(h, "h");
        Intrinsics.checkNotNullParameter(id, "id");
        return new RadialMenuView.Level(R.drawable.ic_flash, "Light", "front · back · both · screen flash", new Function0<List<? extends RadialMenuView.Item>>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.flash.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final List<? extends RadialMenuView.Item> invoke() {
                Layer layerLayerById = h.getProject().layerById(id);
                return layerLayerById == null ? CollectionsKt.emptyList() : RadialMenus.INSTANCE.flashItems(h, layerLayerById);
            }
        });
    }

    @NotNull
    public final RadialMenuView.Level arrange(@NotNull final Host h, @NotNull final String id) {
        Intrinsics.checkNotNullParameter(h, "h");
        Intrinsics.checkNotNullParameter(id, "id");
        return new RadialMenuView.Level(R.drawable.ic_drag, "Arrange", "position · size · z-order", new Function0<List<? extends RadialMenuView.Item>>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.arrange.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final List<? extends RadialMenuView.Item> invoke() {
                final Layer layerLayerById = h.getProject().layerById(id);
                if (layerLayerById == null) {
                    return CollectionsKt.emptyList();
                }
                RadialMenus radialMenus = RadialMenus.INSTANCE;
                final Host host = h;
                RadialMenus radialMenus2 = RadialMenus.INSTANCE;
                final Host host2 = h;
                RadialMenus radialMenus3 = RadialMenus.INSTANCE;
                final Host host3 = h;
                RadialMenus radialMenus4 = RadialMenus.INSTANCE;
                final Host host4 = h;
                RadialMenus radialMenus5 = RadialMenus.INSTANCE;
                final Host host5 = h;
                RadialMenus radialMenus6 = RadialMenus.INSTANCE;
                final Host host6 = h;
                RadialMenus radialMenus7 = RadialMenus.INSTANCE;
                final Host host7 = h;
                RadialMenus radialMenus8 = RadialMenus.INSTANCE;
                final Host host8 = h;
                RadialMenus radialMenus9 = RadialMenus.INSTANCE;
                final Host host9 = h;
                RadialMenus radialMenus10 = RadialMenus.INSTANCE;
                final Host host10 = h;
                return CollectionsKt.listOf((Object[]) new RadialMenuView.Item[]{RadialMenus.item$default(radialMenus, R.drawable.ic_up, "Bring forward", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.arrange.1.1
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host.getCtrl().moveZ(layerLayerById.getId(), "up");
                    }
                }, 92, null), RadialMenus.item$default(radialMenus2, R.drawable.ic_down, "Send backward", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.arrange.1.2
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host2.getCtrl().moveZ(layerLayerById.getId(), "down");
                    }
                }, 92, null), RadialMenus.item$default(radialMenus3, R.drawable.ic_up, "To front", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.arrange.1.3
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host3.getCtrl().moveZ(layerLayerById.getId(), "front");
                    }
                }, 92, null), RadialMenus.item$default(radialMenus4, R.drawable.ic_down, "To back", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.arrange.1.4
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host4.getCtrl().moveZ(layerLayerById.getId(), "back");
                    }
                }, 92, null), RadialMenus.item$default(radialMenus5, R.drawable.ic_reset, "Centre + unrotate", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.arrange.1.5
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host5.getCtrl().resetGeometry(layerLayerById.getId());
                    }
                }, 92, null), RadialMenus.item$default(radialMenus6, R.drawable.ic_corner_tl, "Corner: top-left", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.arrange.1.6
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host6.getCtrl().anchor(layerLayerById.getId(), "tl");
                    }
                }, 92, null), RadialMenus.item$default(radialMenus7, R.drawable.ic_corner_tr, "Corner: top-right", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.arrange.1.7
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host7.getCtrl().anchor(layerLayerById.getId(), "tr");
                    }
                }, 92, null), RadialMenus.item$default(radialMenus8, R.drawable.ic_corner_bl, "Corner: bottom-left", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.arrange.1.8
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host8.getCtrl().anchor(layerLayerById.getId(), "bl");
                    }
                }, 92, null), RadialMenus.item$default(radialMenus9, R.drawable.ic_corner_br, "Corner: bottom-right", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.arrange.1.9
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host9.getCtrl().anchor(layerLayerById.getId(), "br");
                    }
                }, 92, null), RadialMenus.item$default(radialMenus10, R.drawable.ic_fill, "Set as background", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.arrange.1.10
                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host10.getCtrl().setAsCanvasBackground(layerLayerById.getId());
                    }
                }, 124, null)});
            }
        });
    }

    @NotNull
    public final RadialMenuView.Level add(@NotNull final Host h) {
        Intrinsics.checkNotNullParameter(h, "h");
        return new RadialMenuView.Level(R.drawable.ic_add, "Add source", h.getProject().getLayers().isEmpty() ? "the first one fills the canvas" : "added as a PiP overlay", new Function0<List<? extends RadialMenuView.Item>>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.add.1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final List<? extends RadialMenuView.Item> invoke() {
                RadialMenus radialMenus = RadialMenus.INSTANCE;
                final Host host = h;
                RadialMenus radialMenus2 = RadialMenus.INSTANCE;
                final Host host2 = h;
                RadialMenus radialMenus3 = RadialMenus.INSTANCE;
                final Host host3 = h;
                RadialMenus radialMenus4 = RadialMenus.INSTANCE;
                final Host host4 = h;
                RadialMenus radialMenus5 = RadialMenus.INSTANCE;
                final Host host5 = h;
                return CollectionsKt.listOf((Object[]) new RadialMenuView.Item[]{RadialMenus.item$default(radialMenus, R.drawable.ic_camera, "Camera (live on canvas)", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.add.1.1
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host.addCameraLive();
                    }
                }, 124, null), RadialMenus.item$default(radialMenus2, R.drawable.ic_video, "Video file", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.add.1.2
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host2.addVideo();
                    }
                }, 124, null), RadialMenus.item$default(radialMenus3, R.drawable.ic_image, "Image", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.add.1.3
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host3.addImage();
                    }
                }, 124, null), RadialMenus.item$default(radialMenus4, R.drawable.ic_screen, "Screen record", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.add.1.4
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host4.addScreen();
                    }
                }, 124, null), RadialMenus.item$default(radialMenus5, R.drawable.ic_text, "Text overlay", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.add.1.5
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host5.addTextSource();
                    }
                }, 124, null)});
            }
        });
    }

    @NotNull
    public final RadialMenuView.Level canvas(@NotNull final Host h) {
        Intrinsics.checkNotNullParameter(h, "h");
        return new RadialMenuView.Level(R.drawable.ic_aspect, "Canvas", "ratio · background · layout", new Function0<List<? extends RadialMenuView.Item>>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.canvas.1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final List<? extends RadialMenuView.Item> invoke() {
                Project project = h.getProject();
                RadialMenuView.Item[] itemArr = new RadialMenuView.Item[7];
                RadialMenus radialMenus = RadialMenus.INSTANCE;
                boolean z = project.getAspect() == Aspect.R169;
                final Host host = h;
                itemArr[0] = RadialMenus.item$default(radialMenus, R.drawable.ic_aspect, "16:9", z, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.canvas.1.1
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host.setAspect(Aspect.R169);
                    }
                }, 88, null);
                RadialMenus radialMenus2 = RadialMenus.INSTANCE;
                boolean z2 = project.getAspect() == Aspect.R916;
                final Host host2 = h;
                itemArr[1] = RadialMenus.item$default(radialMenus2, R.drawable.ic_aspect, "9:16", z2, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.canvas.1.2
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host2.setAspect(Aspect.R916);
                    }
                }, 88, null);
                RadialMenus radialMenus3 = RadialMenus.INSTANCE;
                boolean z3 = project.getAspect() == Aspect.R11;
                final Host host3 = h;
                itemArr[2] = RadialMenus.item$default(radialMenus3, R.drawable.ic_aspect, "1:1", z3, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.canvas.1.3
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host3.setAspect(Aspect.R11);
                    }
                }, 88, null);
                RadialMenus radialMenus4 = RadialMenus.INSTANCE;
                final Host host4 = h;
                itemArr[3] = RadialMenus.folder$default(radialMenus4, R.drawable.ic_palette, "Background", null, new Function0<RadialMenuView.Level>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.canvas.1.4
                    {
                        super(0);
                    }

                    /* JADX WARN: Can't rename method to resolve collision */
                    @Override // kotlin.jvm.functions.Function0
                    @NotNull
                    public final RadialMenuView.Level invoke() {
                        return RadialMenus.INSTANCE.background(host4);
                    }
                }, 4, null);
                RadialMenus radialMenus5 = RadialMenus.INSTANCE;
                final Host host5 = h;
                itemArr[4] = RadialMenus.item$default(radialMenus5, R.drawable.ic_fullscreen, "Full canvas", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.canvas.1.5
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host5.enterFullCanvas();
                    }
                }, 124, null);
                RadialMenus radialMenus6 = RadialMenus.INSTANCE;
                final Host host6 = h;
                itemArr[5] = RadialMenus.item$default(radialMenus6, R.drawable.ic_fit, "Fit all sources", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.canvas.1.6
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host6.fitAllSources();
                    }
                }, 92, null);
                RadialMenus radialMenus7 = RadialMenus.INSTANCE;
                final Host host7 = h;
                itemArr[6] = RadialMenus.item$default(radialMenus7, R.drawable.ic_fill, "Selection as background", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.canvas.1.7
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        Layer layerSelected = host7.selected();
                        if (layerSelected == null) {
                            host7.toast("Select a source first");
                        } else {
                            host7.getCtrl().setAsCanvasBackground(layerSelected.getId());
                        }
                    }
                }, 92, null);
                return CollectionsKt.listOf((Object[]) itemArr);
            }
        });
    }

    @NotNull
    public final RadialMenuView.Level background(@NotNull final Host h) {
        Intrinsics.checkNotNullParameter(h, "h");
        return new RadialMenuView.Level(R.drawable.ic_palette, "Background", "canvas colour", new Function0<List<? extends RadialMenuView.Item>>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.background.1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final List<? extends RadialMenuView.Item> invoke() {
                RadialMenus radialMenus = RadialMenus.INSTANCE;
                final Host host = h;
                RadialMenus radialMenus2 = RadialMenus.INSTANCE;
                final Host host2 = h;
                RadialMenus radialMenus3 = RadialMenus.INSTANCE;
                final Host host3 = h;
                RadialMenus radialMenus4 = RadialMenus.INSTANCE;
                final Host host4 = h;
                RadialMenus radialMenus5 = RadialMenus.INSTANCE;
                final Host host5 = h;
                RadialMenus radialMenus6 = RadialMenus.INSTANCE;
                final Host host6 = h;
                RadialMenus radialMenus7 = RadialMenus.INSTANCE;
                final Host host7 = h;
                return CollectionsKt.listOf((Object[]) new RadialMenuView.Item[]{RadialMenus.item$default(radialMenus, R.drawable.ic_palette, "Dark", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.background.1.1
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host.setBg(-15723496);
                    }
                }, 92, null), RadialMenus.item$default(radialMenus2, R.drawable.ic_palette, "Black", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.background.1.2
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host2.setBg(-16777216);
                    }
                }, 92, null), RadialMenus.item$default(radialMenus3, R.drawable.ic_palette, "White", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.background.1.3
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host3.setBg(-1);
                    }
                }, 92, null), RadialMenus.item$default(radialMenus4, R.drawable.ic_palette, "Orange", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.background.1.4
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host4.setBg(-42452);
                    }
                }, 92, null), RadialMenus.item$default(radialMenus5, R.drawable.ic_palette, "Navy", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.background.1.5
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host5.setBg(-14795656);
                    }
                }, 92, null), RadialMenus.item$default(radialMenus6, R.drawable.ic_palette, "Green", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.background.1.6
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host6.setBg(-15435686);
                    }
                }, 92, null), RadialMenus.item$default(radialMenus7, R.drawable.ic_palette, "Purple", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.background.1.7
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host7.setBg(-8905126);
                    }
                }, 92, null)});
            }
        });
    }

    @NotNull
    public final RadialMenuView.Level export(@NotNull final Host h) {
        Intrinsics.checkNotNullParameter(h, "h");
        return new RadialMenuView.Level(R.drawable.ic_export, "Export", "render the composition", new Function0<List<? extends RadialMenuView.Item>>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.export.1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final List<? extends RadialMenuView.Item> invoke() {
                RadialMenus radialMenus = RadialMenus.INSTANCE;
                final Host host = h;
                RadialMenus radialMenus2 = RadialMenus.INSTANCE;
                final Host host2 = h;
                return CollectionsKt.listOf((Object[]) new RadialMenuView.Item[]{RadialMenus.item$default(radialMenus, R.drawable.ic_export, "Quick export 720p30", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.export.1.1
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host.quickExport();
                    }
                }, 124, null), RadialMenus.item$default(radialMenus2, R.drawable.ic_settings, "Export settings…", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.export.1.2
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host2.openExportPanel();
                    }
                }, 124, null)});
            }
        });
    }

    @NotNull
    public final RadialMenuView.Level project(@NotNull final Host h) {
        Intrinsics.checkNotNullParameter(h, "h");
        return new RadialMenuView.Level(R.drawable.ic_settings, "Project", h.getProject().getName(), new Function0<List<? extends RadialMenuView.Item>>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.project.1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            @NotNull
            public final List<? extends RadialMenuView.Item> invoke() {
                boolean zIsStatsHudOn = h.isStatsHudOn();
                RadialMenuView.Item[] itemArr = new RadialMenuView.Item[8];
                RadialMenus radialMenus = RadialMenus.INSTANCE;
                final Host host = h;
                itemArr[0] = RadialMenus.item$default(radialMenus, R.drawable.ic_edit, "Rename project", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.project.1.1
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host.renameProject();
                    }
                }, 124, null);
                RadialMenus radialMenus2 = RadialMenus.INSTANCE;
                final Host host2 = h;
                itemArr[1] = RadialMenus.item$default(radialMenus2, R.drawable.ic_check, "Save now", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.project.1.2
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host2.saveNow();
                    }
                }, 92, null);
                RadialMenus radialMenus3 = RadialMenus.INSTANCE;
                final Host host3 = h;
                itemArr[2] = RadialMenus.item$default(radialMenus3, R.drawable.ic_image, "Snapshot frame", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.project.1.3
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host3.snapshotFrame();
                    }
                }, 124, null);
                RadialMenus radialMenus4 = RadialMenus.INSTANCE;
                String str = zIsStatsHudOn ? "Stats overlay: on" : "Stats overlay: off";
                final Host host4 = h;
                itemArr[3] = RadialMenus.item$default(radialMenus4, R.drawable.ic_info, str, zIsStatsHudOn, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.project.1.4
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host4.toggleStatsHud();
                    }
                }, 88, null);
                RadialMenus radialMenus5 = RadialMenus.INSTANCE;
                final Host host5 = h;
                itemArr[4] = RadialMenus.item$default(radialMenus5, R.drawable.ic_undo, "Undo", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.project.1.5
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host5.undo();
                    }
                }, 92, null);
                RadialMenus radialMenus6 = RadialMenus.INSTANCE;
                final Host host6 = h;
                itemArr[5] = RadialMenus.item$default(radialMenus6, R.drawable.ic_redo, "Redo", false, false, null, true, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.project.1.6
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host6.redo();
                    }
                }, 92, null);
                RadialMenus radialMenus7 = RadialMenus.INSTANCE;
                final Host host7 = h;
                itemArr[6] = RadialMenus.item$default(radialMenus7, R.drawable.ic_info, "Diagnostics", false, false, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.project.1.7
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host7.openDiagnostics();
                    }
                }, 124, null);
                RadialMenus radialMenus8 = RadialMenus.INSTANCE;
                final Host host8 = h;
                itemArr[7] = RadialMenus.item$default(radialMenus8, R.drawable.ic_back, "Close project", false, true, null, false, false, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.editor.RadialMenus.project.1.8
                    {
                        super(0);
                    }

                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        host8.closeProject();
                    }
                }, 116, null);
                return CollectionsKt.listOf((Object[]) itemArr);
            }
        });
    }
}
