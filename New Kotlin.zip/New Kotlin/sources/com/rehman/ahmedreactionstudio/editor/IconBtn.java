package com.rehman.ahmedreactionstudio.editor;

import android.content.Context;
import android.view.MotionEvent;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.rehman.ahmedreactionstudio.util.UI;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: Icons.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\u0018\u0000 \u00162\u00020\u0001:\u0001\u0016B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0010\u0010\u000b\u001a\u00020\u00062\u0006\u0010\f\u001a\u00020\rH\u0016J$\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\b\b\u0002\u0010\u0012\u001a\u00020\u00112\n\b\u0002\u0010\u0013\u001a\u0004\u0018\u00010\u0014J\u0018\u0010\u0015\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00112\b\b\u0002\u0010\u0012\u001a\u00020\u0011R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/IconBtn;", "Landroid/widget/FrameLayout;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "downScale", "", "image", "Landroid/widget/ImageView;", "getImage", "()Landroid/widget/ImageView;", "onTouchEvent", "event", "Landroid/view/MotionEvent;", "setIcon", "", "resId", "", "tint", "desc", "", "setIconAnimated", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class IconBtn extends FrameLayout {

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);
    private boolean downScale;

    @NotNull
    private final ImageView image;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public IconBtn(@NotNull Context context) {
        super(context);
        Intrinsics.checkNotNullParameter(context, "context");
        this.image = new ImageView(context);
        int iDp = UI.INSTANCE.dp(context, 8);
        this.image.setPadding(iDp, iDp, iDp, iDp);
        addView(this.image, new FrameLayout.LayoutParams(-1, -1));
        setClickable(true);
        setFocusable(true);
    }

    @NotNull
    public final ImageView getImage() {
        return this.image;
    }

    public static /* synthetic */ void setIcon$default(IconBtn iconBtn, int i, int i2, String str, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i2 = UI.INSTANCE.getFG();
        }
        if ((i3 & 4) != 0) {
            str = null;
        }
        iconBtn.setIcon(i, i2, str);
    }

    public final void setIcon(int resId, int tint, @Nullable String desc) {
        ImageView imageView = this.image;
        Ic ic = Ic.INSTANCE;
        Context context = getContext();
        Intrinsics.checkNotNullExpressionValue(context, "getContext(...)");
        imageView.setImageDrawable(ic.get(context, resId, tint));
        if (desc != null) {
            setContentDescription(desc);
        }
    }

    public static /* synthetic */ void setIconAnimated$default(IconBtn iconBtn, int i, int i2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i2 = UI.INSTANCE.getFG();
        }
        iconBtn.setIconAnimated(i, i2);
    }

    public final void setIconAnimated(final int resId, final int tint) {
        animate().cancel();
        animate().scaleX(0.72f).scaleY(0.72f).setDuration(70L).withEndAction(new Runnable() { // from class: com.rehman.ahmedreactionstudio.editor.-$$Lambda$IconBtn$ToB0ol8v61EeP1ASix9UidCCFx4
            @Override // java.lang.Runnable
            public final void run() {
                IconBtn.setIconAnimated$lambda$0(this.f$0, resId, tint);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void setIconAnimated$lambda$0(IconBtn this$0, int i, int i2) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        setIcon$default(this$0, i, i2, null, 4, null);
        this$0.animate().scaleX(1.0f).scaleY(1.0f).setDuration(240L).setInterpolator(new OvershootInterpolator(2.2f)).start();
    }

    @Override // android.view.View
    public boolean onTouchEvent(@NotNull MotionEvent event) {
        Intrinsics.checkNotNullParameter(event, "event");
        int actionMasked = event.getActionMasked();
        if (actionMasked == 0) {
            this.downScale = true;
            performHapticFeedback(1);
            animate().cancel();
            animate().scaleX(0.86f).scaleY(0.86f).setDuration(80L).start();
        } else if (actionMasked != 1) {
            if (actionMasked == 3) {
                animate().cancel();
                animate().scaleX(1.0f).scaleY(1.0f).setDuration(150L).start();
            }
        } else if (this.downScale) {
            animate().cancel();
            animate().scaleX(1.0f).scaleY(1.0f).setDuration(300L).setInterpolator(new OvershootInterpolator(2.6f)).start();
        }
        return super.onTouchEvent(event);
    }

    /* JADX INFO: compiled from: Icons.kt */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\b"}, d2 = {"Lcom/rehman/ahmedreactionstudio/editor/IconBtn$Companion;", "", "()V", "sized", "Landroid/widget/FrameLayout$LayoutParams;", "ctx", "Landroid/content/Context;", "dpSize", ""}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public static /* synthetic */ FrameLayout.LayoutParams sized$default(Companion companion, Context context, int i, int i2, Object obj) {
            if ((i2 & 2) != 0) {
                i = 42;
            }
            return companion.sized(context, i);
        }

        @NotNull
        public final FrameLayout.LayoutParams sized(@NotNull Context ctx, int dpSize) {
            Intrinsics.checkNotNullParameter(ctx, "ctx");
            return new FrameLayout.LayoutParams(UI.INSTANCE.dp(ctx, dpSize), UI.INSTANCE.dp(ctx, dpSize));
        }
    }
}
