package com.rehman.ahmedreactionstudio.camera;

import android.content.Context;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.io.encoding.Base64;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: TorchController.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000y\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\f*\u0001\u001f\u0018\u0000 ;2\u00020\u0001:\u0003:;<B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\f\u0010%\u001a\b\u0012\u0004\u0012\u00020\b0\u001bJ\u0014\u0010&\u001a\b\u0012\u0004\u0012\u00020\u00070\u001b2\u0006\u0010'\u001a\u00020\u001dJ\u000e\u0010(\u001a\u00020\u00072\u0006\u0010'\u001a\u00020\u001dJ\u0006\u0010)\u001a\u00020\u0007J\u000e\u0010*\u001a\u00020\u001d2\u0006\u0010'\u001a\u00020\u001dJ\u000e\u0010+\u001a\u00020\u001d2\u0006\u0010'\u001a\u00020\u001dJ\u0014\u0010,\u001a\u00020-2\n\u0010.\u001a\u00060/j\u0002`0H\u0002J\u0006\u00101\u001a\u00020-J\u0006\u00102\u001a\u00020-J\u0016\u00103\u001a\u00020\u001d2\u0006\u0010'\u001a\u00020\u001d2\u0006\u00104\u001a\u00020\u001dJ\u0006\u00105\u001a\u00020-J\u0006\u00106\u001a\u00020-J\u0010\u00107\u001a\u0004\u0018\u00010\u00072\u0006\u0010'\u001a\u00020\u001dJ\u000e\u00108\u001a\u00020\u001d2\u0006\u0010'\u001a\u00020\u001dJ\u0010\u00109\u001a\u0004\u0018\u00010\u00072\u0006\u0010'\u001a\u00020\u001dR*\u0010\u0005\u001a\u001e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u0006j\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b`\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u000b\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\u0007@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u001e\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\n\u001a\u00020\u000e@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R*\u0010\u0012\u001a\u001e\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\u00070\u0013j\u000e\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\u0007`\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0018\u001a\u0004\u0018\u00010\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R6\u0010\u001a\u001a*\u0012\u0004\u0012\u00020\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00070\u001b0\u0013j\u0014\u0012\u0004\u0012\u00020\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00070\u001b`\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001e\u001a\u00020\u001fX\u0082\u0004¢\u0006\u0004\n\u0002\u0010 R*\u0010!\u001a\u001e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u001d0\u0013j\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u001d`\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\"\u001a\u0012\u0012\u0004\u0012\u00020\u00070#j\b\u0012\u0004\u0012\u00020\u0007`$X\u0082\u0004¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/camera/TorchController;", "", "ctx", "Landroid/content/Context;", "(Landroid/content/Context;)V", "cams", "Ljava/util/LinkedHashMap;", "", "Lcom/rehman/ahmedreactionstudio/camera/TorchController$Cam;", "Lkotlin/collections/LinkedHashMap;", "<set-?>", "lastError", "getLastError", "()Ljava/lang/String;", "Lcom/rehman/ahmedreactionstudio/camera/TorchController$Fail;", "lastFail", "getLastFail", "()Lcom/rehman/ahmedreactionstudio/camera/TorchController$Fail;", "lastUsed", "Ljava/util/HashMap;", "", "Lkotlin/collections/HashMap;", "mainHandler", "Landroid/os/Handler;", "manager", "Landroid/hardware/camera2/CameraManager;", "preferOrder", "", "registered", "", "torchCallback", "com/rehman/ahmedreactionstudio/camera/TorchController$torchCallback$1", "Lcom/rehman/ahmedreactionstudio/camera/TorchController$torchCallback$1;", "torchState", "torchUnavailable", "Ljava/util/HashSet;", "Lkotlin/collections/HashSet;", "cameraIds", "candidates", "front", "describe", "failureText", "hasFlash", "isTorchOn", "recordFail", "", "e", "Ljava/lang/Exception;", "Lkotlin/Exception;", "refresh", "releaseAll", "setTorch", "on", "shutdown", "start", "torchIdFor", "torchUnsupported", "usedTorchId", "Cam", "Companion", "Fail"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nTorchController.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TorchController.kt\ncom/rehman/ahmedreactionstudio/camera/TorchController\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,327:1\n766#2:328\n857#2,2:329\n1549#2:331\n1620#2,3:332\n1747#2,3:336\n1726#2,3:339\n766#2:342\n857#2,2:343\n1549#2:345\n1620#2,3:346\n1#3:335\n*S KotlinDebug\n*F\n+ 1 TorchController.kt\ncom/rehman/ahmedreactionstudio/camera/TorchController\n*L\n159#1:328\n159#1:329,2\n160#1:331\n160#1:332,3\n188#1:336,3\n194#1:339,3\n298#1:342\n298#1:343,2\n298#1:345\n298#1:346,3\n*E\n"})
public final class TorchController {
    private static final int BACK = 1;
    private static final int FRONT = 0;

    @NotNull
    private final LinkedHashMap<String, Cam> cams;

    @NotNull
    private final Context ctx;

    @NotNull
    private volatile String lastError;

    @NotNull
    private volatile Fail lastFail;

    @NotNull
    private final HashMap<Integer, String> lastUsed;

    @NotNull
    private final Handler mainHandler;

    @Nullable
    private final CameraManager manager;

    @NotNull
    private final HashMap<Integer, List<String>> preferOrder;
    private boolean registered;

    @NotNull
    private final TorchController$torchCallback$1 torchCallback;

    @NotNull
    private final HashMap<String, Boolean> torchState;

    @NotNull
    private final HashSet<String> torchUnavailable;

    /* JADX INFO: compiled from: TorchController.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\n\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000b"}, d2 = {"Lcom/rehman/ahmedreactionstudio/camera/TorchController$Fail;", "", "(Ljava/lang/String;I)V", "NONE", "NO_CAMERA_SERVICE", "NO_FLASH", "TORCH_UNSUPPORTED", "CAMERA_IN_USE", "CAMERA_DISCONNECTED", "CAMERA_DISABLED", "CAMERA_ERROR", "PERMISSION_DENIED"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public enum Fail {
        NONE,
        NO_CAMERA_SERVICE,
        NO_FLASH,
        TORCH_UNSUPPORTED,
        CAMERA_IN_USE,
        CAMERA_DISCONNECTED,
        CAMERA_DISABLED,
        CAMERA_ERROR,
        PERMISSION_DENIED;

        private static final /* synthetic */ EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

        @NotNull
        public static EnumEntries<Fail> getEntries() {
            return $ENTRIES;
        }
    }

    /* JADX INFO: compiled from: TorchController.kt */
    @Metadata(k = Base64.bytesPerGroup, mv = {1, 9, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[Fail.values().length];
            try {
                iArr[Fail.NONE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[Fail.NO_CAMERA_SERVICE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                iArr[Fail.NO_FLASH.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                iArr[Fail.TORCH_UNSUPPORTED.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                iArr[Fail.CAMERA_IN_USE.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                iArr[Fail.CAMERA_DISCONNECTED.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                iArr[Fail.CAMERA_DISABLED.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                iArr[Fail.CAMERA_ERROR.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                iArr[Fail.PERMISSION_DENIED.ordinal()] = 9;
            } catch (NoSuchFieldError unused9) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    /* JADX WARN: Type inference failed for: r2v11, types: [com.rehman.ahmedreactionstudio.camera.TorchController$torchCallback$1] */
    public TorchController(@NotNull Context ctx) {
        CameraManager cameraManager;
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        this.ctx = ctx;
        try {
            Object systemService = this.ctx.getSystemService("camera");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.hardware.camera2.CameraManager");
            cameraManager = (CameraManager) systemService;
        } catch (Exception unused) {
            cameraManager = null;
        }
        this.manager = cameraManager;
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.cams = new LinkedHashMap<>();
        this.torchState = new HashMap<>();
        this.torchUnavailable = new HashSet<>();
        this.preferOrder = new HashMap<>();
        this.lastUsed = new HashMap<>();
        this.lastFail = Fail.NONE;
        this.lastError = "";
        this.torchCallback = new CameraManager.TorchCallback() { // from class: com.rehman.ahmedreactionstudio.camera.TorchController$torchCallback$1
            @Override // android.hardware.camera2.CameraManager.TorchCallback
            public void onTorchModeChanged(@NotNull String cameraId, boolean enabled) {
                Intrinsics.checkNotNullParameter(cameraId, "cameraId");
                TorchController torchController = this.this$0;
                synchronized (torchController) {
                    torchController.torchState.put(cameraId, Boolean.valueOf(enabled));
                    if (enabled) {
                        torchController.torchUnavailable.remove(cameraId);
                    }
                    Unit unit = Unit.INSTANCE;
                }
            }

            @Override // android.hardware.camera2.CameraManager.TorchCallback
            public void onTorchModeUnavailable(@NotNull String cameraId) {
                Intrinsics.checkNotNullParameter(cameraId, "cameraId");
                TorchController torchController = this.this$0;
                synchronized (torchController) {
                    torchController.torchUnavailable.add(cameraId);
                }
            }
        };
    }

    /* JADX INFO: compiled from: TorchController.kt */
    @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0012\b\u0086\b\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0005¢\u0006\u0002\u0010\tJ\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0007HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0005HÆ\u0003J1\u0010\u0015\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u0016\u001a\u00020\u00072\b\u0010\u0017\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0019\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000b"}, d2 = {"Lcom/rehman/ahmedreactionstudio/camera/TorchController$Cam;", "", "id", "", "facing", "", "flash", "", "level", "(Ljava/lang/String;IZI)V", "getFacing", "()I", "getFlash", "()Z", "getId", "()Ljava/lang/String;", "getLevel", "component1", "component2", "component3", "component4", "copy", "equals", "other", "hashCode", "toString"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final /* data */ class Cam {
        private final int facing;
        private final boolean flash;

        @NotNull
        private final String id;
        private final int level;

        public static /* synthetic */ Cam copy$default(Cam cam, String str, int i, boolean z, int i2, int i3, Object obj) {
            if ((i3 & 1) != 0) {
                str = cam.id;
            }
            if ((i3 & 2) != 0) {
                i = cam.facing;
            }
            if ((i3 & 4) != 0) {
                z = cam.flash;
            }
            if ((i3 & 8) != 0) {
                i2 = cam.level;
            }
            return cam.copy(str, i, z, i2);
        }

        @NotNull
        /* JADX INFO: renamed from: component1, reason: from getter */
        public final String getId() {
            return this.id;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final int getFacing() {
            return this.facing;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final boolean getFlash() {
            return this.flash;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final int getLevel() {
            return this.level;
        }

        @NotNull
        public final Cam copy(@NotNull String id, int facing, boolean flash, int level) {
            Intrinsics.checkNotNullParameter(id, "id");
            return new Cam(id, facing, flash, level);
        }

        public boolean equals(@Nullable Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Cam)) {
                return false;
            }
            Cam cam = (Cam) other;
            return Intrinsics.areEqual(this.id, cam.id) && this.facing == cam.facing && this.flash == cam.flash && this.level == cam.level;
        }

        public int hashCode() {
            return (((((this.id.hashCode() * 31) + Integer.hashCode(this.facing)) * 31) + Boolean.hashCode(this.flash)) * 31) + Integer.hashCode(this.level);
        }

        @NotNull
        public String toString() {
            return "Cam(id=" + this.id + ", facing=" + this.facing + ", flash=" + this.flash + ", level=" + this.level + ')';
        }

        public Cam(@NotNull String id, int i, boolean z, int i2) {
            Intrinsics.checkNotNullParameter(id, "id");
            this.id = id;
            this.facing = i;
            this.flash = z;
            this.level = i2;
        }

        @NotNull
        public final String getId() {
            return this.id;
        }

        public final int getFacing() {
            return this.facing;
        }

        public final boolean getFlash() {
            return this.flash;
        }

        public final int getLevel() {
            return this.level;
        }
    }

    @NotNull
    public final Fail getLastFail() {
        return this.lastFail;
    }

    @NotNull
    public final String getLastError() {
        return this.lastError;
    }

    public final void start() {
        CameraManager cameraManager;
        if (this.registered || (cameraManager = this.manager) == null) {
            return;
        }
        try {
            cameraManager.registerTorchCallback(this.torchCallback, this.mainHandler);
            this.registered = true;
        } catch (Exception unused) {
            this.registered = false;
        }
        refresh();
    }

    public final void shutdown() {
        releaseAll();
        CameraManager cameraManager = this.manager;
        if (cameraManager != null && this.registered) {
            try {
                cameraManager.unregisterTorchCallback(this.torchCallback);
            } catch (Exception unused) {
            }
        }
        this.registered = false;
    }

    public final void refresh() {
        int iIntValue;
        synchronized (this) {
            this.cams.clear();
            this.preferOrder.clear();
            CameraManager cameraManager = this.manager;
            if (cameraManager == null) {
                return;
            }
            try {
                String[] cameraIdList = cameraManager.getCameraIdList();
                Intrinsics.checkNotNullExpressionValue(cameraIdList, "getCameraIdList(...)");
                for (String str : cameraIdList) {
                    try {
                        CameraCharacteristics cameraCharacteristics = cameraManager.getCameraCharacteristics(str);
                        Integer num = (Integer) cameraCharacteristics.get(CameraCharacteristics.LENS_FACING);
                        int iIntValue2 = -1;
                        if (num == null) {
                            iIntValue = -1;
                        } else {
                            Intrinsics.checkNotNull(num);
                            iIntValue = num.intValue();
                        }
                        boolean zAreEqual = Intrinsics.areEqual(cameraCharacteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE), (Object) true);
                        Integer num2 = (Integer) cameraCharacteristics.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL);
                        if (num2 != null) {
                            Intrinsics.checkNotNull(num2);
                            iIntValue2 = num2.intValue();
                        }
                        LinkedHashMap<String, Cam> linkedHashMap = this.cams;
                        Intrinsics.checkNotNull(str);
                        linkedHashMap.put(str, new Cam(str, iIntValue, zAreEqual, iIntValue2));
                    } catch (Exception unused) {
                    }
                }
                int[] iArr = {1, 0};
                int length = iArr.length;
                for (int i = 0; i < length; i++) {
                    int i2 = iArr[i];
                    Collection<Cam> collectionValues = this.cams.values();
                    Intrinsics.checkNotNullExpressionValue(collectionValues, "<get-values>(...)");
                    ArrayList arrayList = new ArrayList();
                    for (Object obj : collectionValues) {
                        Cam cam = (Cam) obj;
                        if (cam.getFacing() == i2 && cam.getFlash()) {
                            arrayList.add(obj);
                        }
                    }
                    ArrayList arrayList2 = arrayList;
                    ArrayList arrayList3 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList2, 10));
                    Iterator it = arrayList2.iterator();
                    while (it.hasNext()) {
                        arrayList3.add(((Cam) it.next()).getId());
                    }
                    List<String> listSorted = CollectionsKt.sorted(arrayList3);
                    if (!listSorted.isEmpty()) {
                        this.preferOrder.put(Integer.valueOf(i2), listSorted);
                    }
                }
            } catch (Exception unused2) {
            }
            Unit unit = Unit.INSTANCE;
        }
    }

    @NotNull
    public final List<String> candidates(boolean front) {
        List<String> listEmptyList;
        synchronized (this) {
            listEmptyList = this.preferOrder.get(Integer.valueOf(front ? 0 : 1));
            if (listEmptyList == null) {
                listEmptyList = CollectionsKt.emptyList();
            } else {
                Intrinsics.checkNotNull(listEmptyList);
            }
        }
        Intrinsics.checkNotNullExpressionValue(listEmptyList, "synchronized(...)");
        return listEmptyList;
    }

    public final boolean hasFlash(boolean front) {
        return !candidates(front).isEmpty();
    }

    @Nullable
    public final String torchIdFor(boolean front) {
        return (String) CollectionsKt.firstOrNull((List) candidates(front));
    }

    @Nullable
    public final String usedTorchId(boolean front) {
        String str;
        synchronized (this) {
            str = this.lastUsed.get(Integer.valueOf(front ? 0 : 1));
        }
        return str;
    }

    public final boolean isTorchOn(boolean front) {
        boolean z;
        synchronized (this) {
            List<String> listCandidates = candidates(front);
            z = false;
            if (!(listCandidates instanceof Collection) || !listCandidates.isEmpty()) {
                Iterator<T> it = listCandidates.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    if (Intrinsics.areEqual((Object) this.torchState.get((String) it.next()), (Object) true)) {
                        z = true;
                        break;
                    }
                }
            }
        }
        return z;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean torchUnsupported(boolean r5) {
        /*
            r4 = this;
            java.util.List r5 = r4.candidates(r5)
            r0 = r5
            java.util.Collection r0 = (java.util.Collection) r0
            boolean r0 = r0.isEmpty()
            r1 = 1
            r0 = r0 ^ r1
            r2 = 0
            if (r0 == 0) goto L3d
            java.lang.Iterable r5 = (java.lang.Iterable) r5
            boolean r0 = r5 instanceof java.util.Collection
            if (r0 == 0) goto L21
            r0 = r5
            java.util.Collection r0 = (java.util.Collection) r0
            boolean r0 = r0.isEmpty()
            if (r0 == 0) goto L21
        L1f:
            r5 = r1
            goto L3a
        L21:
            java.util.Iterator r5 = r5.iterator()
        L25:
            boolean r0 = r5.hasNext()
            if (r0 == 0) goto L1f
            java.lang.Object r0 = r5.next()
            java.lang.String r0 = (java.lang.String) r0
            java.util.HashSet<java.lang.String> r3 = r4.torchUnavailable
            boolean r0 = r3.contains(r0)
            if (r0 != 0) goto L25
            r5 = r2
        L3a:
            if (r5 == 0) goto L3d
            goto L3e
        L3d:
            r1 = r2
        L3e:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.camera.TorchController.torchUnsupported(boolean):boolean");
    }

    @NotNull
    public final String describe(boolean front) {
        String str;
        String str2;
        List<String> listCandidates = candidates(front);
        if (listCandidates.isEmpty()) {
            return "none — screen light only";
        }
        String strUsedTorchId = usedTorchId(front);
        if (isTorchOn(front)) {
            str = "LED on";
        } else {
            str = torchUnsupported(front) ? "LED present, torch mode unsupported" : "LED off";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("id ");
        sb.append((String) CollectionsKt.firstOrNull((List) listCandidates));
        if (strUsedTorchId == null || Intrinsics.areEqual(strUsedTorchId, CollectionsKt.firstOrNull((List) listCandidates))) {
            str2 = "";
        } else {
            str2 = " (used " + strUsedTorchId + ')';
        }
        sb.append(str2);
        sb.append(" · ");
        sb.append(str);
        return sb.toString();
    }

    @NotNull
    public final String failureText() {
        switch (WhenMappings.$EnumSwitchMapping$0[this.lastFail.ordinal()]) {
            case 1:
                return "";
            case 2:
                return "No camera service on this device";
            case Base64.bytesPerGroup /* 3 */:
                return "No hardware flash on this camera";
            case 4:
                return "Torch mode unsupported on this device";
            case 5:
                return "Camera is in use by another app";
            case 6:
                return "Camera disconnected";
            case 7:
                return "Camera disabled by policy";
            case 8:
                return "Camera error: " + this.lastError;
            case 9:
                return "Camera permission denied";
            default:
                throw new NoWhenBranchMatchedException();
        }
    }

    @NotNull
    public final List<Cam> cameraIds() {
        List<Cam> list;
        synchronized (this) {
            Collection<Cam> collectionValues = this.cams.values();
            Intrinsics.checkNotNullExpressionValue(collectionValues, "<get-values>(...)");
            list = CollectionsKt.toList(collectionValues);
        }
        return list;
    }

    public final boolean setTorch(boolean front, boolean on) {
        boolean zAreEqual;
        start();
        int i = !front ? 1 : 0;
        List<String> listCandidates = candidates(front);
        if (listCandidates.isEmpty()) {
            this.lastFail = Fail.NO_FLASH;
            this.lastError = "no flash unit";
            return false;
        }
        CameraManager cameraManager = this.manager;
        if (cameraManager == null) {
            this.lastFail = Fail.NO_CAMERA_SERVICE;
            this.lastError = "no CameraManager";
            return false;
        }
        this.lastFail = Fail.NONE;
        this.lastError = "";
        if (!on) {
            boolean z = false;
            for (String str : listCandidates) {
                try {
                    cameraManager.setTorchMode(str, false);
                    synchronized (this) {
                        this.torchState.put(str, false);
                        Unit unit = Unit.INSTANCE;
                    }
                    z = true;
                } catch (Exception e) {
                    recordFail(e);
                }
            }
            return z;
        }
        for (String str2 : listCandidates) {
            synchronized (this) {
                zAreEqual = Intrinsics.areEqual((Object) this.torchState.get(str2), (Object) true);
            }
            if (zAreEqual) {
                synchronized (this) {
                    this.lastUsed.put(Integer.valueOf(i), str2);
                    Unit unit2 = Unit.INSTANCE;
                }
                return true;
            }
            try {
                cameraManager.setTorchMode(str2, true);
                synchronized (this) {
                    this.torchState.put(str2, true);
                    this.lastUsed.put(Integer.valueOf(i), str2);
                    Unit unit3 = Unit.INSTANCE;
                }
                return true;
            } catch (Exception e2) {
                recordFail(e2);
                int i2 = WhenMappings.$EnumSwitchMapping$0[this.lastFail.ordinal()];
                if (i2 == 7 || i2 == 9) {
                    return false;
                }
            }
        }
        return false;
    }

    public final void releaseAll() {
        boolean zIsEmpty;
        ArrayList arrayList;
        CameraManager cameraManager = this.manager;
        if (cameraManager == null) {
            return;
        }
        synchronized (this) {
            zIsEmpty = this.cams.isEmpty();
        }
        if (zIsEmpty) {
            refresh();
        }
        synchronized (this) {
            Collection<Cam> collectionValues = this.cams.values();
            Intrinsics.checkNotNullExpressionValue(collectionValues, "<get-values>(...)");
            ArrayList arrayList2 = new ArrayList();
            for (Object obj : collectionValues) {
                if (((Cam) obj).getFlash()) {
                    arrayList2.add(obj);
                }
            }
            ArrayList arrayList3 = arrayList2;
            ArrayList arrayList4 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList3, 10));
            Iterator it = arrayList3.iterator();
            while (it.hasNext()) {
                arrayList4.add(((Cam) it.next()).getId());
            }
            arrayList = arrayList4;
        }
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            try {
                cameraManager.setTorchMode((String) it2.next(), false);
            } catch (Exception unused) {
            }
        }
        synchronized (this) {
            this.torchState.clear();
            this.lastUsed.clear();
            Unit unit = Unit.INSTANCE;
        }
    }

    private final void recordFail(Exception e) {
        Fail fail;
        String message = e.getMessage();
        if (message == null) {
            message = e.getClass().getSimpleName();
            Intrinsics.checkNotNullExpressionValue(message, "getSimpleName(...)");
        }
        this.lastError = message;
        if (e instanceof SecurityException) {
            fail = Fail.PERMISSION_DENIED;
        } else if (e instanceof IllegalArgumentException) {
            fail = Fail.TORCH_UNSUPPORTED;
        } else if (e instanceof CameraAccessException) {
            int reason = ((CameraAccessException) e).getReason();
            if (reason == 1) {
                fail = Fail.CAMERA_DISABLED;
            } else if (reason == 2) {
                fail = Fail.CAMERA_DISCONNECTED;
            } else if (reason == 4 || reason == 5) {
                fail = Fail.CAMERA_IN_USE;
            } else {
                fail = Fail.CAMERA_ERROR;
            }
        } else {
            fail = Fail.CAMERA_ERROR;
        }
        this.lastFail = fail;
    }
}
