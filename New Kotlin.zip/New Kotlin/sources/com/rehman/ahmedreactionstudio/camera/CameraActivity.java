package com.rehman.ahmedreactionstudio.camera;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import com.rehman.ahmedreactionstudio.R;
import com.rehman.ahmedreactionstudio.camera.CameraActivity;
import com.rehman.ahmedreactionstudio.core.MediaInfo;
import com.rehman.ahmedreactionstudio.core.MediaKit;
import com.rehman.ahmedreactionstudio.core.ProjectStore;
import com.rehman.ahmedreactionstudio.editor.Ic;
import com.rehman.ahmedreactionstudio.util.UI;
import java.io.File;
import java.util.Arrays;
import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: CameraActivity.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000·\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0011\n\u0000\n\u0002\u0010\u0015\n\u0002\b\u0013*\u0001/\u0018\u0000 d2\u00020\u0001:\u0001dB\u0005¢\u0006\u0002\u0010\u0002J\b\u00108\u001a\u000209H\u0002J\b\u0010:\u001a\u000209H\u0002J\b\u0010;\u001a\u000209H\u0002J\b\u0010<\u001a\u000209H\u0002J\u0010\u0010=\u001a\u00020\b2\u0006\u0010>\u001a\u00020\fH\u0002J\b\u0010?\u001a\u000209H\u0002J\b\u0010@\u001a\u000209H\u0002J\b\u0010A\u001a\u00020BH\u0002J\b\u0010C\u001a\u000209H\u0002J\b\u0010D\u001a\u00020\u0012H\u0002J\b\u0010E\u001a\u00020\u0012H\u0002J\b\u0010F\u001a\u00020\u0012H\u0002J\u0012\u0010G\u001a\u0002092\b\u0010H\u001a\u0004\u0018\u00010IH\u0014J\b\u0010J\u001a\u000209H\u0014J\b\u0010K\u001a\u000209H\u0014J-\u0010L\u001a\u0002092\u0006\u0010M\u001a\u00020\f2\u000e\u0010N\u001a\n\u0012\u0006\b\u0001\u0012\u00020\b0O2\u0006\u0010P\u001a\u00020QH\u0016¢\u0006\u0002\u0010RJ\b\u0010S\u001a\u000209H\u0014J\b\u0010T\u001a\u000209H\u0002J\b\u0010U\u001a\u000209H\u0002J\u0010\u0010V\u001a\u0002092\u0006\u0010W\u001a\u00020\u0012H\u0002J\b\u0010X\u001a\u000209H\u0002J\b\u0010Y\u001a\u000209H\u0002J\b\u0010Z\u001a\u000209H\u0002J\b\u0010[\u001a\u000209H\u0002J\b\u0010\\\u001a\u000209H\u0002J\b\u0010]\u001a\u000209H\u0002J\b\u0010^\u001a\u000209H\u0002J\b\u0010_\u001a\u000209H\u0002J\b\u0010`\u001a\u000209H\u0002J\b\u0010a\u001a\u000209H\u0002J\b\u0010b\u001a\u000209H\u0002J\b\u0010c\u001a\u000209H\u0002R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0015\u001a\u0004\u0018\u00010\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010\u001a\u001a\u0004\u0018\u00010\u001bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001e\u001a\u0004\u0018\u00010\u001fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010#\u001a\u0004\u0018\u00010$X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u0019X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020(X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u0019X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020+X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020\u0019X\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010.\u001a\u00020/X\u0082\u0004¢\u0006\u0004\n\u0002\u00100R\u000e\u00101\u001a\u000202X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u00103\u001a\u00020\u0019X\u0082.¢\u0006\u0002\n\u0000R\u000e\u00104\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00105\u001a\u00020\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00106\u001a\u000207X\u0082.¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/camera/CameraActivity;", "Landroid/app/Activity;", "()V", "bgHandler", "Landroid/os/Handler;", "bgThread", "Landroid/os/HandlerThread;", "cameraId", "", "device", "Landroid/hardware/camera2/CameraDevice;", "facing", "", "flashView", "Landroid/view/View;", "maxZoom", "", "opening", "", "previewSize", "Landroid/util/Size;", "previewSurface", "Landroid/view/Surface;", "projectId", "recordBtn", "Landroid/widget/TextView;", "recordFile", "Ljava/io/File;", "recordStart", "", "recorder", "Landroid/media/MediaRecorder;", "recording", CameraActivity.EXTRA_ROLE, "sensorOrientation", "session", "Landroid/hardware/camera2/CameraCaptureSession;", "started", "statusLabel", "store", "Lcom/rehman/ahmedreactionstudio/core/ProjectStore;", "switchBtn", "texture", "Landroid/view/TextureView;", "timerHandler", "timerLabel", "timerTick", "com/rehman/ahmedreactionstudio/camera/CameraActivity$timerTick$1", "Lcom/rehman/ahmedreactionstudio/camera/CameraActivity$timerTick$1;", "torch", "Lcom/rehman/ahmedreactionstudio/camera/TorchController;", "torchBtn", "torchOn", "torchViaRequest", "zoomSlider", "Landroid/widget/SeekBar;", "applyParams", "", "applyTorch", "applyTorchLocked", "buildUi", "cameraIdFor", "lens", "closeCamera", "closeCameraLocked", "cm", "Landroid/hardware/camera2/CameraManager;", "createPreviewSession", "hasPermissions", "hwTorch", "isFront", "onCreate", "b", "Landroid/os/Bundle;", "onDestroy", "onPause", "onRequestPermissionsResult", "code", "perms", "", "res", "", "(I[Ljava/lang/String;[I)V", "onResume", "openCamera", "openCameraLocked", "setScreenLight", "on", "startBg", "startRecording", "startRecordingLocked", "stopBg", "stopRecording", "stopRecordingLocked", "toggleCamera", "toggleRecord", "toggleTorch", "torchOff", "updatePreviewTransform", "updateTorchLabel", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nCameraActivity.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CameraActivity.kt\ncom/rehman/ahmedreactionstudio/camera/CameraActivity\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 ArrayIntrinsics.kt\nkotlin/ArrayIntrinsicsKt\n+ 4 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 5 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,781:1\n1#2:782\n26#3:783\n1282#4,2:784\n1282#4,2:786\n1282#4,2:788\n6523#4:790\n288#5,2:791\n*S KotlinDebug\n*F\n+ 1 CameraActivity.kt\ncom/rehman/ahmedreactionstudio/camera/CameraActivity\n*L\n373#1:783\n374#1:784,2\n375#1:786,2\n637#1:788,2\n639#1:790\n639#1:791,2\n*E\n"})
public final class CameraActivity extends Activity {

    @NotNull
    public static final String EXTRA_PROJECT_ID = "pid";

    @NotNull
    public static final String EXTRA_RESULT_REL = "rel";

    @NotNull
    public static final String EXTRA_ROLE = "role";
    private static final int REQ_PERMS = 100;

    @Nullable
    private Handler bgHandler;

    @Nullable
    private HandlerThread bgThread;

    @Nullable
    private String cameraId;

    @Nullable
    private CameraDevice device;
    private int facing;
    private View flashView;
    private boolean opening;

    @Nullable
    private Surface previewSurface;
    private TextView recordBtn;

    @Nullable
    private File recordFile;
    private long recordStart;

    @Nullable
    private MediaRecorder recorder;
    private boolean recording;

    @Nullable
    private CameraCaptureSession session;
    private boolean started;
    private TextView statusLabel;
    private ProjectStore store;
    private TextView switchBtn;
    private TextureView texture;
    private TextView timerLabel;
    private TextView torchBtn;
    private volatile boolean torchOn;
    private volatile boolean torchViaRequest;
    private SeekBar zoomSlider;

    @NotNull
    private String projectId = "";

    @NotNull
    private String role = "main";

    @NotNull
    private Size previewSize = new Size(1280, 720);
    private int sensorOrientation = 90;

    @NotNull
    private final TorchController torch = new TorchController(this);
    private float maxZoom = 1.0f;

    @NotNull
    private final Handler timerHandler = new Handler(Looper.getMainLooper());

    @NotNull
    private final CameraActivity$timerTick$1 timerTick = new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.CameraActivity$timerTick$1
        @Override // java.lang.Runnable
        public void run() {
            if (this.this$0.recording) {
                long jElapsedRealtime = (SystemClock.elapsedRealtime() - this.this$0.recordStart) / ((long) 1000);
                TextView textView = this.this$0.timerLabel;
                if (textView == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("timerLabel");
                    textView = null;
                }
                StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
                long j = 60;
                Object[] objArr = {Long.valueOf(jElapsedRealtime / j), Long.valueOf(jElapsedRealtime % j)};
                String str = String.format("%02d:%02d", Arrays.copyOf(objArr, objArr.length));
                Intrinsics.checkNotNullExpressionValue(str, "format(...)");
                textView.setText(str);
                this.this$0.timerHandler.postDelayed(this, 250L);
            }
        }
    };

    @Override // android.app.Activity
    protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        UI.styleWindow$default(UI.INSTANCE, this, false, 2, null);
        String stringExtra = getIntent().getStringExtra("pid");
        if (stringExtra == null) {
            finish();
            return;
        }
        this.projectId = stringExtra;
        String stringExtra2 = getIntent().getStringExtra(EXTRA_ROLE);
        if (stringExtra2 == null) {
            stringExtra2 = "main";
        }
        this.role = stringExtra2;
        this.store = new ProjectStore(this);
        setRequestedOrientation(6);
        buildUi();
        if (hasPermissions()) {
            return;
        }
        requestPermissions(new String[]{"android.permission.CAMERA", "android.permission.RECORD_AUDIO"}, REQ_PERMS);
    }

    private final boolean hasPermissions() {
        return checkSelfPermission("android.permission.CAMERA") == 0;
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int code, @NotNull String[] perms, @NotNull int[] res) {
        Intrinsics.checkNotNullParameter(perms, "perms");
        Intrinsics.checkNotNullParameter(res, "res");
        if (code == REQ_PERMS) {
            if (!hasPermissions()) {
                UI.INSTANCE.toast(this, "Camera permission is needed to record reaction takes.");
                finish();
            }
            TextureView textureView = this.texture;
            if (textureView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("texture");
                textureView = null;
            }
            if (textureView.isAvailable()) {
                openCamera();
            }
        }
    }

    private final void buildUi() {
        CameraActivity cameraActivity = this;
        FrameLayout frameLayout = new FrameLayout(cameraActivity);
        frameLayout.setBackgroundColor(-16777216);
        this.texture = new TextureView(cameraActivity);
        TextureView textureView = this.texture;
        if (textureView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("texture");
            textureView = null;
        }
        frameLayout.addView(textureView, new FrameLayout.LayoutParams(-1, -1));
        TextureView textureView2 = this.texture;
        if (textureView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("texture");
            textureView2 = null;
        }
        textureView2.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() { // from class: com.rehman.ahmedreactionstudio.camera.CameraActivity.buildUi.1
            @Override // android.view.TextureView.SurfaceTextureListener
            public boolean onSurfaceTextureDestroyed(@NotNull SurfaceTexture st) {
                Intrinsics.checkNotNullParameter(st, "st");
                return true;
            }

            @Override // android.view.TextureView.SurfaceTextureListener
            public void onSurfaceTextureUpdated(@NotNull SurfaceTexture st) {
                Intrinsics.checkNotNullParameter(st, "st");
            }

            @Override // android.view.TextureView.SurfaceTextureListener
            public void onSurfaceTextureAvailable(@NotNull SurfaceTexture st, int w, int h) {
                Intrinsics.checkNotNullParameter(st, "st");
                CameraActivity.this.openCamera();
            }

            @Override // android.view.TextureView.SurfaceTextureListener
            public void onSurfaceTextureSizeChanged(@NotNull SurfaceTexture st, int w, int h) {
                Intrinsics.checkNotNullParameter(st, "st");
                CameraActivity.this.updatePreviewTransform();
            }
        });
        this.flashView = new View(cameraActivity);
        View view = this.flashView;
        if (view == null) {
            Intrinsics.throwUninitializedPropertyAccessException("flashView");
            view = null;
        }
        view.setBackgroundColor(-1);
        View view2 = this.flashView;
        if (view2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("flashView");
            view2 = null;
        }
        view2.setAlpha(0.0f);
        View view3 = this.flashView;
        if (view3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("flashView");
            view3 = null;
        }
        view3.setClickable(false);
        View view4 = this.flashView;
        if (view4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("flashView");
            view4 = null;
        }
        frameLayout.addView(view4, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout = new LinearLayout(cameraActivity);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        linearLayout.setPadding(UI.INSTANCE.dp(cameraActivity, 10), UI.INSTANCE.dp(cameraActivity, 12), UI.INSTANCE.dp(cameraActivity, 10), UI.INSTANCE.dp(cameraActivity, 8));
        linearLayout.setBackgroundColor(Color.argb(90, 0, 0, 0));
        frameLayout.addView(linearLayout, new FrameLayout.LayoutParams(-1, -2, 48));
        TextView textViewChip = UI.INSTANCE.chip(cameraActivity, "Close");
        textViewChip.setCompoundDrawablesRelativeWithIntrinsicBounds(Ic.INSTANCE.get(cameraActivity, R.drawable.ic_back, UI.INSTANCE.getFG()), (Drawable) null, (Drawable) null, (Drawable) null);
        textViewChip.setCompoundDrawablePadding(UI.INSTANCE.dp(cameraActivity, 4));
        textViewChip.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$nWstH3ekR8rn2VfEm7jEIojz76E
            @Override // android.view.View.OnClickListener
            public final void onClick(View view5) {
                CameraActivity.buildUi$lambda$1(this.f$0, view5);
            }
        });
        linearLayout.addView(textViewChip);
        TextView textView = new TextView(cameraActivity);
        textView.setText(Intrinsics.areEqual(this.role, "main") ? "Record main canvas" : "Record PiP reaction");
        textView.setTextColor(-1);
        textView.setTextSize(13.0f);
        textView.setGravity(17);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams.gravity = 16;
        textView.setLayoutParams(layoutParams);
        linearLayout.addView(textView);
        this.statusLabel = UI.INSTANCE.label(cameraActivity, "", false, 12.0f);
        TextView textView2 = this.statusLabel;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("statusLabel");
            textView2 = null;
        }
        textView2.setTextColor(-1);
        TextView textView3 = this.statusLabel;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("statusLabel");
            textView3 = null;
        }
        textView3.setGravity(8388613);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams2.gravity = 16;
        TextView textView4 = this.statusLabel;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("statusLabel");
            textView4 = null;
        }
        textView4.setLayoutParams(layoutParams2);
        TextView textView5 = this.statusLabel;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("statusLabel");
            textView5 = null;
        }
        linearLayout.addView(textView5);
        LinearLayout linearLayout2 = new LinearLayout(cameraActivity);
        linearLayout2.setOrientation(1);
        linearLayout2.setGravity(1);
        linearLayout2.setPadding(UI.INSTANCE.dp(cameraActivity, 12), UI.INSTANCE.dp(cameraActivity, 14), UI.INSTANCE.dp(cameraActivity, 12), UI.INSTANCE.dp(cameraActivity, 20));
        linearLayout2.setBackgroundColor(Color.argb(120, 0, 0, 0));
        frameLayout.addView(linearLayout2, new FrameLayout.LayoutParams(-1, -2, 80));
        this.timerLabel = new TextView(cameraActivity);
        TextView textView6 = this.timerLabel;
        if (textView6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("timerLabel");
            textView6 = null;
        }
        textView6.setText("00:00");
        TextView textView7 = this.timerLabel;
        if (textView7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("timerLabel");
            textView7 = null;
        }
        textView7.setTextColor(-1);
        TextView textView8 = this.timerLabel;
        if (textView8 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("timerLabel");
            textView8 = null;
        }
        textView8.setTextSize(20.0f);
        TextView textView9 = this.timerLabel;
        if (textView9 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("timerLabel");
            textView9 = null;
        }
        textView9.setTypeface(Typeface.create("monospace", 1));
        TextView textView10 = this.timerLabel;
        if (textView10 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("timerLabel");
            textView10 = null;
        }
        linearLayout2.addView(textView10);
        LinearLayout linearLayout3 = new LinearLayout(cameraActivity);
        linearLayout3.setOrientation(0);
        linearLayout3.setGravity(16);
        linearLayout2.addView(linearLayout3);
        final TextView textViewLabel = UI.INSTANCE.label(cameraActivity, "1×", false, 12.0f);
        textViewLabel.setTextColor(-1);
        linearLayout3.addView(textViewLabel);
        this.zoomSlider = new SeekBar(cameraActivity);
        SeekBar seekBar = this.zoomSlider;
        if (seekBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("zoomSlider");
            seekBar = null;
        }
        seekBar.setMax(REQ_PERMS);
        SeekBar seekBar2 = this.zoomSlider;
        if (seekBar2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("zoomSlider");
            seekBar2 = null;
        }
        seekBar2.setProgress(0);
        SeekBar seekBar3 = this.zoomSlider;
        if (seekBar3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("zoomSlider");
            seekBar3 = null;
        }
        seekBar3.setProgressTintList(ColorStateList.valueOf(-1));
        SeekBar seekBar4 = this.zoomSlider;
        if (seekBar4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("zoomSlider");
            seekBar4 = null;
        }
        seekBar4.setThumbTintList(ColorStateList.valueOf(-1));
        SeekBar seekBar5 = this.zoomSlider;
        if (seekBar5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("zoomSlider");
            seekBar5 = null;
        }
        seekBar5.setLayoutParams(new LinearLayout.LayoutParams(UI.INSTANCE.dp(cameraActivity, 200), -2));
        SeekBar seekBar6 = this.zoomSlider;
        if (seekBar6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("zoomSlider");
            seekBar6 = null;
        }
        linearLayout3.addView(seekBar6);
        linearLayout3.addView(UI.INSTANCE.label(cameraActivity, "🔍", false, 13.0f));
        SeekBar seekBar7 = this.zoomSlider;
        if (seekBar7 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("zoomSlider");
            seekBar7 = null;
        }
        seekBar7.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: com.rehman.ahmedreactionstudio.camera.CameraActivity.buildUi.3
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(@Nullable SeekBar s) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(@Nullable SeekBar s) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(@Nullable SeekBar s, int v, boolean u) {
                TextView textView11 = textViewLabel;
                StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
                Object[] objArr = {Float.valueOf(((v / 100.0f) * RangesKt.coerceAtLeast(this.maxZoom - 1.0f, 0.0f)) + 1.0f)};
                String str = String.format("%.1f×", Arrays.copyOf(objArr, objArr.length));
                Intrinsics.checkNotNullExpressionValue(str, "format(...)");
                textView11.setText(str);
                if (u) {
                    this.applyParams();
                }
            }
        });
        LinearLayout linearLayout4 = new LinearLayout(cameraActivity);
        linearLayout4.setOrientation(0);
        linearLayout4.setGravity(17);
        linearLayout2.addView(linearLayout4);
        this.switchBtn = UI.INSTANCE.chip(cameraActivity, "Camera");
        TextView textView11 = this.switchBtn;
        if (textView11 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("switchBtn");
            textView11 = null;
        }
        textView11.setCompoundDrawablesRelativeWithIntrinsicBounds(Ic.INSTANCE.get(cameraActivity, R.drawable.ic_switch, UI.INSTANCE.getFG()), (Drawable) null, (Drawable) null, (Drawable) null);
        TextView textView12 = this.switchBtn;
        if (textView12 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("switchBtn");
            textView12 = null;
        }
        textView12.setCompoundDrawablePadding(UI.INSTANCE.dp(cameraActivity, 4));
        TextView textView13 = this.switchBtn;
        if (textView13 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("switchBtn");
            textView13 = null;
        }
        textView13.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$ZG_fOWu73Y07lcVLFCthaXiRpaE
            @Override // android.view.View.OnClickListener
            public final void onClick(View view5) {
                CameraActivity.buildUi$lambda$2(this.f$0, view5);
            }
        });
        TextView textView14 = this.switchBtn;
        if (textView14 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("switchBtn");
            textView14 = null;
        }
        linearLayout4.addView(textView14);
        UI ui = UI.INSTANCE;
        TextView textView15 = this.switchBtn;
        if (textView15 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("switchBtn");
            textView15 = null;
        }
        ui.margin(textView15, 0, 0, 10, 0, cameraActivity);
        this.torchBtn = UI.INSTANCE.chip(cameraActivity, "Flash");
        TextView textView16 = this.torchBtn;
        if (textView16 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("torchBtn");
            textView16 = null;
        }
        textView16.setCompoundDrawablesRelativeWithIntrinsicBounds(Ic.INSTANCE.get(cameraActivity, R.drawable.ic_flash, UI.INSTANCE.getFG()), (Drawable) null, (Drawable) null, (Drawable) null);
        TextView textView17 = this.torchBtn;
        if (textView17 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("torchBtn");
            textView17 = null;
        }
        textView17.setCompoundDrawablePadding(UI.INSTANCE.dp(cameraActivity, 4));
        TextView textView18 = this.torchBtn;
        if (textView18 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("torchBtn");
            textView18 = null;
        }
        textView18.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$9oL59ouvXpLtpgqQ6BD3wa2HKCQ
            @Override // android.view.View.OnClickListener
            public final void onClick(View view5) {
                CameraActivity.buildUi$lambda$3(this.f$0, view5);
            }
        });
        TextView textView19 = this.torchBtn;
        if (textView19 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("torchBtn");
            textView19 = null;
        }
        linearLayout4.addView(textView19);
        UI ui2 = UI.INSTANCE;
        TextView textView20 = this.torchBtn;
        if (textView20 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("torchBtn");
            textView20 = null;
        }
        ui2.margin(textView20, 0, 0, 10, 0, cameraActivity);
        this.recordBtn = new TextView(cameraActivity);
        TextView textView21 = this.recordBtn;
        if (textView21 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
            textView21 = null;
        }
        textView21.setText("●");
        TextView textView22 = this.recordBtn;
        if (textView22 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
            textView22 = null;
        }
        textView22.setGravity(17);
        TextView textView23 = this.recordBtn;
        if (textView23 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
            textView23 = null;
        }
        textView23.setTextColor(-1);
        TextView textView24 = this.recordBtn;
        if (textView24 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
            textView24 = null;
        }
        textView24.setTextSize(26.0f);
        TextView textView25 = this.recordBtn;
        if (textView25 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
            textView25 = null;
        }
        textView25.setContentDescription("Start recording");
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(UI.INSTANCE.dpf(cameraActivity, 34.0f));
        gradientDrawable.setColor(-1754827);
        TextView textView26 = this.recordBtn;
        if (textView26 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
            textView26 = null;
        }
        textView26.setBackground(gradientDrawable);
        TextView textView27 = this.recordBtn;
        if (textView27 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
            textView27 = null;
        }
        textView27.setTag(gradientDrawable);
        TextView textView28 = this.recordBtn;
        if (textView28 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
            textView28 = null;
        }
        textView28.setLayoutParams(new LinearLayout.LayoutParams(UI.INSTANCE.dp(cameraActivity, 68), UI.INSTANCE.dp(cameraActivity, 68)));
        TextView textView29 = this.recordBtn;
        if (textView29 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
            textView29 = null;
        }
        textView29.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$07a-fl2yVjY4PlTgf8LMhkoMld0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view5) {
                CameraActivity.buildUi$lambda$4(this.f$0, view5);
            }
        });
        TextView textView30 = this.recordBtn;
        if (textView30 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
            textView30 = null;
        }
        linearLayout4.addView(textView30);
        TextView textViewLabel2 = UI.INSTANCE.label(cameraActivity, "Tap the red button to record this camera", false, 11.0f);
        textViewLabel2.setTextColor(Color.argb(200, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams3.topMargin = UI.INSTANCE.dp(cameraActivity, 6);
        textViewLabel2.setLayoutParams(layoutParams3);
        linearLayout2.addView(textViewLabel2);
        setContentView(frameLayout);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildUi$lambda$1(CameraActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.finish();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildUi$lambda$2(CameraActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.toggleCamera();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildUi$lambda$3(CameraActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.toggleTorch();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildUi$lambda$4(CameraActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.toggleRecord();
    }

    private final void startBg() {
        if (this.bgThread != null) {
            return;
        }
        HandlerThread handlerThread = new HandlerThread("cam");
        handlerThread.start();
        this.bgThread = handlerThread;
        HandlerThread handlerThread2 = this.bgThread;
        Intrinsics.checkNotNull(handlerThread2);
        this.bgHandler = new Handler(handlerThread2.getLooper());
    }

    private final void stopBg() {
        HandlerThread handlerThread = this.bgThread;
        if (handlerThread != null) {
            handlerThread.quitSafely();
        }
        try {
            HandlerThread handlerThread2 = this.bgThread;
            if (handlerThread2 != null) {
                handlerThread2.join(800L);
            }
        } catch (Exception unused) {
        }
        this.bgThread = null;
        this.bgHandler = null;
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        startBg();
        try {
            this.torch.start();
        } catch (Exception unused) {
        }
        if (hasPermissions()) {
            TextureView textureView = this.texture;
            if (textureView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("texture");
                textureView = null;
            }
            if (textureView.isAvailable()) {
                openCamera();
            }
        }
    }

    @Override // android.app.Activity
    protected void onPause() {
        closeCamera();
        stopBg();
        super.onPause();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        try {
            this.torch.shutdown();
        } catch (Exception unused) {
        }
        super.onDestroy();
    }

    private final CameraManager cm() {
        Object systemService = getSystemService("camera");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.hardware.camera2.CameraManager");
        return (CameraManager) systemService;
    }

    private final String cameraIdFor(int lens) {
        try {
            String[] cameraIdList = cm().getCameraIdList();
            Intrinsics.checkNotNullExpressionValue(cameraIdList, "getCameraIdList(...)");
            for (String str : cameraIdList) {
                Integer num = (Integer) cm().getCameraCharacteristics(str).get(CameraCharacteristics.LENS_FACING);
                if (num != null && num.intValue() == lens) {
                    Intrinsics.checkNotNull(str);
                    return str;
                }
            }
            String[] cameraIdList2 = cm().getCameraIdList();
            Intrinsics.checkNotNullExpressionValue(cameraIdList2, "getCameraIdList(...)");
            String str2 = (String) ArraysKt.firstOrNull(cameraIdList2);
            return str2 == null ? "" : str2;
        } catch (Exception unused) {
            return "";
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void openCamera() {
        Handler handler;
        if (hasPermissions() && (handler = this.bgHandler) != null) {
            handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$howpgQKJbT6e0sGcPlHedkw5AxI
                @Override // java.lang.Runnable
                public final void run() {
                    CameraActivity.openCamera$lambda$7(this.f$0);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void openCamera$lambda$7(final CameraActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (this$0.opening || this$0.started) {
            return;
        }
        this$0.opening = true;
        try {
            this$0.openCameraLocked();
        } catch (Exception unused) {
            this$0.opening = false;
            this$0.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$a5Cokq3K91cp1KQp9m49LOlf2UI
                @Override // java.lang.Runnable
                public final void run() {
                    CameraActivity.openCamera$lambda$7$lambda$6(this.f$0);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void openCamera$lambda$7$lambda$6(CameraActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        TextView textView = this$0.statusLabel;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("statusLabel");
            textView = null;
        }
        textView.setText("Camera unavailable");
    }

    private final void openCameraLocked() throws CameraAccessException {
        String strCameraIdFor;
        Size size;
        closeCameraLocked();
        if (this.facing == 1) {
            strCameraIdFor = cameraIdFor(1);
        } else {
            strCameraIdFor = cameraIdFor(0);
        }
        if (strCameraIdFor.length() == 0) {
            this.opening = false;
            runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$FetbXlmJ-CVYyYUwt8bp9m0BM1Y
                @Override // java.lang.Runnable
                public final void run() {
                    CameraActivity.openCameraLocked$lambda$8(this.f$0);
                }
            });
            return;
        }
        this.cameraId = strCameraIdFor;
        CameraCharacteristics cameraCharacteristics = cm().getCameraCharacteristics(strCameraIdFor);
        Integer num = (Integer) cameraCharacteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
        this.sensorOrientation = num == null ? 90 : num.intValue();
        this.torch.refresh();
        runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$qFcHaPkIYSUQ8sYolSp8cQ2vFUM
            @Override // java.lang.Runnable
            public final void run() {
                CameraActivity.openCameraLocked$lambda$9(this.f$0);
            }
        });
        Float f = (Float) cameraCharacteristics.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
        this.maxZoom = f == null ? 1.0f : f.floatValue();
        StreamConfigurationMap streamConfigurationMap = (StreamConfigurationMap) cameraCharacteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        Size[] outputSizes = streamConfigurationMap != null ? streamConfigurationMap.getOutputSizes(SurfaceTexture.class) : null;
        if (outputSizes == null) {
            outputSizes = new Size[0];
        }
        int length = outputSizes.length;
        int i = 0;
        while (true) {
            if (i >= length) {
                size = null;
                break;
            }
            size = outputSizes[i];
            if (size.getWidth() == 1280 && size.getHeight() == 720) {
                break;
            } else {
                i++;
            }
        }
        if (size == null) {
            int length2 = outputSizes.length;
            int i2 = 0;
            while (true) {
                if (i2 >= length2) {
                    size = null;
                    break;
                }
                size = outputSizes[i2];
                int width = size.getWidth();
                if (640 <= width && width < 1921) {
                    break;
                } else {
                    i2++;
                }
            }
            if (size == null && (size = (Size) ArraysKt.firstOrNull(outputSizes)) == null) {
                size = new Size(1280, 720);
            }
        }
        this.previewSize = size;
        runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$8_XUW2My2Lj0mW2tNw9iMDFIb78
            @Override // java.lang.Runnable
            public final void run() {
                CameraActivity.openCameraLocked$lambda$12(this.f$0);
            }
        });
        cm().openCamera(strCameraIdFor, new AnonymousClass6(), this.bgHandler);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void openCameraLocked$lambda$8(CameraActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        TextView textView = this$0.statusLabel;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("statusLabel");
            textView = null;
        }
        textView.setText("No camera found");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void openCameraLocked$lambda$9(CameraActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.updateTorchLabel();
    }

    /* JADX INFO: renamed from: com.rehman.ahmedreactionstudio.camera.CameraActivity$openCameraLocked$6, reason: invalid class name */
    /* JADX INFO: compiled from: CameraActivity.kt */
    @Metadata(d1 = {"\u0000\u001f\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\u0018\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\bH\u0016J\u0010\u0010\t\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016"}, d2 = {"com/rehman/ahmedreactionstudio/camera/CameraActivity$openCameraLocked$6", "Landroid/hardware/camera2/CameraDevice$StateCallback;", "onDisconnected", "", "camera", "Landroid/hardware/camera2/CameraDevice;", "onError", "error", "", "onOpened"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class AnonymousClass6 extends CameraDevice.StateCallback {
        AnonymousClass6() {
        }

        @Override // android.hardware.camera2.CameraDevice.StateCallback
        public void onOpened(@NotNull CameraDevice camera) {
            Intrinsics.checkNotNullParameter(camera, "camera");
            CameraActivity.this.opening = false;
            CameraActivity.this.started = true;
            CameraActivity.this.device = camera;
            CameraActivity.this.createPreviewSession();
        }

        @Override // android.hardware.camera2.CameraDevice.StateCallback
        public void onDisconnected(@NotNull CameraDevice camera) {
            Intrinsics.checkNotNullParameter(camera, "camera");
            CameraActivity.this.opening = false;
            CameraActivity.this.started = false;
            CameraActivity.this.torchOff();
            try {
                camera.close();
            } catch (Exception unused) {
            }
            CameraActivity.this.device = null;
        }

        @Override // android.hardware.camera2.CameraDevice.StateCallback
        public void onError(@NotNull CameraDevice camera, final int error) {
            Intrinsics.checkNotNullParameter(camera, "camera");
            CameraActivity.this.opening = false;
            CameraActivity.this.started = false;
            CameraActivity.this.torchOff();
            try {
                camera.close();
            } catch (Exception unused) {
            }
            CameraActivity.this.device = null;
            final CameraActivity cameraActivity = CameraActivity.this;
            cameraActivity.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$openCameraLocked$6$Ot4dLvTGeP8YB0KZhfB1OQySUq8
                @Override // java.lang.Runnable
                public final void run() {
                    CameraActivity.AnonymousClass6.onError$lambda$0(cameraActivity, error);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void onError$lambda$0(CameraActivity this$0, int i) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            TextView textView = this$0.statusLabel;
            if (textView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("statusLabel");
                textView = null;
            }
            textView.setText("Camera error " + i);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void openCameraLocked$lambda$12(CameraActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.updatePreviewTransform();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void updatePreviewTransform() {
        TextureView textureView = this.texture;
        TextureView textureView2 = null;
        if (textureView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("texture");
            textureView = null;
        }
        SurfaceTexture surfaceTexture = textureView.getSurfaceTexture();
        if (surfaceTexture == null) {
            return;
        }
        TextureView textureView3 = this.texture;
        if (textureView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("texture");
            textureView3 = null;
        }
        int width = textureView3.getWidth();
        TextureView textureView4 = this.texture;
        if (textureView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("texture");
            textureView4 = null;
        }
        int height = textureView4.getHeight();
        if (width == 0 || height == 0) {
            return;
        }
        float f = width;
        float f2 = height;
        float f3 = f / f2;
        float width2 = this.previewSize.getWidth() / this.previewSize.getHeight();
        Matrix matrix = new Matrix();
        int rotation = (((this.sensorOrientation + (this.facing == 0 ? 180 : 0)) - (getWindowManager().getDefaultDisplay().getRotation() * 90)) + 360) % 360;
        if (rotation == 90 || rotation == 270) {
            matrix.postScale((1.0f / f3) * width2, (f3 / width2) * 1.0f);
        } else {
            matrix.postScale((f3 / width2) * 1.0f, (1.0f / f3) * width2);
        }
        float f4 = f / 2.0f;
        float f5 = f2 / 2.0f;
        matrix.postRotate(rotation, f4, f5);
        if (this.facing == 0) {
            matrix.postScale(-1.0f, 1.0f, f4, f5);
        }
        TextureView textureView5 = this.texture;
        if (textureView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("texture");
        } else {
            textureView2 = textureView5;
        }
        textureView2.setTransform(matrix);
        surfaceTexture.setDefaultBufferSize(this.previewSize.getWidth(), this.previewSize.getHeight());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void createPreviewSession() {
        CameraDevice cameraDevice = this.device;
        if (cameraDevice == null) {
            return;
        }
        TextureView textureView = this.texture;
        if (textureView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("texture");
            textureView = null;
        }
        SurfaceTexture surfaceTexture = textureView.getSurfaceTexture();
        if (surfaceTexture == null) {
            return;
        }
        try {
            surfaceTexture.setDefaultBufferSize(this.previewSize.getWidth(), this.previewSize.getHeight());
            try {
                Surface surface = this.previewSurface;
                if (surface != null) {
                    surface.release();
                }
            } catch (Exception unused) {
            }
            Surface surface2 = new Surface(surfaceTexture);
            this.previewSurface = surface2;
            cameraDevice.createCaptureSession(CollectionsKt.listOf(surface2), new C00101(), this.bgHandler);
        } catch (Exception unused2) {
            runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$La91IDXawEE0DyPnvyzDeRCV_J8
                @Override // java.lang.Runnable
                public final void run() {
                    CameraActivity.createPreviewSession$lambda$13(this.f$0);
                }
            });
        }
    }

    /* JADX INFO: renamed from: com.rehman.ahmedreactionstudio.camera.CameraActivity$createPreviewSession$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: CameraActivity.kt */
    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\u0010\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016"}, d2 = {"com/rehman/ahmedreactionstudio/camera/CameraActivity$createPreviewSession$1", "Landroid/hardware/camera2/CameraCaptureSession$StateCallback;", "onConfigureFailed", "", "s", "Landroid/hardware/camera2/CameraCaptureSession;", "onConfigured"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class C00101 extends CameraCaptureSession.StateCallback {
        C00101() {
        }

        @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
        public void onConfigured(@NotNull CameraCaptureSession s) {
            Intrinsics.checkNotNullParameter(s, "s");
            CameraActivity.this.session = s;
            CameraActivity.this.applyParams();
            final CameraActivity cameraActivity = CameraActivity.this;
            cameraActivity.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$createPreviewSession$1$JI7WC_FMlYpT1LbBuCpgNcjkrAc
                @Override // java.lang.Runnable
                public final void run() {
                    CameraActivity.C00101.onConfigured$lambda$0(cameraActivity);
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void onConfigured$lambda$0(CameraActivity this$0) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            TextView textView = this$0.statusLabel;
            if (textView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("statusLabel");
                textView = null;
            }
            textView.setText("");
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void onConfigureFailed$lambda$1(CameraActivity this$0) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            TextView textView = this$0.statusLabel;
            if (textView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("statusLabel");
                textView = null;
            }
            textView.setText("Preview failed");
        }

        @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
        public void onConfigureFailed(@NotNull CameraCaptureSession s) {
            Intrinsics.checkNotNullParameter(s, "s");
            final CameraActivity cameraActivity = CameraActivity.this;
            cameraActivity.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$createPreviewSession$1$xS9a1DEaonQqhg5jgDLmp8MXN0c
                @Override // java.lang.Runnable
                public final void run() {
                    CameraActivity.C00101.onConfigureFailed$lambda$1(cameraActivity);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void createPreviewSession$lambda$13(CameraActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        TextView textView = this$0.statusLabel;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("statusLabel");
            textView = null;
        }
        textView.setText("Preview failed");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void applyParams() {
        CameraCaptureSession cameraCaptureSession;
        Surface surface;
        CameraDevice cameraDevice = this.device;
        if (cameraDevice == null || (cameraCaptureSession = this.session) == null || (surface = this.previewSurface) == null) {
            return;
        }
        try {
            CaptureRequest.Builder builderCreateCaptureRequest = cameraDevice.createCaptureRequest(this.recording ? 3 : 1);
            builderCreateCaptureRequest.addTarget(surface);
            if (this.recording) {
                MediaRecorder mediaRecorder = this.recorder;
                Surface surface2 = mediaRecorder != null ? mediaRecorder.getSurface() : null;
                if (surface2 != null) {
                    builderCreateCaptureRequest.addTarget(surface2);
                }
            }
            builderCreateCaptureRequest.set(CaptureRequest.CONTROL_MODE, 1);
            builderCreateCaptureRequest.set(CaptureRequest.FLASH_MODE, Integer.valueOf((this.torchOn && this.torchViaRequest) ? 2 : 0));
            if (this.torchOn && this.torchViaRequest) {
                builderCreateCaptureRequest.set(CaptureRequest.CONTROL_AE_MODE, 1);
            }
            String str = this.cameraId;
            if (str != null) {
                CameraCharacteristics cameraCharacteristics = cm().getCameraCharacteristics(str);
                Float f = (Float) cameraCharacteristics.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
                float fFloatValue = f == null ? 1.0f : f.floatValue();
                if (fFloatValue > 1.0f) {
                    SeekBar seekBar = this.zoomSlider;
                    if (seekBar == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("zoomSlider");
                        seekBar = null;
                    }
                    float progress = 1.0f + ((seekBar.getProgress() / 100.0f) * (fFloatValue - 1.0f));
                    Rect rect = (Rect) cameraCharacteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
                    if (rect != null && progress > 1.01f) {
                        int iWidth = (int) (rect.width() / progress);
                        int iHeight = (int) (rect.height() / progress);
                        builderCreateCaptureRequest.set(CaptureRequest.SCALER_CROP_REGION, new Rect(rect.centerX() - (iWidth / 2), rect.centerY() - (iHeight / 2), rect.centerX() + (iWidth / 2), rect.centerY() + (iHeight / 2)));
                    }
                }
            }
            cameraCaptureSession.setRepeatingRequest(builderCreateCaptureRequest.build(), null, this.bgHandler);
        } catch (Exception unused) {
        }
    }

    private final void closeCamera() {
        Handler handler = this.bgHandler;
        if (handler == null) {
            closeCameraLocked();
        } else {
            handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$IO27Xd2sa7T6KLzlGcZwztsrFxc
                @Override // java.lang.Runnable
                public final void run() {
                    CameraActivity.closeCamera$lambda$14(this.f$0);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void closeCamera$lambda$14(CameraActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.closeCameraLocked();
    }

    private final void closeCameraLocked() {
        try {
            CameraCaptureSession cameraCaptureSession = this.session;
            if (cameraCaptureSession != null) {
                cameraCaptureSession.close();
            }
        } catch (Exception unused) {
        }
        this.session = null;
        try {
            CameraDevice cameraDevice = this.device;
            if (cameraDevice != null) {
                cameraDevice.close();
            }
        } catch (Exception unused2) {
        }
        this.device = null;
        try {
            Surface surface = this.previewSurface;
            if (surface != null) {
                surface.release();
            }
        } catch (Exception unused3) {
        }
        this.previewSurface = null;
        this.opening = false;
        this.started = false;
        torchOff();
    }

    private final boolean isFront() {
        return this.facing == 0;
    }

    private final boolean hwTorch() {
        return this.torch.hasFlash(isFront());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void torchOff() {
        this.torchOn = false;
        this.torchViaRequest = false;
        try {
            this.torch.releaseAll();
        } catch (Exception unused) {
        }
        runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$qhIxt989lFNugfXR9cVR7OFZDzs
            @Override // java.lang.Runnable
            public final void run() {
                CameraActivity.torchOff$lambda$15(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void torchOff$lambda$15(CameraActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.setScreenLight(false);
    }

    private final void setScreenLight(boolean on) {
        try {
            View view = this.flashView;
            if (view == null) {
                Intrinsics.throwUninitializedPropertyAccessException("flashView");
                view = null;
            }
            view.animate().alpha(on ? 0.85f : 0.0f).setDuration(120L).start();
        } catch (Exception unused) {
        }
    }

    private final void toggleCamera() {
        if (this.recording || this.opening) {
            return;
        }
        torchOff();
        this.facing = this.facing == 1 ? 0 : 1;
        SeekBar seekBar = this.zoomSlider;
        if (seekBar == null) {
            Intrinsics.throwUninitializedPropertyAccessException("zoomSlider");
            seekBar = null;
        }
        seekBar.setProgress(0);
        openCamera();
    }

    private final void updateTorchLabel() {
        String str;
        boolean zIsFront = isFront();
        if (hwTorch()) {
            TextView textView = this.torchBtn;
            if (textView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("torchBtn");
                textView = null;
            }
            textView.setEnabled(true);
            TextView textView2 = this.torchBtn;
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("torchBtn");
                textView2 = null;
            }
            if (this.torchOn) {
                str = zIsFront ? "Front torch ON" : "Torch ON";
            } else {
                str = zIsFront ? "Front torch" : "Torch";
            }
            textView2.setText(str);
            return;
        }
        if (zIsFront) {
            TextView textView3 = this.torchBtn;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("torchBtn");
                textView3 = null;
            }
            textView3.setEnabled(true);
            TextView textView4 = this.torchBtn;
            if (textView4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("torchBtn");
                textView4 = null;
            }
            textView4.setText(this.torchOn ? "Screen light ON" : "Screen light");
            return;
        }
        this.torchOn = false;
        setScreenLight(false);
        TextView textView5 = this.torchBtn;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("torchBtn");
            textView5 = null;
        }
        textView5.setText("No flash");
        TextView textView6 = this.torchBtn;
        if (textView6 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("torchBtn");
            textView6 = null;
        }
        textView6.setEnabled(false);
    }

    private final void toggleTorch() {
        boolean zIsFront = isFront();
        boolean z = !this.torchOn;
        this.torchOn = z;
        if (hwTorch()) {
            setScreenLight(false);
            applyTorch();
        } else if (zIsFront) {
            setScreenLight(z);
        } else {
            this.torchOn = false;
            setScreenLight(false);
            UI.INSTANCE.toast(this, "This device has no rear flash");
        }
        updateTorchLabel();
    }

    private final void applyTorch() {
        Handler handler = this.bgHandler;
        if (handler == null) {
            applyTorchLocked();
        } else {
            handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$O1q5bGY_T84ujgGsmbB_Xi-2YsQ
                @Override // java.lang.Runnable
                public final void run() {
                    CameraActivity.applyTorch$lambda$16(this.f$0);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void applyTorch$lambda$16(CameraActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.applyTorchLocked();
    }

    private final void applyTorchLocked() {
        boolean zIsFront = isFront();
        if (!hwTorch()) {
            this.torchViaRequest = false;
            return;
        }
        if (this.torchOn) {
            boolean torch = this.torch.setTorch(zIsFront, true);
            this.torchViaRequest = !torch;
            if (!torch && !this.torchViaRequest) {
                this.torchOn = false;
                runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$a5Gip_zc0__v4IfoGZrHEHA07jU
                    @Override // java.lang.Runnable
                    public final void run() {
                        CameraActivity.applyTorchLocked$lambda$17(this.f$0);
                    }
                });
            }
            applyParams();
            return;
        }
        this.torch.setTorch(zIsFront, false);
        this.torchViaRequest = false;
        applyParams();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void applyTorchLocked$lambda$17(CameraActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        UI.INSTANCE.toast(this$0, this$0.torch.failureText());
        this$0.updateTorchLabel();
    }

    private final void toggleRecord() {
        if (this.recording) {
            stopRecording();
        } else {
            startRecording();
        }
    }

    private final void startRecording() {
        Handler handler = this.bgHandler;
        if (handler == null) {
            return;
        }
        handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$Vk4oMHjmhpNHLliIkYetoLpnujA
            @Override // java.lang.Runnable
            public final void run() {
                CameraActivity.startRecording$lambda$18(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startRecording$lambda$18(CameraActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.startRecordingLocked();
    }

    /* JADX WARN: Removed duplicated region for block: B:44:0x0082  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void startRecordingLocked() {
        /*
            Method dump skipped, instruction units count: 438
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.camera.CameraActivity.startRecordingLocked():void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startRecordingLocked$lambda$22(CameraActivity this$0, Exception e) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(e, "$e");
        UI.INSTANCE.toast(this$0, "Recorder init failed: " + e.getMessage());
    }

    /* JADX INFO: renamed from: com.rehman.ahmedreactionstudio.camera.CameraActivity$startRecordingLocked$4, reason: invalid class name */
    /* JADX INFO: compiled from: CameraActivity.kt */
    @Metadata(d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\u0010\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016"}, d2 = {"com/rehman/ahmedreactionstudio/camera/CameraActivity$startRecordingLocked$4", "Landroid/hardware/camera2/CameraCaptureSession$StateCallback;", "onConfigureFailed", "", "s", "Landroid/hardware/camera2/CameraCaptureSession;", "onConfigured"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class AnonymousClass4 extends CameraCaptureSession.StateCallback {
        final /* synthetic */ File $f;
        final /* synthetic */ MediaRecorder $r;

        AnonymousClass4(MediaRecorder mediaRecorder, File file) {
            this.$r = mediaRecorder;
            this.$f = file;
        }

        @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
        public void onConfigured(@NotNull CameraCaptureSession s) {
            Intrinsics.checkNotNullParameter(s, "s");
            CameraActivity.this.session = s;
            CameraActivity.this.recording = true;
            CameraActivity.this.applyParams();
            try {
                this.$r.start();
                CameraActivity.this.recordFile = this.$f;
                CameraActivity.this.recordStart = SystemClock.elapsedRealtime();
                CameraActivity.this.timerHandler.post(CameraActivity.this.timerTick);
                final CameraActivity cameraActivity = CameraActivity.this;
                cameraActivity.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$startRecordingLocked$4$pHNOZ6QWQ3YSkdZxoqsLueIjWqk
                    @Override // java.lang.Runnable
                    public final void run() {
                        CameraActivity.AnonymousClass4.onConfigured$lambda$1(cameraActivity);
                    }
                });
            } catch (Exception unused) {
                CameraActivity.this.recording = false;
                try {
                    this.$r.release();
                } catch (Exception unused2) {
                }
                CameraActivity.this.recorder = null;
                final CameraActivity cameraActivity2 = CameraActivity.this;
                cameraActivity2.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$startRecordingLocked$4$BF3Rco-lLpgSGRyG2Ac3Tvh-XuI
                    @Override // java.lang.Runnable
                    public final void run() {
                        CameraActivity.AnonymousClass4.onConfigured$lambda$0(cameraActivity2);
                    }
                });
                CameraActivity.this.createPreviewSession();
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void onConfigured$lambda$0(CameraActivity this$0) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            UI.INSTANCE.toast(this$0, "Could not start recording");
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void onConfigured$lambda$1(CameraActivity this$0) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            TextView textView = this$0.recordBtn;
            if (textView == null) {
                Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
                textView = null;
            }
            textView.setText("■");
            TextView textView2 = this$0.recordBtn;
            if (textView2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
                textView2 = null;
            }
            Object tag = textView2.getTag();
            GradientDrawable gradientDrawable = tag instanceof GradientDrawable ? (GradientDrawable) tag : null;
            if (gradientDrawable != null) {
                gradientDrawable.setColor(-2937041);
            }
            TextView textView3 = this$0.recordBtn;
            if (textView3 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
                textView3 = null;
            }
            textView3.setContentDescription("Stop recording");
            TextView textView4 = this$0.statusLabel;
            if (textView4 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("statusLabel");
                textView4 = null;
            }
            textView4.setText("Recording …");
        }

        @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
        public void onConfigureFailed(@NotNull CameraCaptureSession s) {
            Intrinsics.checkNotNullParameter(s, "s");
            try {
                this.$r.release();
            } catch (Exception unused) {
            }
            CameraActivity.this.recorder = null;
            final CameraActivity cameraActivity = CameraActivity.this;
            cameraActivity.runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$startRecordingLocked$4$tKNl7qJcDXXb7uSoFa4xdzS3Yeg
                @Override // java.lang.Runnable
                public final void run() {
                    CameraActivity.AnonymousClass4.onConfigureFailed$lambda$2(cameraActivity);
                }
            });
            CameraActivity.this.createPreviewSession();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void onConfigureFailed$lambda$2(CameraActivity this$0) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            UI.INSTANCE.toast(this$0, "Could not start recording");
        }
    }

    private final void stopRecording() {
        Handler handler = this.bgHandler;
        if (handler == null) {
            return;
        }
        handler.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$bxgA0i28HPjrTpUHMrCChVy_Bd8
            @Override // java.lang.Runnable
            public final void run() {
                CameraActivity.stopRecording$lambda$23(this.f$0);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void stopRecording$lambda$23(CameraActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.stopRecordingLocked();
    }

    private final void stopRecordingLocked() {
        MediaRecorder mediaRecorder = this.recorder;
        if (mediaRecorder == null) {
            return;
        }
        boolean z = false;
        this.recording = false;
        torchOff();
        this.timerHandler.removeCallbacks(this.timerTick);
        try {
            mediaRecorder.stop();
            z = true;
        } catch (Exception unused) {
        }
        try {
            mediaRecorder.release();
        } catch (Exception unused2) {
        }
        this.recorder = null;
        File file = this.recordFile;
        this.recordFile = null;
        try {
            CameraCaptureSession cameraCaptureSession = this.session;
            if (cameraCaptureSession != null) {
                cameraCaptureSession.close();
            }
        } catch (Exception unused3) {
        }
        this.session = null;
        if (this.device != null) {
            createPreviewSession();
        }
        runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$14Rl9mKvkwLmlB5Wf-P7zjTj_JA
            @Override // java.lang.Runnable
            public final void run() {
                CameraActivity.stopRecordingLocked$lambda$24(this.f$0);
            }
        });
        if (!z || file == null || !file.exists() || file.length() < 50000) {
            runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$zybI_KonoW9lMDkhDZGyL4d0yy0
                @Override // java.lang.Runnable
                public final void run() {
                    CameraActivity.stopRecordingLocked$lambda$25(this.f$0);
                }
            });
            if (file != null) {
                try {
                    file.delete();
                    return;
                } catch (Exception unused4) {
                    return;
                }
            }
            return;
        }
        MediaKit mediaKit = MediaKit.INSTANCE;
        String absolutePath = file.getAbsolutePath();
        Intrinsics.checkNotNullExpressionValue(absolutePath, "getAbsolutePath(...)");
        MediaInfo mediaInfoProbe = mediaKit.probe(absolutePath);
        if (mediaInfoProbe.getDurMs() < 300 || mediaInfoProbe.getWidth() == 0) {
            try {
                file.delete();
            } catch (Exception unused5) {
            }
            runOnUiThread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.camera.-$$Lambda$CameraActivity$DSiSC1BF5PTPmQK3Oq4jS1Tbv-I
                @Override // java.lang.Runnable
                public final void run() {
                    CameraActivity.stopRecordingLocked$lambda$26(this.f$0);
                }
            });
            return;
        }
        String str = "media/" + file.getName();
        Intent intent = new Intent();
        intent.putExtra(EXTRA_RESULT_REL, str);
        intent.putExtra(EXTRA_ROLE, this.role);
        setResult(-1, intent);
        finish();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void stopRecordingLocked$lambda$24(CameraActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        TextView textView = this$0.recordBtn;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
            textView = null;
        }
        textView.setText("●");
        TextView textView2 = this$0.recordBtn;
        if (textView2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
            textView2 = null;
        }
        Object tag = textView2.getTag();
        GradientDrawable gradientDrawable = tag instanceof GradientDrawable ? (GradientDrawable) tag : null;
        if (gradientDrawable != null) {
            gradientDrawable.setColor(-1754827);
        }
        TextView textView3 = this$0.recordBtn;
        if (textView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("recordBtn");
            textView3 = null;
        }
        textView3.setContentDescription("Start recording");
        TextView textView4 = this$0.timerLabel;
        if (textView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("timerLabel");
            textView4 = null;
        }
        textView4.setText("00:00");
        TextView textView5 = this$0.statusLabel;
        if (textView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("statusLabel");
            textView5 = null;
        }
        textView5.setText("");
        this$0.updateTorchLabel();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void stopRecordingLocked$lambda$25(CameraActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        UI.INSTANCE.toast(this$0, "Recording failed or was too short");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void stopRecordingLocked$lambda$26(CameraActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        UI.INSTANCE.toast(this$0, "Take too short or unreadable");
    }
}
