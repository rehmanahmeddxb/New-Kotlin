package com.rehman.ahmedreactionstudio.core.gpu;

import android.graphics.Bitmap;
import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Build;
import com.rehman.ahmedreactionstudio.core.gpu.GlUtil;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: GpuVideoDecoder.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000l\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\b\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0002\u0010\u0005J*\u00107\u001a\u00020\u000e2\u0006\u00108\u001a\u00020\u00072\u0006\u00109\u001a\u00020$2\b\b\u0002\u0010:\u001a\u00020\u000e2\b\b\u0002\u0010;\u001a\u00020\u000eJ\b\u0010<\u001a\u00020\fH\u0002J\u0006\u0010=\u001a\u00020>J\b\u0010?\u001a\u0004\u0018\u00010\u0010J\u0014\u0010@\u001a\u000e\u0012\u0004\u0012\u00020$\u0012\u0004\u0012\u00020$0AH\u0002J\u0018\u0010B\u001a\u00020\u000e2\u0006\u0010C\u001a\u00020\u00072\u0006\u0010D\u001a\u00020\u0007H\u0002J\b\u0010E\u001a\u00020>H\u0002J\u0006\u0010&\u001a\u00020>J\u0010\u0010F\u001a\u00020\u000e2\b\u0010G\u001a\u0004\u0018\u00010\u0010J\u0010\u0010H\u001a\u00020>2\u0006\u0010C\u001a\u00020\u0007H\u0002R\u001e\u0010\b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0007@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0010\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0017\u001a\u0004\u0018\u00010\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u000e\u0010\u001b\u001a\u00020\u001cX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010\u001e\u001a\u00020\u000e8F¢\u0006\u0006\u001a\u0004\b\u001e\u0010\u001fR\u001e\u0010 \u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0007@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\nR\u000e\u0010\"\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020$X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010%\u001a\u0004\u0018\u00010\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b(\u0010\u001aR\u000e\u0010)\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010*\u001a\u00020\u000e2\u0006\u0010\u0006\u001a\u00020\u000e@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b+\u0010\u001fR\u0010\u0010,\u001a\u0004\u0018\u00010\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010-\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0007@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b.\u0010\nR\u000e\u0010/\u001a\u00020$X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00100\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00101\u001a\u00020$X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00102\u001a\u00020$X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u00103\u001a\u0004\u0018\u000104X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00105\u001a\u00020$X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00106\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/gpu/GpuVideoDecoder;", "", "id", "", "path", "(Ljava/lang/String;Ljava/lang/String;)V", "<set-?>", "", "avgFrameUs", "getAvgFrameUs", "()J", "blit", "Lcom/rehman/ahmedreactionstudio/core/gpu/GlUtil$OesToBitmap;", "broken", "", "bufA", "Landroid/graphics/Bitmap;", "bufB", "busy", "Ljava/util/concurrent/atomic/AtomicBoolean;", "codec", "Landroid/media/MediaCodec;", "durationUs", "extractor", "Landroid/media/MediaExtractor;", "getId", "()Ljava/lang/String;", "info", "Landroid/media/MediaCodec$BufferInfo;", "inputDone", "isBroken", "()Z", "lastDecodeMs", "getLastDecodeMs", "lastPtsUs", "maxPx", "", "mime", "open", "outputDone", "getPath", "pendingSeekUs", "produced", "getProduced", "published", "publishedPtsUs", "getPublishedPtsUs", "rotation", "sawOutput", "srcH", "srcW", "target", "Lcom/rehman/ahmedreactionstudio/core/gpu/OesSurfaceTarget;", "trackIdx", "writeA", "advanceTo", "mediaMs", "maxSide", "forceSeek", "paced", "blitter", "close", "", "currentBitmap", "displaySize", "Lkotlin/Pair;", "drainOutput", "targetUs", "timeoutUs", "feedInput", "owns", "bmp", "seekInternal"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nGpuVideoDecoder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GpuVideoDecoder.kt\ncom/rehman/ahmedreactionstudio/core/gpu/GpuVideoDecoder\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,531:1\n1#2:532\n*E\n"})
public final class GpuVideoDecoder {
    private volatile long avgFrameUs;

    @Nullable
    private GlUtil.OesToBitmap blit;
    private volatile boolean broken;

    @Nullable
    private Bitmap bufA;

    @Nullable
    private Bitmap bufB;

    @NotNull
    private final AtomicBoolean busy;

    @Nullable
    private MediaCodec codec;
    private long durationUs;

    @Nullable
    private MediaExtractor extractor;

    @NotNull
    private final String id;

    @NotNull
    private final MediaCodec.BufferInfo info;
    private boolean inputDone;
    private volatile long lastDecodeMs;
    private long lastPtsUs;
    private int maxPx;

    @Nullable
    private String mime;
    private volatile boolean open;
    private boolean outputDone;

    @NotNull
    private final String path;
    private long pendingSeekUs;
    private volatile boolean produced;

    @Nullable
    private volatile Bitmap published;
    private volatile long publishedPtsUs;
    private int rotation;
    private boolean sawOutput;
    private int srcH;
    private int srcW;

    @Nullable
    private OesSurfaceTarget target;
    private int trackIdx;
    private boolean writeA;

    public GpuVideoDecoder(@NotNull String id, @NotNull String path) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(path, "path");
        this.id = id;
        this.path = path;
        this.trackIdx = -1;
        this.lastPtsUs = -1L;
        this.pendingSeekUs = -1L;
        this.maxPx = 720;
        this.writeA = true;
        this.publishedPtsUs = -1L;
        this.info = new MediaCodec.BufferInfo();
        this.busy = new AtomicBoolean(false);
    }

    @NotNull
    public final String getId() {
        return this.id;
    }

    @NotNull
    public final String getPath() {
        return this.path;
    }

    public final long getLastDecodeMs() {
        return this.lastDecodeMs;
    }

    public final boolean getProduced() {
        return this.produced;
    }

    public final long getPublishedPtsUs() {
        return this.publishedPtsUs;
    }

    public final long getAvgFrameUs() {
        return this.avgFrameUs;
    }

    private final GlUtil.OesToBitmap blitter() {
        GlUtil.OesToBitmap oesToBitmap = this.blit;
        if (oesToBitmap != null) {
            return oesToBitmap;
        }
        GlUtil.OesToBitmap oesToBitmap2 = new GlUtil.OesToBitmap();
        oesToBitmap2.ensureProgram();
        this.blit = oesToBitmap2;
        return oesToBitmap2;
    }

    public final void open() {
        MediaFormat trackFormat;
        String string;
        if (this.open || this.broken) {
            return;
        }
        try {
            EglCore eglCoreEgl$main = GpuVideoPipeline.INSTANCE.egl$main();
            if (eglCoreEgl$main != null) {
                eglCoreEgl$main.makeCurrent();
            }
            MediaExtractor mediaExtractor = new MediaExtractor();
            mediaExtractor.setDataSource(this.path);
            int i = -1;
            int trackCount = mediaExtractor.getTrackCount();
            int i2 = 0;
            while (true) {
                if (i2 >= trackCount) {
                    trackFormat = null;
                    string = null;
                    break;
                }
                trackFormat = mediaExtractor.getTrackFormat(i2);
                string = trackFormat.getString("mime");
                if (string != null && StringsKt.startsWith$default(string, "video/", false, 2, (Object) null)) {
                    i = i2;
                    break;
                }
                i2++;
            }
            if (i >= 0 && string != null && trackFormat != null) {
                mediaExtractor.selectTrack(i);
                this.trackIdx = i;
                this.mime = string;
                this.srcW = trackFormat.containsKey("width") ? trackFormat.getInteger("width") : 0;
                this.srcH = trackFormat.containsKey("height") ? trackFormat.getInteger("height") : 0;
                int integer = (trackFormat.containsKey("rotation-degrees") || trackFormat.containsKey("rotation-degrees")) ? trackFormat.getInteger("rotation-degrees") : 0;
                this.rotation = integer;
                this.durationUs = trackFormat.containsKey("durationUs") ? trackFormat.getLong("durationUs") : 0L;
                OesSurfaceTarget oesSurfaceTarget = new OesSurfaceTarget();
                if (this.srcW > 0 && this.srcH > 0) {
                    oesSurfaceTarget.setDefaultBufferSize(this.srcW, this.srcH);
                }
                try {
                    MediaCodec mediaCodecCreateDecoderByType = MediaCodec.createDecoderByType(string);
                    try {
                        try {
                            if (Build.VERSION.SDK_INT >= 30) {
                                try {
                                    trackFormat.setInteger("low-latency", 1);
                                } catch (Exception unused) {
                                }
                            }
                            mediaCodecCreateDecoderByType.configure(trackFormat, oesSurfaceTarget.getSurface(), (MediaCrypto) null, 0);
                            mediaCodecCreateDecoderByType.start();
                            this.extractor = mediaExtractor;
                            this.codec = mediaCodecCreateDecoderByType;
                            this.target = oesSurfaceTarget;
                            this.open = true;
                            this.inputDone = false;
                            this.outputDone = false;
                            this.sawOutput = false;
                            this.lastPtsUs = -1L;
                            return;
                        } catch (Exception unused2) {
                            oesSurfaceTarget.release();
                            mediaExtractor.release();
                            this.broken = true;
                            return;
                        }
                    } catch (Exception unused3) {
                        mediaCodecCreateDecoderByType.release();
                        oesSurfaceTarget.release();
                        mediaExtractor.release();
                        this.broken = true;
                        return;
                    }
                } catch (Exception unused4) {
                    oesSurfaceTarget.release();
                    mediaExtractor.release();
                    this.broken = true;
                    return;
                }
            }
            mediaExtractor.release();
            this.broken = true;
        } catch (Exception unused5) {
            this.broken = true;
            close();
        }
    }

    public final void close() {
        this.open = false;
        try {
            MediaCodec mediaCodec = this.codec;
            if (mediaCodec != null) {
                mediaCodec.stop();
            }
        } catch (Exception unused) {
        }
        try {
            MediaCodec mediaCodec2 = this.codec;
            if (mediaCodec2 != null) {
                mediaCodec2.release();
            }
        } catch (Exception unused2) {
        }
        this.codec = null;
        try {
            MediaExtractor mediaExtractor = this.extractor;
            if (mediaExtractor != null) {
                mediaExtractor.release();
            }
        } catch (Exception unused3) {
        }
        this.extractor = null;
        try {
            OesSurfaceTarget oesSurfaceTarget = this.target;
            if (oesSurfaceTarget != null) {
                oesSurfaceTarget.release();
            }
        } catch (Exception unused4) {
        }
        this.target = null;
        try {
            GlUtil.OesToBitmap oesToBitmap = this.blit;
            if (oesToBitmap != null) {
                oesToBitmap.release();
            }
        } catch (Exception unused5) {
        }
        this.blit = null;
        try {
            Bitmap bitmap = this.bufA;
            if (bitmap != null) {
                bitmap.recycle();
            }
        } catch (Exception unused6) {
        }
        try {
            Bitmap bitmap2 = this.bufB;
            if (bitmap2 != null) {
                bitmap2.recycle();
            }
        } catch (Exception unused7) {
        }
        this.bufA = null;
        this.bufB = null;
        this.published = null;
        this.publishedPtsUs = -1L;
        this.avgFrameUs = 0L;
        this.broken = true;
    }

    @Nullable
    /* JADX INFO: renamed from: currentBitmap, reason: from getter */
    public final Bitmap getPublished() {
        return this.published;
    }

    /* JADX INFO: renamed from: isBroken, reason: from getter */
    public final boolean getBroken() {
        return this.broken;
    }

    public final boolean owns(@Nullable Bitmap bmp) {
        return bmp != null && (bmp == this.bufA || bmp == this.bufB || bmp == this.published);
    }

    /* JADX WARN: Code restructure failed: missing block: B:66:0x00cd, code lost:
    
        r16 = true;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean advanceTo(long r22, int r24, boolean r25, boolean r26) {
        /*
            Method dump skipped, instruction units count: 440
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.core.gpu.GpuVideoDecoder.advanceTo(long, int, boolean, boolean):boolean");
    }

    private final Pair<Integer, Integer> displaySize() {
        int i = this.rotation;
        if (i == 90 || i == 270) {
            return new Pair<>(Integer.valueOf(RangesKt.coerceAtLeast(this.srcH, 2)), Integer.valueOf(RangesKt.coerceAtLeast(this.srcW, 2)));
        }
        return new Pair<>(Integer.valueOf(RangesKt.coerceAtLeast(this.srcW, 2)), Integer.valueOf(RangesKt.coerceAtLeast(this.srcH, 2)));
    }

    private final void seekInternal(long targetUs) {
        MediaCodec mediaCodec;
        MediaExtractor mediaExtractor = this.extractor;
        if (mediaExtractor == null || (mediaCodec = this.codec) == null) {
            return;
        }
        try {
            try {
                mediaExtractor.seekTo(RangesKt.coerceAtLeast(targetUs, 0L), 0);
                mediaCodec.flush();
            } catch (Exception unused) {
            }
        } catch (Exception unused2) {
            mediaCodec.flush();
        }
        this.inputDone = false;
        this.outputDone = false;
        this.lastPtsUs = -1L;
        this.publishedPtsUs = -1L;
        this.pendingSeekUs = targetUs;
    }

    private final void feedInput() {
        MediaCodec mediaCodec;
        MediaExtractor mediaExtractor;
        int iDequeueInputBuffer;
        ByteBuffer inputBuffer;
        if (this.inputDone || (mediaCodec = this.codec) == null || (mediaExtractor = this.extractor) == null) {
            return;
        }
        int sampleData = -1;
        try {
            iDequeueInputBuffer = mediaCodec.dequeueInputBuffer(0L);
        } catch (Exception unused) {
            iDequeueInputBuffer = -1;
        }
        if (iDequeueInputBuffer < 0) {
            return;
        }
        try {
            inputBuffer = mediaCodec.getInputBuffer(iDequeueInputBuffer);
        } catch (Exception unused2) {
            inputBuffer = null;
        }
        if (inputBuffer == null) {
            return;
        }
        try {
            sampleData = mediaExtractor.readSampleData(inputBuffer, 0);
        } catch (Exception unused3) {
        }
        if (sampleData < 0) {
            try {
                mediaCodec.queueInputBuffer(iDequeueInputBuffer, 0, 0, 0L, 4);
            } catch (Exception unused4) {
            }
            this.inputDone = true;
        } else {
            try {
                mediaCodec.queueInputBuffer(iDequeueInputBuffer, 0, sampleData, mediaExtractor.getSampleTime(), 0);
            } catch (Exception unused5) {
            }
            try {
                mediaExtractor.advance();
            } catch (Exception unused6) {
            }
        }
    }

    private final boolean drainOutput(long targetUs, long timeoutUs) {
        MediaCodec mediaCodec = this.codec;
        boolean z = false;
        if (mediaCodec == null) {
            return false;
        }
        try {
            int iDequeueOutputBuffer = mediaCodec.dequeueOutputBuffer(this.info, timeoutUs);
            if (iDequeueOutputBuffer == -1) {
                return false;
            }
            if (iDequeueOutputBuffer == -2) {
                try {
                    MediaFormat outputFormat = mediaCodec.getOutputFormat();
                    if (outputFormat.containsKey("width")) {
                        this.srcW = outputFormat.getInteger("width");
                    }
                    if (outputFormat.containsKey("height")) {
                        this.srcH = outputFormat.getInteger("height");
                    }
                    if (outputFormat.containsKey("rotation-degrees")) {
                        this.rotation = outputFormat.getInteger("rotation-degrees");
                    }
                } catch (Exception unused) {
                }
                return false;
            }
            if (iDequeueOutputBuffer >= 0) {
                if ((this.info.flags & 4) != 0) {
                    this.outputDone = true;
                }
                long j = this.info.presentationTimeUs;
                boolean z2 = this.info.size > 0 && (targetUs - j < 120000 || this.lastPtsUs < 0 || this.pendingSeekUs >= 0);
                try {
                    mediaCodec.releaseOutputBuffer(iDequeueOutputBuffer, z2);
                    if (!z2) {
                        return false;
                    }
                    long j2 = this.lastPtsUs;
                    if (j2 >= 0 && j > j2) {
                        long j3 = j - j2;
                        if (1000 <= j3 && j3 < 200001) {
                            z = true;
                        }
                        if (z) {
                            if (this.avgFrameUs > 0) {
                                j3 = ((this.avgFrameUs * ((long) 3)) + j3) / ((long) 4);
                            }
                            this.avgFrameUs = j3;
                        }
                    }
                    this.lastPtsUs = j;
                    this.sawOutput = true;
                    long j4 = this.pendingSeekUs;
                    if (j4 >= 0 && j + 30000 >= j4) {
                        this.pendingSeekUs = -1L;
                    }
                    return true;
                } catch (Exception unused2) {
                    mediaCodec.releaseOutputBuffer(iDequeueOutputBuffer, false);
                    return false;
                }
            }
        } catch (Exception unused3) {
        }
        return false;
    }
}
