package com.rehman.ahmedreactionstudio.core.gpu;

import android.graphics.Bitmap;
import android.opengl.GLES20;
import android.opengl.GLES30;
import android.opengl.Matrix;
import android.util.Log;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Arrays;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.UByte;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: GlUtil.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0014\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\b\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001\u001dB\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nJ\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u0004J\u0006\u0010\u000e\u001a\u00020\u0006J\u0016\u0010\u000f\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\n2\u0006\u0010\u0011\u001a\u00020\nJ\u000e\u0010\u0012\u001a\u00020\b2\u0006\u0010\u0013\u001a\u00020\u0006J*\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00060\u00152\u0006\u0010\u0016\u001a\u00020\u00062\u0006\u0010\u0017\u001a\u00020\u00062\u0006\u0010\u0018\u001a\u00020\u0006J\u0006\u0010\u0019\u001a\u00020\u0004J\u0018\u0010\u001a\u001a\u00020\u00062\u0006\u0010\u001b\u001a\u00020\u00062\u0006\u0010\u001c\u001a\u00020\nH\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0086T¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/gpu/GlUtil;", "", "()V", "IDENTITY", "", "NO_TEXTURE", "", "checkGl", "", "op", "", "createFloatBuffer", "Ljava/nio/FloatBuffer;", "coords", "createOesTexture", "createProgram", "vertexSrc", "fragmentSrc", "deleteTexture", "id", "fitSize", "Lkotlin/Pair;", "srcW", "srcH", "maxPx", "identity", "loadShader", "type", "src", "OesToBitmap"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nGlUtil.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GlUtil.kt\ncom/rehman/ahmedreactionstudio/core/gpu/GlUtil\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,466:1\n1#2:467\n*E\n"})
public final class GlUtil {

    @NotNull
    private static final float[] IDENTITY;

    @NotNull
    public static final GlUtil INSTANCE = new GlUtil();
    public static final int NO_TEXTURE = 0;

    private GlUtil() {
    }

    static {
        float[] fArr = new float[16];
        Matrix.setIdentityM(fArr, 0);
        IDENTITY = fArr;
    }

    @NotNull
    public final float[] identity() {
        float[] fArr = IDENTITY;
        float[] fArrCopyOf = Arrays.copyOf(fArr, fArr.length);
        Intrinsics.checkNotNullExpressionValue(fArrCopyOf, "copyOf(...)");
        return fArrCopyOf;
    }

    @NotNull
    public final FloatBuffer createFloatBuffer(@NotNull float[] coords) {
        Intrinsics.checkNotNullParameter(coords, "coords");
        FloatBuffer floatBufferAsFloatBuffer = ByteBuffer.allocateDirect(coords.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        floatBufferAsFloatBuffer.put(coords);
        floatBufferAsFloatBuffer.position(0);
        Intrinsics.checkNotNull(floatBufferAsFloatBuffer);
        return floatBufferAsFloatBuffer;
    }

    public final void checkGl(@NotNull String op) {
        Intrinsics.checkNotNullParameter(op, "op");
        for (int iGlGetError = GLES20.glGetError(); iGlGetError != 0; iGlGetError = GLES20.glGetError()) {
            Log.w("GlUtil", op + ": glError 0x" + Integer.toHexString(iGlGetError));
        }
    }

    public final int createProgram(@NotNull String vertexSrc, @NotNull String fragmentSrc) {
        Intrinsics.checkNotNullParameter(vertexSrc, "vertexSrc");
        Intrinsics.checkNotNullParameter(fragmentSrc, "fragmentSrc");
        int iLoadShader = loadShader(35633, vertexSrc);
        if (iLoadShader == 0) {
            return 0;
        }
        int iLoadShader2 = loadShader(35632, fragmentSrc);
        if (iLoadShader2 == 0) {
            GLES20.glDeleteShader(iLoadShader);
            return 0;
        }
        int iGlCreateProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(iGlCreateProgram, iLoadShader);
        GLES20.glAttachShader(iGlCreateProgram, iLoadShader2);
        GLES20.glLinkProgram(iGlCreateProgram);
        int[] iArr = new int[1];
        GLES20.glGetProgramiv(iGlCreateProgram, 35714, iArr, 0);
        if (iArr[0] != 1) {
            Log.e("GlUtil", "link fail: " + GLES20.glGetProgramInfoLog(iGlCreateProgram));
            GLES20.glDeleteProgram(iGlCreateProgram);
            GLES20.glDeleteShader(iLoadShader);
            GLES20.glDeleteShader(iLoadShader2);
            return 0;
        }
        GLES20.glDeleteShader(iLoadShader);
        GLES20.glDeleteShader(iLoadShader2);
        return iGlCreateProgram;
    }

    private final int loadShader(int type, String src) {
        int iGlCreateShader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(iGlCreateShader, src);
        GLES20.glCompileShader(iGlCreateShader);
        int[] iArr = new int[1];
        GLES20.glGetShaderiv(iGlCreateShader, 35713, iArr, 0);
        if (iArr[0] != 0) {
            return iGlCreateShader;
        }
        Log.e("GlUtil", "shader compile: " + GLES20.glGetShaderInfoLog(iGlCreateShader));
        GLES20.glDeleteShader(iGlCreateShader);
        return 0;
    }

    public final int createOesTexture() {
        int[] iArr = new int[1];
        GLES20.glGenTextures(1, iArr, 0);
        int i = iArr[0];
        GLES20.glBindTexture(36197, i);
        GLES20.glTexParameteri(36197, 10241, 9729);
        GLES20.glTexParameteri(36197, 10240, 9729);
        GLES20.glTexParameteri(36197, 10242, 33071);
        GLES20.glTexParameteri(36197, 10243, 33071);
        GLES20.glBindTexture(36197, 0);
        return i;
    }

    public final void deleteTexture(int id) {
        if (id != 0) {
            GLES20.glDeleteTextures(1, new int[]{id}, 0);
        }
    }

    /* JADX INFO: compiled from: GlUtil.kt */
    @Metadata(d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0010\u0014\n\u0002\b\u0002\n\u0002\u0010\u0015\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0011\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J(\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020$2\u0006\u0010%\u001a\u00020\u001a2\u0006\u0010&\u001a\u00020\n2\u0006\u0010'\u001a\u00020\nH\u0002J2\u0010(\u001a\u0004\u0018\u00010$2\u0006\u0010)\u001a\u00020\n2\u0006\u0010*\u001a\u00020\u00112\u0006\u0010+\u001a\u00020\n2\u0006\u0010,\u001a\u00020\n2\b\u0010-\u001a\u0004\u0018\u00010$J\u0018\u0010.\u001a\u00020\"2\u0006\u0010&\u001a\u00020\n2\u0006\u0010'\u001a\u00020\nH\u0002J\u0018\u0010/\u001a\u00020\"2\u0006\u0010&\u001a\u00020\n2\u0006\u0010'\u001a\u00020\nH\u0002J\u0006\u00100\u001a\u00020\"J(\u00101\u001a\u00020\u00172\u0006\u00102\u001a\u00020\u00142\u0006\u0010&\u001a\u00020\n2\u0006\u0010'\u001a\u00020\n2\u0006\u0010#\u001a\u00020$H\u0002J\u0006\u00103\u001a\u00020\"J\b\u00104\u001a\u00020\"H\u0002J\b\u00105\u001a\u00020\"H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0019\u001a\u0004\u0018\u00010\u001aX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/gpu/GlUtil$OesToBitmap;", "", "()V", "FRAG", "", "POS", "Ljava/nio/FloatBuffer;", "TEX", "VERT", "aPos", "", "aTex", "colorTex", "fbo", "fboH", "fboW", "mvp", "", "pboH", "pboIds", "", "pboIndex", "pboPrimed", "", "pboW", "pixelBuf", "Ljava/nio/ByteBuffer;", "prog", "slowPath", "st", "uMvp", "uSt", "uTex", "copyInto", "", "bmp", "Landroid/graphics/Bitmap;", "buf", "w", "h", "draw", "oesTexId", "stMatrix", "outW", "outH", "reuse", "ensureFbo", "ensurePbos", "ensureProgram", "readViaPbo", "ids", "release", "releaseFbo", "releasePbos"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class OesToBitmap {
        private int aPos;
        private int aTex;
        private int colorTex;
        private int fbo;
        private int fboH;
        private int fboW;
        private int pboH;

        @Nullable
        private int[] pboIds;
        private int pboIndex;
        private boolean pboPrimed;
        private int pboW;

        @Nullable
        private ByteBuffer pixelBuf;
        private int prog;
        private boolean slowPath;
        private int uMvp;
        private int uSt;
        private int uTex;

        @NotNull
        private final float[] mvp = new float[16];

        @NotNull
        private final float[] st = new float[16];

        @NotNull
        private final String VERT = "attribute vec4 aPos;\nattribute vec4 aTex;\nuniform mat4 uMvp;\nuniform mat4 uSt;\nvarying vec2 vTex;\nvoid main() {\n    gl_Position = uMvp * aPos;\n    vTex = (uSt * aTex).xy;\n}";

        @NotNull
        private final String FRAG = "#extension GL_OES_EGL_image_external : require\nprecision mediump float;\nvarying vec2 vTex;\nuniform samplerExternalOES uTex;\nvoid main() {\n    gl_FragColor = texture2D(uTex, vTex);\n}";

        @NotNull
        private final FloatBuffer POS = GlUtil.INSTANCE.createFloatBuffer(new float[]{-1.0f, -1.0f, 1.0f, -1.0f, -1.0f, 1.0f, 1.0f, 1.0f});

        @NotNull
        private final FloatBuffer TEX = GlUtil.INSTANCE.createFloatBuffer(new float[]{0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f});

        public final void ensureProgram() {
            if (this.prog != 0) {
                return;
            }
            this.prog = GlUtil.INSTANCE.createProgram(this.VERT, this.FRAG);
            int i = this.prog;
            if (i == 0) {
                return;
            }
            this.aPos = GLES20.glGetAttribLocation(i, "aPos");
            this.aTex = GLES20.glGetAttribLocation(this.prog, "aTex");
            this.uMvp = GLES20.glGetUniformLocation(this.prog, "uMvp");
            this.uSt = GLES20.glGetUniformLocation(this.prog, "uSt");
            this.uTex = GLES20.glGetUniformLocation(this.prog, "uTex");
            Matrix.setIdentityM(this.mvp, 0);
            Matrix.scaleM(this.mvp, 0, 1.0f, -1.0f, 1.0f);
        }

        private final void ensureFbo(int w, int h) {
            if (this.fbo != 0 && this.fboW == w && this.fboH == h) {
                return;
            }
            releaseFbo();
            this.fboW = w;
            this.fboH = h;
            int[] iArr = new int[1];
            GLES20.glGenTextures(1, iArr, 0);
            this.colorTex = iArr[0];
            GLES20.glBindTexture(3553, this.colorTex);
            GLES20.glTexImage2D(3553, 0, 6408, w, h, 0, 6408, 5121, null);
            GLES20.glTexParameteri(3553, 10241, 9729);
            GLES20.glTexParameteri(3553, 10240, 9729);
            GLES20.glTexParameteri(3553, 10242, 33071);
            GLES20.glTexParameteri(3553, 10243, 33071);
            int[] iArr2 = new int[1];
            GLES20.glGenFramebuffers(1, iArr2, 0);
            this.fbo = iArr2[0];
            GLES20.glBindFramebuffer(36160, this.fbo);
            GLES20.glFramebufferTexture2D(36160, 36064, 3553, this.colorTex, 0);
            int iGlCheckFramebufferStatus = GLES20.glCheckFramebufferStatus(36160);
            if (iGlCheckFramebufferStatus != 36053) {
                Log.e("GlUtil", "FBO incomplete: 0x" + Integer.toHexString(iGlCheckFramebufferStatus));
            }
            GLES20.glBindFramebuffer(36160, 0);
            this.pixelBuf = ByteBuffer.allocateDirect((w * h * 4) + 64).order(ByteOrder.nativeOrder());
            ensurePbos(w, h);
        }

        private final void ensurePbos(int w, int h) {
            if (EglCore.INSTANCE.getEs3()) {
                if (this.pboIds != null && this.pboW == w && this.pboH == h) {
                    return;
                }
                releasePbos();
                try {
                    int[] iArr = new int[2];
                    GLES30.glGenBuffers(2, iArr, 0);
                    if (iArr[0] != 0 && iArr[1] != 0) {
                        int i = w * h * 4;
                        for (int i2 : iArr) {
                            GLES30.glBindBuffer(35051, i2);
                            GLES30.glBufferData(35051, i, null, 35041);
                        }
                        GLES30.glBindBuffer(35051, 0);
                        if (GLES20.glGetError() != 0) {
                            releasePbos();
                            return;
                        }
                        this.pboIds = iArr;
                        this.pboW = w;
                        this.pboH = h;
                        this.pboIndex = 0;
                        this.pboPrimed = false;
                    }
                } catch (Throwable unused) {
                    releasePbos();
                }
            }
        }

        private final void releasePbos() {
            int[] iArr = this.pboIds;
            if (iArr != null) {
                try {
                    GLES30.glDeleteBuffers(2, iArr, 0);
                } catch (Throwable unused) {
                }
            }
            this.pboIds = null;
            this.pboPrimed = false;
            this.pboW = 0;
            this.pboH = 0;
        }

        private final void releaseFbo() {
            int i = this.fbo;
            if (i != 0) {
                GLES20.glDeleteFramebuffers(1, new int[]{i}, 0);
                this.fbo = 0;
            }
            int i2 = this.colorTex;
            if (i2 != 0) {
                GLES20.glDeleteTextures(1, new int[]{i2}, 0);
                this.colorTex = 0;
            }
            this.fboW = 0;
            this.fboH = 0;
            this.pixelBuf = null;
        }

        @Nullable
        public final Bitmap draw(int oesTexId, @NotNull float[] stMatrix, int outW, int outH, @Nullable Bitmap reuse) {
            Intrinsics.checkNotNullParameter(stMatrix, "stMatrix");
            if (oesTexId == 0 || outW <= 0 || outH <= 0) {
                return null;
            }
            ensureProgram();
            if (this.prog == 0) {
                return null;
            }
            ensureFbo(outW, outH);
            GLES20.glBindFramebuffer(36160, this.fbo);
            GLES20.glViewport(0, 0, outW, outH);
            GLES20.glUseProgram(this.prog);
            GLES20.glActiveTexture(33984);
            GLES20.glBindTexture(36197, oesTexId);
            GLES20.glUniform1i(this.uTex, 0);
            GLES20.glUniformMatrix4fv(this.uMvp, 1, false, this.mvp, 0);
            System.arraycopy(stMatrix, 0, this.st, 0, 16);
            GLES20.glUniformMatrix4fv(this.uSt, 1, false, this.st, 0);
            this.POS.position(0);
            GLES20.glEnableVertexAttribArray(this.aPos);
            GLES20.glVertexAttribPointer(this.aPos, 2, 5126, false, 0, (Buffer) this.POS);
            this.TEX.position(0);
            GLES20.glEnableVertexAttribArray(this.aTex);
            GLES20.glVertexAttribPointer(this.aTex, 2, 5126, false, 0, (Buffer) this.TEX);
            GLES20.glDrawArrays(5, 0, 4);
            GLES20.glDisableVertexAttribArray(this.aPos);
            GLES20.glDisableVertexAttribArray(this.aTex);
            Bitmap bitmapCreateBitmap = (reuse != null && !reuse.isRecycled() && reuse.getWidth() == outW && reuse.getHeight() == outH && reuse.getConfig() == Bitmap.Config.ARGB_8888) ? reuse : Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
            int[] iArr = this.pboIds;
            if (iArr != null) {
                Intrinsics.checkNotNull(bitmapCreateBitmap);
                if (readViaPbo(iArr, outW, outH, bitmapCreateBitmap)) {
                    GLES20.glBindFramebuffer(36160, 0);
                    GLES20.glBindTexture(36197, 0);
                    return bitmapCreateBitmap;
                }
                if (this.pboIds != null) {
                    ByteBuffer byteBuffer = this.pixelBuf;
                    if (byteBuffer != null) {
                        byteBuffer.rewind();
                        GLES20.glReadPixels(0, 0, outW, outH, 6408, 5121, byteBuffer);
                        byteBuffer.rewind();
                        copyInto(bitmapCreateBitmap, byteBuffer, outW, outH);
                    }
                    GLES20.glBindFramebuffer(36160, 0);
                    GLES20.glBindTexture(36197, 0);
                    return bitmapCreateBitmap;
                }
                GLES20.glBindFramebuffer(36160, this.fbo);
            }
            ByteBuffer byteBuffer2 = this.pixelBuf;
            if (byteBuffer2 == null) {
                return null;
            }
            byteBuffer2.rewind();
            GLES20.glReadPixels(0, 0, outW, outH, 6408, 5121, byteBuffer2);
            GLES20.glBindFramebuffer(36160, 0);
            GLES20.glBindTexture(36197, 0);
            byteBuffer2.rewind();
            Intrinsics.checkNotNull(bitmapCreateBitmap);
            copyInto(bitmapCreateBitmap, byteBuffer2, outW, outH);
            return bitmapCreateBitmap;
        }

        private final boolean readViaPbo(int[] ids, int w, int h, Bitmap bmp) {
            boolean z;
            try {
                try {
                    int i = this.pboIndex;
                    int i2 = 1 - this.pboIndex;
                    int i3 = w * h * 4;
                    GLES30.glBindBuffer(35051, ids[i]);
                    GLES30.glReadPixels(0, 0, w, h, 6408, 5121, 0);
                    if (this.pboPrimed) {
                        GLES30.glBindBuffer(35051, ids[i2]);
                        Buffer bufferGlMapBufferRange = GLES30.glMapBufferRange(35051, 0, i3, 1);
                        ByteBuffer byteBuffer = bufferGlMapBufferRange instanceof ByteBuffer ? (ByteBuffer) bufferGlMapBufferRange : null;
                        if (byteBuffer != null) {
                            byteBuffer.order(ByteOrder.nativeOrder());
                            byteBuffer.rewind();
                            copyInto(bmp, byteBuffer, w, h);
                            z = true;
                        } else {
                            z = false;
                        }
                        GLES30.glUnmapBuffer(35051);
                    } else {
                        z = false;
                    }
                    GLES30.glBindBuffer(35051, 0);
                    if (GLES20.glGetError() != 0 && !z) {
                        releasePbos();
                        return false;
                    }
                    this.pboIndex = 1 - this.pboIndex;
                    this.pboPrimed = true;
                    return z;
                } catch (Throwable unused) {
                    releasePbos();
                    return false;
                }
            } catch (Throwable unused2) {
                GLES30.glBindBuffer(35051, 0);
                releasePbos();
                return false;
            }
        }

        private final void copyInto(Bitmap bmp, ByteBuffer buf, int w, int h) {
            if (!this.slowPath) {
                try {
                    buf.rewind();
                    bmp.copyPixelsFromBuffer(buf);
                    return;
                } catch (Exception unused) {
                    this.slowPath = true;
                    Log.w("GlUtil", "copyPixelsFromBuffer failed; using manual copy");
                }
            }
            buf.rewind();
            int[] iArr = new int[w * h];
            for (int i = 0; i < iArr.length && buf.remaining() >= 4; i++) {
                int i2 = buf.get() & UByte.MAX_VALUE;
                int i3 = buf.get() & UByte.MAX_VALUE;
                iArr[i] = (i2 << 16) | ((buf.get() & UByte.MAX_VALUE) << 24) | (i3 << 8) | (buf.get() & UByte.MAX_VALUE);
            }
            bmp.setPixels(iArr, 0, w, 0, 0, w, h);
        }

        public final void release() {
            releasePbos();
            releaseFbo();
            int i = this.prog;
            if (i != 0) {
                GLES20.glDeleteProgram(i);
                this.prog = 0;
            }
        }
    }

    @NotNull
    public final Pair<Integer, Integer> fitSize(int srcW, int srcH, int maxPx) {
        if (srcW <= 0 || srcH <= 0) {
            return new Pair<>(2, 2);
        }
        if (maxPx <= 0) {
            return new Pair<>(Integer.valueOf(srcW & (-2)), Integer.valueOf(srcH & (-2)));
        }
        float fMax = Math.max(srcW, srcH);
        float f = maxPx;
        float f2 = fMax > f ? f / fMax : 1.0f;
        return new Pair<>(Integer.valueOf(RangesKt.coerceAtLeast(RangesKt.coerceAtLeast((int) (srcW * f2), 2) & (-2), 2)), Integer.valueOf(RangesKt.coerceAtLeast(RangesKt.coerceAtLeast((int) (srcH * f2), 2) & (-2), 2)));
    }
}
