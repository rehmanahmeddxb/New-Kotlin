package com.rehman.ahmedreactionstudio.core.gpu;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: GpuVideoDecoder.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u0012\u001a\u00020\u0005J\u000f\u0010\u0007\u001a\u0004\u0018\u00010\bH\u0000¢\u0006\u0002\b\u0013J\u0006\u0010\u0014\u001a\u00020\u0015J\u0016\u0010\u0016\u001a\u00020\u00062\u0006\u0010\u0012\u001a\u00020\u00052\u0006\u0010\u0017\u001a\u00020\u0005J\r\u0010\u0018\u001a\u00020\nH\u0000¢\u0006\u0002\b\u0019J\u000e\u0010\u001a\u001a\u00020\u00152\u0006\u0010\u001b\u001a\u00020\u001cJ\u0006\u0010\u001d\u001a\u00020\u0015J\u000e\u0010\u001e\u001a\u00020\u00152\u0006\u0010\u0012\u001a\u00020\u0005J\u001e\u0010\u001f\u001a\u00020\u00152\b\b\u0002\u0010 \u001a\u00020!2\f\u0010\"\u001a\b\u0012\u0004\u0012\u00020\u00150#R\u001a\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u0010X\u0082\u000e¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/gpu/GpuVideoPipeline;", "", "()V", "decoders", "Ljava/util/concurrent/ConcurrentHashMap;", "", "Lcom/rehman/ahmedreactionstudio/core/gpu/GpuVideoDecoder;", "egl", "Lcom/rehman/ahmedreactionstudio/core/gpu/EglCore;", "handler", "Landroid/os/Handler;", "lock", "main", "running", "", "thread", "Landroid/os/HandlerThread;", "decoder", "id", "egl$main", "ensure", "", "getOrCreate", "path", "mainHandler", "mainHandler$main", "post", "r", "Ljava/lang/Runnable;", "releaseAll", "releaseDecoder", "runSync", "timeoutMs", "", "block", "Lkotlin/Function0;"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nGpuVideoDecoder.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GpuVideoDecoder.kt\ncom/rehman/ahmedreactionstudio/core/gpu/GpuVideoPipeline\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,531:1\n1#2:532\n*E\n"})
public final class GpuVideoPipeline {

    @Nullable
    private static EglCore egl;

    @Nullable
    private static Handler handler;
    private static boolean running;

    @Nullable
    private static HandlerThread thread;

    @NotNull
    public static final GpuVideoPipeline INSTANCE = new GpuVideoPipeline();

    @NotNull
    private static final Object lock = new Object();

    @NotNull
    private static final ConcurrentHashMap<String, GpuVideoDecoder> decoders = new ConcurrentHashMap<>();

    @NotNull
    private static final Handler main = new Handler(Looper.getMainLooper());

    private GpuVideoPipeline() {
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void ensure() {
        synchronized (lock) {
            if (running) {
                return;
            }
            HandlerThread handlerThread = new HandlerThread("gpu-video");
            handlerThread.start();
            GpuVideoPipeline gpuVideoPipeline = INSTANCE;
            thread = handlerThread;
            GpuVideoPipeline gpuVideoPipeline2 = INSTANCE;
            handler = new Handler(handlerThread.getLooper());
            final CountDownLatch countDownLatch = new CountDownLatch(1);
            final Ref.ObjectRef objectRef = new Ref.ObjectRef();
            Handler handler2 = handler;
            Intrinsics.checkNotNull(handler2);
            handler2.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.core.gpu.-$$Lambda$GpuVideoPipeline$SmMuIzH6hha-PTFYT6Vt9UzFhoE
                @Override // java.lang.Runnable
                public final void run() {
                    GpuVideoPipeline.ensure$lambda$1$lambda$0(objectRef, countDownLatch);
                }
            });
            try {
                countDownLatch.await();
            } catch (Exception unused) {
            }
            if (objectRef.element != 0) {
                try {
                    handlerThread.quitSafely();
                } catch (Exception unused2) {
                }
                GpuVideoPipeline gpuVideoPipeline3 = INSTANCE;
                thread = null;
                GpuVideoPipeline gpuVideoPipeline4 = INSTANCE;
                handler = null;
                T t = objectRef.element;
                Intrinsics.checkNotNull(t);
                throw ((Throwable) t);
            }
            GpuVideoPipeline gpuVideoPipeline5 = INSTANCE;
            running = true;
            Unit unit = Unit.INSTANCE;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Type inference failed for: r0v2, types: [T, java.lang.Exception] */
    public static final void ensure$lambda$1$lambda$0(Ref.ObjectRef err, CountDownLatch ready) {
        Intrinsics.checkNotNullParameter(err, "$err");
        Intrinsics.checkNotNullParameter(ready, "$ready");
        try {
            try {
                EglCore eglCore = new EglCore();
                eglCore.init();
                GpuVideoPipeline gpuVideoPipeline = INSTANCE;
                egl = eglCore;
            } catch (Exception e) {
                err.element = e;
            }
        } finally {
            ready.countDown();
        }
    }

    public final void post(@NotNull Runnable r) {
        Intrinsics.checkNotNullParameter(r, "r");
        ensure();
        Handler handler2 = handler;
        if (handler2 != null) {
            handler2.post(r);
        }
    }

    public static /* synthetic */ void runSync$default(GpuVideoPipeline gpuVideoPipeline, long j, Function0 function0, int i, Object obj) {
        if ((i & 1) != 0) {
            j = 4000;
        }
        gpuVideoPipeline.runSync(j, function0);
    }

    public final void runSync(long timeoutMs, @NotNull final Function0<Unit> block) {
        Intrinsics.checkNotNullParameter(block, "block");
        ensure();
        Handler handler2 = handler;
        if (handler2 == null) {
            return;
        }
        if (Intrinsics.areEqual(Looper.myLooper(), handler2.getLooper())) {
            block.invoke();
            return;
        }
        final CountDownLatch countDownLatch = new CountDownLatch(1);
        handler2.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.core.gpu.-$$Lambda$GpuVideoPipeline$dxoJqrGLXSLanR7yafkpz4X-f_g
            @Override // java.lang.Runnable
            public final void run() {
                GpuVideoPipeline.runSync$lambda$2(block, countDownLatch);
            }
        });
        try {
            countDownLatch.await(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (Exception unused) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void runSync$lambda$2(Function0 block, CountDownLatch done) {
        Intrinsics.checkNotNullParameter(block, "$block");
        Intrinsics.checkNotNullParameter(done, "$done");
        try {
            block.invoke();
        } finally {
            done.countDown();
        }
    }

    @NotNull
    public final GpuVideoDecoder getOrCreate(@NotNull String id, @NotNull String path) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(path, "path");
        ensure();
        GpuVideoDecoder gpuVideoDecoder = decoders.get(id);
        if (gpuVideoDecoder != null && Intrinsics.areEqual(gpuVideoDecoder.getPath(), path) && !gpuVideoDecoder.getBroken()) {
            return gpuVideoDecoder;
        }
        if (gpuVideoDecoder != null) {
            INSTANCE.releaseDecoder(id);
        }
        final GpuVideoDecoder gpuVideoDecoder2 = new GpuVideoDecoder(id, path);
        decoders.put(id, gpuVideoDecoder2);
        runSync$default(this, 0L, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.core.gpu.GpuVideoPipeline.getOrCreate.2
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                gpuVideoDecoder2.open();
            }
        }, 1, null);
        if (!gpuVideoDecoder2.getBroken()) {
            return gpuVideoDecoder2;
        }
        decoders.remove(id);
        throw new IllegalStateException("gpu decoder could not open: " + path);
    }

    @Nullable
    public final GpuVideoDecoder decoder(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return decoders.get(id);
    }

    public final void releaseDecoder(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        final GpuVideoDecoder gpuVideoDecoderRemove = decoders.remove(id);
        if (gpuVideoDecoderRemove == null) {
            return;
        }
        runSync$default(this, 0L, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.core.gpu.GpuVideoPipeline.releaseDecoder.1
            {
                super(0);
            }

            @Override // kotlin.jvm.functions.Function0
            public /* bridge */ /* synthetic */ Unit invoke() {
                invoke2();
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                gpuVideoDecoderRemove.close();
            }
        }, 1, null);
    }

    public final void releaseAll() {
        synchronized (lock) {
            if (running) {
                Iterator it = new ArrayList(decoders.keySet()).iterator();
                while (it.hasNext()) {
                    final GpuVideoDecoder gpuVideoDecoderRemove = decoders.remove((String) it.next());
                    runSync$default(INSTANCE, 0L, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.core.gpu.GpuVideoPipeline$releaseAll$1$1
                        {
                            super(0);
                        }

                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            GpuVideoDecoder gpuVideoDecoder = gpuVideoDecoderRemove;
                            if (gpuVideoDecoder != null) {
                                gpuVideoDecoder.close();
                            }
                        }
                    }, 1, null);
                }
                runSync$default(INSTANCE, 0L, new Function0<Unit>() { // from class: com.rehman.ahmedreactionstudio.core.gpu.GpuVideoPipeline$releaseAll$1$2
                    @Override // kotlin.jvm.functions.Function0
                    public /* bridge */ /* synthetic */ Unit invoke() {
                        invoke2();
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final void invoke2() {
                        try {
                            EglCore eglCore = GpuVideoPipeline.egl;
                            if (eglCore != null) {
                                eglCore.release();
                            }
                        } catch (Exception unused) {
                        }
                        GpuVideoPipeline gpuVideoPipeline = GpuVideoPipeline.INSTANCE;
                        GpuVideoPipeline.egl = null;
                    }
                }, 1, null);
                try {
                    HandlerThread handlerThread = thread;
                    if (handlerThread != null) {
                        handlerThread.quitSafely();
                    }
                } catch (Exception unused) {
                }
                GpuVideoPipeline gpuVideoPipeline = INSTANCE;
                thread = null;
                GpuVideoPipeline gpuVideoPipeline2 = INSTANCE;
                handler = null;
                GpuVideoPipeline gpuVideoPipeline3 = INSTANCE;
                running = false;
                Unit unit = Unit.INSTANCE;
            }
        }
    }

    @Nullable
    public final EglCore egl$main() {
        return egl;
    }

    @NotNull
    public final Handler mainHandler$main() {
        return main;
    }
}
