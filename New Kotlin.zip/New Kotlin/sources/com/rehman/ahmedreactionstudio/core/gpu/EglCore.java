package com.rehman.ahmedreactionstudio.core.gpu;

import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES20;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: EglCore.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\u0018\u0000 \u000f2\u00020\u0001:\u0001\u000fB\u0005¢\u0006\u0002\u0010\u0002J\u0006\u0010\u000b\u001a\u00020\fJ\u0006\u0010\r\u001a\u00020\fJ\u0006\u0010\u000e\u001a\u00020\fR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/gpu/EglCore;", "", "()V", "context", "Landroid/opengl/EGLContext;", "display", "Landroid/opengl/EGLDisplay;", "released", "", "surface", "Landroid/opengl/EGLSurface;", "init", "", "makeCurrent", "release", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class EglCore {

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);
    private static volatile boolean es3;

    @NotNull
    private EGLContext context;

    @NotNull
    private EGLDisplay display;
    private boolean released;

    @NotNull
    private EGLSurface surface;

    public EglCore() {
        EGLDisplay EGL_NO_DISPLAY = EGL14.EGL_NO_DISPLAY;
        Intrinsics.checkNotNullExpressionValue(EGL_NO_DISPLAY, "EGL_NO_DISPLAY");
        this.display = EGL_NO_DISPLAY;
        EGLContext EGL_NO_CONTEXT = EGL14.EGL_NO_CONTEXT;
        Intrinsics.checkNotNullExpressionValue(EGL_NO_CONTEXT, "EGL_NO_CONTEXT");
        this.context = EGL_NO_CONTEXT;
        EGLSurface EGL_NO_SURFACE = EGL14.EGL_NO_SURFACE;
        Intrinsics.checkNotNullExpressionValue(EGL_NO_SURFACE, "EGL_NO_SURFACE");
        this.surface = EGL_NO_SURFACE;
    }

    /* JADX INFO: compiled from: EglCore.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R$\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0004@@X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\t"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/gpu/EglCore$Companion;", "", "()V", "<set-?>", "", "es3", "getEs3", "()Z", "setEs3$main", "(Z)V"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final boolean getEs3() {
            return EglCore.es3;
        }

        public final void setEs3$main(boolean z) {
            EglCore.es3 = z;
        }
    }

    public final void init() {
        if (Intrinsics.areEqual(this.display, EGL14.EGL_NO_DISPLAY)) {
            EGLDisplay eGLDisplayEglGetDisplay = EGL14.eglGetDisplay(0);
            Intrinsics.checkNotNullExpressionValue(eGLDisplayEglGetDisplay, "eglGetDisplay(...)");
            this.display = eGLDisplayEglGetDisplay;
            if (Intrinsics.areEqual(this.display, EGL14.EGL_NO_DISPLAY)) {
                throw new RuntimeException("eglGetDisplay failed");
            }
            int[] iArr = new int[2];
            boolean z = true;
            if (!EGL14.eglInitialize(this.display, iArr, 0, iArr, 1)) {
                throw new RuntimeException("eglInitialize failed");
            }
            EGLConfig eGLConfig = null;
            int[] iArr2 = {3, 2};
            int length = iArr2.length;
            int i = 0;
            while (true) {
                if (i >= length) {
                    z = false;
                    break;
                }
                int i2 = iArr2[i];
                EGLConfig[] eGLConfigArr = new EGLConfig[1];
                int[] iArr3 = new int[1];
                if (EGL14.eglChooseConfig(this.display, new int[]{12324, 8, 12323, 8, 12322, 8, 12321, 8, 12352, i2 == 3 ? 64 : 4, 12339, 1, 12344}, 0, eGLConfigArr, 0, 1, iArr3, 0) && iArr3[0] != 0 && eGLConfigArr[0] != null) {
                    EGLDisplay eGLDisplay = this.display;
                    EGLConfig eGLConfig2 = eGLConfigArr[0];
                    Intrinsics.checkNotNull(eGLConfig2);
                    EGLContext eGLContextEglCreateContext = EGL14.eglCreateContext(eGLDisplay, eGLConfig2, EGL14.EGL_NO_CONTEXT, new int[]{12440, i2, 12344}, 0);
                    if (eGLContextEglCreateContext != null && !Intrinsics.areEqual(eGLContextEglCreateContext, EGL14.EGL_NO_CONTEXT)) {
                        this.context = eGLContextEglCreateContext;
                        eGLConfig = eGLConfigArr[0];
                        Intrinsics.checkNotNull(eGLConfig);
                        Companion companion = INSTANCE;
                        es3 = i2 == 3;
                    }
                }
                i++;
            }
            if (!z || eGLConfig == null) {
                throw new RuntimeException("eglCreateContext failed");
            }
            EGLSurface eGLSurfaceEglCreatePbufferSurface = EGL14.eglCreatePbufferSurface(this.display, eGLConfig, new int[]{12375, 1, 12374, 1, 12344}, 0);
            Intrinsics.checkNotNullExpressionValue(eGLSurfaceEglCreatePbufferSurface, "eglCreatePbufferSurface(...)");
            this.surface = eGLSurfaceEglCreatePbufferSurface;
            if (Intrinsics.areEqual(this.surface, EGL14.EGL_NO_SURFACE)) {
                throw new RuntimeException("eglCreatePbufferSurface failed");
            }
            makeCurrent();
            GLES20.glDisable(2929);
            GLES20.glDisable(2884);
        }
    }

    public final void makeCurrent() {
        EGLDisplay eGLDisplay = this.display;
        EGLSurface eGLSurface = this.surface;
        if (!EGL14.eglMakeCurrent(eGLDisplay, eGLSurface, eGLSurface, this.context)) {
            throw new RuntimeException("eglMakeCurrent failed");
        }
    }

    public final void release() {
        if (this.released) {
            return;
        }
        this.released = true;
        if (!Intrinsics.areEqual(this.display, EGL14.EGL_NO_DISPLAY)) {
            EGL14.eglMakeCurrent(this.display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
            if (!Intrinsics.areEqual(this.surface, EGL14.EGL_NO_SURFACE)) {
                EGL14.eglDestroySurface(this.display, this.surface);
            }
            if (!Intrinsics.areEqual(this.context, EGL14.EGL_NO_CONTEXT)) {
                EGL14.eglDestroyContext(this.display, this.context);
            }
            EGL14.eglTerminate(this.display);
        }
        EGLDisplay EGL_NO_DISPLAY = EGL14.EGL_NO_DISPLAY;
        Intrinsics.checkNotNullExpressionValue(EGL_NO_DISPLAY, "EGL_NO_DISPLAY");
        this.display = EGL_NO_DISPLAY;
        EGLContext EGL_NO_CONTEXT = EGL14.EGL_NO_CONTEXT;
        Intrinsics.checkNotNullExpressionValue(EGL_NO_CONTEXT, "EGL_NO_CONTEXT");
        this.context = EGL_NO_CONTEXT;
        EGLSurface EGL_NO_SURFACE = EGL14.EGL_NO_SURFACE;
        Intrinsics.checkNotNullExpressionValue(EGL_NO_SURFACE, "EGL_NO_SURFACE");
        this.surface = EGL_NO_SURFACE;
    }
}
