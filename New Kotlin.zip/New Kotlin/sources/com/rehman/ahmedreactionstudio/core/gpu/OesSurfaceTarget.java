package com.rehman.ahmedreactionstudio.core.gpu;

import android.graphics.SurfaceTexture;
import android.opengl.Matrix;
import android.view.Surface;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: EglCore.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0014\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0006\u0010\u0016\u001a\u00020\u0004J\u0006\u0010\u0017\u001a\u00020\u0018J\u0016\u0010\u0019\u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u00132\u0006\u0010\u001b\u001a\u00020\u0013J\u0006\u0010\u001c\u001a\u00020\tR\u001e\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0004@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\n\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u000e\u001a\u00020\u000f¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0012\u001a\u00020\u0013¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/gpu/OesSurfaceTarget;", "", "()V", "<set-?>", "", "frameAvailable", "getFrameAvailable", "()Z", "stMatrix", "", "surface", "Landroid/view/Surface;", "getSurface", "()Landroid/view/Surface;", "surfaceTexture", "Landroid/graphics/SurfaceTexture;", "getSurfaceTexture", "()Landroid/graphics/SurfaceTexture;", "texId", "", "getTexId", "()I", "consumeFrameAvailable", "release", "", "setDefaultBufferSize", "w", "h", "updateTexImage"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nEglCore.kt\nKotlin\n*S Kotlin\n*F\n+ 1 EglCore.kt\ncom/rehman/ahmedreactionstudio/core/gpu/OesSurfaceTarget\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,167:1\n1#2:168\n*E\n"})
public final class OesSurfaceTarget {
    private volatile boolean frameAvailable;

    @NotNull
    private final float[] stMatrix;

    @NotNull
    private final Surface surface;

    @NotNull
    private final SurfaceTexture surfaceTexture;
    private final int texId;

    public OesSurfaceTarget() {
        float[] fArr = new float[16];
        Matrix.setIdentityM(fArr, 0);
        this.stMatrix = fArr;
        this.texId = GlUtil.INSTANCE.createOesTexture();
        this.surfaceTexture = new SurfaceTexture(this.texId);
        this.surfaceTexture.setOnFrameAvailableListener(new SurfaceTexture.OnFrameAvailableListener() { // from class: com.rehman.ahmedreactionstudio.core.gpu.-$$Lambda$OesSurfaceTarget$N0wTRAuLJPWeSCn6uUt2HJ5qnsk
            @Override // android.graphics.SurfaceTexture.OnFrameAvailableListener
            public final void onFrameAvailable(SurfaceTexture surfaceTexture) {
                OesSurfaceTarget._init_$lambda$1(this.f$0, surfaceTexture);
            }
        });
        this.surface = new Surface(this.surfaceTexture);
    }

    public final int getTexId() {
        return this.texId;
    }

    @NotNull
    public final SurfaceTexture getSurfaceTexture() {
        return this.surfaceTexture;
    }

    @NotNull
    public final Surface getSurface() {
        return this.surface;
    }

    public final boolean getFrameAvailable() {
        return this.frameAvailable;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void _init_$lambda$1(OesSurfaceTarget this$0, SurfaceTexture surfaceTexture) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.frameAvailable = true;
    }

    public final boolean consumeFrameAvailable() {
        if (!this.frameAvailable) {
            return false;
        }
        this.frameAvailable = false;
        return true;
    }

    @NotNull
    public final float[] updateTexImage() {
        try {
            this.surfaceTexture.updateTexImage();
            this.surfaceTexture.getTransformMatrix(this.stMatrix);
        } catch (Exception unused) {
        }
        this.frameAvailable = false;
        return this.stMatrix;
    }

    public final void setDefaultBufferSize(int w, int h) {
        try {
            this.surfaceTexture.setDefaultBufferSize(w, h);
        } catch (Exception unused) {
        }
    }

    public final void release() {
        try {
            this.surface.release();
        } catch (Exception unused) {
        }
        try {
            this.surfaceTexture.release();
        } catch (Exception unused2) {
        }
        GlUtil.INSTANCE.deleteTexture(this.texId);
    }
}
