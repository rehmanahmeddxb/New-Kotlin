package com.rehman.ahmedreactionstudio.core;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: Model.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J@\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\b\u0010\t\u001a\u0004\u0018\u00010\b2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\rJP\u0010\u0010\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\b\u0010\t\u001a\u0004\u0018\u00010\b2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\r2\u0006\u0010\u0011\u001a\u00020\r2\u0006\u0010\u0012\u001a\u00020\r"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/LayerPresets;", "", "()V", "fullscreen", "Lcom/rehman/ahmedreactionstudio/core/Layer;", "type", "Lcom/rehman/ahmedreactionstudio/core/LayerType;", "name", "", "relPath", "durMs", "", "sw", "", "sh", "rot", "pipDefault", "canvasW", "canvasH"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class LayerPresets {

    @NotNull
    public static final LayerPresets INSTANCE = new LayerPresets();

    private LayerPresets() {
    }

    @NotNull
    public final Layer fullscreen(@NotNull LayerType type, @NotNull String name, @Nullable String relPath, long durMs, int sw, int sh, int rot) {
        Intrinsics.checkNotNullParameter(type, "type");
        Intrinsics.checkNotNullParameter(name, "name");
        Layer layer = new Layer(null, type, name, relPath, durMs, sw, sh, rot, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, false, false, false, false, false, null, 0.0f, 0.0f, false, 0L, 0.0f, false, 0, false, null, 0, 0.0f, false, 0L, -255, null);
        LayerFit.INSTANCE.fill(layer);
        return layer;
    }

    @NotNull
    public final Layer pipDefault(@NotNull LayerType type, @NotNull String name, @Nullable String relPath, long durMs, int sw, int sh, int rot, int canvasW, int canvasH) {
        Intrinsics.checkNotNullParameter(type, "type");
        Intrinsics.checkNotNullParameter(name, "name");
        Layer layer = new Layer(null, type, name, relPath, durMs, sw, sh, rot, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, false, false, false, false, false, null, 0.0f, 0.0f, false, 0L, 0.0f, false, 0, false, null, 0, 0.0f, false, 0L, -255, null);
        LayerFit.pip$default(LayerFit.INSTANCE, layer, canvasW, canvasH, null, 0.0f, 0.0f, 0.0f, 120, null);
        return layer;
    }
}
