package com.rehman.ahmedreactionstudio.core;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import com.rehman.ahmedreactionstudio.export.AudioConfig;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import kotlin.Metadata;
import kotlin.io.ByteStreamsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: MediaKit.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001\u0019B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u001e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nJ\u001a\u0010\u000b\u001a\u0004\u0018\u00010\f2\u0006\u0010\r\u001a\u00020\u000e2\b\b\u0002\u0010\u000f\u001a\u00020\u0010J\u0010\u0010\u0011\u001a\u00020\u00042\b\u0010\u0012\u001a\u0004\u0018\u00010\u000eJ\u0016\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u0006J\u000e\u0010\u0013\u001a\u00020\u00142\u0006\u0010\r\u001a\u00020\u000eJ,\u0010\u0015\u001a\u0004\u0018\u00010\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u0016\u001a\u00020\u00172\b\b\u0002\u0010\u000f\u001a\u00020\u00102\b\b\u0002\u0010\u0018\u001a\u00020\u0004"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/MediaKit;", "", "()V", "copyContentToFile", "", "ctx", "Landroid/content/Context;", "uri", "Landroid/net/Uri;", "dest", "Ljava/io/File;", "image", "Landroid/graphics/Bitmap;", "path", "", "maxPx", "", "isImageMime", "mime", "probe", "Lcom/rehman/ahmedreactionstudio/core/MediaInfo;", "videoFrame", "ms", "", "closest", "FrameSource"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class MediaKit {

    @NotNull
    public static final MediaKit INSTANCE = new MediaKit();

    private MediaKit() {
    }

    @NotNull
    public final MediaInfo probe(@NotNull String path) {
        MediaInfo mediaInfo;
        Integer intOrNull;
        Integer intOrNull2;
        Integer intOrNull3;
        Long longOrNull;
        Intrinsics.checkNotNullParameter(path, "path");
        MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
        try {
            try {
                mediaMetadataRetriever.setDataSource(path);
                String strExtractMetadata = mediaMetadataRetriever.extractMetadata(9);
                long jLongValue = (strExtractMetadata == null || (longOrNull = StringsKt.toLongOrNull(strExtractMetadata)) == null) ? 0L : longOrNull.longValue();
                String strExtractMetadata2 = mediaMetadataRetriever.extractMetadata(18);
                int iIntValue = (strExtractMetadata2 == null || (intOrNull3 = StringsKt.toIntOrNull(strExtractMetadata2)) == null) ? 0 : intOrNull3.intValue();
                String strExtractMetadata3 = mediaMetadataRetriever.extractMetadata(19);
                int iIntValue2 = (strExtractMetadata3 == null || (intOrNull2 = StringsKt.toIntOrNull(strExtractMetadata3)) == null) ? 0 : intOrNull2.intValue();
                String strExtractMetadata4 = mediaMetadataRetriever.extractMetadata(24);
                mediaInfo = new MediaInfo(jLongValue, iIntValue, iIntValue2, (strExtractMetadata4 == null || (intOrNull = StringsKt.toIntOrNull(strExtractMetadata4)) == null) ? 0 : intOrNull.intValue(), mediaMetadataRetriever.extractMetadata(12));
            } finally {
                try {
                    mediaMetadataRetriever.release();
                } catch (Exception unused) {
                }
            }
        } catch (Exception unused2) {
            mediaInfo = new MediaInfo(0L, 0, 0, 0, null);
        }
        return mediaInfo;
    }

    @NotNull
    public final MediaInfo probe(@NotNull Uri uri, @NotNull Context ctx) {
        MediaInfo mediaInfo;
        Integer intOrNull;
        Integer intOrNull2;
        Integer intOrNull3;
        Long longOrNull;
        Intrinsics.checkNotNullParameter(uri, "uri");
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
        try {
            try {
                mediaMetadataRetriever.setDataSource(ctx, uri);
                String strExtractMetadata = mediaMetadataRetriever.extractMetadata(9);
                long jLongValue = (strExtractMetadata == null || (longOrNull = StringsKt.toLongOrNull(strExtractMetadata)) == null) ? 0L : longOrNull.longValue();
                String strExtractMetadata2 = mediaMetadataRetriever.extractMetadata(18);
                int iIntValue = (strExtractMetadata2 == null || (intOrNull3 = StringsKt.toIntOrNull(strExtractMetadata2)) == null) ? 0 : intOrNull3.intValue();
                String strExtractMetadata3 = mediaMetadataRetriever.extractMetadata(19);
                int iIntValue2 = (strExtractMetadata3 == null || (intOrNull2 = StringsKt.toIntOrNull(strExtractMetadata3)) == null) ? 0 : intOrNull2.intValue();
                String strExtractMetadata4 = mediaMetadataRetriever.extractMetadata(24);
                mediaInfo = new MediaInfo(jLongValue, iIntValue, iIntValue2, (strExtractMetadata4 == null || (intOrNull = StringsKt.toIntOrNull(strExtractMetadata4)) == null) ? 0 : intOrNull.intValue(), null);
            } finally {
                try {
                    mediaMetadataRetriever.release();
                } catch (Exception unused) {
                }
            }
        } catch (Exception unused2) {
            mediaInfo = new MediaInfo(0L, 0, 0, 0, null);
        }
        return mediaInfo;
    }

    public final boolean isImageMime(@Nullable String mime) {
        if (mime != null) {
            return StringsKt.startsWith$default(mime, "image/", false, 2, (Object) null) || Intrinsics.areEqual(mime, "image/webp");
        }
        return false;
    }

    /* JADX INFO: compiled from: MediaKit.kt */
    @Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\"\u0010\u0015\u001a\u0004\u0018\u00010\u00162\u0006\u0010\u0017\u001a\u00020\b2\u0006\u0010\u0018\u001a\u00020\u00142\b\b\u0002\u0010\u0019\u001a\u00020\u0006J\u0018\u0010\u001a\u001a\u00020\u00162\u0006\u0010\u001b\u001a\u00020\u00162\u0006\u0010\u0018\u001a\u00020\u0014H\u0002J\u0006\u0010\u001c\u001a\u00020\u001dJ\n\u0010\u001e\u001a\u0004\u0018\u00010\u0012H\u0002R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\t\u001a\u00020\b2\u0006\u0010\u0007\u001a\u00020\b@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u001e\u0010\u000e\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0006@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/MediaKit$FrameSource;", "", "path", "", "(Ljava/lang/String;)V", "broken", "", "<set-?>", "", "lastDecodeMs", "getLastDecodeMs", "()J", "getPath", "()Ljava/lang/String;", "produced", "getProduced", "()Z", "r", "Landroid/media/MediaMetadataRetriever;", "rot", "", "frameAt", "Landroid/graphics/Bitmap;", "ms", "maxPx", "closest", "postProcess", "src", "release", "", "retriever"}, k = 1, mv = {1, 9, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nMediaKit.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MediaKit.kt\ncom/rehman/ahmedreactionstudio/core/MediaKit$FrameSource\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,187:1\n1#2:188\n*E\n"})
    public static final class FrameSource {
        private boolean broken;
        private long lastDecodeMs;

        @NotNull
        private final String path;
        private boolean produced;

        @Nullable
        private MediaMetadataRetriever r;
        private int rot;

        public FrameSource(@NotNull String path) {
            Intrinsics.checkNotNullParameter(path, "path");
            this.path = path;
        }

        @NotNull
        public final String getPath() {
            return this.path;
        }

        public final long getLastDecodeMs() {
            return this.lastDecodeMs;
        }

        public final boolean getProduced() {
            return this.produced;
        }

        private final synchronized MediaMetadataRetriever retriever() {
            MediaMetadataRetriever mediaMetadataRetriever;
            Integer intOrNull;
            if (this.broken) {
                return null;
            }
            MediaMetadataRetriever mediaMetadataRetriever2 = this.r;
            if (mediaMetadataRetriever2 != null) {
                return mediaMetadataRetriever2;
            }
            try {
                mediaMetadataRetriever = new MediaMetadataRetriever();
                mediaMetadataRetriever.setDataSource(this.path);
                String strExtractMetadata = mediaMetadataRetriever.extractMetadata(24);
                this.rot = (strExtractMetadata == null || (intOrNull = StringsKt.toIntOrNull(strExtractMetadata)) == null) ? 0 : intOrNull.intValue();
            } catch (Exception unused) {
                this.broken = true;
                mediaMetadataRetriever = null;
            }
            this.r = mediaMetadataRetriever;
            return mediaMetadataRetriever;
        }

        public static /* synthetic */ Bitmap frameAt$default(FrameSource frameSource, long j, int i, boolean z, int i2, Object obj) {
            if ((i2 & 4) != 0) {
                z = false;
            }
            return frameSource.frameAt(j, i, z);
        }

        /* JADX WARN: Removed duplicated region for block: B:30:0x0047 A[DONT_GENERATE] */
        /* JADX WARN: Removed duplicated region for block: B:32:0x0049  */
        /* JADX WARN: Removed duplicated region for block: B:42:0x0037 A[EXC_TOP_SPLITTER, SYNTHETIC] */
        @org.jetbrains.annotations.Nullable
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final synchronized android.graphics.Bitmap frameAt(long r11, int r13, boolean r14) {
            /*
                r10 = this;
                monitor-enter(r10)
                boolean r0 = r10.broken     // Catch: java.lang.Throwable -> L52
                r1 = 0
                if (r0 == 0) goto L8
                monitor-exit(r10)
                return r1
            L8:
                android.media.MediaMetadataRetriever r0 = r10.retriever()     // Catch: java.lang.Throwable -> L52
                if (r0 != 0) goto L10
                monitor-exit(r10)
                return r1
            L10:
                long r8 = android.os.SystemClock.elapsedRealtime()     // Catch: java.lang.Throwable -> L52
                r2 = 0
                long r11 = kotlin.ranges.RangesKt.coerceAtLeast(r11, r2)     // Catch: java.lang.Throwable -> L52
                r2 = 1000(0x3e8, double:4.94E-321)
                long r11 = r11 * r2
                if (r14 == 0) goto L21
                r14 = 2
                goto L22
            L21:
                r14 = 0
            L22:
                int r2 = android.os.Build.VERSION.SDK_INT     // Catch: java.lang.Throwable -> L52
                r3 = 27
                if (r2 < r3) goto L34
                if (r13 <= 0) goto L34
                r2 = r0
                r3 = r11
                r5 = r14
                r6 = r13
                r7 = r13
                android.graphics.Bitmap r2 = r2.getScaledFrameAtTime(r3, r5, r6, r7)     // Catch: java.lang.Exception -> L34 java.lang.Throwable -> L52
                goto L35
            L34:
                r2 = r1
            L35:
                if (r2 != 0) goto L3e
                android.graphics.Bitmap r11 = r0.getFrameAtTime(r11, r14)     // Catch: java.lang.Exception -> L3d java.lang.Throwable -> L52
                r2 = r11
                goto L3e
            L3d:
                r2 = r1
            L3e:
                long r11 = android.os.SystemClock.elapsedRealtime()     // Catch: java.lang.Throwable -> L52
                long r11 = r11 - r8
                r10.lastDecodeMs = r11     // Catch: java.lang.Throwable -> L52
                if (r2 != 0) goto L49
                monitor-exit(r10)
                return r1
            L49:
                r11 = 1
                r10.produced = r11     // Catch: java.lang.Throwable -> L52
                android.graphics.Bitmap r11 = r10.postProcess(r2, r13)     // Catch: java.lang.Throwable -> L52
                monitor-exit(r10)
                return r11
            L52:
                r11 = move-exception
                monitor-exit(r10)
                throw r11
            */
            throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.core.MediaKit.FrameSource.frameAt(long, int, boolean):android.graphics.Bitmap");
        }

        private final Bitmap postProcess(Bitmap src, int maxPx) {
            Bitmap bitmapCreateBitmap;
            float fMax = maxPx > 0 ? maxPx / Math.max(src.getWidth(), src.getHeight()) : 1.0f;
            boolean z = fMax < 0.999f;
            if (this.rot == 0 && !z) {
                return src;
            }
            Matrix matrix = new Matrix();
            int i = this.rot;
            if (i != 0) {
                matrix.postRotate(i);
            }
            if (z) {
                matrix.postScale(fMax, fMax);
            }
            try {
                bitmapCreateBitmap = Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), matrix, true);
            } catch (Exception unused) {
                bitmapCreateBitmap = null;
            }
            if (bitmapCreateBitmap != null && bitmapCreateBitmap != src) {
                src.recycle();
            }
            return bitmapCreateBitmap == null ? src : bitmapCreateBitmap;
        }

        public final synchronized void release() {
            try {
                MediaMetadataRetriever mediaMetadataRetriever = this.r;
                if (mediaMetadataRetriever != null) {
                    mediaMetadataRetriever.release();
                }
            } catch (Exception unused) {
            }
            this.r = null;
            this.broken = true;
        }
    }

    public static /* synthetic */ Bitmap videoFrame$default(MediaKit mediaKit, String str, long j, int i, boolean z, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            i = 1280;
        }
        int i3 = i;
        if ((i2 & 8) != 0) {
            z = false;
        }
        return mediaKit.videoFrame(str, j, i3, z);
    }

    @Nullable
    public final Bitmap videoFrame(@NotNull String path, long ms, int maxPx, boolean closest) {
        Intrinsics.checkNotNullParameter(path, "path");
        FrameSource frameSource = new FrameSource(path);
        try {
            return frameSource.frameAt(ms, maxPx, closest);
        } finally {
            frameSource.release();
        }
    }

    public static /* synthetic */ Bitmap image$default(MediaKit mediaKit, String str, int i, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            i = AudioConfig.CHUNK_BYTES;
        }
        return mediaKit.image(str, i);
    }

    @Nullable
    public final Bitmap image(@NotNull String path, int maxPx) {
        Intrinsics.checkNotNullParameter(path, "path");
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            int i = 1;
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, options);
            while (true) {
                int i2 = i * 2;
                if (Math.max(options.outWidth, options.outHeight) / i2 <= maxPx) {
                    BitmapFactory.Options options2 = new BitmapFactory.Options();
                    options2.inSampleSize = i;
                    return BitmapFactory.decodeFile(path, options2);
                }
                i = i2;
            }
        } catch (Exception unused) {
            return null;
        }
    }

    public final boolean copyContentToFile(@NotNull Context ctx, @NotNull Uri uri, @NotNull File dest) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(uri, "uri");
        Intrinsics.checkNotNullParameter(dest, "dest");
        try {
            File parentFile = dest.getParentFile();
            if (parentFile != null) {
                parentFile.mkdirs();
            }
            InputStream inputStreamOpenInputStream = ctx.getContentResolver().openInputStream(uri);
            if (inputStreamOpenInputStream == null) {
                return false;
            }
            FileOutputStream fileOutputStream = new FileOutputStream(dest);
            ByteStreamsKt.copyTo$default(inputStreamOpenInputStream, fileOutputStream, 0, 2, null);
            fileOutputStream.flush();
            fileOutputStream.close();
            inputStreamOpenInputStream.close();
            return true;
        } catch (Exception unused) {
            return false;
        }
    }
}
