package com.rehman.ahmedreactionstudio.core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: Model.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0007\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0006\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J \u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\nJ \u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\n2\u0006\u0010\u000e\u001a\u00020\nH\u0002J\u0018\u0010\u000f\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u000e\u001a\u00020\nJ(\u0010\u0010\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00122\b\b\u0002\u0010\u0014\u001a\u00020\nJ:\u0010\u0015\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\n0\u00162\u0006\u0010\u0017\u001a\u00020\n2\u0006\u0010\u0018\u001a\u00020\n2\u0006\u0010\u0019\u001a\u00020\u00122\u0006\u0010\u001a\u001a\u00020\u00122\u0006\u0010\u001b\u001a\u00020\bJ*\u0010\u001c\u001a\u000e\u0012\u0004\u0012\u00020\u0012\u0012\u0004\u0012\u00020\u00120\u00162\u0006\u0010\u001d\u001a\u00020\u00122\u0006\u0010\u001e\u001a\u00020\u00122\u0006\u0010\u001f\u001a\u00020\u0012J\u000e\u0010 \u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006J6\u0010!\u001a\u0004\u0018\u00010\u00062\f\u0010\"\u001a\b\u0012\u0004\u0012\u00020\u00060#2\u0006\u0010$\u001a\u00020\n2\u0006\u0010%\u001a\u00020\n2\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0012J\u000e\u0010&\u001a\u00020'2\u0006\u0010\u0005\u001a\u00020\u0006JF\u0010(\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00122\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010)\u001a\u00020\n2\b\b\u0002\u0010*\u001a\u00020\n2\b\b\u0002\u0010\t\u001a\u00020\nJ,\u0010+\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\f\u0010,\u001a\b\u0012\u0004\u0012\u00020\u00060#2\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0012J\u001e\u0010-\u001a\u00020\n2\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0012"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/LayerFit;", "", "()V", "anchorTo", "", "l", "Lcom/rehman/ahmedreactionstudio/core/Layer;", "anchor", "", "margin", "", "clampAxis", "v", "size", "keep", "clampInside", "contain", "canvasW", "", "canvasH", "inset", "drawnFrame", "Lkotlin/Pair;", "boxW", "boxH", "effW", "effH", Layer.FIT_FIT, "effective", "srcW", "srcH", "rotation", Layer.FIT_FILL, "hitTest", "layers", "", "x", "y", "isFullBleed", "", "pip", "maxW", "maxH", "placeNewPip", "existing", "sourceAspect"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nModel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Model.kt\ncom/rehman/ahmedreactionstudio/core/LayerFit\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,430:1\n766#2:431\n857#2,2:432\n2624#2,3:434\n*S KotlinDebug\n*F\n+ 1 Model.kt\ncom/rehman/ahmedreactionstudio/core/LayerFit\n*L\n340#1:431\n340#1:432,2\n346#1:434,3\n*E\n"})
public final class LayerFit {

    @NotNull
    public static final LayerFit INSTANCE = new LayerFit();

    private LayerFit() {
    }

    @NotNull
    public final Pair<Integer, Integer> effective(int srcW, int srcH, int rotation) {
        if ((rotation == 90 || rotation == 270) && srcW > 0 && srcH > 0) {
            return new Pair<>(Integer.valueOf(srcH), Integer.valueOf(srcW));
        }
        return new Pair<>(Integer.valueOf(srcW), Integer.valueOf(srcH));
    }

    @NotNull
    public final Pair<Float, Float> drawnFrame(float boxW, float boxH, int effW, int effH, @NotNull String fit) {
        Intrinsics.checkNotNullParameter(fit, "fit");
        Float fValueOf = Float.valueOf(0.0f);
        if (effW <= 0 || effH <= 0 || boxW <= 0.0f || boxH <= 0.0f) {
            return new Pair<>(fValueOf, fValueOf);
        }
        float fMin = Intrinsics.areEqual(fit, Layer.FIT_FIT) ? Math.min(boxW / effW, boxH / effH) : Math.max(boxW / effW, boxH / effH);
        return new Pair<>(Float.valueOf(effW * fMin), Float.valueOf(effH * fMin));
    }

    public final float sourceAspect(@NotNull Layer l, int canvasW, int canvasH) {
        Intrinsics.checkNotNullParameter(l, "l");
        Pair<Integer, Integer> pairEffective = effective(l.getSrcW(), l.getSrcH(), l.getSrcRotation());
        int iIntValue = pairEffective.component1().intValue();
        int iIntValue2 = pairEffective.component2().intValue();
        return (iIntValue <= 0 || iIntValue2 <= 0) ? canvasW / canvasH : iIntValue / iIntValue2;
    }

    public final boolean isFullBleed(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        return l.getWN() >= 0.985f && l.getHN() >= 0.985f;
    }

    public final void fill(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        l.setCx(0.5f);
        l.setCy(0.5f);
        l.setWN(1.0f);
        l.setHN(1.0f);
        l.setRotDeg(0.0f);
    }

    public static /* synthetic */ void contain$default(LayerFit layerFit, Layer layer, int i, int i2, float f, int i3, Object obj) {
        if ((i3 & 8) != 0) {
            f = 1.0f;
        }
        layerFit.contain(layer, i, i2, f);
    }

    public final void contain(@NotNull Layer l, int canvasW, int canvasH, float inset) {
        Intrinsics.checkNotNullParameter(l, "l");
        float fSourceAspect = sourceAspect(l, canvasW, canvasH);
        float f = canvasW / canvasH;
        if (fSourceAspect >= f) {
            l.setWN(1.0f);
            l.setHN(f / fSourceAspect);
        } else {
            l.setHN(1.0f);
            l.setWN(fSourceAspect / f);
        }
        l.setWN(l.getWN() * inset);
        l.setHN(l.getHN() * inset);
        l.setCx(0.5f);
        l.setCy(0.5f);
    }

    public static /* synthetic */ void pip$default(LayerFit layerFit, Layer layer, int i, int i2, String str, float f, float f2, float f3, int i3, Object obj) {
        layerFit.pip(layer, i, i2, (i3 & 8) != 0 ? "br" : str, (i3 & 16) != 0 ? 0.36f : f, (i3 & 32) != 0 ? 0.42f : f2, (i3 & 64) != 0 ? 0.035f : f3);
    }

    public final void pip(@NotNull Layer l, int canvasW, int canvasH, @NotNull String anchor, float maxW, float maxH, float margin) {
        Intrinsics.checkNotNullParameter(l, "l");
        Intrinsics.checkNotNullParameter(anchor, "anchor");
        Pair<Integer, Integer> pairEffective = effective(l.getSrcW(), l.getSrcH(), l.getSrcRotation());
        int iIntValue = pairEffective.component1().intValue();
        int iIntValue2 = pairEffective.component2().intValue();
        float f = (iIntValue <= 0 || iIntValue2 <= 0) ? canvasW : iIntValue;
        float f2 = (iIntValue <= 0 || iIntValue2 <= 0) ? canvasH : iIntValue2;
        float f3 = canvasW;
        float f4 = canvasH;
        float fMin = Math.min((maxW * f3) / f, (maxH * f4) / f2);
        l.setWN((f * fMin) / f3);
        l.setHN((f2 * fMin) / f4);
        l.setRotDeg(0.0f);
        anchorTo(l, anchor, margin);
    }

    public final void placeNewPip(@NotNull Layer l, @NotNull List<Layer> existing, int canvasW, int canvasH) {
        boolean z;
        Intrinsics.checkNotNullParameter(l, "l");
        Intrinsics.checkNotNullParameter(existing, "existing");
        ArrayList arrayList = new ArrayList();
        Iterator<T> it = existing.iterator();
        while (true) {
            boolean z2 = false;
            if (!it.hasNext()) {
                break;
            }
            Object next = it.next();
            Layer layer = (Layer) next;
            if (!Intrinsics.areEqual(layer.getId(), l.getId()) && layer.getVisible() && !INSTANCE.isFullBleed(layer)) {
                z2 = true;
            }
            if (z2) {
                arrayList.add(next);
            }
        }
        ArrayList arrayList2 = arrayList;
        String[] strArr = {"br", "bl", "tr", "tl"};
        int length = strArr.length;
        int i = 0;
        while (i < length) {
            int i2 = i;
            pip$default(this, l, canvasW, canvasH, strArr[i], 0.0f, 0.0f, 0.0f, 112, null);
            ArrayList arrayList3 = arrayList2;
            if ((arrayList3 instanceof Collection) && arrayList3.isEmpty()) {
                z = true;
            } else {
                Iterator it2 = arrayList3.iterator();
                while (it2.hasNext()) {
                    if (placeNewPip$overlaps((Layer) it2.next(), l)) {
                        z = false;
                        break;
                    }
                }
                z = true;
            }
            if (z) {
                return;
            } else {
                i = i2 + 1;
            }
        }
        pip$default(this, l, canvasW, canvasH, "br", 0.0f, 0.0f, 0.0f, 112, null);
        Layer layer2 = (Layer) CollectionsKt.lastOrNull((List) arrayList2);
        if (layer2 == null) {
            return;
        }
        l.setCx(layer2.getCx() - 0.06f);
        l.setCy(layer2.getCy() - 0.06f);
        clampInside$default(this, l, 0.0f, 2, null);
    }

    private static final boolean placeNewPip$overlaps(Layer layer, Layer layer2) {
        return Math.abs(layer.getCx() - layer2.getCx()) < ((layer.getWN() + layer2.getWN()) / 2.0f) * 0.9f && Math.abs(layer.getCy() - layer2.getCy()) < ((layer.getHN() + layer2.getHN()) / 2.0f) * 0.9f;
    }

    @Nullable
    public final Layer hitTest(@NotNull List<Layer> layers, float x, float y, int canvasW, int canvasH) {
        int size;
        Intrinsics.checkNotNullParameter(layers, "layers");
        if (x < 0.0f || y < 0.0f) {
            return null;
        }
        float f = canvasW;
        if (x > f) {
            return null;
        }
        float f2 = canvasH;
        if (y > f2 || layers.size() - 1 < 0) {
            return null;
        }
        while (true) {
            int i = size - 1;
            Layer layer = layers.get(size);
            if (layer.getVisible() && layer.getOpacity() > 0.01f) {
                float cx = layer.getCx() * f;
                float cy = layer.getCy() * f2;
                float wn = (layer.getWN() * f) / 2.0f;
                float hn = (layer.getHN() * f2) / 2.0f;
                double radians = Math.toRadians(-layer.getRotDeg());
                double d = x - cx;
                double d2 = y - cy;
                float fCos = (float) ((Math.cos(radians) * d) - (Math.sin(radians) * d2));
                float fSin = (float) ((d * Math.sin(radians)) + (d2 * Math.cos(radians)));
                if (Math.abs(fCos) <= wn && Math.abs(fSin) <= hn) {
                    return layer;
                }
            }
            if (i < 0) {
                return null;
            }
            size = i;
        }
    }

    public static /* synthetic */ void anchorTo$default(LayerFit layerFit, Layer layer, String str, float f, int i, Object obj) {
        if ((i & 4) != 0) {
            f = 0.035f;
        }
        layerFit.anchorTo(layer, str, f);
    }

    /* JADX WARN: Removed duplicated region for block: B:49:0x00fc  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void anchorTo(@org.jetbrains.annotations.NotNull com.rehman.ahmedreactionstudio.core.Layer r6, @org.jetbrains.annotations.NotNull java.lang.String r7, float r8) {
        /*
            Method dump skipped, instruction units count: 279
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.core.LayerFit.anchorTo(com.rehman.ahmedreactionstudio.core.Layer, java.lang.String, float):void");
    }

    public static /* synthetic */ void clampInside$default(LayerFit layerFit, Layer layer, float f, int i, Object obj) {
        if ((i & 2) != 0) {
            f = 0.4f;
        }
        layerFit.clampInside(layer, f);
    }

    public final void clampInside(@NotNull Layer l, float keep) {
        Intrinsics.checkNotNullParameter(l, "l");
        l.setCx(clampAxis(l.getCx(), l.getWN(), keep));
        l.setCy(clampAxis(l.getCy(), l.getHN(), keep));
    }

    private final float clampAxis(float v, float size, float keep) {
        float f = size / 2.0f;
        float f2 = size * (1.0f - keep);
        float f3 = f - f2;
        float f4 = (1.0f - f) + f2;
        if (f3 >= f4) {
            return 0.5f;
        }
        return RangesKt.coerceIn(v, f3, f4);
    }
}
