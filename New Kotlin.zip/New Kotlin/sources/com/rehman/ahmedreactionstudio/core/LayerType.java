package com.rehman.ahmedreactionstudio.core;

import java.util.Iterator;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: Model.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\b\t\b\u0086\u0081\u0002\u0018\u0000 \f2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\fB\u000f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000b"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/LayerType;", "", "label", "", "(Ljava/lang/String;ILjava/lang/String;)V", "getLabel", "()Ljava/lang/String;", "VIDEO", "CAMERA", "SCREEN", "IMAGE", "TEXT", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
public enum LayerType {
    VIDEO("Video"),
    CAMERA("Camera"),
    SCREEN("Screen record"),
    IMAGE("Image"),
    TEXT("Text");


    @NotNull
    private final String label;
    private static final /* synthetic */ EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @NotNull
    public static EnumEntries<LayerType> getEntries() {
        return $ENTRIES;
    }

    LayerType(String str) {
        this.label = str;
    }

    @NotNull
    public final String getLabel() {
        return this.label;
    }

    /* JADX INFO: compiled from: Model.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/LayerType$Companion;", "", "()V", "from", "Lcom/rehman/ahmedreactionstudio/core/LayerType;", "s", ""}, k = 1, mv = {1, 9, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nModel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Model.kt\ncom/rehman/ahmedreactionstudio/core/LayerType$Companion\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,430:1\n288#2,2:431\n*S KotlinDebug\n*F\n+ 1 Model.kt\ncom/rehman/ahmedreactionstudio/core/LayerType$Companion\n*L\n26#1:431,2\n*E\n"})
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        @NotNull
        public final LayerType from(@NotNull String s) {
            LayerType next;
            Intrinsics.checkNotNullParameter(s, "s");
            Iterator<LayerType> it = LayerType.getEntries().iterator();
            while (true) {
                if (!it.hasNext()) {
                    next = null;
                    break;
                }
                next = it.next();
                if (Intrinsics.areEqual(next.name(), s)) {
                    break;
                }
            }
            LayerType layerType = next;
            return layerType == null ? LayerType.VIDEO : layerType;
        }
    }
}
