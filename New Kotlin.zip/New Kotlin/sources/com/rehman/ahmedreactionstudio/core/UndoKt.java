package com.rehman.ahmedreactionstudio.core;

import com.rehman.ahmedreactionstudio.core.Aspect;
import com.rehman.ahmedreactionstudio.core.Layer;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: Undo.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0016\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005\u001a\u000e\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0002\u001a\u00020\u0003"}, d2 = {"applyLayersJson", "", "p", "Lcom/rehman/ahmedreactionstudio/core/Project;", "o", "Lorg/json/JSONObject;", "layersJsonOf"}, k = 2, mv = {1, 9, 0}, xi = 48)
public final class UndoKt {
    @NotNull
    public static final JSONObject layersJsonOf(@NotNull Project p) throws JSONException {
        Intrinsics.checkNotNullParameter(p, "p");
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("id", p.getId());
        jSONObject.put("aspect", p.getAspect().getCode());
        JSONArray jSONArray = new JSONArray();
        Iterator<Layer> it = p.getLayers().iterator();
        while (it.hasNext()) {
            jSONArray.put(it.next().toJson());
        }
        jSONObject.put("layers", jSONArray);
        return jSONObject;
    }

    public static final void applyLayersJson(@NotNull Project p, @NotNull JSONObject o) {
        Intrinsics.checkNotNullParameter(p, "p");
        Intrinsics.checkNotNullParameter(o, "o");
        if (o.has("aspect")) {
            try {
                Aspect.Companion companion = Aspect.INSTANCE;
                String string = o.getString("aspect");
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                p.setAspect(companion.from(string));
            } catch (Exception unused) {
            }
        }
        p.getLayers().clear();
        JSONArray jSONArrayOptJSONArray = o.optJSONArray("layers");
        if (jSONArrayOptJSONArray == null) {
            return;
        }
        int length = jSONArrayOptJSONArray.length();
        for (int i = 0; i < length; i++) {
            try {
                List<Layer> layers = p.getLayers();
                Layer.Companion companion2 = Layer.INSTANCE;
                JSONObject jSONObject = jSONArrayOptJSONArray.getJSONObject(i);
                Intrinsics.checkNotNullExpressionValue(jSONObject, "getJSONObject(...)");
                layers.add(companion2.fromJson(jSONObject));
            } catch (Exception unused2) {
            }
        }
    }
}
