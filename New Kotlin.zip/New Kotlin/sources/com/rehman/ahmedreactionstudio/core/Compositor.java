package com.rehman.ahmedreactionstudio.core;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: Compositor.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010$\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001'B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J0\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\rJn\u0010\u000e\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\u0013\u001a\u00020\u00142\u0014\u0010\u0015\u001a\u0010\u0012\u0004\u0012\u00020\u0006\u0012\u0006\u0012\u0004\u0018\u00010\b0\u00162\u0006\u0010\u0017\u001a\u00020\u00182\n\b\u0002\u0010\u0019\u001a\u0004\u0018\u00010\u001a2\u0014\b\u0002\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u001a\u0012\u0004\u0012\u00020\u001a0\u001cJJ\u0010\u001d\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\u0005\u001a\u00020\u00062\b\u0010\u001e\u001a\u0004\u0018\u00010\b2\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u001f\u001a\u00020\u001aH\u0002J0\u0010 \u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010!\u001a\u00020\r2\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u001f\u001a\u00020\u001aH\u0002J*\u0010\"\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\n0#2\u0006\u0010$\u001a\u00020\n2\u0006\u0010%\u001a\u00020\n2\u0006\u0010&\u001a\u00020\n"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/Compositor;", "", "()V", "chromeRect", "", "l", "Lcom/rehman/ahmedreactionstudio/core/Layer;", "b", "Landroid/graphics/Bitmap;", "W", "", "H", "out", "Landroid/graphics/RectF;", "draw", "ctx", "Lcom/rehman/ahmedreactionstudio/core/Compositor$Ctx;", "canvas", "Landroid/graphics/Canvas;", "p", "Lcom/rehman/ahmedreactionstudio/core/Project;", "bitmapFor", "Lkotlin/Function1;", "timeMs", "", "selectionId", "", "textOverrides", "", "drawLayer", "bmp", "text", "drawText", "box", "effectiveSize", "Lkotlin/Pair;", "sw", "sh", "rotation", "Ctx"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nCompositor.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Compositor.kt\ncom/rehman/ahmedreactionstudio/core/Compositor\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,210:1\n766#2:211\n857#2,2:212\n*S KotlinDebug\n*F\n+ 1 Compositor.kt\ncom/rehman/ahmedreactionstudio/core/Compositor\n*L\n176#1:211\n176#1:212,2\n*E\n"})
public final class Compositor {

    @NotNull
    public static final Compositor INSTANCE = new Compositor();

    private Compositor() {
    }

    /* JADX INFO: compiled from: Compositor.kt */
    @Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u001a\u0010\u0007\u001a\u00020\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\fR\u0011\u0010\r\u001a\u00020\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0011\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0006R-\u0010\u0013\u001a\u001e\u0012\u0004\u0012\u00020\u0015\u0012\u0004\u0012\u00020\u00160\u0014j\u000e\u0012\u0004\u0012\u00020\u0015\u0012\u0004\u0012\u00020\u0016`\u0017¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0011\u0010\u001a\u001a\u00020\u001b¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001d"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/Compositor$Ctx;", "", "()V", "dst", "Landroid/graphics/RectF;", "getDst", "()Landroid/graphics/RectF;", "measuredFontPx", "", "getMeasuredFontPx", "()F", "setMeasuredFontPx", "(F)V", "p", "Landroid/graphics/Paint;", "getP", "()Landroid/graphics/Paint;", "rect", "getRect", "staticCache", "Ljava/util/HashMap;", "", "Landroid/text/StaticLayout;", "Lkotlin/collections/HashMap;", "getStaticCache", "()Ljava/util/HashMap;", "textPaint", "Landroid/text/TextPaint;", "getTextPaint", "()Landroid/text/TextPaint;"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Ctx {
        private float measuredFontPx;

        @NotNull
        private final TextPaint textPaint = new TextPaint(1);

        @NotNull
        private final Paint p = new Paint(3);

        @NotNull
        private final RectF rect = new RectF();

        @NotNull
        private final RectF dst = new RectF();

        @NotNull
        private final HashMap<String, StaticLayout> staticCache = new HashMap<>();

        @NotNull
        public final TextPaint getTextPaint() {
            return this.textPaint;
        }

        @NotNull
        public final Paint getP() {
            return this.p;
        }

        @NotNull
        public final RectF getRect() {
            return this.rect;
        }

        @NotNull
        public final RectF getDst() {
            return this.dst;
        }

        @NotNull
        public final HashMap<String, StaticLayout> getStaticCache() {
            return this.staticCache;
        }

        public final float getMeasuredFontPx() {
            return this.measuredFontPx;
        }

        public final void setMeasuredFontPx(float f) {
            this.measuredFontPx = f;
        }
    }

    @NotNull
    public final Pair<Integer, Integer> effectiveSize(int sw, int sh, int rotation) {
        return (rotation == 90 || rotation == 270) ? new Pair<>(Integer.valueOf(sh), Integer.valueOf(sw)) : new Pair<>(Integer.valueOf(sw), Integer.valueOf(sh));
    }

    public final void chromeRect(@NotNull Layer l, @Nullable Bitmap b, int W, int H, @NotNull RectF out) {
        Intrinsics.checkNotNullParameter(l, "l");
        Intrinsics.checkNotNullParameter(out, "out");
        float f = W;
        float cx = l.getCx() * f;
        float f2 = H;
        float cy = l.getCy() * f2;
        float wn = f * l.getWN();
        float hn = f2 * l.getHN();
        if (l.getType() != LayerType.TEXT && b != null && !b.isRecycled()) {
            Pair<Integer, Integer> pairEffectiveSize = l.getSrcW() > 0 ? effectiveSize(l.getSrcW(), l.getSrcH(), l.getSrcRotation()) : new Pair<>(Integer.valueOf(b.getWidth()), Integer.valueOf(b.getHeight()));
            Pair<Float, Float> pairDrawnFrame = LayerFit.INSTANCE.drawnFrame(wn, hn, pairEffectiveSize.component1().intValue(), pairEffectiveSize.component2().intValue(), l.getFit());
            float fFloatValue = pairDrawnFrame.component1().floatValue();
            float fFloatValue2 = pairDrawnFrame.component2().floatValue();
            if (fFloatValue >= 1.0f && fFloatValue2 >= 1.0f) {
                wn = Math.min(wn, fFloatValue);
                hn = Math.min(hn, fFloatValue2);
            }
        }
        float fCoerceAtLeast = RangesKt.coerceAtLeast(wn, 1.0f) / 2.0f;
        float fCoerceAtLeast2 = RangesKt.coerceAtLeast(hn, 1.0f) / 2.0f;
        out.set(cx - fCoerceAtLeast, cy - fCoerceAtLeast2, cx + fCoerceAtLeast, cy + fCoerceAtLeast2);
    }

    public final void draw(@NotNull Ctx ctx, @NotNull Canvas canvas, int W, int H, @NotNull Project p, @NotNull Function1<? super Layer, Bitmap> bitmapFor, long timeMs, @Nullable String selectionId, @NotNull Map<String, String> textOverrides) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        Intrinsics.checkNotNullParameter(canvas, "canvas");
        Intrinsics.checkNotNullParameter(p, "p");
        Intrinsics.checkNotNullParameter(bitmapFor, "bitmapFor");
        Intrinsics.checkNotNullParameter(textOverrides, "textOverrides");
        canvas.drawColor(p.getBgColor());
        for (Layer layer : p.getLayers()) {
            if (layer.getVisible() && layer.getOpacity() > 0.005f) {
                Bitmap bitmapInvoke = bitmapFor.invoke(layer);
                String text = textOverrides.get(layer.getId());
                if (text == null) {
                    text = layer.getText();
                }
                drawLayer(ctx, canvas, W, H, layer, bitmapInvoke, timeMs, text);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x0135  */
    /* JADX WARN: Removed duplicated region for block: B:34:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void drawLayer(com.rehman.ahmedreactionstudio.core.Compositor.Ctx r17, android.graphics.Canvas r18, int r19, int r20, com.rehman.ahmedreactionstudio.core.Layer r21, android.graphics.Bitmap r22, long r23, java.lang.String r25) {
        /*
            Method dump skipped, instruction units count: 316
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.core.Compositor.drawLayer(com.rehman.ahmedreactionstudio.core.Compositor$Ctx, android.graphics.Canvas, int, int, com.rehman.ahmedreactionstudio.core.Layer, android.graphics.Bitmap, long, java.lang.String):void");
    }

    private final void drawText(Ctx ctx, Canvas canvas, RectF box, Layer l, String text) {
        String string = StringsKt.trim((CharSequence) text).toString();
        if (string.length() == 0) {
            return;
        }
        float fCoerceAtLeast = RangesKt.coerceAtLeast(l.getFontSizeN() * box.height(), 6.0f);
        ctx.getTextPaint().setTextSize(fCoerceAtLeast);
        ctx.getTextPaint().setColor(l.getTextColor());
        ctx.getTextPaint().setTypeface(Typeface.create("sans-serif-condensed", 1));
        ctx.getTextPaint().setAntiAlias(true);
        ctx.getTextPaint().setTextAlign(Paint.Align.LEFT);
        ctx.getTextPaint().setAlpha(RangesKt.coerceIn((int) (l.getOpacity() * 255.0f), 0, KotlinVersion.MAX_COMPONENT_VALUE));
        int iCoerceAtLeast = RangesKt.coerceAtLeast((int) (box.width() - (box.width() * 0.08f)), 40);
        List listSplit$default = StringsKt.split$default((CharSequence) string, new String[]{"\n"}, false, 0, 6, (Object) null);
        ArrayList arrayList = new ArrayList();
        for (Object obj : listSplit$default) {
            if (!StringsKt.isBlank((String) obj)) {
                arrayList.add(obj);
            }
        }
        ArrayList<String> arrayList2 = arrayList;
        if (arrayList2.isEmpty()) {
            return;
        }
        if (l.getShadow()) {
            ctx.getTextPaint().setShadowLayer(0.12f * fCoerceAtLeast, 0.0f, 0.06f * fCoerceAtLeast, -1728053248);
        }
        ArrayList<StaticLayout> arrayList3 = new ArrayList(arrayList2.size());
        int height = 0;
        for (String str : arrayList2) {
            String str2 = str + '|' + iCoerceAtLeast + '|' + ((int) fCoerceAtLeast) + '|' + l.getShadow();
            StaticLayout staticLayoutBuild = ctx.getStaticCache().get(str2);
            if (staticLayoutBuild == null) {
                staticLayoutBuild = StaticLayout.Builder.obtain(str, 0, str.length(), ctx.getTextPaint(), iCoerceAtLeast).setAlignment(Layout.Alignment.ALIGN_CENTER).setIncludePad(false).build();
                if (ctx.getStaticCache().size() > 96) {
                    ctx.getStaticCache().clear();
                }
                HashMap<String, StaticLayout> staticCache = ctx.getStaticCache();
                Intrinsics.checkNotNull(staticLayoutBuild);
                staticCache.put(str2, staticLayoutBuild);
            }
            arrayList3.add(staticLayoutBuild);
            height += staticLayoutBuild.getHeight();
        }
        float fCenterY = box.centerY() - (height / 2.0f);
        for (StaticLayout staticLayout : arrayList3) {
            canvas.save();
            canvas.translate(box.left + ((box.width() - iCoerceAtLeast) / 2.0f), fCenterY);
            staticLayout.draw(canvas);
            canvas.restore();
            fCenterY += staticLayout.getHeight();
        }
        ctx.getTextPaint().clearShadowLayer();
        ctx.getTextPaint().setAlpha(KotlinVersion.MAX_COMPONENT_VALUE);
    }
}
