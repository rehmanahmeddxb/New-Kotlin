package com.rehman.ahmedreactionstudio.core;

import kotlin.Metadata;
import kotlin.collections.ArrayDeque;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONObject;

/* JADX INFO: compiled from: Undo.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u0006\u0010\t\u001a\u00020\nJ\u0006\u0010\u000b\u001a\u00020\nJ\u0006\u0010\f\u001a\u00020\rJ\u0016\u0010\u000e\u001a\u0004\u0018\u00010\u000f2\f\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u000f0\u0011J\u0016\u0010\u0012\u001a\u0004\u0018\u00010\u000f2\f\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u000f0\u0011J\u0018\u0010\u0013\u001a\u00020\r2\u0006\u0010\u0014\u001a\u00020\u000f2\b\b\u0002\u0010\u0015\u001a\u00020\nR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u0004¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/UndoStack;", "", "maxDepth", "", "(I)V", "redo", "Lkotlin/collections/ArrayDeque;", "", "undo", "canRedo", "", "canUndo", "clear", "", "popRedo", "Lorg/json/JSONObject;", "storeCurrent", "Lkotlin/Function0;", "popUndo", "pushSnapshot", "layersJson", "limitSize"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class UndoStack {
    private final int maxDepth;

    @NotNull
    private final ArrayDeque<String> redo;

    @NotNull
    private final ArrayDeque<String> undo;

    public UndoStack() {
        this(0, 1, null);
    }

    public UndoStack(int i) {
        this.maxDepth = i;
        this.undo = new ArrayDeque<>();
        this.redo = new ArrayDeque<>();
    }

    public /* synthetic */ UndoStack(int i, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this((i2 & 1) != 0 ? 50 : i);
    }

    public static /* synthetic */ void pushSnapshot$default(UndoStack undoStack, JSONObject jSONObject, boolean z, int i, Object obj) {
        if ((i & 2) != 0) {
            z = true;
        }
        undoStack.pushSnapshot(jSONObject, z);
    }

    public final void pushSnapshot(@NotNull JSONObject layersJson, boolean limitSize) {
        Intrinsics.checkNotNullParameter(layersJson, "layersJson");
        if (this.undo.size() >= this.maxDepth) {
            this.undo.removeLast();
        }
        ArrayDeque<String> arrayDeque = this.undo;
        String string = layersJson.toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        arrayDeque.addFirst(string);
        this.redo.clear();
    }

    public final boolean canUndo() {
        return !this.undo.isEmpty();
    }

    public final boolean canRedo() {
        return !this.redo.isEmpty();
    }

    @Nullable
    public final JSONObject popUndo(@NotNull Function0<? extends JSONObject> storeCurrent) {
        Intrinsics.checkNotNullParameter(storeCurrent, "storeCurrent");
        if (this.undo.isEmpty()) {
            return null;
        }
        JSONObject jSONObjectInvoke = storeCurrent.invoke();
        ArrayDeque<String> arrayDeque = this.redo;
        String string = jSONObjectInvoke.toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        arrayDeque.addFirst(string);
        try {
            return new JSONObject(this.undo.removeFirst());
        } catch (Exception unused) {
            return null;
        }
    }

    @Nullable
    public final JSONObject popRedo(@NotNull Function0<? extends JSONObject> storeCurrent) {
        Intrinsics.checkNotNullParameter(storeCurrent, "storeCurrent");
        if (this.redo.isEmpty()) {
            return null;
        }
        JSONObject jSONObjectInvoke = storeCurrent.invoke();
        ArrayDeque<String> arrayDeque = this.undo;
        String string = jSONObjectInvoke.toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        arrayDeque.addFirst(string);
        try {
            return new JSONObject(this.redo.removeFirst());
        } catch (Exception unused) {
            return null;
        }
    }

    public final void clear() {
        this.undo.clear();
        this.redo.clear();
    }
}
