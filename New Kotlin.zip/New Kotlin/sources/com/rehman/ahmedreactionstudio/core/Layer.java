package com.rehman.ahmedreactionstudio.core;

import com.rehman.ahmedreactionstudio.core.LayerType;
import com.rehman.ahmedreactionstudio.export.AudioConfig;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.io.ConstantsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.IntCompanionObject;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: Model.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\bc\n\u0002\u0018\u0002\n\u0000\u0018\u0000 z2\u00020\u0001:\u0001zBÇ\u0002\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\u0003\u0012\b\b\u0002\u0010\b\u001a\u00020\t\u0012\b\b\u0002\u0010\n\u001a\u00020\u000b\u0012\b\b\u0002\u0010\f\u001a\u00020\u000b\u0012\b\b\u0002\u0010\r\u001a\u00020\u000b\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u000f\u0012\b\b\u0002\u0010\u0010\u001a\u00020\u000f\u0012\b\b\u0002\u0010\u0011\u001a\u00020\u000f\u0012\b\b\u0002\u0010\u0012\u001a\u00020\u000f\u0012\b\b\u0002\u0010\u0013\u001a\u00020\u000f\u0012\b\b\u0002\u0010\u0014\u001a\u00020\u0015\u0012\b\b\u0002\u0010\u0016\u001a\u00020\u0015\u0012\b\b\u0002\u0010\u0017\u001a\u00020\u0015\u0012\b\b\u0002\u0010\u0018\u001a\u00020\u0015\u0012\b\b\u0002\u0010\u0019\u001a\u00020\u0015\u0012\b\b\u0002\u0010\u001a\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u001b\u001a\u00020\u000f\u0012\b\b\u0002\u0010\u001c\u001a\u00020\u000f\u0012\b\b\u0002\u0010\u001d\u001a\u00020\u0015\u0012\b\b\u0002\u0010\u001e\u001a\u00020\t\u0012\b\b\u0002\u0010\u001f\u001a\u00020\u000f\u0012\b\b\u0002\u0010 \u001a\u00020\u0015\u0012\b\b\u0002\u0010!\u001a\u00020\u000b\u0012\b\b\u0002\u0010\"\u001a\u00020\u0015\u0012\b\b\u0002\u0010#\u001a\u00020\u0003\u0012\b\b\u0002\u0010$\u001a\u00020\u000b\u0012\b\b\u0002\u0010%\u001a\u00020\u000f\u0012\b\b\u0002\u0010&\u001a\u00020\u0015\u0012\b\b\u0002\u0010'\u001a\u00020\t¢\u0006\u0002\u0010(J\u0006\u0010s\u001a\u00020\u0000J\u0006\u0010t\u001a\u00020\u0015J\u0006\u0010u\u001a\u00020\u0015J\u0006\u0010v\u001a\u00020\u0015J\u0006\u0010w\u001a\u00020\u0015J\u0006\u0010x\u001a\u00020yR\u001a\u0010'\u001a\u00020\tX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b)\u0010*\"\u0004\b+\u0010,R\u001a\u0010!\u001a\u00020\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b-\u0010.\"\u0004\b/\u00100R\u001a\u0010\u000e\u001a\u00020\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b1\u00102\"\u0004\b3\u00104R\u001a\u0010\u0010\u001a\u00020\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b5\u00102\"\u0004\b6\u00104R\u001a\u0010\b\u001a\u00020\tX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b7\u0010*\"\u0004\b8\u0010,R\u001a\u0010\u001a\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b9\u0010:\"\u0004\b;\u0010<R\u001a\u0010%\u001a\u00020\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b=\u00102\"\u0004\b>\u00104R\u001a\u0010\u0012\u001a\u00020\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b?\u00102\"\u0004\b@\u00104R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bA\u0010:\"\u0004\bB\u0010<R\u001a\u0010 \u001a\u00020\u0015X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bC\u0010D\"\u0004\bE\u0010FR\u001a\u0010\u0016\u001a\u00020\u0015X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bG\u0010D\"\u0004\bH\u0010FR\u001a\u0010\u0019\u001a\u00020\u0015X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bI\u0010D\"\u0004\bJ\u0010FR\u001a\u0010\"\u001a\u00020\u0015X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bK\u0010D\"\u0004\bL\u0010FR\u001a\u0010\u0017\u001a\u00020\u0015X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bM\u0010D\"\u0004\bN\u0010FR\u001a\u0010\u0006\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bO\u0010:\"\u0004\bP\u0010<R\u001a\u0010\u001c\u001a\u00020\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bQ\u00102\"\u0004\bR\u00104R\u001a\u0010\u001e\u001a\u00020\tX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bS\u0010*\"\u0004\bT\u0010,R\u001a\u0010\u001d\u001a\u00020\u0015X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bU\u0010D\"\u0004\bV\u0010FR\u001c\u0010\u0007\u001a\u0004\u0018\u00010\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bW\u0010:\"\u0004\bX\u0010<R\u001a\u0010\u0013\u001a\u00020\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bY\u00102\"\u0004\bZ\u00104R\u001a\u0010&\u001a\u00020\u0015X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b[\u0010D\"\u0004\b\\\u0010FR\u001a\u0010\u0018\u001a\u00020\u0015X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b]\u0010D\"\u0004\b^\u0010FR\u001a\u0010\u001f\u001a\u00020\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b_\u00102\"\u0004\b`\u00104R\u001a\u0010\f\u001a\u00020\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\ba\u0010.\"\u0004\bb\u00100R\u001a\u0010\r\u001a\u00020\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bc\u0010.\"\u0004\bd\u00100R\u001a\u0010\n\u001a\u00020\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\be\u0010.\"\u0004\bf\u00100R\u001a\u0010#\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bg\u0010:\"\u0004\bh\u0010<R\u001a\u0010$\u001a\u00020\u000bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bi\u0010.\"\u0004\bj\u00100R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\bk\u0010lR\u001a\u0010\u0014\u001a\u00020\u0015X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bm\u0010D\"\u0004\bn\u0010FR\u001a\u0010\u001b\u001a\u00020\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bo\u00102\"\u0004\bp\u00104R\u001a\u0010\u0011\u001a\u00020\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\bq\u00102\"\u0004\br\u00104"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/Layer;", "", "id", "", "type", "Lcom/rehman/ahmedreactionstudio/core/LayerType;", "name", "relPath", "durMs", "", "srcW", "", "srcH", "srcRotation", "cx", "", "cy", "wN", "hN", "rotDeg", "visible", "", "locked", "muted", "solo", "loop", Layer.FIT_FIT, "volume", "opacity", "playing", "pausedMediaMs", "speed", "live", "camFacing", "mirror", "text", "textColor", "fontSizeN", "shadow", "addedAt", "(Ljava/lang/String;Lcom/rehman/ahmedreactionstudio/core/LayerType;Ljava/lang/String;Ljava/lang/String;JIIIFFFFFZZZZZLjava/lang/String;FFZJFZIZLjava/lang/String;IFZJ)V", "getAddedAt", "()J", "setAddedAt", "(J)V", "getCamFacing", "()I", "setCamFacing", "(I)V", "getCx", "()F", "setCx", "(F)V", "getCy", "setCy", "getDurMs", "setDurMs", "getFit", "()Ljava/lang/String;", "setFit", "(Ljava/lang/String;)V", "getFontSizeN", "setFontSizeN", "getHN", "setHN", "getId", "setId", "getLive", "()Z", "setLive", "(Z)V", "getLocked", "setLocked", "getLoop", "setLoop", "getMirror", "setMirror", "getMuted", "setMuted", "getName", "setName", "getOpacity", "setOpacity", "getPausedMediaMs", "setPausedMediaMs", "getPlaying", "setPlaying", "getRelPath", "setRelPath", "getRotDeg", "setRotDeg", "getShadow", "setShadow", "getSolo", "setSolo", "getSpeed", "setSpeed", "getSrcH", "setSrcH", "getSrcRotation", "setSrcRotation", "getSrcW", "setSrcW", "getText", "setText", "getTextColor", "setTextColor", "getType", "()Lcom/rehman/ahmedreactionstudio/core/LayerType;", "getVisible", "setVisible", "getVolume", "setVolume", "getWN", "setWN", "clone", "isClip", "isLive", "isText", "isVideoLike", "toJson", "Lorg/json/JSONObject;", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nModel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Model.kt\ncom/rehman/ahmedreactionstudio/core/Layer\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,430:1\n1#2:431\n*E\n"})
public final class Layer {

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);
    public static final int FACING_BACK = 1;
    public static final int FACING_FRONT = 0;

    @NotNull
    public static final String FIT_FILL = "fill";

    @NotNull
    public static final String FIT_FIT = "fit";
    private long addedAt;
    private int camFacing;
    private float cx;
    private float cy;
    private long durMs;

    @NotNull
    private String fit;
    private float fontSizeN;
    private float hN;

    @NotNull
    private String id;
    private boolean live;
    private boolean locked;
    private boolean loop;
    private boolean mirror;
    private boolean muted;

    @NotNull
    private String name;
    private float opacity;
    private long pausedMediaMs;
    private boolean playing;

    @Nullable
    private String relPath;
    private float rotDeg;
    private boolean shadow;
    private boolean solo;
    private float speed;
    private int srcH;
    private int srcRotation;
    private int srcW;

    @NotNull
    private String text;
    private int textColor;

    @NotNull
    private final LayerType type;
    private boolean visible;
    private float volume;
    private float wN;

    public Layer() {
        this(null, null, null, null, 0L, 0, 0, 0, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, false, false, false, false, false, null, 0.0f, 0.0f, false, 0L, 0.0f, false, 0, false, null, 0, 0.0f, false, 0L, -1, null);
    }

    public Layer(@NotNull String id, @NotNull LayerType type, @NotNull String name, @Nullable String str, long j, int i, int i2, int i3, float f, float f2, float f3, float f4, float f5, boolean z, boolean z2, boolean z3, boolean z4, boolean z5, @NotNull String fit, float f6, float f7, boolean z6, long j2, float f8, boolean z7, int i4, boolean z8, @NotNull String text, int i5, float f9, boolean z9, long j3) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(type, "type");
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(fit, "fit");
        Intrinsics.checkNotNullParameter(text, "text");
        this.id = id;
        this.type = type;
        this.name = name;
        this.relPath = str;
        this.durMs = j;
        this.srcW = i;
        this.srcH = i2;
        this.srcRotation = i3;
        this.cx = f;
        this.cy = f2;
        this.wN = f3;
        this.hN = f4;
        this.rotDeg = f5;
        this.visible = z;
        this.locked = z2;
        this.muted = z3;
        this.solo = z4;
        this.loop = z5;
        this.fit = fit;
        this.volume = f6;
        this.opacity = f7;
        this.playing = z6;
        this.pausedMediaMs = j2;
        this.speed = f8;
        this.live = z7;
        this.camFacing = i4;
        this.mirror = z8;
        this.text = text;
        this.textColor = i5;
        this.fontSizeN = f9;
        this.shadow = z9;
        this.addedAt = j3;
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public /* synthetic */ Layer(String str, LayerType layerType, String str2, String str3, long j, int i, int i2, int i3, float f, float f2, float f3, float f4, float f5, boolean z, boolean z2, boolean z3, boolean z4, boolean z5, String str4, float f6, float f7, boolean z6, long j2, float f8, boolean z7, int i4, boolean z8, String str5, int i5, float f9, boolean z9, long j3, int i6, DefaultConstructorMarker defaultConstructorMarker) {
        String string;
        if ((i6 & 1) != 0) {
            string = UUID.randomUUID().toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        } else {
            string = str;
        }
        this(string, (i6 & 2) != 0 ? LayerType.VIDEO : layerType, (i6 & 4) != 0 ? "" : str2, (i6 & 8) != 0 ? null : str3, (i6 & 16) != 0 ? 0L : j, (i6 & 32) != 0 ? 0 : i, (i6 & 64) != 0 ? 0 : i2, (i6 & 128) != 0 ? 0 : i3, (i6 & 256) != 0 ? 0.5f : f, (i6 & ConstantsKt.MINIMUM_BLOCK_SIZE) == 0 ? f2 : 0.5f, (i6 & 1024) != 0 ? 1.0f : f3, (i6 & AudioConfig.CHUNK_BYTES) != 0 ? 1.0f : f4, (i6 & ConstantsKt.DEFAULT_BLOCK_SIZE) != 0 ? 0.0f : f5, (i6 & ConstantsKt.DEFAULT_BUFFER_SIZE) != 0 ? true : z, (i6 & 16384) != 0 ? false : z2, (i6 & 32768) != 0 ? false : z3, (i6 & 65536) != 0 ? false : z4, (i6 & 131072) != 0 ? false : z5, (i6 & 262144) != 0 ? FIT_FILL : str4, (i6 & 524288) != 0 ? 1.0f : f6, (i6 & 1048576) != 0 ? 1.0f : f7, (i6 & 2097152) != 0 ? true : z6, (i6 & 4194304) != 0 ? 0L : j2, (i6 & 8388608) != 0 ? 1.0f : f8, (i6 & 16777216) != 0 ? false : z7, (i6 & 33554432) != 0 ? 0 : i4, (i6 & 67108864) != 0 ? true : z8, (i6 & 134217728) != 0 ? "" : str5, (i6 & 268435456) != 0 ? -1 : i5, (i6 & 536870912) != 0 ? 0.08f : f9, (i6 & 1073741824) == 0 ? z9 : true, (i6 & IntCompanionObject.MIN_VALUE) != 0 ? System.currentTimeMillis() : j3);
    }

    @NotNull
    public final String getId() {
        return this.id;
    }

    public final void setId(@NotNull String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.id = str;
    }

    @NotNull
    public final LayerType getType() {
        return this.type;
    }

    @NotNull
    public final String getName() {
        return this.name;
    }

    public final void setName(@NotNull String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.name = str;
    }

    @Nullable
    public final String getRelPath() {
        return this.relPath;
    }

    public final void setRelPath(@Nullable String str) {
        this.relPath = str;
    }

    public final long getDurMs() {
        return this.durMs;
    }

    public final void setDurMs(long j) {
        this.durMs = j;
    }

    public final int getSrcW() {
        return this.srcW;
    }

    public final void setSrcW(int i) {
        this.srcW = i;
    }

    public final int getSrcH() {
        return this.srcH;
    }

    public final void setSrcH(int i) {
        this.srcH = i;
    }

    public final int getSrcRotation() {
        return this.srcRotation;
    }

    public final void setSrcRotation(int i) {
        this.srcRotation = i;
    }

    public final float getCx() {
        return this.cx;
    }

    public final void setCx(float f) {
        this.cx = f;
    }

    public final float getCy() {
        return this.cy;
    }

    public final void setCy(float f) {
        this.cy = f;
    }

    public final float getWN() {
        return this.wN;
    }

    public final void setWN(float f) {
        this.wN = f;
    }

    public final float getHN() {
        return this.hN;
    }

    public final void setHN(float f) {
        this.hN = f;
    }

    public final float getRotDeg() {
        return this.rotDeg;
    }

    public final void setRotDeg(float f) {
        this.rotDeg = f;
    }

    public final boolean getVisible() {
        return this.visible;
    }

    public final void setVisible(boolean z) {
        this.visible = z;
    }

    public final boolean getLocked() {
        return this.locked;
    }

    public final void setLocked(boolean z) {
        this.locked = z;
    }

    public final boolean getMuted() {
        return this.muted;
    }

    public final void setMuted(boolean z) {
        this.muted = z;
    }

    public final boolean getSolo() {
        return this.solo;
    }

    public final void setSolo(boolean z) {
        this.solo = z;
    }

    public final boolean getLoop() {
        return this.loop;
    }

    public final void setLoop(boolean z) {
        this.loop = z;
    }

    @NotNull
    public final String getFit() {
        return this.fit;
    }

    public final void setFit(@NotNull String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.fit = str;
    }

    public final float getVolume() {
        return this.volume;
    }

    public final void setVolume(float f) {
        this.volume = f;
    }

    public final float getOpacity() {
        return this.opacity;
    }

    public final void setOpacity(float f) {
        this.opacity = f;
    }

    public final boolean getPlaying() {
        return this.playing;
    }

    public final void setPlaying(boolean z) {
        this.playing = z;
    }

    public final long getPausedMediaMs() {
        return this.pausedMediaMs;
    }

    public final void setPausedMediaMs(long j) {
        this.pausedMediaMs = j;
    }

    public final float getSpeed() {
        return this.speed;
    }

    public final void setSpeed(float f) {
        this.speed = f;
    }

    public final boolean getLive() {
        return this.live;
    }

    public final void setLive(boolean z) {
        this.live = z;
    }

    public final int getCamFacing() {
        return this.camFacing;
    }

    public final void setCamFacing(int i) {
        this.camFacing = i;
    }

    public final boolean getMirror() {
        return this.mirror;
    }

    public final void setMirror(boolean z) {
        this.mirror = z;
    }

    @NotNull
    public final String getText() {
        return this.text;
    }

    public final void setText(@NotNull String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.text = str;
    }

    public final int getTextColor() {
        return this.textColor;
    }

    public final void setTextColor(int i) {
        this.textColor = i;
    }

    public final float getFontSizeN() {
        return this.fontSizeN;
    }

    public final void setFontSizeN(float f) {
        this.fontSizeN = f;
    }

    public final boolean getShadow() {
        return this.shadow;
    }

    public final void setShadow(boolean z) {
        this.shadow = z;
    }

    public final long getAddedAt() {
        return this.addedAt;
    }

    public final void setAddedAt(long j) {
        this.addedAt = j;
    }

    public final boolean isVideoLike() {
        return this.type == LayerType.VIDEO || this.type == LayerType.CAMERA || this.type == LayerType.SCREEN;
    }

    public final boolean isLive() {
        return this.live && this.type == LayerType.CAMERA;
    }

    public final boolean isClip() {
        return isVideoLike() && !isLive();
    }

    public final boolean isText() {
        return this.type == LayerType.TEXT;
    }

    @NotNull
    public final Layer clone() {
        return new Layer(this.id, this.type, this.name, this.relPath, this.durMs, this.srcW, this.srcH, this.srcRotation, this.cx, this.cy, this.wN, this.hN, this.rotDeg, this.visible, this.locked, this.muted, this.solo, this.loop, this.fit, this.volume, this.opacity, this.playing, this.pausedMediaMs, this.speed, this.live, this.camFacing, this.mirror, this.text, this.textColor, this.fontSizeN, this.shadow, this.addedAt);
    }

    @NotNull
    public final JSONObject toJson() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("id", this.id);
        jSONObject.put("type", this.type.name());
        jSONObject.put("name", this.name);
        String str = this.relPath;
        if (str != null) {
            jSONObject.put("relPath", str);
        }
        jSONObject.put("durMs", this.durMs);
        jSONObject.put("srcW", this.srcW);
        jSONObject.put("srcH", this.srcH);
        jSONObject.put("srcRotation", this.srcRotation);
        jSONObject.put("cx", this.cx);
        jSONObject.put("cy", this.cy);
        jSONObject.put("wN", this.wN);
        jSONObject.put("hN", this.hN);
        jSONObject.put("rotDeg", this.rotDeg);
        jSONObject.put("visible", this.visible);
        jSONObject.put("locked", this.locked);
        jSONObject.put("muted", this.muted);
        jSONObject.put("solo", this.solo);
        jSONObject.put("loop", this.loop);
        jSONObject.put(FIT_FIT, this.fit);
        jSONObject.put("volume", this.volume);
        jSONObject.put("opacity", this.opacity);
        jSONObject.put("playing", this.playing);
        jSONObject.put("pausedMediaMs", this.pausedMediaMs);
        jSONObject.put("speed", this.speed);
        if (this.type == LayerType.CAMERA) {
            jSONObject.put("live", this.live);
            jSONObject.put("camFacing", this.camFacing);
            jSONObject.put("mirror", this.mirror);
        }
        if (this.type == LayerType.TEXT) {
            jSONObject.put("text", this.text);
            jSONObject.put("textColor", this.textColor);
            jSONObject.put("fontSizeN", this.fontSizeN);
            jSONObject.put("shadow", this.shadow);
        }
        jSONObject.put("addedAt", this.addedAt);
        return jSONObject;
    }

    /* JADX INFO: compiled from: Model.kt */
    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fR\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0007X\u0086T¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/Layer$Companion;", "", "()V", "FACING_BACK", "", "FACING_FRONT", "FIT_FILL", "", "FIT_FIT", "fromJson", "Lcom/rehman/ahmedreactionstudio/core/Layer;", "o", "Lorg/json/JSONObject;"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        @NotNull
        public final Layer fromJson(@NotNull JSONObject o) {
            Intrinsics.checkNotNullParameter(o, "o");
            LayerType.Companion companion = LayerType.INSTANCE;
            String strOptString = o.optString("type", "VIDEO");
            Intrinsics.checkNotNullExpressionValue(strOptString, "optString(...)");
            LayerType layerTypeFrom = companion.from(strOptString);
            String str = layerTypeFrom == LayerType.CAMERA ? Layer.FIT_FIT : Layer.FIT_FILL;
            String strOptString2 = o.optString("id", UUID.randomUUID().toString());
            Intrinsics.checkNotNullExpressionValue(strOptString2, "optString(...)");
            String strOptString3 = o.optString("name", layerTypeFrom.getLabel());
            Intrinsics.checkNotNullExpressionValue(strOptString3, "optString(...)");
            String string = o.has("relPath") ? o.getString("relPath") : null;
            long jOptLong = o.optLong("durMs");
            int iOptInt = o.optInt("srcW");
            int iOptInt2 = o.optInt("srcH");
            int iOptInt3 = o.optInt("srcRotation");
            float fOptDouble = (float) o.optDouble("cx", 0.5d);
            float fOptDouble2 = (float) o.optDouble("cy", 0.5d);
            float fOptDouble3 = (float) o.optDouble("wN", 1.0d);
            float fOptDouble4 = (float) o.optDouble("hN", 1.0d);
            float fOptDouble5 = (float) o.optDouble("rotDeg", 0.0d);
            boolean zOptBoolean = o.optBoolean("visible", true);
            boolean zOptBoolean2 = o.optBoolean("locked", false);
            boolean zOptBoolean3 = o.optBoolean("muted", false);
            boolean zOptBoolean4 = o.optBoolean("solo", false);
            boolean zOptBoolean5 = o.optBoolean("loop", false);
            String strOptString4 = o.optString(Layer.FIT_FIT, str);
            Intrinsics.checkNotNullExpressionValue(strOptString4, "optString(...)");
            float fOptDouble6 = (float) o.optDouble("volume", 1.0d);
            float fOptDouble7 = (float) o.optDouble("opacity", 1.0d);
            boolean zOptBoolean6 = o.optBoolean("playing", true);
            long jOptLong2 = o.optLong("pausedMediaMs");
            float fOptDouble8 = (float) o.optDouble("speed", 1.0d);
            boolean zOptBoolean7 = o.optBoolean("live", false);
            int iOptInt4 = o.optInt("camFacing", 0);
            boolean zOptBoolean8 = o.optBoolean("mirror", true);
            String strOptString5 = o.optString("text", "");
            Intrinsics.checkNotNullExpressionValue(strOptString5, "optString(...)");
            return new Layer(strOptString2, layerTypeFrom, strOptString3, string, jOptLong, iOptInt, iOptInt2, iOptInt3, fOptDouble, fOptDouble2, fOptDouble3, fOptDouble4, fOptDouble5, zOptBoolean, zOptBoolean2, zOptBoolean3, zOptBoolean4, zOptBoolean5, strOptString4, fOptDouble6, fOptDouble7, zOptBoolean6, jOptLong2, fOptDouble8, zOptBoolean7, iOptInt4, zOptBoolean8, strOptString5, o.optInt("textColor", -1), (float) o.optDouble("fontSizeN", 0.08d), o.optBoolean("shadow", true), o.optLong("addedAt", System.currentTimeMillis()));
        }
    }
}
