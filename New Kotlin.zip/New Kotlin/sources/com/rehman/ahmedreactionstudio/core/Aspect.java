package com.rehman.ahmedreactionstudio.core;

import java.util.Iterator;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: Model.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\r\b\u0086\u0081\u0002\u0018\u0000 \u00122\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u0012B'\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0003¢\u0006\u0002\u0010\bR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\rj\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/Aspect;", "", "code", "", "canvasW", "", "canvasH", "label", "(Ljava/lang/String;ILjava/lang/String;IILjava/lang/String;)V", "getCanvasH", "()I", "getCanvasW", "getCode", "()Ljava/lang/String;", "getLabel", "R169", "R916", "R11", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
public enum Aspect {
    R169("16:9", 1920, 1080, "16:9 · Landscape"),
    R916("9:16", 1080, 1920, "9:16 · Portrait"),
    R11("1:1", 1080, 1080, "1:1 · Square");

    private final int canvasH;
    private final int canvasW;

    @NotNull
    private final String code;

    @NotNull
    private final String label;
    private static final /* synthetic */ EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @NotNull
    public static EnumEntries<Aspect> getEntries() {
        return $ENTRIES;
    }

    Aspect(String str, int i, int i2, String str2) {
        this.code = str;
        this.canvasW = i;
        this.canvasH = i2;
        this.label = str2;
    }

    public final int getCanvasH() {
        return this.canvasH;
    }

    public final int getCanvasW() {
        return this.canvasW;
    }

    @NotNull
    public final String getCode() {
        return this.code;
    }

    @NotNull
    public final String getLabel() {
        return this.label;
    }

    /* JADX INFO: compiled from: Model.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/Aspect$Companion;", "", "()V", "from", "Lcom/rehman/ahmedreactionstudio/core/Aspect;", "code", ""}, k = 1, mv = {1, 9, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nModel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Model.kt\ncom/rehman/ahmedreactionstudio/core/Aspect$Companion\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,430:1\n288#2,2:431\n*S KotlinDebug\n*F\n+ 1 Model.kt\ncom/rehman/ahmedreactionstudio/core/Aspect$Companion\n*L\n14#1:431,2\n*E\n"})
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        @NotNull
        public final Aspect from(@NotNull String code) {
            Aspect next;
            Intrinsics.checkNotNullParameter(code, "code");
            Iterator<Aspect> it = Aspect.getEntries().iterator();
            while (true) {
                if (!it.hasNext()) {
                    next = null;
                    break;
                }
                next = it.next();
                if (Intrinsics.areEqual(next.getCode(), code)) {
                    break;
                }
            }
            Aspect aspect = next;
            return aspect == null ? Aspect.R169 : aspect;
        }
    }
}
