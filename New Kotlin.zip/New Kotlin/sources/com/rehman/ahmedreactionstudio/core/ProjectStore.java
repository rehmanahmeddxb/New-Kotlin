package com.rehman.ahmedreactionstudio.core;

import android.content.Context;
import android.graphics.Bitmap;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.Triple;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.io.FilesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONObject;

/* JADX INFO: compiled from: ProjectStore.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010 \n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u0000 12\u00020\u0001:\u00011B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fJ\u0016\u0010\r\u001a\u00020\f2\u0006\u0010\u000e\u001a\u00020\f2\u0006\u0010\u000f\u001a\u00020\u0006J\u0016\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\f2\u0006\u0010\u0013\u001a\u00020\u0014J\u000e\u0010\u0015\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fJ\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u000b\u001a\u00020\fJ\u0006\u0010\u0017\u001a\u00020\nJ\u000e\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u000b\u001a\u00020\fJ\f\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\f0\u001bJ\u0010\u0010\u001c\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u000b\u001a\u00020\fJ\u0012\u0010\u001d\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u001e\u001a\u00020\u0006H\u0002J\u0010\u0010\u001f\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u000b\u001a\u00020\fJ\u0010\u0010 \u001a\u0004\u0018\u00010\u00112\u0006\u0010\u000b\u001a\u00020\fJ\u000e\u0010!\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fJ\u000e\u0010\"\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\fJ\u0016\u0010#\u001a\u00020\u00062\u0006\u0010\u000e\u001a\u00020\f2\u0006\u0010$\u001a\u00020\fJ\u000e\u0010%\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\fJ\u000e\u0010&\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\fJ\u0018\u0010'\u001a\u00020\n2\u0006\u0010(\u001a\u00020\u00112\b\b\u0002\u0010)\u001a\u00020\u0019J\u0018\u0010*\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\b\u0010+\u001a\u0004\u0018\u00010,J\u000e\u0010-\u001a\u00020\u00062\u0006\u0010\u000e\u001a\u00020\fJ\u000e\u0010.\u001a\u00020\n2\u0006\u0010(\u001a\u00020\u0011J\u000e\u0010/\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\fJ\u000e\u00100\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\fR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\u00020\u00068BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\b"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/ProjectStore;", "", "ctx", "Landroid/content/Context;", "(Landroid/content/Context;)V", "root", "Ljava/io/File;", "getRoot", "()Ljava/io/File;", "clearOpen", "", "id", "", "copyIntoMedia", "projectId", "src", "create", "Lcom/rehman/ahmedreactionstudio/core/Project;", "name", "aspect", "Lcom/rehman/ahmedreactionstudio/core/Aspect;", "delete", "duplicate", "ensureRoot", "isDirty", "", "listIds", "", "load", "loadFile", "f", "loadMeta", "loadSnapshot", "markOpen", "mediaDir", "mediaFile", "relPath", "projectDir", "projectFile", "save", "p", "alsoSnapshot", "saveThumb", "bmp", "Landroid/graphics/Bitmap;", "sessionOpenFlag", "snapshot", "snapshotFile", "thumbFile", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nProjectStore.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ProjectStore.kt\ncom/rehman/ahmedreactionstudio/core/ProjectStore\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 ArrayIntrinsics.kt\nkotlin/ArrayIntrinsicsKt\n+ 4 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 5 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,154:1\n1#2:155\n1#2:170\n26#3:156\n3792#4:157\n4307#4,2:158\n1603#5,9:160\n1855#5:169\n1856#5:171\n1612#5:172\n1054#5:173\n1549#5:174\n1620#5,3:175\n*S KotlinDebug\n*F\n+ 1 ProjectStore.kt\ncom/rehman/ahmedreactionstudio/core/ProjectStore\n*L\n79#1:170\n77#1:156\n78#1:157\n78#1:158,2\n79#1:160,9\n79#1:169\n79#1:171\n79#1:172\n85#1:173\n86#1:174\n86#1:175,3\n*E\n"})
public final class ProjectStore {

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @NotNull
    private static final String DIR_NAME = "projects";
    public static final int SCHEMA = 1;

    @NotNull
    private final Context ctx;

    public ProjectStore(@NotNull Context ctx) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        this.ctx = ctx;
    }

    /* JADX INFO: compiled from: ProjectStore.kt */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u0014\u0010\u0003\u001a\u00020\u0004X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u000e\u0010\u0007\u001a\u00020\bX\u0086T¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/ProjectStore$Companion;", "", "()V", "DIR_NAME", "", "getDIR_NAME", "()Ljava/lang/String;", "SCHEMA", ""}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        @NotNull
        public final String getDIR_NAME() {
            return ProjectStore.DIR_NAME;
        }
    }

    private final File getRoot() {
        return new File(this.ctx.getFilesDir(), DIR_NAME);
    }

    public final void ensureRoot() {
        if (getRoot().exists()) {
            return;
        }
        getRoot().mkdirs();
    }

    @NotNull
    public final File projectDir(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return new File(getRoot(), id);
    }

    @NotNull
    public final File mediaDir(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return new File(projectDir(id), "media");
    }

    @NotNull
    public final File projectFile(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return new File(projectDir(id), "project.json");
    }

    @NotNull
    public final File snapshotFile(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return new File(projectDir(id), "snapshot.json");
    }

    @NotNull
    public final File thumbFile(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return new File(projectDir(id), "thumb.png");
    }

    @NotNull
    public final Project create(@NotNull String name, @NotNull Aspect aspect) {
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(aspect, "aspect");
        ensureRoot();
        String string = UUID.randomUUID().toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        String str = name;
        if (StringsKt.isBlank(str)) {
            str = "My Project";
        }
        Project project = new Project(string, str, aspect, 0, null, 0L, 0L, 0L, 248, null);
        projectDir(project.getId()).mkdirs();
        mediaDir(project.getId()).mkdirs();
        save$default(this, project, false, 2, null);
        return project;
    }

    public static /* synthetic */ void save$default(ProjectStore projectStore, Project project, boolean z, int i, Object obj) {
        if ((i & 2) != 0) {
            z = false;
        }
        projectStore.save(project, z);
    }

    public final void save(@NotNull Project p, boolean alsoSnapshot) {
        Intrinsics.checkNotNullParameter(p, "p");
        try {
            File fileProjectDir = projectDir(p.getId());
            fileProjectDir.mkdirs();
            mediaDir(p.getId()).mkdirs();
            File file = new File(fileProjectDir, "project.json.tmp");
            String string = p.toJson().toString(2);
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            FilesKt.writeText$default(file, string, null, 2, null);
            if (file.exists()) {
                file.renameTo(projectFile(p.getId()));
            }
            if (alsoSnapshot) {
                snapshot(p);
            }
        } catch (Exception unused) {
        }
    }

    public final void snapshot(@NotNull Project p) {
        Intrinsics.checkNotNullParameter(p, "p");
        try {
            File fileProjectDir = projectDir(p.getId());
            fileProjectDir.mkdirs();
            File file = new File(fileProjectDir, "snapshot.json.tmp");
            String string = p.toJson().toString(2);
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            FilesKt.writeText$default(file, string, null, 2, null);
            if (file.exists()) {
                file.renameTo(snapshotFile(p.getId()));
            }
        } catch (Exception unused) {
        }
    }

    @Nullable
    public final Project load(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return loadFile(projectFile(id));
    }

    @Nullable
    public final Project loadSnapshot(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return loadFile(snapshotFile(id));
    }

    private final Project loadFile(File f) {
        if (!f.exists()) {
            return null;
        }
        try {
            return Project.INSTANCE.fromJson(new JSONObject(FilesKt.readText$default(f, null, 1, null)));
        } catch (Exception unused) {
            return null;
        }
    }

    @NotNull
    public final List<String> listIds() {
        ensureRoot();
        File[] fileArrListFiles = getRoot().listFiles();
        if (fileArrListFiles == null) {
            fileArrListFiles = new File[0];
        }
        ArrayList<File> arrayList = new ArrayList();
        int length = fileArrListFiles.length;
        int i = 0;
        while (true) {
            if (i >= length) {
                break;
            }
            File file = fileArrListFiles[i];
            if (file.isDirectory() && new File(file, "project.json").exists()) {
                arrayList.add(file);
            }
            i++;
        }
        ArrayList arrayList2 = new ArrayList();
        for (File file2 : arrayList) {
            Triple triple = null;
            try {
                Project projectFromJson = Project.INSTANCE.fromJson(new JSONObject(FilesKt.readText$default(new File(file2, "project.json"), null, 1, null)));
                triple = new Triple(file2.getName(), Long.valueOf(projectFromJson.getUpdatedAt()), projectFromJson);
            } catch (Exception unused) {
            }
            if (triple != null) {
                arrayList2.add(triple);
            }
        }
        List listSortedWith = CollectionsKt.sortedWith(arrayList2, new Comparator() { // from class: com.rehman.ahmedreactionstudio.core.ProjectStore$listIds$$inlined$sortedByDescending$1
            /* JADX WARN: Multi-variable type inference failed */
            @Override // java.util.Comparator
            public final int compare(T t, T t2) {
                return ComparisonsKt.compareValues((Long) ((Triple) t2).getSecond(), (Long) ((Triple) t).getSecond());
            }
        });
        ArrayList arrayList3 = new ArrayList(CollectionsKt.collectionSizeOrDefault(listSortedWith, 10));
        Iterator it = listSortedWith.iterator();
        while (it.hasNext()) {
            arrayList3.add((String) ((Triple) it.next()).getFirst());
        }
        return arrayList3;
    }

    @Nullable
    public final Project loadMeta(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return load(id);
    }

    public final void delete(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        FilesKt.deleteRecursively(projectDir(id));
    }

    @Nullable
    public final Project duplicate(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        Project projectLoad = load(id);
        if (projectLoad == null) {
            return null;
        }
        String string = UUID.randomUUID().toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        Project project = new Project(string, projectLoad.getName() + " copy", projectLoad.getAspect(), projectLoad.getBgColor(), null, System.currentTimeMillis(), System.currentTimeMillis(), 0L, 144, null);
        projectDir(project.getId()).mkdirs();
        mediaDir(project.getId()).mkdirs();
        for (Layer layer : projectLoad.getLayers()) {
            Layer layerClone = layer.clone();
            if (layer.getRelPath() != null) {
                File file = new File(projectDir(projectLoad.getId()), layer.getRelPath());
                if (file.exists()) {
                    layerClone.setRelPath(copyIntoMedia(project.getId(), file));
                }
            }
            project.getLayers().add(layerClone);
        }
        save$default(this, project, false, 2, null);
        return project;
    }

    @NotNull
    public final String copyIntoMedia(@NotNull String projectId, @NotNull File src) {
        Intrinsics.checkNotNullParameter(projectId, "projectId");
        Intrinsics.checkNotNullParameter(src, "src");
        File fileMediaDir = mediaDir(projectId);
        fileMediaDir.mkdirs();
        String name = src.getName();
        Intrinsics.checkNotNull(name);
        if (StringsKt.isBlank(name)) {
            name = "clip_" + System.currentTimeMillis() + ".mp4";
        }
        File file = new File(fileMediaDir, name);
        int i = 1;
        while (file.exists()) {
            file = new File(fileMediaDir, name + '_' + i);
            i++;
        }
        FilesKt.copyTo$default(src, file, false, 0, 4, null);
        return "media/" + file.getName();
    }

    @NotNull
    public final File mediaFile(@NotNull String projectId, @NotNull String relPath) {
        Intrinsics.checkNotNullParameter(projectId, "projectId");
        Intrinsics.checkNotNullParameter(relPath, "relPath");
        return new File(projectDir(projectId), relPath);
    }

    @NotNull
    public final File sessionOpenFlag(@NotNull String projectId) {
        Intrinsics.checkNotNullParameter(projectId, "projectId");
        return new File(projectDir(projectId), "open.flag");
    }

    public final void markOpen(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        try {
            FilesKt.writeText$default(sessionOpenFlag(id), String.valueOf(System.currentTimeMillis()), null, 2, null);
        } catch (Exception unused) {
        }
    }

    public final void clearOpen(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        try {
            sessionOpenFlag(id).delete();
        } catch (Exception unused) {
        }
    }

    public final boolean isDirty(@NotNull String id) {
        Intrinsics.checkNotNullParameter(id, "id");
        return sessionOpenFlag(id).exists();
    }

    public final void saveThumb(@NotNull String id, @Nullable Bitmap bmp) {
        Intrinsics.checkNotNullParameter(id, "id");
        if (bmp == null) {
            return;
        }
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(thumbFile(id));
            bmp.compress(Bitmap.CompressFormat.PNG, 90, fileOutputStream);
            fileOutputStream.close();
        } catch (Exception unused) {
        }
    }
}
