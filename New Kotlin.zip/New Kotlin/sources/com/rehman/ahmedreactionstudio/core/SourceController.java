package com.rehman.ahmedreactionstudio.core;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: Sources.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\n\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0010\u0007\n\u0002\b\t\n\u0002\u0018\u0002\u0018\u00002\u00020\u0001B/\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003\u0012\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003¢\u0006\u0002\u0010\bJ\u000e\u0010\f\u001a\u00020\u00062\u0006\u0010\r\u001a\u00020\u000eJ\u0018\u0010\u000f\u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u000f\u001a\u00020\u0011J\u0006\u0010\u0012\u001a\u00020\u0013J\u0010\u0010\u0014\u001a\u00020\u00132\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011J\u0010\u0010\u0015\u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011J\u0010\u0010\u0016\u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011J\u0012\u0010\u0017\u001a\u0004\u0018\u00010\u00112\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011J\u000e\u0010\u0018\u001a\u00020\u00132\u0006\u0010\r\u001a\u00020\u000eJ\u000e\u0010\u0019\u001a\u00020\u00132\u0006\u0010\r\u001a\u00020\u000eJ\u0018\u0010\u001a\u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u001b\u001a\u00020\u0011J\u0016\u0010\u001c\u001a\u00020\u00062\u0006\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\u001eJ\u0010\u0010 \u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011J\u0010\u0010!\u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011J\u0018\u0010\"\u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u00112\u0006\u0010#\u001a\u00020\u0011J\u0018\u0010$\u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u00112\u0006\u0010%\u001a\u00020\u0011J\u0018\u0010&\u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u00112\u0006\u0010'\u001a\u00020(J\u0018\u0010)\u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u00112\u0006\u0010'\u001a\u00020(J\u0010\u0010*\u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011J\u0010\u0010+\u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011J\u0010\u0010,\u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011J\u0010\u0010-\u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011J\u0010\u0010.\u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011J\u0010\u0010/\u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011J&\u00100\u001a\u00020\u00062\b\u0010\u0010\u001a\u0004\u0018\u00010\u00112\u0012\u00101\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u000602H\u0002R\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\u00020\u00048BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\n\u0010\u000bR\u0014\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00060\u0003X\u0082\u0004¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/SourceController;", "", "projectRef", "Lkotlin/Function0;", "Lcom/rehman/ahmedreactionstudio/core/Project;", "willMutate", "", "onChanged", "(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V", "p", "getP", "()Lcom/rehman/ahmedreactionstudio/core/Project;", "add", "l", "Lcom/rehman/ahmedreactionstudio/core/Layer;", "anchor", "id", "", "anySolo", "", "canDuplicate", "center", "delete", "duplicate", "effectiveMuted", "effectiveVisible", "moveZ", "mode", "reorderLive", "fromIndex", "", "toIndex", "resetGeometry", "setAsCanvasBackground", "setFit", Layer.FIT_FIT, "setName", "name", "setOpacity", "v", "", "setVolume", "toggleFit", "toggleLocked", "toggleLoop", "toggleMuted", "toggleSolo", "toggleVisible", "withLayer", "f", "Lkotlin/Function1;"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nSources.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Sources.kt\ncom/rehman/ahmedreactionstudio/core/SourceController\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,161:1\n1747#2,3:162\n*S KotlinDebug\n*F\n+ 1 Sources.kt\ncom/rehman/ahmedreactionstudio/core/SourceController\n*L\n35#1:162,3\n*E\n"})
public final class SourceController {

    @NotNull
    private final Function0<Unit> onChanged;

    @NotNull
    private final Function0<Project> projectRef;

    @NotNull
    private final Function0<Unit> willMutate;

    public SourceController(@NotNull Function0<Project> projectRef, @NotNull Function0<Unit> willMutate, @NotNull Function0<Unit> onChanged) {
        Intrinsics.checkNotNullParameter(projectRef, "projectRef");
        Intrinsics.checkNotNullParameter(willMutate, "willMutate");
        Intrinsics.checkNotNullParameter(onChanged, "onChanged");
        this.projectRef = projectRef;
        this.willMutate = willMutate;
        this.onChanged = onChanged;
    }

    private final Project getP() {
        return this.projectRef.invoke();
    }

    public final boolean anySolo() {
        List<Layer> layers = getP().getLayers();
        if ((layers instanceof Collection) && layers.isEmpty()) {
            return false;
        }
        Iterator<T> it = layers.iterator();
        while (it.hasNext()) {
            if (((Layer) it.next()).getSolo()) {
                return true;
            }
        }
        return false;
    }

    public final boolean effectiveMuted(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        return l.getMuted() || (anySolo() && !l.getSolo());
    }

    public final boolean effectiveVisible(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        return l.getVisible();
    }

    private final void withLayer(String id, Function1<? super Layer, Unit> f) {
        Layer layerLayerById;
        Project p = getP();
        if (id == null || (layerLayerById = p.layerById(id)) == null) {
            return;
        }
        this.willMutate.invoke();
        f.invoke(layerLayerById);
        this.onChanged.invoke();
    }

    public final void toggleVisible(@Nullable String id) {
        withLayer(id, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.core.SourceController.toggleVisible.1
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer it) {
                Intrinsics.checkNotNullParameter(it, "it");
                it.setVisible(!it.getVisible());
            }
        });
    }

    public final void toggleMuted(@Nullable String id) {
        withLayer(id, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.core.SourceController.toggleMuted.1
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer it) {
                Intrinsics.checkNotNullParameter(it, "it");
                it.setMuted(!it.getMuted());
            }
        });
    }

    public final void toggleLocked(@Nullable String id) {
        withLayer(id, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.core.SourceController.toggleLocked.1
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer it) {
                Intrinsics.checkNotNullParameter(it, "it");
                it.setLocked(!it.getLocked());
            }
        });
    }

    public final void toggleSolo(@Nullable String id) {
        withLayer(id, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.core.SourceController.toggleSolo.1
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer it) {
                Intrinsics.checkNotNullParameter(it, "it");
                it.setSolo(!it.getSolo());
            }
        });
    }

    public final void toggleLoop(@Nullable String id) {
        withLayer(id, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.core.SourceController.toggleLoop.1
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer it) {
                Intrinsics.checkNotNullParameter(it, "it");
                it.setLoop(!it.getLoop());
            }
        });
    }

    public final void toggleFit(@Nullable String id) {
        withLayer(id, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.core.SourceController.toggleFit.1
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer it) {
                Intrinsics.checkNotNullParameter(it, "it");
                String fit = it.getFit();
                String str = Layer.FIT_FIT;
                if (Intrinsics.areEqual(fit, Layer.FIT_FIT)) {
                    str = Layer.FIT_FILL;
                }
                it.setFit(str);
            }
        });
    }

    public final void setFit(@Nullable String id, @NotNull final String fit) {
        Intrinsics.checkNotNullParameter(fit, "fit");
        withLayer(id, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.core.SourceController.setFit.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer it) {
                Intrinsics.checkNotNullParameter(it, "it");
                it.setFit(fit);
            }
        });
    }

    public final void setOpacity(@Nullable String id, final float v) {
        withLayer(id, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.core.SourceController.setOpacity.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer it) {
                Intrinsics.checkNotNullParameter(it, "it");
                it.setOpacity(RangesKt.coerceIn(v, 0.0f, 1.0f));
            }
        });
    }

    public final void setVolume(@Nullable String id, final float v) {
        withLayer(id, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.core.SourceController.setVolume.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer it) {
                Intrinsics.checkNotNullParameter(it, "it");
                it.setVolume(RangesKt.coerceIn(v, 0.0f, 1.0f));
            }
        });
    }

    public final void setName(@Nullable String id, @NotNull final String name) {
        Intrinsics.checkNotNullParameter(name, "name");
        withLayer(id, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.core.SourceController.setName.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer it) {
                Intrinsics.checkNotNullParameter(it, "it");
                it.setName(name);
            }
        });
    }

    /* JADX WARN: Removed duplicated region for block: B:34:0x0078  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void moveZ(@org.jetbrains.annotations.Nullable java.lang.String r6, @org.jetbrains.annotations.NotNull java.lang.String r7) {
        /*
            r5 = this;
            java.lang.String r0 = "mode"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
            com.rehman.ahmedreactionstudio.core.Project r0 = r5.getP()
            if (r6 != 0) goto Lc
            return
        Lc:
            com.rehman.ahmedreactionstudio.core.Layer r6 = r0.layerById(r6)
            if (r6 != 0) goto L13
            return
        L13:
            com.rehman.ahmedreactionstudio.core.Project r0 = r5.getP()
            java.util.List r0 = r0.getLayers()
            int r1 = r0.indexOf(r6)
            if (r1 >= 0) goto L22
            return
        L22:
            kotlin.jvm.functions.Function0<kotlin.Unit> r2 = r5.willMutate
            r2.invoke()
            r0.remove(r1)
            int r2 = r7.hashCode()
            r3 = 3739(0xe9b, float:5.24E-42)
            if (r2 == r3) goto L70
            r3 = 3015911(0x2e04e7, float:4.226191E-39)
            r4 = 0
            if (r2 == r3) goto L63
            r3 = 3089570(0x2f24a2, float:4.32941E-39)
            if (r2 == r3) goto L50
            r3 = 97705513(0x5d2de29, float:1.9829914E-35)
            if (r2 == r3) goto L43
            goto L78
        L43:
            java.lang.String r2 = "front"
            boolean r7 = r7.equals(r2)
            if (r7 != 0) goto L4c
            goto L78
        L4c:
            r0.add(r6)
            goto L89
        L50:
            java.lang.String r2 = "down"
            boolean r7 = r7.equals(r2)
            if (r7 != 0) goto L59
            goto L78
        L59:
            int r1 = r1 + (-1)
            int r7 = java.lang.Math.max(r1, r4)
            r0.add(r7, r6)
            goto L89
        L63:
            java.lang.String r2 = "back"
            boolean r7 = r7.equals(r2)
            if (r7 != 0) goto L6c
            goto L78
        L6c:
            r0.add(r4, r6)
            goto L89
        L70:
            java.lang.String r2 = "up"
            boolean r7 = r7.equals(r2)
            if (r7 != 0) goto L7c
        L78:
            r0.add(r1, r6)
            goto L89
        L7c:
            int r1 = r1 + 1
            int r7 = r0.size()
            int r7 = java.lang.Math.min(r1, r7)
            r0.add(r7, r6)
        L89:
            kotlin.jvm.functions.Function0<kotlin.Unit> r6 = r5.onChanged
            r6.invoke()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.core.SourceController.moveZ(java.lang.String, java.lang.String):void");
    }

    public final void anchor(@Nullable String id, @NotNull final String anchor) {
        Intrinsics.checkNotNullParameter(anchor, "anchor");
        withLayer(id, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.core.SourceController.anchor.1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer it) {
                Intrinsics.checkNotNullParameter(it, "it");
                LayerFit.anchorTo$default(LayerFit.INSTANCE, it, anchor, 0.0f, 4, null);
            }
        });
    }

    public final void center(@Nullable String id) {
        withLayer(id, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.core.SourceController.center.1
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer it) {
                Intrinsics.checkNotNullParameter(it, "it");
                it.setCx(0.5f);
                it.setCy(0.5f);
            }
        });
    }

    public final void resetGeometry(@Nullable String id) {
        withLayer(id, new Function1<Layer, Unit>() { // from class: com.rehman.ahmedreactionstudio.core.SourceController.resetGeometry.1
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Unit invoke(Layer layer) {
                invoke2(layer);
                return Unit.INSTANCE;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2(@NotNull Layer it) {
                Intrinsics.checkNotNullParameter(it, "it");
                it.setCx(0.5f);
                it.setCy(0.5f);
                it.setRotDeg(0.0f);
                LayerFit.clampInside$default(LayerFit.INSTANCE, it, 0.0f, 2, null);
            }
        });
    }

    public final void setAsCanvasBackground(@Nullable String id) {
        Layer layerLayerById;
        Project p = getP();
        if (id == null || (layerLayerById = p.layerById(id)) == null || layerLayerById.isText()) {
            return;
        }
        this.willMutate.invoke();
        LayerFit.INSTANCE.fill(layerLayerById);
        getP().getLayers().remove(layerLayerById);
        getP().getLayers().add(0, layerLayerById);
        this.onChanged.invoke();
    }

    public final boolean canDuplicate(@Nullable String id) {
        Layer layerLayerById;
        Project p = getP();
        if (id == null || (layerLayerById = p.layerById(id)) == null) {
            return false;
        }
        return !layerLayerById.isLive();
    }

    @Nullable
    public final String duplicate(@Nullable String id) {
        Layer layerLayerById;
        Project p = getP();
        if (id == null || (layerLayerById = p.layerById(id)) == null || layerLayerById.isLive()) {
            return null;
        }
        this.willMutate.invoke();
        Layer layerClone = layerLayerById.clone();
        String string = UUID.randomUUID().toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        layerClone.setId(string);
        layerClone.setName(layerLayerById.getName() + " copy");
        layerClone.setSolo(false);
        layerClone.setCx(RangesKt.coerceIn((layerLayerById.getCx() + 0.06f) % 1.0f, 0.0f, 1.0f));
        layerClone.setCy(RangesKt.coerceIn((layerLayerById.getCy() + 0.06f) % 1.0f, 0.0f, 1.0f));
        getP().getLayers().add(getP().getLayers().indexOf(layerLayerById) + 1, layerClone);
        this.onChanged.invoke();
        return layerClone.getId();
    }

    public final void delete(@Nullable String id) {
        Layer layerLayerById;
        Project p = getP();
        if (id == null || (layerLayerById = p.layerById(id)) == null) {
            return;
        }
        this.willMutate.invoke();
        getP().getLayers().remove(layerLayerById);
        this.onChanged.invoke();
    }

    public final void add(@NotNull Layer l) {
        Intrinsics.checkNotNullParameter(l, "l");
        this.willMutate.invoke();
        getP().getLayers().add(l);
        this.onChanged.invoke();
    }

    public final void reorderLive(int fromIndex, int toIndex) {
        List<Layer> layers = getP().getLayers();
        if (fromIndex >= 0 && fromIndex < layers.size()) {
            layers.add(RangesKt.coerceIn(toIndex, 0, layers.size()), layers.remove(fromIndex));
        }
    }
}
