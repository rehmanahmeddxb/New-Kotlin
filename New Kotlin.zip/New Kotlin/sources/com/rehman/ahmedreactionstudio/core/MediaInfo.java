package com.rehman.ahmedreactionstudio.core;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: MediaKit.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0010\n\u0002\u0010\u000b\n\u0002\b\u0003\b\u0086\b\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\b\u0010\b\u001a\u0004\u0018\u00010\t¢\u0006\u0002\u0010\nJ\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0005HÆ\u0003J\u000b\u0010\u0017\u001a\u0004\u0018\u00010\tHÆ\u0003J=\u0010\u0018\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\tHÆ\u0001J\u0013\u0010\u0019\u001a\u00020\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001c\u001a\u00020\u0005HÖ\u0001J\t\u0010\u001d\u001a\u00020\tHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0013\u0010\b\u001a\u0004\u0018\u00010\t¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u000e"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/MediaInfo;", "", "durMs", "", "width", "", "height", "rotation", "mime", "", "(JIIILjava/lang/String;)V", "getDurMs", "()J", "getHeight", "()I", "getMime", "()Ljava/lang/String;", "getRotation", "getWidth", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "toString"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final /* data */ class MediaInfo {
    private final long durMs;
    private final int height;

    @Nullable
    private final String mime;
    private final int rotation;
    private final int width;

    public static /* synthetic */ MediaInfo copy$default(MediaInfo mediaInfo, long j, int i, int i2, int i3, String str, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            j = mediaInfo.durMs;
        }
        long j2 = j;
        if ((i4 & 2) != 0) {
            i = mediaInfo.width;
        }
        int i5 = i;
        if ((i4 & 4) != 0) {
            i2 = mediaInfo.height;
        }
        int i6 = i2;
        if ((i4 & 8) != 0) {
            i3 = mediaInfo.rotation;
        }
        int i7 = i3;
        if ((i4 & 16) != 0) {
            str = mediaInfo.mime;
        }
        return mediaInfo.copy(j2, i5, i6, i7, str);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final long getDurMs() {
        return this.durMs;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final int getWidth() {
        return this.width;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final int getHeight() {
        return this.height;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final int getRotation() {
        return this.rotation;
    }

    @Nullable
    /* JADX INFO: renamed from: component5, reason: from getter */
    public final String getMime() {
        return this.mime;
    }

    @NotNull
    public final MediaInfo copy(long durMs, int width, int height, int rotation, @Nullable String mime) {
        return new MediaInfo(durMs, width, height, rotation, mime);
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof MediaInfo)) {
            return false;
        }
        MediaInfo mediaInfo = (MediaInfo) other;
        return this.durMs == mediaInfo.durMs && this.width == mediaInfo.width && this.height == mediaInfo.height && this.rotation == mediaInfo.rotation && Intrinsics.areEqual(this.mime, mediaInfo.mime);
    }

    public int hashCode() {
        int iHashCode = ((((((Long.hashCode(this.durMs) * 31) + Integer.hashCode(this.width)) * 31) + Integer.hashCode(this.height)) * 31) + Integer.hashCode(this.rotation)) * 31;
        String str = this.mime;
        return iHashCode + (str == null ? 0 : str.hashCode());
    }

    @NotNull
    public String toString() {
        return "MediaInfo(durMs=" + this.durMs + ", width=" + this.width + ", height=" + this.height + ", rotation=" + this.rotation + ", mime=" + this.mime + ')';
    }

    public MediaInfo(long j, int i, int i2, int i3, @Nullable String str) {
        this.durMs = j;
        this.width = i;
        this.height = i2;
        this.rotation = i3;
        this.mime = str;
    }

    public final long getDurMs() {
        return this.durMs;
    }

    public final int getWidth() {
        return this.width;
    }

    public final int getHeight() {
        return this.height;
    }

    public final int getRotation() {
        return this.rotation;
    }

    @Nullable
    public final String getMime() {
        return this.mime;
    }
}
