package com.rehman.ahmedreactionstudio.core;

import kotlin.Metadata;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: ViewportFit.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\r\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001\u0016B\u0007\b\u0002¢\u0006\u0002\u0010\u0002JV\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\t2\u0006\u0010\r\u001a\u00020\u00062\u0006\u0010\u000e\u001a\u00020\t2\u0006\u0010\u000f\u001a\u00020\t2\u0006\u0010\u0010\u001a\u00020\u0006J&\u0010\u0011\u001a\u00020\t2\u0006\u0010\u0012\u001a\u00020\t2\u0006\u0010\u0013\u001a\u00020\t2\u0006\u0010\u0014\u001a\u00020\t2\u0006\u0010\u0015\u001a\u00020\t"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/ViewportFit;", "", "()V", "contain", "Lcom/rehman/ahmedreactionstudio/core/ViewportFit$Box;", "viewW", "", "viewH", "insetL", "", "insetT", "insetR", "insetB", "pad", "srcW", "srcH", "minPx", "panelHeight", "viewHeight", "topInset", "fixedSheet", "floatingControls", "Box"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class ViewportFit {

    @NotNull
    public static final ViewportFit INSTANCE = new ViewportFit();

    /* JADX INFO: compiled from: ViewportFit.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u000e\n\u0002\u0010\u000e\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003¢\u0006\u0002\u0010\u0007J\b\u0010\u0011\u001a\u00020\u0012H\u0016R\u0011\u0010\b\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\nR\u0011\u0010\r\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\b\u000e\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\nR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\n"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/ViewportFit$Box;", "", "left", "", "top", "width", "height", "(FFFF)V", "bottom", "getBottom", "()F", "getHeight", "getLeft", "right", "getRight", "getTop", "getWidth", "toString", ""}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Box {
        private final float height;

        /* JADX INFO: renamed from: left, reason: from kotlin metadata and from toString */
        private final float l;
        private final float top;
        private final float width;

        public Box(float f, float f2, float f3, float f4) {
            this.l = f;
            this.top = f2;
            this.width = f3;
            this.height = f4;
        }

        public final float getHeight() {
            return this.height;
        }

        /* JADX INFO: renamed from: getLeft, reason: from getter */
        public final float getL() {
            return this.l;
        }

        public final float getTop() {
            return this.top;
        }

        public final float getWidth() {
            return this.width;
        }

        public final float getRight() {
            return this.l + this.width;
        }

        public final float getBottom() {
            return this.top + this.height;
        }

        @NotNull
        public String toString() {
            return "Box(l=" + this.l + " t=" + this.top + " w=" + this.width + " h=" + this.height + ')';
        }
    }

    private ViewportFit() {
    }

    public final int panelHeight(int viewHeight, int topInset, int fixedSheet, int floatingControls) {
        float fCoerceAtLeast = RangesKt.coerceAtLeast(viewHeight, 0);
        return (int) RangesKt.coerceAtLeast(Math.min(fCoerceAtLeast * 0.38f, (((fCoerceAtLeast - RangesKt.coerceAtLeast(topInset, 0)) - RangesKt.coerceAtLeast(fixedSheet, 0)) - RangesKt.coerceAtLeast(floatingControls, 0)) - (0.28f * fCoerceAtLeast)), 0.0f);
    }

    @NotNull
    public final Box contain(float viewW, float viewH, int insetL, int insetT, int insetR, int insetB, float pad, int srcW, int srcH, float minPx) {
        float fCoerceAtLeast = RangesKt.coerceAtLeast(insetL, 0);
        float f = fCoerceAtLeast + pad;
        float fCoerceAtLeast2 = RangesKt.coerceAtLeast(insetT, 0);
        float f2 = fCoerceAtLeast2 + pad;
        float f3 = pad * 2.0f;
        float fCoerceAtLeast3 = ((viewW - fCoerceAtLeast) - RangesKt.coerceAtLeast(insetR, 0)) - f3;
        float fCoerceAtLeast4 = ((viewH - fCoerceAtLeast2) - RangesKt.coerceAtLeast(insetB, 0)) - f3;
        if (fCoerceAtLeast3 < minPx || fCoerceAtLeast4 < minPx) {
            fCoerceAtLeast3 = viewW - f3;
            fCoerceAtLeast4 = viewH - f3;
            f2 = pad;
        } else {
            pad = f;
        }
        if (fCoerceAtLeast3 < 1.0f) {
            fCoerceAtLeast3 = 1.0f;
        }
        float f4 = fCoerceAtLeast4 >= 1.0f ? fCoerceAtLeast4 : 1.0f;
        float fCoerceAtLeast5 = RangesKt.coerceAtLeast(srcW, 1);
        float fCoerceAtLeast6 = RangesKt.coerceAtLeast(srcH, 1);
        float fMin = Math.min(fCoerceAtLeast3 / fCoerceAtLeast5, f4 / fCoerceAtLeast6);
        float f5 = fCoerceAtLeast5 * fMin;
        float f6 = fCoerceAtLeast6 * fMin;
        return new Box(pad + ((fCoerceAtLeast3 - f5) / 2.0f), f2 + ((f4 - f6) / 2.0f), f5, f6);
    }
}
