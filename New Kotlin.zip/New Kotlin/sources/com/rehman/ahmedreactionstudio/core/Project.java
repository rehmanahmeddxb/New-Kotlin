package com.rehman.ahmedreactionstudio.core;

import com.rehman.ahmedreactionstudio.core.Aspect;
import com.rehman.ahmedreactionstudio.core.Layer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: Model.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u001e\n\u0002\u0018\u0002\n\u0000\u0018\u0000 -2\u00020\u0001:\u0001-BU\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b\u0012\u000e\b\u0002\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n\u0012\b\b\u0002\u0010\f\u001a\u00020\r\u0012\b\b\u0002\u0010\u000e\u001a\u00020\r\u0012\b\b\u0002\u0010\u000f\u001a\u00020\r¢\u0006\u0002\u0010\u0010J\u0006\u0010)\u001a\u00020\rJ\u0010\u0010*\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\u0002\u001a\u00020\u0003J\u0006\u0010+\u001a\u00020,R\u001a\u0010\u0005\u001a\u00020\u0006X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u001a\u0010\u0007\u001a\u00020\bX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0016\"\u0004\b\u0017\u0010\u0018R\u001a\u0010\f\u001a\u00020\rX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0019\u0010\u001a\"\u0004\b\u001b\u0010\u001cR\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u001e\"\u0004\b\u001f\u0010 R\u001a\u0010\u000f\u001a\u00020\rX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b!\u0010\u001a\"\u0004\b\"\u0010\u001cR\u0017\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n¢\u0006\b\n\u0000\u001a\u0004\b#\u0010$R\u001a\u0010\u0004\u001a\u00020\u0003X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b%\u0010\u001e\"\u0004\b&\u0010 R\u001a\u0010\u000e\u001a\u00020\rX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b'\u0010\u001a\"\u0004\b(\u0010\u001c"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/Project;", "", "id", "", "name", "aspect", "Lcom/rehman/ahmedreactionstudio/core/Aspect;", "bgColor", "", "layers", "", "Lcom/rehman/ahmedreactionstudio/core/Layer;", "createdAt", "", "updatedAt", "lastPlayheadMs", "(Ljava/lang/String;Ljava/lang/String;Lcom/rehman/ahmedreactionstudio/core/Aspect;ILjava/util/List;JJJ)V", "getAspect", "()Lcom/rehman/ahmedreactionstudio/core/Aspect;", "setAspect", "(Lcom/rehman/ahmedreactionstudio/core/Aspect;)V", "getBgColor", "()I", "setBgColor", "(I)V", "getCreatedAt", "()J", "setCreatedAt", "(J)V", "getId", "()Ljava/lang/String;", "setId", "(Ljava/lang/String;)V", "getLastPlayheadMs", "setLastPlayheadMs", "getLayers", "()Ljava/util/List;", "getName", "setName", "getUpdatedAt", "setUpdatedAt", "durationMs", "layerById", "toJson", "Lorg/json/JSONObject;", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nModel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Model.kt\ncom/rehman/ahmedreactionstudio/core/Project\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,430:1\n288#2,2:431\n*S KotlinDebug\n*F\n+ 1 Model.kt\ncom/rehman/ahmedreactionstudio/core/Project\n*L\n194#1:431,2\n*E\n"})
public final class Project {

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @NotNull
    private Aspect aspect;
    private int bgColor;
    private long createdAt;

    @NotNull
    private String id;
    private long lastPlayheadMs;

    @NotNull
    private final List<Layer> layers;

    @NotNull
    private String name;
    private long updatedAt;

    public Project(@NotNull String id, @NotNull String name, @NotNull Aspect aspect, int i, @NotNull List<Layer> layers, long j, long j2, long j3) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(name, "name");
        Intrinsics.checkNotNullParameter(aspect, "aspect");
        Intrinsics.checkNotNullParameter(layers, "layers");
        this.id = id;
        this.name = name;
        this.aspect = aspect;
        this.bgColor = i;
        this.layers = layers;
        this.createdAt = j;
        this.updatedAt = j2;
        this.lastPlayheadMs = j3;
    }

    @NotNull
    public final String getId() {
        return this.id;
    }

    public final void setId(@NotNull String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.id = str;
    }

    @NotNull
    public final String getName() {
        return this.name;
    }

    public final void setName(@NotNull String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        this.name = str;
    }

    @NotNull
    public final Aspect getAspect() {
        return this.aspect;
    }

    public final void setAspect(@NotNull Aspect aspect) {
        Intrinsics.checkNotNullParameter(aspect, "<set-?>");
        this.aspect = aspect;
    }

    public final int getBgColor() {
        return this.bgColor;
    }

    public final void setBgColor(int i) {
        this.bgColor = i;
    }

    public /* synthetic */ Project(String str, String str2, Aspect aspect, int i, List list, long j, long j2, long j3, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, str2, aspect, (i2 & 8) != 0 ? -15723496 : i, (i2 & 16) != 0 ? new ArrayList() : list, (i2 & 32) != 0 ? System.currentTimeMillis() : j, (i2 & 64) != 0 ? System.currentTimeMillis() : j2, (i2 & 128) != 0 ? 0L : j3);
    }

    @NotNull
    public final List<Layer> getLayers() {
        return this.layers;
    }

    public final long getCreatedAt() {
        return this.createdAt;
    }

    public final void setCreatedAt(long j) {
        this.createdAt = j;
    }

    public final long getUpdatedAt() {
        return this.updatedAt;
    }

    public final void setUpdatedAt(long j) {
        this.updatedAt = j;
    }

    public final long getLastPlayheadMs() {
        return this.lastPlayheadMs;
    }

    public final void setLastPlayheadMs(long j) {
        this.lastPlayheadMs = j;
    }

    @Nullable
    public final Layer layerById(@NotNull String id) {
        Object next;
        Intrinsics.checkNotNullParameter(id, "id");
        Iterator<T> it = this.layers.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            if (Intrinsics.areEqual(((Layer) next).getId(), id)) {
                break;
            }
        }
        return (Layer) next;
    }

    public final long durationMs() {
        long durMs = 0;
        for (Layer layer : this.layers) {
            if (layer.isVideoLike() && layer.getDurMs() > durMs) {
                durMs = layer.getDurMs();
            }
        }
        if (durMs <= 0) {
            return 5000L;
        }
        return durMs;
    }

    @NotNull
    public final JSONObject toJson() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("schemaVersion", 1);
        jSONObject.put("id", this.id);
        jSONObject.put("name", this.name);
        jSONObject.put("aspect", this.aspect.getCode());
        jSONObject.put("bgColor", this.bgColor);
        jSONObject.put("createdAt", this.createdAt);
        jSONObject.put("updatedAt", this.updatedAt);
        jSONObject.put("lastPlayheadMs", this.lastPlayheadMs);
        JSONArray jSONArray = new JSONArray();
        Iterator<Layer> it = this.layers.iterator();
        while (it.hasNext()) {
            jSONArray.put(it.next().toJson());
        }
        jSONObject.put("layers", jSONArray);
        return jSONObject;
    }

    /* JADX INFO: compiled from: Model.kt */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006"}, d2 = {"Lcom/rehman/ahmedreactionstudio/core/Project$Companion;", "", "()V", "fromJson", "Lcom/rehman/ahmedreactionstudio/core/Project;", "o", "Lorg/json/JSONObject;"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        @NotNull
        public final Project fromJson(@NotNull JSONObject o) {
            Intrinsics.checkNotNullParameter(o, "o");
            String strOptString = o.optString("id", UUID.randomUUID().toString());
            Intrinsics.checkNotNullExpressionValue(strOptString, "optString(...)");
            String strOptString2 = o.optString("name", "Untitled");
            Intrinsics.checkNotNullExpressionValue(strOptString2, "optString(...)");
            Aspect.Companion companion = Aspect.INSTANCE;
            String strOptString3 = o.optString("aspect", "16:9");
            Intrinsics.checkNotNullExpressionValue(strOptString3, "optString(...)");
            Project project = new Project(strOptString, strOptString2, companion.from(strOptString3), o.optInt("bgColor", -15723496), null, o.optLong("createdAt"), o.optLong("updatedAt"), o.optLong("lastPlayheadMs"), 16, null);
            JSONArray jSONArrayOptJSONArray = o.optJSONArray("layers");
            if (jSONArrayOptJSONArray == null) {
                jSONArrayOptJSONArray = new JSONArray();
            }
            int length = jSONArrayOptJSONArray.length();
            for (int i = 0; i < length; i++) {
                try {
                    List<Layer> layers = project.getLayers();
                    Layer.Companion companion2 = Layer.INSTANCE;
                    JSONObject jSONObject = jSONArrayOptJSONArray.getJSONObject(i);
                    Intrinsics.checkNotNullExpressionValue(jSONObject, "getJSONObject(...)");
                    layers.add(companion2.fromJson(jSONObject));
                } catch (Exception unused) {
                }
            }
            return project;
        }
    }
}
