package com.rehman.ahmedreactionstudio.capture;

import android.R;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.widget.Toast;
import java.io.File;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: ScreenCaptureService.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\f\u0018\u0000 '2\u00020\u0001:\u0001'B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0013\u001a\u00020\u0014H\u0002J\u0010\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0016\u001a\u00020\u0017H\u0002J\u0014\u0010\u0018\u001a\u0004\u0018\u00010\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH\u0016J\b\u0010\u001c\u001a\u00020\u0014H\u0016J\"\u0010\u001d\u001a\u00020\u00042\b\u0010\u001a\u001a\u0004\u0018\u00010\u001b2\u0006\u0010\u001e\u001a\u00020\u00042\u0006\u0010\u001f\u001a\u00020\u0004H\u0016J\b\u0010 \u001a\u00020\u0014H\u0002J \u0010!\u001a\u00020\u00142\u0006\u0010\"\u001a\u00020\u00042\u0006\u0010#\u001a\u00020\u001b2\u0006\u0010$\u001a\u00020\tH\u0002J\b\u0010%\u001a\u00020\u0014H\u0002J\b\u0010&\u001a\u00020\u0014H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\b\u001a\u0004\u0018\u00010\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0010\u001a\u0004\u0018\u00010\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/capture/ScreenCaptureService;", "Landroid/app/Service;", "()V", "density", "", "handler", "Landroid/os/Handler;", "height", "outFile", "Ljava/io/File;", "projection", "Landroid/media/projection/MediaProjection;", "recorder", "Landroid/media/MediaRecorder;", "thread", "Landroid/os/HandlerThread;", "virtualDisplay", "Landroid/hardware/display/VirtualDisplay;", "width", "cleanup", "", "failShutdown", "msg", "", "onBind", "Landroid/os/IBinder;", "intent", "Landroid/content/Intent;", "onDestroy", "onStartCommand", "flags", "startId", "startForegroundCompat", "startRecording", "code", ScreenCaptureService.EXTRA_RESULT_DATA, "projectDir", "stopForegroundCompat", "stopRecording", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nScreenCaptureService.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ScreenCaptureService.kt\ncom/rehman/ahmedreactionstudio/capture/ScreenCaptureService\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,257:1\n1#2:258\n*E\n"})
public final class ScreenCaptureService extends Service {

    @NotNull
    public static final String ACTION_START = "ars.screen.start";

    @NotNull
    public static final String ACTION_STOP = "ars.screen.stop";

    @NotNull
    public static final String CHANNEL_ID = "ars_screen_rec";

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);

    @NotNull
    public static final String EXTRA_PROJECT_DIR = "pdir";

    @NotNull
    public static final String EXTRA_RESULT_CODE = "rc";

    @NotNull
    public static final String EXTRA_RESULT_DATA = "data";
    public static final int NOTIF_ID = 7123;

    @NotNull
    public static final String STOP_LABEL = "Stop screen recording";

    @Nullable
    private static Function1<? super File, Unit> onStopped;

    @Nullable
    private static volatile File pendingFile;
    private static volatile boolean running;

    @Nullable
    private Handler handler;

    @Nullable
    private File outFile;

    @Nullable
    private MediaProjection projection;

    @Nullable
    private MediaRecorder recorder;

    @Nullable
    private HandlerThread thread;

    @Nullable
    private VirtualDisplay virtualDisplay;
    private int width = 1280;
    private int height = 720;
    private int density = 1;

    @Override // android.app.Service
    @Nullable
    public IBinder onBind(@Nullable Intent intent) {
        return null;
    }

    /* JADX INFO: compiled from: ScreenCaptureService.kt */
    @Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R*\u0010\r\u001a\u0012\u0012\u0006\u0012\u0004\u0018\u00010\u000f\u0012\u0004\u0012\u00020\u0010\u0018\u00010\u000eX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u001c\u0010\u0015\u001a\u0004\u0018\u00010\u000fX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u0017\"\u0004\b\u0018\u0010\u0019R\u001e\u0010\u001c\u001a\u00020\u001b2\u0006\u0010\u001a\u001a\u00020\u001b@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001e"}, d2 = {"Lcom/rehman/ahmedreactionstudio/capture/ScreenCaptureService$Companion;", "", "()V", "ACTION_START", "", "ACTION_STOP", "CHANNEL_ID", "EXTRA_PROJECT_DIR", "EXTRA_RESULT_CODE", "EXTRA_RESULT_DATA", "NOTIF_ID", "", "STOP_LABEL", "onStopped", "Lkotlin/Function1;", "Ljava/io/File;", "", "getOnStopped", "()Lkotlin/jvm/functions/Function1;", "setOnStopped", "(Lkotlin/jvm/functions/Function1;)V", "pendingFile", "getPendingFile", "()Ljava/io/File;", "setPendingFile", "(Ljava/io/File;)V", "<set-?>", "", "running", "getRunning", "()Z"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        @Nullable
        public final File getPendingFile() {
            return ScreenCaptureService.pendingFile;
        }

        public final void setPendingFile(@Nullable File file) {
            ScreenCaptureService.pendingFile = file;
        }

        public final boolean getRunning() {
            return ScreenCaptureService.running;
        }

        @Nullable
        public final Function1<File, Unit> getOnStopped() {
            return ScreenCaptureService.onStopped;
        }

        public final void setOnStopped(@Nullable Function1<? super File, Unit> function1) {
            ScreenCaptureService.onStopped = function1;
        }
    }

    @Override // android.app.Service
    public int onStartCommand(@Nullable Intent intent, int flags, int startId) {
        Intent intent2;
        String action = intent != null ? intent.getAction() : null;
        if (Intrinsics.areEqual(action, ACTION_START)) {
            int intExtra = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
            if (Build.VERSION.SDK_INT >= 33) {
                intent2 = (Intent) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
            } else {
                intent2 = (Intent) intent.getParcelableExtra(EXTRA_RESULT_DATA);
            }
            String stringExtra = intent.getStringExtra(EXTRA_PROJECT_DIR);
            if (intExtra == 0 || intent2 == null || stringExtra == null) {
                stopSelf();
                return 2;
            }
            startForegroundCompat();
            startRecording(intExtra, intent2, new File(stringExtra));
        } else if (Intrinsics.areEqual(action, ACTION_STOP)) {
            stopRecording();
        }
        return 2;
    }

    private final void startForegroundCompat() {
        Notification notificationBuild;
        Object systemService = getSystemService("notification");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.app.NotificationManager");
        NotificationManager notificationManager = (NotificationManager) systemService;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, "Screen recording", 2);
            notificationChannel.setShowBadge(false);
            notificationManager.createNotificationChannel(notificationChannel);
        }
        ScreenCaptureService screenCaptureService = this;
        PendingIntent service = PendingIntent.getService(screenCaptureService, 0, new Intent(screenCaptureService, (Class<?>) ScreenCaptureService.class).setAction(ACTION_STOP), 201326592);
        if (Build.VERSION.SDK_INT >= 26) {
            notificationBuild = new Notification.Builder(screenCaptureService, CHANNEL_ID).setContentTitle("Recording screen").setContentText("Stop screen recording — it is added to your project").setSmallIcon(R.drawable.presence_video_online).setOngoing(true).setContentIntent(service).build();
            Intrinsics.checkNotNullExpressionValue(notificationBuild, "build(...)");
        } else {
            notificationBuild = new Notification.Builder(screenCaptureService).setContentTitle("Recording screen").setContentText("Stop screen recording — it is added to your project").setSmallIcon(R.drawable.presence_video_online).setOngoing(true).setContentIntent(service).build();
            Intrinsics.checkNotNullExpressionValue(notificationBuild, "build(...)");
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notificationBuild, 32);
        } else {
            startForeground(NOTIF_ID, notificationBuild);
        }
    }

    private final void startRecording(int code, Intent data, File projectDir) {
        try {
            Object systemService = getSystemService("media_projection");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.media.projection.MediaProjectionManager");
            MediaProjection mediaProjection = ((MediaProjectionManager) systemService).getMediaProjection(code, data);
            if (mediaProjection == null) {
                failShutdown("Screen capture permission was denied");
                return;
            }
            this.projection = mediaProjection;
            if (Build.VERSION.SDK_INT >= 34) {
                HandlerThread handlerThread = new HandlerThread("screen-cap");
                handlerThread.start();
                this.thread = handlerThread;
                HandlerThread handlerThread2 = this.thread;
                Intrinsics.checkNotNull(handlerThread2);
                this.handler = new Handler(handlerThread2.getLooper());
                mediaProjection.registerCallback(new MediaProjection.Callback() { // from class: com.rehman.ahmedreactionstudio.capture.ScreenCaptureService.startRecording.2
                    @Override // android.media.projection.MediaProjection.Callback
                    public void onStop() {
                        ScreenCaptureService.this.stopRecording();
                    }
                }, this.handler);
            }
            DisplayMetrics displayMetrics = new DisplayMetrics();
            Object systemService2 = getSystemService("window");
            Intrinsics.checkNotNull(systemService2, "null cannot be cast to non-null type android.view.WindowManager");
            ((WindowManager) systemService2).getDefaultDisplay().getRealMetrics(displayMetrics);
            this.density = RangesKt.coerceAtLeast(displayMetrics.densityDpi, 1);
            int i = displayMetrics.widthPixels;
            int i2 = displayMetrics.heightPixels;
            int iMax = Math.max(i, i2);
            if (iMax > 1080) {
                float f = 1080.0f / iMax;
                i = (int) (i * f);
                i2 = (int) (i2 * f);
            }
            this.width = (i / 2) * 2;
            this.height = (i2 / 2) * 2;
            File file = new File(projectDir, "media");
            file.mkdirs();
            File file2 = new File(file, "screen_" + System.currentTimeMillis() + ".mp4");
            this.outFile = file2;
            boolean z = checkSelfPermission("android.permission.RECORD_AUDIO") == 0;
            MediaRecorder mediaRecorder = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            mediaRecorder.setVideoSource(2);
            if (z) {
                mediaRecorder.setAudioSource(1);
            }
            mediaRecorder.setOutputFormat(2);
            mediaRecorder.setOutputFile(file2.getAbsolutePath());
            mediaRecorder.setVideoEncoder(2);
            mediaRecorder.setVideoSize(this.width, this.height);
            mediaRecorder.setVideoFrameRate(30);
            mediaRecorder.setVideoEncodingBitRate(10000000);
            if (z) {
                mediaRecorder.setAudioEncoder(3);
                mediaRecorder.setAudioEncodingBitRate(128000);
                mediaRecorder.setAudioSamplingRate(44100);
            }
            mediaRecorder.prepare();
            this.recorder = mediaRecorder;
            this.virtualDisplay = mediaProjection.createVirtualDisplay("ars-screen", this.width, this.height, this.density, 16, mediaRecorder.getSurface(), null, this.handler);
            mediaRecorder.start();
            Companion companion = INSTANCE;
            running = true;
        } catch (Exception e) {
            failShutdown("Could not start screen recording: " + e.getMessage());
        }
    }

    private final void failShutdown(final String msg) {
        Companion companion = INSTANCE;
        running = false;
        new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.capture.-$$Lambda$ScreenCaptureService$V7lu0RJ-cIO1I247MXpFTs4WsLU
            @Override // java.lang.Runnable
            public final void run() {
                ScreenCaptureService.failShutdown$lambda$2(this.f$0, msg);
            }
        });
        cleanup();
        stopForegroundCompat();
        stopSelf();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void failShutdown$lambda$2(ScreenCaptureService this$0, String msg) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(msg, "$msg");
        Toast.makeText(this$0, msg, 1).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:26:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:40:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void stopRecording() {
        /*
            r6 = this;
            boolean r0 = com.rehman.ahmedreactionstudio.capture.ScreenCaptureService.running
            if (r0 != 0) goto L8
            r6.stopSelf()
            return
        L8:
            com.rehman.ahmedreactionstudio.capture.ScreenCaptureService$Companion r0 = com.rehman.ahmedreactionstudio.capture.ScreenCaptureService.INSTANCE
            r0 = 0
            com.rehman.ahmedreactionstudio.capture.ScreenCaptureService.running = r0
            r0 = 0
            android.media.MediaRecorder r1 = r6.recorder     // Catch: java.lang.Exception -> L3a
            if (r1 == 0) goto L1b
            r1.stop()     // Catch: java.lang.Exception -> L15
        L15:
            r1.reset()     // Catch: java.lang.Exception -> L18
        L18:
            r1.release()     // Catch: java.lang.Exception -> L3a
        L1b:
            java.io.File r1 = r6.outFile     // Catch: java.lang.Exception -> L3a
            if (r1 == 0) goto L35
            boolean r2 = r1.exists()     // Catch: java.lang.Exception -> L3a
            if (r2 == 0) goto L35
            long r2 = r1.length()     // Catch: java.lang.Exception -> L3a
            r4 = 50000(0xc350, double:2.47033E-319)
            int r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r2 <= 0) goto L35
            com.rehman.ahmedreactionstudio.capture.ScreenCaptureService$Companion r2 = com.rehman.ahmedreactionstudio.capture.ScreenCaptureService.INSTANCE     // Catch: java.lang.Exception -> L3b
            com.rehman.ahmedreactionstudio.capture.ScreenCaptureService.pendingFile = r1     // Catch: java.lang.Exception -> L3b
            goto L3b
        L35:
            if (r1 == 0) goto L3a
            r1.delete()     // Catch: java.lang.Exception -> L3a
        L3a:
            r1 = r0
        L3b:
            r6.recorder = r0
            kotlin.jvm.functions.Function1<? super java.io.File, kotlin.Unit> r2 = com.rehman.ahmedreactionstudio.capture.ScreenCaptureService.onStopped
            com.rehman.ahmedreactionstudio.capture.ScreenCaptureService$Companion r3 = com.rehman.ahmedreactionstudio.capture.ScreenCaptureService.INSTANCE
            com.rehman.ahmedreactionstudio.capture.ScreenCaptureService.onStopped = r0
            r6.cleanup()
            r6.stopForegroundCompat()
            r6.stopSelf()
            if (r2 == 0) goto L51
            r2.invoke(r1)
        L51:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.capture.ScreenCaptureService.stopRecording():void");
    }

    private final void cleanup() {
        try {
            VirtualDisplay virtualDisplay = this.virtualDisplay;
            if (virtualDisplay != null) {
                virtualDisplay.release();
            }
        } catch (Exception unused) {
        }
        this.virtualDisplay = null;
        try {
            MediaProjection mediaProjection = this.projection;
            if (mediaProjection != null) {
                mediaProjection.stop();
            }
        } catch (Exception unused2) {
        }
        this.projection = null;
        try {
            HandlerThread handlerThread = this.thread;
            if (handlerThread != null) {
                handlerThread.quitSafely();
            }
        } catch (Exception unused3) {
        }
        this.thread = null;
        this.handler = null;
    }

    private final void stopForegroundCompat() {
        try {
            if (Build.VERSION.SDK_INT >= 24) {
                stopForeground(1);
            } else {
                stopForeground(true);
            }
        } catch (Exception unused) {
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        cleanup();
        Companion companion = INSTANCE;
        running = false;
        super.onDestroy();
    }
}
