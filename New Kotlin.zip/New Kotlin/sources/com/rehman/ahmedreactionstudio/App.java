package com.rehman.ahmedreactionstudio;

import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Process;
import android.util.Log;
import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.Thread;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.io.FilesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: App.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\n\u0000\u0018\u0000 \n2\u00020\u0001:\u0001\nB\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0016J\u0018\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0002"}, d2 = {"Lcom/rehman/ahmedreactionstudio/App;", "Landroid/app/Application;", "()V", "onCreate", "", "writeCrash", "thread", "Ljava/lang/Thread;", "ex", "", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nApp.kt\nKotlin\n*S Kotlin\n*F\n+ 1 App.kt\ncom/rehman/ahmedreactionstudio/App\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,90:1\n6523#2:91\n1855#3:92\n1856#3:94\n1#4:93\n*S KotlinDebug\n*F\n+ 1 App.kt\ncom/rehman/ahmedreactionstudio/App\n*L\n74#1:91\n76#1:92\n76#1:94\n*E\n"})
public final class App extends Application {

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    @NotNull
    public static final Companion INSTANCE = new Companion(null);
    private static final int MAX_CRASH_LOGS = 6;

    @NotNull
    private static final String TAG = "AhmedStudio";

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler defaultUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() { // from class: com.rehman.ahmedreactionstudio.-$$Lambda$App$d4JO6BEAOY5nbwir_ta6MyWZkoM
            @Override // java.lang.Thread.UncaughtExceptionHandler
            public final void uncaughtException(Thread thread, Throwable th) {
                App.onCreate$lambda$0(this.f$0, defaultUncaughtExceptionHandler, thread, th);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$0(App this$0, Thread.UncaughtExceptionHandler uncaughtExceptionHandler, Thread thread, Throwable th) {
        Unit unit;
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        try {
            Intrinsics.checkNotNull(thread);
            Intrinsics.checkNotNull(th);
            this$0.writeCrash(thread, th);
        } catch (Throwable unused) {
        }
        if (uncaughtExceptionHandler != null) {
            uncaughtExceptionHandler.uncaughtException(thread, th);
            unit = Unit.INSTANCE;
        } else {
            unit = null;
        }
        if (unit == null) {
            Process.killProcess(Process.myPid());
        }
    }

    private final void writeCrash(Thread thread, Throwable ex) {
        List listSortedWith;
        List<File> listDrop;
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        printWriter.println("Ahmed Reaction Studio — uncaught exception");
        printWriter.println("time:     " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
        printWriter.println("android:  " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ')');
        StringBuilder sb = new StringBuilder();
        sb.append("device:   ");
        sb.append(Build.MANUFACTURER);
        sb.append(' ');
        sb.append(Build.MODEL);
        printWriter.println(sb.toString());
        printWriter.println("thread:   " + thread.getName() + " (id " + thread.getId() + ')');
        StringBuilder sb2 = new StringBuilder();
        sb2.append("process:  ");
        sb2.append(getApplicationContext().getPackageName());
        printWriter.println(sb2.toString());
        printWriter.println();
        ex.printStackTrace(printWriter);
        Throwable cause = ex.getCause();
        if (cause != null && cause != ex) {
            printWriter.println();
            printWriter.println("caused by:");
            cause.printStackTrace(printWriter);
        }
        printWriter.flush();
        File file = new File(getFilesDir(), "crashes");
        file.mkdirs();
        File file2 = new File(file, "crash-" + System.currentTimeMillis() + ".txt");
        String string = stringWriter.toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        FilesKt.writeText$default(file2, string, null, 2, null);
        Log.e(TAG, "uncaught on " + thread.getName(), ex);
        File[] fileArrListFiles = file.listFiles();
        if (fileArrListFiles == null || (listSortedWith = ArraysKt.sortedWith(fileArrListFiles, new Comparator() { // from class: com.rehman.ahmedreactionstudio.App$writeCrash$$inlined$sortedByDescending$1
            /* JADX WARN: Multi-variable type inference failed */
            @Override // java.util.Comparator
            public final int compare(T t, T t2) {
                return ComparisonsKt.compareValues(Long.valueOf(((File) t2).lastModified()), Long.valueOf(((File) t).lastModified()));
            }
        })) == null || (listDrop = CollectionsKt.drop(listSortedWith, MAX_CRASH_LOGS)) == null) {
            return;
        }
        for (File file3 : listDrop) {
            try {
                Result.Companion companion = Result.INSTANCE;
                App app = this;
                Result.m59constructorimpl(Boolean.valueOf(file3.delete()));
            } catch (Throwable th) {
                Result.Companion companion2 = Result.INSTANCE;
                Result.m59constructorimpl(ResultKt.createFailure(th));
            }
        }
    }

    /* JADX INFO: compiled from: App.kt */
    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\b2\u0006\u0010\n\u001a\u00020\u000bR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082T¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/App$Companion;", "", "()V", "MAX_CRASH_LOGS", "", "TAG", "", "crashLogs", "", "Ljava/io/File;", "ctx", "Landroid/content/Context;"}, k = 1, mv = {1, 9, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nApp.kt\nKotlin\n*S Kotlin\n*F\n+ 1 App.kt\ncom/rehman/ahmedreactionstudio/App$Companion\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,90:1\n6523#2:91\n*S KotlinDebug\n*F\n+ 1 App.kt\ncom/rehman/ahmedreactionstudio/App$Companion\n*L\n86#1:91\n*E\n"})
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        @NotNull
        public final List<File> crashLogs(@NotNull Context ctx) {
            List<File> listSortedWith;
            Intrinsics.checkNotNullParameter(ctx, "ctx");
            File[] fileArrListFiles = new File(ctx.getFilesDir(), "crashes").listFiles();
            return (fileArrListFiles == null || (listSortedWith = ArraysKt.sortedWith(fileArrListFiles, new Comparator() { // from class: com.rehman.ahmedreactionstudio.App$Companion$crashLogs$$inlined$sortedByDescending$1
                /* JADX WARN: Multi-variable type inference failed */
                @Override // java.util.Comparator
                public final int compare(T t, T t2) {
                    return ComparisonsKt.compareValues(Long.valueOf(((File) t2).lastModified()), Long.valueOf(((File) t).lastModified()));
                }
            })) == null) ? CollectionsKt.emptyList() : listSortedWith;
        }
    }
}
