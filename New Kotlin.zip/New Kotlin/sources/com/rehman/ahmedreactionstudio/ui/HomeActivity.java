package com.rehman.ahmedreactionstudio.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.rehman.ahmedreactionstudio.core.Aspect;
import com.rehman.ahmedreactionstudio.core.Project;
import com.rehman.ahmedreactionstudio.core.ProjectStore;
import com.rehman.ahmedreactionstudio.editor.EditorActivity;
import com.rehman.ahmedreactionstudio.ui.HomeActivity;
import com.rehman.ahmedreactionstudio.util.UI;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.StringsKt;
import kotlin.text.Typography;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: HomeActivity.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001:\u0001 B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u000b\u001a\u00020\fH\u0002J\u0010\u0010\r\u001a\u00020\f2\u0006\u0010\u000e\u001a\u00020\u0007H\u0002J\u0012\u0010\u000f\u001a\u00020\f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0014J\b\u0010\u0012\u001a\u00020\fH\u0014J\u0010\u0010\u0013\u001a\u00020\f2\u0006\u0010\u0014\u001a\u00020\u0015H\u0002J\b\u0010\u0016\u001a\u00020\fH\u0002J,\u0010\u0017\u001a\u00020\f2\"\u0010\u0018\u001a\u001e\u0012\u0004\u0012\u00020\u001a\u0012\u0004\u0012\u00020\u001b0\u0019j\u000e\u0012\u0004\u0012\u00020\u001a\u0012\u0004\u0012\u00020\u001b`\u001cH\u0002J\u0010\u0010\u001d\u001a\u00020\f2\u0006\u0010\u000e\u001a\u00020\u0007H\u0002J\b\u0010\u001e\u001a\u00020\fH\u0002J\u0010\u0010\u001f\u001a\u00020\f2\u0006\u0010\u000e\u001a\u00020\u0007H\u0002R\u0012\u0010\u0003\u001a\u00060\u0004R\u00020\u0000X\u0082.¢\u0006\u0002\n\u0000R\u001e\u0010\u0005\u001a\u0012\u0012\u0004\u0012\u00020\u00070\u0006j\b\u0012\u0004\u0012\u00020\u0007`\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082.¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/ui/HomeActivity;", "Landroid/app/Activity;", "()V", "adapter", "Lcom/rehman/ahmedreactionstudio/ui/HomeActivity$ProjectsAdapter;", "projects", "Ljava/util/ArrayList;", "Lcom/rehman/ahmedreactionstudio/core/Project;", "Lkotlin/collections/ArrayList;", "store", "Lcom/rehman/ahmedreactionstudio/core/ProjectStore;", "buildUi", "", "confirmDelete", "p", "onCreate", "b", "Landroid/os/Bundle;", "onResume", "openProject", "id", "", "refresh", "refreshChips", "chips", "Ljava/util/HashMap;", "Lcom/rehman/ahmedreactionstudio/core/Aspect;", "Landroid/widget/TextView;", "Lkotlin/collections/HashMap;", "renameProject", "showNewDialog", "showProjectMenu", "ProjectsAdapter"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nHomeActivity.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HomeActivity.kt\ncom/rehman/ahmedreactionstudio/ui/HomeActivity\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,351:1\n1#2:352\n288#3,2:353\n288#3,2:355\n*S KotlinDebug\n*F\n+ 1 HomeActivity.kt\ncom/rehman/ahmedreactionstudio/ui/HomeActivity\n*L\n208#1:353,2\n222#1:355,2\n*E\n"})
public final class HomeActivity extends Activity {
    private ProjectsAdapter adapter;

    @NotNull
    private final ArrayList<Project> projects = new ArrayList<>();
    private ProjectStore store;

    @Override // android.app.Activity
    protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        UI.styleWindow$default(UI.INSTANCE, this, false, 2, null);
        this.store = new ProjectStore(this);
        ProjectStore projectStore = this.store;
        if (projectStore == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore = null;
        }
        projectStore.ensureRoot();
        buildUi();
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        refresh();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void refresh() {
        this.projects.clear();
        ProjectStore projectStore = this.store;
        if (projectStore == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore = null;
        }
        for (String str : projectStore.listIds()) {
            ProjectStore projectStore2 = this.store;
            if (projectStore2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("store");
                projectStore2 = null;
            }
            Project projectLoad = projectStore2.load(str);
            if (projectLoad != null) {
                this.projects.add(projectLoad);
            }
        }
        ProjectsAdapter projectsAdapter = this.adapter;
        if (projectsAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
            projectsAdapter = null;
        }
        projectsAdapter.notifyDataSetChanged();
    }

    private final void buildUi() {
        HomeActivity homeActivity = this;
        LinearLayout linearLayoutCol = UI.INSTANCE.col(homeActivity, true);
        linearLayoutCol.setPadding(UI.INSTANCE.dp(homeActivity, 16), UI.INSTANCE.dp(homeActivity, 22), UI.INSTANCE.dp(homeActivity, 16), 0);
        LinearLayout linearLayoutCol2 = UI.INSTANCE.col(homeActivity, false);
        TextView textView = new TextView(homeActivity);
        textView.setText("▶");
        textView.setTextColor(UI.INSTANCE.getACCENT());
        textView.setTextSize(26.0f);
        textView.setGravity(17);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(UI.INSTANCE.dpf(homeActivity, 10.0f));
        gradientDrawable.setColor(Color.argb(40, KotlinVersion.MAX_COMPONENT_VALUE, 90, 44));
        textView.setBackground(gradientDrawable);
        textView.setLayoutParams(new LinearLayout.LayoutParams(UI.INSTANCE.dp(homeActivity, 46), UI.INSTANCE.dp(homeActivity, 46)));
        linearLayoutCol2.addView(textView);
        LinearLayout linearLayoutCol3 = UI.INSTANCE.col(homeActivity, true);
        linearLayoutCol3.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayoutCol3.addView(UI.INSTANCE.title(homeActivity, "Ahmed Reaction Studio"));
        linearLayoutCol3.addView(UI.INSTANCE.label(homeActivity, "Local-first Kotlin reaction & PiP editor", true, 12.0f));
        linearLayoutCol2.addView(linearLayoutCol3);
        TextView textViewChip = UI.INSTANCE.chip(homeActivity, "ⓘ Diag");
        textViewChip.setContentDescription("Open diagnostics");
        textViewChip.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$HomeActivity$WIFn9gbtQD7zrYjwreXWId_f5Mw
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                HomeActivity.buildUi$lambda$1(this.f$0, view);
            }
        });
        linearLayoutCol2.addView(textViewChip);
        linearLayoutCol.addView(linearLayoutCol2);
        TextView textViewLabel = UI.INSTANCE.label(homeActivity, "Projects are stored on this device only. No accounts, no cloud.", true, 11.0f);
        UI.INSTANCE.margin(textViewLabel, 0, 14, 0, 0, homeActivity);
        linearLayoutCol.addView(textViewLabel);
        ListView listView = new ListView(homeActivity);
        ProjectsAdapter projectsAdapter = null;
        listView.setDivider(null);
        listView.setPadding(0, UI.INSTANCE.dp(homeActivity, 6), 0, 0);
        listView.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1.0f));
        this.adapter = new ProjectsAdapter();
        ProjectsAdapter projectsAdapter2 = this.adapter;
        if (projectsAdapter2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("adapter");
        } else {
            projectsAdapter = projectsAdapter2;
        }
        listView.setAdapter((ListAdapter) projectsAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$HomeActivity$xc9RQZIYgIhvXSQNUXaMSbXv9rk
            @Override // android.widget.AdapterView.OnItemClickListener
            public final void onItemClick(AdapterView adapterView, View view, int i, long j) {
                HomeActivity.buildUi$lambda$2(this.f$0, adapterView, view, i, j);
            }
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$HomeActivity$SGwBHJmsZkFDBK2Q-z0h1BpSd9A
            @Override // android.widget.AdapterView.OnItemLongClickListener
            public final boolean onItemLongClick(AdapterView adapterView, View view, int i, long j) {
                return HomeActivity.buildUi$lambda$4(this.f$0, adapterView, view, i, j);
            }
        });
        linearLayoutCol.addView(listView);
        Button buttonBtn$default = UI.btn$default(UI.INSTANCE, homeActivity, "+  New project", true, false, 8, null);
        buttonBtn$default.setLayoutParams(new LinearLayout.LayoutParams(-1, UI.INSTANCE.dp(homeActivity, 50)));
        buttonBtn$default.setContentDescription("Create a new project");
        buttonBtn$default.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$HomeActivity$K4zKqn7lzaXPPH2cb6h9kEZGQ6g
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                HomeActivity.buildUi$lambda$5(this.f$0, view);
            }
        });
        linearLayoutCol.addView(buttonBtn$default);
        setContentView(linearLayoutCol);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildUi$lambda$1(HomeActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.startActivity(new Intent(this$0, (Class<?>) DiagnosticsActivity.class));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildUi$lambda$2(HomeActivity this$0, AdapterView adapterView, View view, int i, long j) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.openProject(this$0.projects.get(i).getId());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean buildUi$lambda$4(HomeActivity this$0, AdapterView adapterView, View view, int i, long j) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Project project = (Project) CollectionsKt.getOrNull(this$0.projects, i);
        if (project == null) {
            return true;
        }
        this$0.showProjectMenu(project);
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildUi$lambda$5(HomeActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.showNewDialog();
    }

    private final void showProjectMenu(final Project p) {
        new AlertDialog.Builder(this).setTitle(p.getName()).setItems(new String[]{"Open", "Rename project", "Duplicate", "Delete"}, new DialogInterface.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$HomeActivity$l74sT1jRgnWAZXEg80uxrpSjgyA
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                HomeActivity.showProjectMenu$lambda$6(this.f$0, p, dialogInterface, i);
            }
        }).setNegativeButton("Cancel", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showProjectMenu$lambda$6(HomeActivity this$0, Project p, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(p, "$p");
        if (i == 0) {
            this$0.openProject(p.getId());
            return;
        }
        if (i == 1) {
            this$0.renameProject(p);
            return;
        }
        if (i != 2) {
            if (i != 3) {
                return;
            }
            this$0.confirmDelete(p);
        } else {
            ProjectStore projectStore = this$0.store;
            if (projectStore == null) {
                Intrinsics.throwUninitializedPropertyAccessException("store");
                projectStore = null;
            }
            projectStore.duplicate(p.getId());
            this$0.refresh();
        }
    }

    private final void renameProject(final Project p) {
        HomeActivity homeActivity = this;
        final EditText editText = new EditText(homeActivity);
        editText.setText(p.getName());
        editText.setSelection(editText.getText().length());
        editText.setTextColor(UI.INSTANCE.getFG());
        new AlertDialog.Builder(homeActivity).setTitle("Rename project").setView(editText).setPositiveButton("Rename", new DialogInterface.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$HomeActivity$Cb-keCCm3q7jLZt340PrBfE6dik
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                HomeActivity.renameProject$lambda$7(editText, this, p, dialogInterface, i);
            }
        }).setNegativeButton("Cancel", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void renameProject$lambda$7(EditText input, HomeActivity this$0, Project p, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(input, "$input");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(p, "$p");
        String string = StringsKt.trim((CharSequence) input.getText().toString()).toString();
        if (string.length() == 0) {
            return;
        }
        ProjectStore projectStore = this$0.store;
        if (projectStore == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore = null;
        }
        Project projectLoad = projectStore.load(p.getId());
        if (projectLoad == null) {
            return;
        }
        projectLoad.setName(string);
        ProjectStore projectStore2 = this$0.store;
        if (projectStore2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore2 = null;
        }
        ProjectStore.save$default(projectStore2, projectLoad, false, 2, null);
        this$0.refresh();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void confirmDelete(final Project p) {
        new AlertDialog.Builder(this).setTitle("Delete project").setMessage(Typography.quote + p.getName() + "\" and its project media will be deleted from this device.").setPositiveButton("Delete", new DialogInterface.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$HomeActivity$IhlTR-j8HMhBmsYLXVD55jhSI9c
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                HomeActivity.confirmDelete$lambda$8(this.f$0, p, dialogInterface, i);
            }
        }).setNegativeButton("Cancel", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void confirmDelete$lambda$8(HomeActivity this$0, Project p, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(p, "$p");
        ProjectStore projectStore = this$0.store;
        if (projectStore == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore = null;
        }
        projectStore.delete(p.getId());
        this$0.refresh();
    }

    private final void openProject(String id) {
        ProjectStore projectStore = this.store;
        if (projectStore == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore = null;
        }
        Project projectLoad = projectStore.load(id);
        if (projectLoad == null) {
            return;
        }
        Intent intent = new Intent(this, (Class<?>) EditorActivity.class);
        intent.putExtra("pid", id);
        intent.putExtra(EditorActivity.EXTRA_PROJECT_NAME, projectLoad.getName());
        intent.putExtra(EditorActivity.EXTRA_PROJECT_ASPECT, projectLoad.getAspect().getCode());
        ProjectStore projectStore2 = this.store;
        if (projectStore2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore2 = null;
        }
        projectStore2.markOpen(id);
        startActivity(intent);
    }

    private final void showNewDialog() {
        HomeActivity homeActivity = this;
        LinearLayout linearLayout = new LinearLayout(homeActivity);
        linearLayout.setOrientation(1);
        linearLayout.setPadding(UI.INSTANCE.dp(homeActivity, 22), UI.INSTANCE.dp(homeActivity, 8), UI.INSTANCE.dp(homeActivity, 22), 0);
        final EditText editText = new EditText(homeActivity);
        editText.setHint("Project name");
        editText.setText("My Reaction");
        editText.setTextColor(UI.INSTANCE.getFG());
        editText.setHintTextColor(Color.argb(150, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
        linearLayout.addView(editText);
        LinearLayout linearLayoutCol = UI.INSTANCE.col(homeActivity, false);
        linearLayoutCol.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        LinearLayout linearLayout2 = linearLayoutCol;
        UI.INSTANCE.margin(linearLayout2, 0, 14, 0, 6, homeActivity);
        final HashMap<Aspect, TextView> map = new HashMap<>();
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, UI.INSTANCE.dp(homeActivity, 40), 1.0f);
        for (Aspect aspect : Aspect.getEntries()) {
            final TextView textViewChip = UI.INSTANCE.chip(homeActivity, aspect.getCode());
            textViewChip.setContentDescription("Canvas aspect ratio " + aspect.getCode());
            textViewChip.setLayoutParams(layoutParams);
            textViewChip.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$HomeActivity$VH4HK_rfGhqr1yL5Pi1wphfnd60
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    HomeActivity.showNewDialog$lambda$10(map, textViewChip, this, view);
                }
            });
            map.put(aspect, textViewChip);
            linearLayoutCol.addView(textViewChip);
        }
        linearLayout.addView(linearLayout2);
        new AlertDialog.Builder(homeActivity).setTitle("New project").setView(linearLayout).setPositiveButton("Create", new DialogInterface.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$HomeActivity$DIAhELZAgSnDDut33zGKUEYetyg
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                HomeActivity.showNewDialog$lambda$12(editText, map, this, dialogInterface, i);
            }
        }).setNegativeButton("Cancel", (DialogInterface.OnClickListener) null).show();
        TextView textView = map.get(Aspect.R169);
        if (textView != null) {
            textView.setSelected(true);
        }
        refreshChips(map);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showNewDialog$lambda$10(HashMap chips, TextView c, HomeActivity this$0, View view) {
        Object next;
        Intrinsics.checkNotNullParameter(chips, "$chips");
        Intrinsics.checkNotNullParameter(c, "$c");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Collection collectionValues = chips.values();
        Intrinsics.checkNotNullExpressionValue(collectionValues, "<get-values>(...)");
        Iterator it = collectionValues.iterator();
        while (true) {
            if (it.hasNext()) {
                next = it.next();
                if (((TextView) next) == c) {
                    break;
                }
            } else {
                next = null;
                break;
            }
        }
        if (((TextView) next) == null) {
            return;
        }
        for (Map.Entry entry : chips.entrySet()) {
            TextView textView = (TextView) entry.getValue();
            textView.setSelected(textView == c);
        }
        this$0.refreshChips(chips);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void showNewDialog$lambda$12(EditText nameInput, HashMap chips, HomeActivity this$0, DialogInterface dialogInterface, int i) {
        Object next;
        Aspect aspect;
        Intrinsics.checkNotNullParameter(nameInput, "$nameInput");
        Intrinsics.checkNotNullParameter(chips, "$chips");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        String string = nameInput.getText().toString();
        Set setEntrySet = chips.entrySet();
        Intrinsics.checkNotNullExpressionValue(setEntrySet, "<get-entries>(...)");
        Iterator it = setEntrySet.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            } else {
                next = it.next();
                if (((TextView) ((Map.Entry) next).getValue()).isSelected()) {
                    break;
                }
            }
        }
        Map.Entry entry = (Map.Entry) next;
        if (entry == null || (aspect = (Aspect) entry.getKey()) == null) {
            aspect = Aspect.R169;
        }
        Intrinsics.checkNotNull(aspect);
        ProjectStore projectStore = this$0.store;
        if (projectStore == null) {
            Intrinsics.throwUninitializedPropertyAccessException("store");
            projectStore = null;
        }
        this$0.openProject(projectStore.create(string, aspect).getId());
    }

    private final void refreshChips(HashMap<Aspect, TextView> chips) {
        for (Map.Entry<Aspect, TextView> entry : chips.entrySet()) {
            entry.getKey();
            TextView value = entry.getValue();
            Drawable background = value.getBackground();
            Intrinsics.checkNotNull(background, "null cannot be cast to non-null type android.graphics.drawable.GradientDrawable");
            GradientDrawable gradientDrawable = (GradientDrawable) background;
            if (value.isSelected()) {
                gradientDrawable.setColor(UI.INSTANCE.getACCENT());
                gradientDrawable.setStroke(UI.INSTANCE.dp(this, 1), Color.argb(140, KotlinVersion.MAX_COMPONENT_VALUE, 220, 180));
                value.setTextColor(-1);
            } else {
                gradientDrawable.setColor(UI.INSTANCE.getBG3());
                gradientDrawable.setStroke(UI.INSTANCE.dp(this, 1), Color.argb(60, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
                value.setTextColor(UI.INSTANCE.getFG());
            }
            value.setBackground(gradientDrawable);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: HomeActivity.kt */
    @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0016J\u0010\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0004H\u0016J\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\u0007\u001a\u00020\u0004H\u0016J$\u0010\n\u001a\u00020\u000b2\u0006\u0010\u0007\u001a\u00020\u00042\b\u0010\f\u001a\u0004\u0018\u00010\u000b2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0016"}, d2 = {"Lcom/rehman/ahmedreactionstudio/ui/HomeActivity$ProjectsAdapter;", "Landroid/widget/BaseAdapter;", "(Lcom/rehman/ahmedreactionstudio/ui/HomeActivity;)V", "getCount", "", "getItem", "", "pos", "getItemId", "", "getView", "Landroid/view/View;", "convert", "parent", "Landroid/view/ViewGroup;"}, k = 1, mv = {1, 9, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nHomeActivity.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HomeActivity.kt\ncom/rehman/ahmedreactionstudio/ui/HomeActivity$ProjectsAdapter\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,351:1\n1#2:352\n*E\n"})
    final class ProjectsAdapter extends BaseAdapter {
        @Override // android.widget.Adapter
        public long getItemId(int pos) {
            return pos;
        }

        public ProjectsAdapter() {
        }

        @Override // android.widget.Adapter
        public int getCount() {
            return HomeActivity.this.projects.size();
        }

        @Override // android.widget.Adapter
        @NotNull
        public Object getItem(int pos) {
            Object obj = HomeActivity.this.projects.get(pos);
            Intrinsics.checkNotNullExpressionValue(obj, "get(...)");
            return obj;
        }

        @Override // android.widget.Adapter
        @NotNull
        public View getView(int pos, @Nullable View convert, @Nullable ViewGroup parent) {
            HomeActivity homeActivity = HomeActivity.this;
            Object obj = homeActivity.projects.get(pos);
            Intrinsics.checkNotNullExpressionValue(obj, "get(...)");
            final Project project = (Project) obj;
            HomeActivity homeActivity2 = homeActivity;
            LinearLayout linearLayout = new LinearLayout(homeActivity2);
            linearLayout.setOrientation(0);
            linearLayout.setPadding(UI.INSTANCE.dp(homeActivity2, 12), UI.INSTANCE.dp(homeActivity2, 10), UI.INSTANCE.dp(homeActivity2, 12), UI.INSTANCE.dp(homeActivity2, 10));
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setCornerRadius(UI.INSTANCE.dpf(homeActivity2, 14.0f));
            gradientDrawable.setColor(UI.INSTANCE.getBG2());
            gradientDrawable.setStroke(UI.INSTANCE.dp(homeActivity2, 1), Color.argb(50, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
            linearLayout.setBackground(gradientDrawable);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, UI.INSTANCE.dp(homeActivity2, 92));
            layoutParams.setMargins(0, 0, 0, UI.INSTANCE.dp(homeActivity2, 8));
            linearLayout.setLayoutParams(layoutParams);
            FrameLayout frameLayout = new FrameLayout(homeActivity2);
            frameLayout.setLayoutParams(new LinearLayout.LayoutParams(UI.INSTANCE.dp(homeActivity2, 66), UI.INSTANCE.dp(homeActivity2, 66)));
            final ImageView imageView = new ImageView(homeActivity2);
            ProjectStore projectStore = HomeActivity.this.store;
            if (projectStore == null) {
                Intrinsics.throwUninitializedPropertyAccessException("store");
                projectStore = null;
            }
            File fileThumbFile = projectStore.thumbFile(project.getId());
            GradientDrawable gradientDrawable2 = new GradientDrawable();
            gradientDrawable2.setCornerRadius(UI.INSTANCE.dpf(homeActivity2, 8.0f));
            gradientDrawable2.setColor(UI.INSTANCE.getBG3());
            frameLayout.setBackground(gradientDrawable2);
            imageView.setTag(null);
            imageView.setImageDrawable(null);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            if (fileThumbFile.exists()) {
                final String absolutePath = fileThumbFile.getAbsolutePath();
                imageView.setTag(absolutePath);
                new Thread(new Runnable() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$HomeActivity$ProjectsAdapter$0OaJUi71ZNpng_xNg0NObApxRlA
                    @Override // java.lang.Runnable
                    public final void run() {
                        HomeActivity.ProjectsAdapter.getView$lambda$2(absolutePath, imageView);
                    }
                }).start();
            }
            frameLayout.addView(imageView, new FrameLayout.LayoutParams(-1, -1));
            linearLayout.addView(frameLayout);
            LinearLayout linearLayoutCol = UI.INSTANCE.col(homeActivity2, true);
            linearLayoutCol.setLayoutParams(new LinearLayout.LayoutParams(0, -1, 1.0f));
            LinearLayout linearLayout2 = linearLayoutCol;
            UI.INSTANCE.margin(linearLayout2, 12, 0, 8, 0, homeActivity2);
            TextView textView = new TextView(homeActivity2);
            textView.setText(project.getName());
            textView.setTextColor(UI.INSTANCE.getFG());
            textView.setTextSize(15.0f);
            textView.setTypeface(Typeface.create("sans-serif-medium", 1));
            textView.setMaxLines(1);
            linearLayoutCol.addView(textView);
            TextView textView2 = new TextView(homeActivity2);
            StringBuilder sb = new StringBuilder();
            sb.append(project.getAspect().getCode());
            sb.append("  ·  ");
            sb.append(project.getLayers().size());
            sb.append(" layer");
            sb.append(project.getLayers().size() == 1 ? "" : "s");
            sb.append("  ·  ");
            sb.append(UI.INSTANCE.fmtTime(project.durationMs()));
            sb.append("  ·  ");
            sb.append(UI.INSTANCE.relTime(project.getUpdatedAt()));
            textView2.setText(sb.toString());
            textView2.setTextColor(UI.INSTANCE.getFG2());
            textView2.setTextSize(11.5f);
            TextView textView3 = textView2;
            UI.INSTANCE.margin(textView3, 0, 2, 0, 0, homeActivity2);
            linearLayoutCol.addView(textView3);
            linearLayout.addView(linearLayout2);
            TextView textViewChip = UI.INSTANCE.chip(homeActivity2, "✕");
            textViewChip.setContentDescription("Delete project " + project.getName());
            textViewChip.setTextColor(UI.INSTANCE.getDANGER());
            final HomeActivity homeActivity3 = HomeActivity.this;
            textViewChip.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$HomeActivity$ProjectsAdapter$SbA9tt0srgxb7kXANvl9a9hsR-g
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    HomeActivity.ProjectsAdapter.getView$lambda$3(homeActivity3, project, view);
                }
            });
            LinearLayout linearLayoutCol2 = UI.INSTANCE.col(homeActivity2, true);
            linearLayoutCol2.setLayoutParams(new LinearLayout.LayoutParams(-2, -1));
            linearLayoutCol2.setGravity(8388629);
            TextView textViewChip2 = UI.INSTANCE.chip(homeActivity2, "Copy");
            textViewChip2.setContentDescription("Duplicate project " + project.getName());
            final HomeActivity homeActivity4 = HomeActivity.this;
            textViewChip2.setOnClickListener(new View.OnClickListener() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$HomeActivity$ProjectsAdapter$8OYaEvZEt7mzk1kdtUvWuPdn5Nw
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    HomeActivity.ProjectsAdapter.getView$lambda$4(homeActivity4, project, view);
                }
            });
            linearLayoutCol2.addView(textViewChip2);
            TextView textView4 = textViewChip;
            UI.INSTANCE.margin(textView4, 0, 6, 0, 0, homeActivity2);
            linearLayoutCol2.addView(textView4);
            linearLayout.addView(linearLayoutCol2);
            return linearLayout;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void getView$lambda$2(final String str, final ImageView thumb) {
            Intrinsics.checkNotNullParameter(thumb, "$thumb");
            try {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = 4;
                final Bitmap bitmapDecodeFile = BitmapFactory.decodeFile(str, options);
                thumb.post(new Runnable() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$HomeActivity$ProjectsAdapter$9NOn-553dF5x_50mMosyICrAhOo
                    @Override // java.lang.Runnable
                    public final void run() {
                        HomeActivity.ProjectsAdapter.getView$lambda$2$lambda$1(thumb, str, bitmapDecodeFile);
                    }
                });
            } catch (Exception unused) {
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void getView$lambda$2$lambda$1(ImageView thumb, String str, Bitmap bitmap) {
            Intrinsics.checkNotNullParameter(thumb, "$thumb");
            if (Intrinsics.areEqual(thumb.getTag(), str) && bitmap != null) {
                thumb.setImageBitmap(bitmap);
            } else if (bitmap != null) {
                try {
                    bitmap.recycle();
                } catch (Exception unused) {
                }
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void getView$lambda$3(HomeActivity this$0, Project p, View view) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(p, "$p");
            this$0.confirmDelete(p);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void getView$lambda$4(HomeActivity this$0, Project p, View view) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(p, "$p");
            ProjectStore projectStore = this$0.store;
            if (projectStore == null) {
                Intrinsics.throwUninitializedPropertyAccessException("store");
                projectStore = null;
            }
            projectStore.duplicate(p.getId());
            this$0.refresh();
        }
    }
}
