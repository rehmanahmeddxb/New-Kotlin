package com.rehman.ahmedreactionstudio.ui;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.rehman.ahmedreactionstudio.editor.EditorActivity;
import com.rehman.ahmedreactionstudio.util.UI;
import java.io.File;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;

/* JADX INFO: compiled from: DiagnosticsActivity.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0012\u0010\u0003\u001a\u00020\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\u0014"}, d2 = {"Lcom/rehman/ahmedreactionstudio/ui/DiagnosticsActivity;", "Landroid/app/Activity;", "()V", "onCreate", "", "b", "Landroid/os/Bundle;"}, k = 1, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nDiagnosticsActivity.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DiagnosticsActivity.kt\ncom/rehman/ahmedreactionstudio/ui/DiagnosticsActivity\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,205:1\n1855#2:206\n1856#2:208\n1#3:207\n*S KotlinDebug\n*F\n+ 1 DiagnosticsActivity.kt\ncom/rehman/ahmedreactionstudio/ui/DiagnosticsActivity\n*L\n180#1:206\n180#1:208\n*E\n"})
public final class DiagnosticsActivity extends Activity {
    /* JADX WARN: Can't wrap try/catch for region: R(36:0|2|(1:4)|5|128|6|(2:138|7)|134|8|(1:10)|11|12|(3:142|13|(7:15|(1:17)(6:18|(1:20)|27|(1:29)(1:30)|31|32)|(1:25)(1:26)|27|(0)(0)|31|32))|(2:140|33)|(3:144|34|35)|(4:124|37|(22:39|40|130|41|(2:43|(8:45|47|48|49|(7:51|126|52|(1:(1:55)(1:56))|57|(1:151)(1:(2:60|152)(2:61|150))|62)|149|64|148)(7:46|48|49|(0)|149|64|148))(7:47|48|49|(0)|149|64|148)|70|136|71|(3:73|(2:75|(8:77|(1:79)|80|(1:82)|83|(1:85)|86|(1:158)(2:90|154))(1:156))(1:155)|91)|153|92|93|(1:95)(1:96)|(1:98)|99|(1:101)(1:102)|103|(1:105)(1:106)|107|(4:109|132|110|113)|114|115)(2:66|147)|67)|146|68|70|136|71|(0)|153|92|93|(0)(0)|(0)|99|(0)(0)|103|(0)(0)|107|(0)|114|115|(1:(0))) */
    /* JADX WARN: Removed duplicated region for block: B:101:0x036f  */
    /* JADX WARN: Removed duplicated region for block: B:102:0x0372  */
    /* JADX WARN: Removed duplicated region for block: B:105:0x03ce  */
    /* JADX WARN: Removed duplicated region for block: B:106:0x03d1  */
    /* JADX WARN: Removed duplicated region for block: B:109:0x040c  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0195  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0198  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0224  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x02c9 A[Catch: Exception -> 0x0347, TryCatch #6 {Exception -> 0x0347, blocks: (B:71:0x02b4, B:73:0x02c9, B:75:0x02d1, B:77:0x02e0, B:79:0x02f2, B:80:0x02f4, B:82:0x02fc, B:83:0x02fe, B:85:0x0306, B:86:0x0308, B:88:0x030c, B:90:0x0314, B:91:0x0316, B:92:0x0319), top: B:136:0x02b4 }] */
    /* JADX WARN: Removed duplicated region for block: B:95:0x034e  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x0353  */
    /* JADX WARN: Removed duplicated region for block: B:98:0x0356  */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    protected void onCreate(@org.jetbrains.annotations.Nullable android.os.Bundle r23) {
        /*
            Method dump skipped, instruction units count: 1293
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.rehman.ahmedreactionstudio.ui.DiagnosticsActivity.onCreate(android.os.Bundle):void");
    }

    private static final void onCreate$row(StringBuilder sb, DiagnosticsActivity diagnosticsActivity, LinearLayout linearLayout, String str, String str2) {
        sb.append(str);
        sb.append(": ");
        sb.append(str2);
        sb.append("\n");
        DiagnosticsActivity diagnosticsActivity2 = diagnosticsActivity;
        LinearLayout linearLayout2 = new LinearLayout(diagnosticsActivity2);
        linearLayout2.setOrientation(0);
        TextView textView = new TextView(diagnosticsActivity2);
        textView.setText(str);
        textView.setTextColor(UI.INSTANCE.getFG2());
        textView.setTextSize(12.5f);
        textView.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView2 = new TextView(diagnosticsActivity2);
        textView2.setText(str2);
        textView2.setTextColor(UI.INSTANCE.getFG());
        textView2.setTextSize(12.5f);
        textView2.setGravity(8388613);
        linearLayout2.addView(textView);
        linearLayout2.addView(textView2);
        linearLayout.addView(linearLayout2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$0(SharedPreferences sharedPreferences, Button hudBtn, View view) {
        Intrinsics.checkNotNullParameter(hudBtn, "$hudBtn");
        boolean z = true ^ sharedPreferences.getBoolean(EditorActivity.PREF_STATS_HUD, true);
        sharedPreferences.edit().putBoolean(EditorActivity.PREF_STATS_HUD, z).apply();
        hudBtn.setText(z ? "Preview stats overlay: ON" : "Preview stats overlay: OFF");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$4(List crashes, DiagnosticsActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(crashes, "$crashes");
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Iterator it = crashes.iterator();
        while (it.hasNext()) {
            File file = (File) it.next();
            try {
                Result.Companion companion = Result.INSTANCE;
                Result.m59constructorimpl(Boolean.valueOf(file.delete()));
            } catch (Throwable th) {
                Result.Companion companion2 = Result.INSTANCE;
                Result.m59constructorimpl(ResultKt.createFailure(th));
            }
        }
        UI.INSTANCE.toast(this$0, "Crash logs cleared");
        this$0.recreate();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$5(DiagnosticsActivity this$0, StringBuilder sb, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(sb, "$sb");
        Object systemService = this$0.getSystemService("clipboard");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
        ((ClipboardManager) systemService).setPrimaryClip(ClipData.newPlainText("diagnostics", sb.toString()));
        UI.INSTANCE.toast(this$0, "Copied");
    }
}
