package com.rehman.ahmedreactionstudio.ui;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.rehman.ahmedreactionstudio.util.UI;
import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: SplashActivity.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\u0018\u0000 \u001c2\u00020\u0001:\u0001\u001cB\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\n\u001a\u00020\u000bH\u0002J\b\u0010\f\u001a\u00020\u000bH\u0002J\b\u0010\r\u001a\u00020\u000eH\u0002J\u0010\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u0011H\u0002J\u0012\u0010\u0012\u001a\u00020\u000b2\b\u0010\u0013\u001a\u0004\u0018\u00010\u0014H\u0014J\b\u0010\u0015\u001a\u00020\u000bH\u0014J \u0010\u0016\u001a\u00020\u000b2\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\u001aH\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000"}, d2 = {"Lcom/rehman/ahmedreactionstudio/ui/SplashActivity;", "Landroid/app/Activity;", "()V", "advance", "Ljava/lang/Runnable;", "launchHome", "leaving", "", "main", "Landroid/os/Handler;", "fadeOutAndGo", "", "goHome", "makeBadge", "Landroid/widget/TextView;", "makeRing", "color", "", "onCreate", "b", "Landroid/os/Bundle;", "onDestroy", "pulse", "v", "Landroid/view/View;", "delayMs", "", "durMs", "Companion"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class SplashActivity extends Activity {

    @NotNull
    public static final String VERSION = "1.0.0";
    private boolean leaving;

    @NotNull
    private final Handler main = new Handler(Looper.getMainLooper());

    @NotNull
    private final Runnable advance = new Runnable() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$SplashActivity$YWUbHAdVD2DGJs1kCzXXEp1lxxc
        @Override // java.lang.Runnable
        public final void run() {
            SplashActivity.advance$lambda$0(this.f$0);
        }
    };

    @NotNull
    private final Runnable launchHome = new Runnable() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$SplashActivity$Ve68KddknUpHRGwMjP5OyvAtKzU
        @Override // java.lang.Runnable
        public final void run() {
            SplashActivity.launchHome$lambda$1(this.f$0);
        }
    };

    /* JADX INFO: Access modifiers changed from: private */
    public static final void advance$lambda$0(SplashActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.fadeOutAndGo();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void launchHome$lambda$1(SplashActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.goHome();
    }

    @Override // android.app.Activity
    protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        UI.styleWindow$default(UI.INSTANCE, this, false, 2, null);
        SplashActivity splashActivity = this;
        FrameLayout frameLayout = new FrameLayout(splashActivity);
        frameLayout.setClipChildren(false);
        frameLayout.setClipToPadding(false);
        frameLayout.setBackgroundColor(0);
        LinearLayout linearLayout = new LinearLayout(splashActivity);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(1);
        linearLayout.setClipChildren(false);
        linearLayout.setClipToPadding(false);
        FrameLayout frameLayout2 = new FrameLayout(splashActivity);
        frameLayout2.setClipChildren(false);
        frameLayout2.setClipToPadding(false);
        TextView textViewMakeRing = makeRing(Color.rgb(KotlinVersion.MAX_COMPONENT_VALUE, 90, 44));
        TextView textViewMakeRing2 = makeRing(Color.rgb(KotlinVersion.MAX_COMPONENT_VALUE, 160, 44));
        TextView textView = textViewMakeRing;
        frameLayout2.addView(textView);
        TextView textView2 = textViewMakeRing2;
        frameLayout2.addView(textView2);
        TextView textViewMakeBadge = makeBadge();
        frameLayout2.addView(textViewMakeBadge, new FrameLayout.LayoutParams(UI.INSTANCE.dp(splashActivity, 96), UI.INSTANCE.dp(splashActivity, 96), 17));
        linearLayout.addView(frameLayout2, new LinearLayout.LayoutParams(UI.INSTANCE.dp(splashActivity, 150), UI.INSTANCE.dp(splashActivity, 150)));
        LinearLayout linearLayout2 = new LinearLayout(splashActivity);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(1);
        linearLayout2.setPadding(0, UI.INSTANCE.dp(splashActivity, 6), 0, 0);
        onCreate$word(this, linearLayout2, "Ahmed", UI.INSTANCE.getFG(), 0.02f);
        onCreate$word(this, linearLayout2, " Reaction Studio", Color.rgb(KotlinVersion.MAX_COMPONENT_VALUE, 122, 60), 0.02f);
        linearLayout.addView(linearLayout2);
        TextView textViewLabel = UI.INSTANCE.label(splashActivity, "RECORD  ·  LAYER  ·  REACT  ·  EXPORT", true, 10.5f);
        textViewLabel.setLetterSpacing(0.26f);
        textViewLabel.setGravity(1);
        textViewLabel.setPadding(0, UI.INSTANCE.dp(splashActivity, 10), 0, 0);
        linearLayout.addView(textViewLabel);
        frameLayout.addView(linearLayout, new FrameLayout.LayoutParams(-2, -2, 17));
        TextView textViewLabel2 = UI.INSTANCE.label(splashActivity, "v1.0.0", true, 10.0f);
        textViewLabel2.setGravity(1);
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2, 81);
        layoutParams.bottomMargin = UI.INSTANCE.dp(splashActivity, 26);
        Unit unit = Unit.INSTANCE;
        frameLayout.addView(textViewLabel2, layoutParams);
        setContentView(frameLayout);
        textViewMakeBadge.setAlpha(0.0f);
        textViewMakeBadge.setScaleX(0.3f);
        textViewMakeBadge.setScaleY(0.3f);
        linearLayout2.setAlpha(0.0f);
        linearLayout2.setTranslationY(UI.INSTANCE.dp(splashActivity, 26));
        textViewLabel.setAlpha(0.0f);
        textViewLabel2.setAlpha(0.0f);
        ObjectAnimator objectAnimatorOfPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(textViewMakeBadge, PropertyValuesHolder.ofFloat("scaleX", 0.3f, 1.0f), PropertyValuesHolder.ofFloat("scaleY", 0.3f, 1.0f), PropertyValuesHolder.ofFloat("alpha", 0.0f, 1.0f));
        objectAnimatorOfPropertyValuesHolder.setDuration(900L);
        objectAnimatorOfPropertyValuesHolder.setInterpolator(new OvershootInterpolator(2.4f));
        objectAnimatorOfPropertyValuesHolder.start();
        ObjectAnimator objectAnimatorOfPropertyValuesHolder2 = ObjectAnimator.ofPropertyValuesHolder(linearLayout2, PropertyValuesHolder.ofFloat("alpha", 0.0f, 1.0f), PropertyValuesHolder.ofFloat("translationY", linearLayout2.getTranslationY(), 0.0f));
        objectAnimatorOfPropertyValuesHolder2.setDuration(650L);
        objectAnimatorOfPropertyValuesHolder2.setStartDelay(420L);
        objectAnimatorOfPropertyValuesHolder2.setInterpolator(new DecelerateInterpolator(1.6f));
        objectAnimatorOfPropertyValuesHolder2.start();
        ObjectAnimator objectAnimatorOfPropertyValuesHolder3 = ObjectAnimator.ofPropertyValuesHolder(textViewLabel, PropertyValuesHolder.ofFloat("alpha", 0.0f, 1.0f));
        objectAnimatorOfPropertyValuesHolder3.setDuration(500L);
        objectAnimatorOfPropertyValuesHolder3.setStartDelay(620L);
        objectAnimatorOfPropertyValuesHolder3.start();
        ObjectAnimator objectAnimatorOfPropertyValuesHolder4 = ObjectAnimator.ofPropertyValuesHolder(textViewLabel2, PropertyValuesHolder.ofFloat("alpha", 0.0f, 0.85f));
        objectAnimatorOfPropertyValuesHolder4.setDuration(500L);
        objectAnimatorOfPropertyValuesHolder4.setStartDelay(900L);
        objectAnimatorOfPropertyValuesHolder4.start();
        pulse(textView, 150L, 1900L);
        pulse(textView2, 1000L, 1900L);
        this.main.postDelayed(this.advance, 2400L);
    }

    private static final TextView onCreate$word(SplashActivity splashActivity, LinearLayout linearLayout, String str, int i, float f) {
        TextView textView = new TextView(splashActivity);
        textView.setText(str);
        textView.setTextColor(i);
        textView.setTextSize(27.0f);
        textView.setLetterSpacing(f);
        textView.setTypeface(Typeface.create("sans-serif-medium", 1));
        textView.setIncludeFontPadding(false);
        linearLayout.addView(textView);
        return textView;
    }

    private final TextView makeRing(int color) {
        SplashActivity splashActivity = this;
        TextView textView = new TextView(splashActivity);
        int iDp = UI.INSTANCE.dp(splashActivity, 128);
        textView.setLayoutParams(new FrameLayout.LayoutParams(iDp, iDp, 17));
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        gradientDrawable.setColor(0);
        gradientDrawable.setStroke(UI.INSTANCE.dp(splashActivity, 2), color);
        textView.setBackground(gradientDrawable);
        textView.setAlpha(0.0f);
        return textView;
    }

    private final TextView makeBadge() {
        SplashActivity splashActivity = this;
        TextView textView = new TextView(splashActivity);
        textView.setText("▶");
        textView.setGravity(17);
        textView.setTextColor(-1);
        textView.setTextSize(34.0f);
        textView.setPadding(UI.INSTANCE.dp(splashActivity, 4), 0, 0, 0);
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Color.rgb(KotlinVersion.MAX_COMPONENT_VALUE, 145, 60), Color.rgb(238, 60, 28)});
        gradientDrawable.setCornerRadius(UI.INSTANCE.dpf(splashActivity, 26.0f));
        gradientDrawable.setStroke(UI.INSTANCE.dp(splashActivity, 1), Color.argb(90, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE, KotlinVersion.MAX_COMPONENT_VALUE));
        textView.setBackground(gradientDrawable);
        return textView;
    }

    private final void pulse(final View v, long delayMs, long durMs) {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        valueAnimatorOfFloat.setDuration(durMs);
        valueAnimatorOfFloat.setStartDelay(delayMs);
        valueAnimatorOfFloat.setRepeatCount(-1);
        valueAnimatorOfFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$SplashActivity$R9u0rv_-N2tzqhJT3av6cUJZB1c
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                SplashActivity.pulse$lambda$7(v, valueAnimator);
            }
        });
        valueAnimatorOfFloat.start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void pulse$lambda$7(View v, ValueAnimator valueAnimator) {
        Intrinsics.checkNotNullParameter(v, "$v");
        Object animatedValue = valueAnimator.getAnimatedValue();
        Intrinsics.checkNotNull(animatedValue, "null cannot be cast to non-null type kotlin.Float");
        float fFloatValue = ((Float) animatedValue).floatValue();
        float f = (1.5f * fFloatValue) + 0.4f;
        v.setScaleX(f);
        v.setScaleY(f);
        v.setAlpha(RangesKt.coerceIn((1.0f - fFloatValue) * 0.55f, 0.0f, 0.55f));
    }

    private final void fadeOutAndGo() {
        if (this.leaving) {
            return;
        }
        this.leaving = true;
        ObjectAnimator objectAnimatorOfPropertyValuesHolder = ObjectAnimator.ofPropertyValuesHolder(findViewById(R.id.content), PropertyValuesHolder.ofFloat("alpha", 1.0f, 0.0f), PropertyValuesHolder.ofFloat("scaleX", 1.0f, 1.08f), PropertyValuesHolder.ofFloat("scaleY", 1.0f, 1.08f));
        objectAnimatorOfPropertyValuesHolder.setDuration(320L);
        objectAnimatorOfPropertyValuesHolder.addListener(new AnimatorListenerAdapter() { // from class: com.rehman.ahmedreactionstudio.ui.SplashActivity$fadeOutAndGo$1$1
            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public void onAnimationEnd(@NotNull Animator a) {
                Intrinsics.checkNotNullParameter(a, "a");
                this.this$0.main.postDelayed(this.this$0.launchHome, 40L);
            }
        });
        objectAnimatorOfPropertyValuesHolder.start();
    }

    private final void goHome() {
        if (isFinishing()) {
            return;
        }
        startActivity(new Intent(this, (Class<?>) HomeActivity.class));
        overridePendingTransition(0, 0);
        this.main.postDelayed(new Runnable() { // from class: com.rehman.ahmedreactionstudio.ui.-$$Lambda$SplashActivity$uczQDGMYs2-K_pBNFp4mt5ea6gE
            @Override // java.lang.Runnable
            public final void run() {
                SplashActivity.goHome$lambda$9(this.f$0);
            }
        }, 60L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void goHome$lambda$9(SplashActivity this$0) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.finish();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        this.leaving = true;
        this.main.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
