package kotlin.collections;

import kotlin.ExperimentalUnsignedTypes;
import kotlin.Metadata;
import kotlin.UByte;
import kotlin.UByteArray;
import kotlin.UIntArray;
import kotlin.ULongArray;
import kotlin.UShort;
import kotlin.UShortArray;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: UArraySorting.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u00000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0010\u001a'\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0003¢\u0006\u0004\b\u0006\u0010\u0007\u001a'\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\b2\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0003¢\u0006\u0004\b\t\u0010\n\u001a'\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u000b2\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0003¢\u0006\u0004\b\f\u0010\r\u001a'\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u000e2\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0003¢\u0006\u0004\b\u000f\u0010\u0010\u001a'\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0003¢\u0006\u0004\b\u0013\u0010\u0014\u001a'\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0002\u001a\u00020\b2\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0003¢\u0006\u0004\b\u0015\u0010\u0016\u001a'\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0002\u001a\u00020\u000b2\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0003¢\u0006\u0004\b\u0017\u0010\u0018\u001a'\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0002\u001a\u00020\u000e2\u0006\u0010\u0004\u001a\u00020\u00012\u0006\u0010\u0005\u001a\u00020\u0001H\u0003¢\u0006\u0004\b\u0019\u0010\u001a\u001a'\u0010\u001b\u001a\u00020\u00122\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u001c\u001a\u00020\u00012\u0006\u0010\u001d\u001a\u00020\u0001H\u0001¢\u0006\u0004\b\u001e\u0010\u0014\u001a'\u0010\u001b\u001a\u00020\u00122\u0006\u0010\u0002\u001a\u00020\b2\u0006\u0010\u001c\u001a\u00020\u00012\u0006\u0010\u001d\u001a\u00020\u0001H\u0001¢\u0006\u0004\b\u001f\u0010\u0016\u001a'\u0010\u001b\u001a\u00020\u00122\u0006\u0010\u0002\u001a\u00020\u000b2\u0006\u0010\u001c\u001a\u00020\u00012\u0006\u0010\u001d\u001a\u00020\u0001H\u0001¢\u0006\u0004\b \u0010\u0018\u001a'\u0010\u001b\u001a\u00020\u00122\u0006\u0010\u0002\u001a\u00020\u000e2\u0006\u0010\u001c\u001a\u00020\u00012\u0006\u0010\u001d\u001a\u00020\u0001H\u0001¢\u0006\u0004\b!\u0010\u001a¨\u0006\""}, d2 = {"partition", "", "array", "Lkotlin/UByteArray;", "left", "right", "partition-4UcCI2c", "([BII)I", "Lkotlin/UIntArray;", "partition-oBK06Vg", "([III)I", "Lkotlin/ULongArray;", "partition--nroSd4", "([JII)I", "Lkotlin/UShortArray;", "partition-Aa5vz7o", "([SII)I", "quickSort", "", "quickSort-4UcCI2c", "([BII)V", "quickSort-oBK06Vg", "([III)V", "quickSort--nroSd4", "([JII)V", "quickSort-Aa5vz7o", "([SII)V", "sortArray", "fromIndex", "toIndex", "sortArray-4UcCI2c", "sortArray-oBK06Vg", "sortArray--nroSd4", "sortArray-Aa5vz7o", "kotlin-stdlib"}, k = 2, mv = {1, 9, 0}, xi = 48)
public final class UArraySortingKt {
    @ExperimentalUnsignedTypes
    /* JADX INFO: renamed from: partition-4UcCI2c, reason: not valid java name */
    private static final int m515partition4UcCI2c(byte[] bArr, int i, int i2) {
        int i3;
        byte bM135getw2LRezQ = UByteArray.m135getw2LRezQ(bArr, (i + i2) / 2);
        while (i <= i2) {
            while (true) {
                int iM135getw2LRezQ = UByteArray.m135getw2LRezQ(bArr, i) & UByte.MAX_VALUE;
                i3 = bM135getw2LRezQ & UByte.MAX_VALUE;
                if (Intrinsics.compare(iM135getw2LRezQ, i3) >= 0) {
                    break;
                }
                i++;
            }
            while (Intrinsics.compare(UByteArray.m135getw2LRezQ(bArr, i2) & UByte.MAX_VALUE, i3) > 0) {
                i2--;
            }
            if (i <= i2) {
                byte bM135getw2LRezQ2 = UByteArray.m135getw2LRezQ(bArr, i);
                UByteArray.m140setVurrAj0(bArr, i, UByteArray.m135getw2LRezQ(bArr, i2));
                UByteArray.m140setVurrAj0(bArr, i2, bM135getw2LRezQ2);
                i++;
                i2--;
            }
        }
        return i;
    }

    @ExperimentalUnsignedTypes
    /* JADX INFO: renamed from: quickSort-4UcCI2c, reason: not valid java name */
    private static final void m519quickSort4UcCI2c(byte[] bArr, int i, int i2) {
        int iM515partition4UcCI2c = m515partition4UcCI2c(bArr, i, i2);
        int i3 = iM515partition4UcCI2c - 1;
        if (i < i3) {
            m519quickSort4UcCI2c(bArr, i, i3);
        }
        if (iM515partition4UcCI2c < i2) {
            m519quickSort4UcCI2c(bArr, iM515partition4UcCI2c, i2);
        }
    }

    @ExperimentalUnsignedTypes
    /* JADX INFO: renamed from: partition-Aa5vz7o, reason: not valid java name */
    private static final int m516partitionAa5vz7o(short[] sArr, int i, int i2) {
        int i3;
        short sM398getMh2AYeg = UShortArray.m398getMh2AYeg(sArr, (i + i2) / 2);
        while (i <= i2) {
            while (true) {
                int iM398getMh2AYeg = UShortArray.m398getMh2AYeg(sArr, i) & UShort.MAX_VALUE;
                i3 = sM398getMh2AYeg & UShort.MAX_VALUE;
                if (Intrinsics.compare(iM398getMh2AYeg, i3) >= 0) {
                    break;
                }
                i++;
            }
            while (Intrinsics.compare(UShortArray.m398getMh2AYeg(sArr, i2) & UShort.MAX_VALUE, i3) > 0) {
                i2--;
            }
            if (i <= i2) {
                short sM398getMh2AYeg2 = UShortArray.m398getMh2AYeg(sArr, i);
                UShortArray.m403set01HTLdE(sArr, i, UShortArray.m398getMh2AYeg(sArr, i2));
                UShortArray.m403set01HTLdE(sArr, i2, sM398getMh2AYeg2);
                i++;
                i2--;
            }
        }
        return i;
    }

    @ExperimentalUnsignedTypes
    /* JADX INFO: renamed from: quickSort-Aa5vz7o, reason: not valid java name */
    private static final void m520quickSortAa5vz7o(short[] sArr, int i, int i2) {
        int iM516partitionAa5vz7o = m516partitionAa5vz7o(sArr, i, i2);
        int i3 = iM516partitionAa5vz7o - 1;
        if (i < i3) {
            m520quickSortAa5vz7o(sArr, i, i3);
        }
        if (iM516partitionAa5vz7o < i2) {
            m520quickSortAa5vz7o(sArr, iM516partitionAa5vz7o, i2);
        }
    }

    @ExperimentalUnsignedTypes
    /* JADX INFO: renamed from: partition-oBK06Vg, reason: not valid java name */
    private static final int m517partitionoBK06Vg(int[] iArr, int i, int i2) {
        int iM214getpVg5ArA = UIntArray.m214getpVg5ArA(iArr, (i + i2) / 2);
        while (i <= i2) {
            while (Integer.compareUnsigned(UIntArray.m214getpVg5ArA(iArr, i), iM214getpVg5ArA) < 0) {
                i++;
            }
            while (Integer.compareUnsigned(UIntArray.m214getpVg5ArA(iArr, i2), iM214getpVg5ArA) > 0) {
                i2--;
            }
            if (i <= i2) {
                int iM214getpVg5ArA2 = UIntArray.m214getpVg5ArA(iArr, i);
                UIntArray.m219setVXSXFK8(iArr, i, UIntArray.m214getpVg5ArA(iArr, i2));
                UIntArray.m219setVXSXFK8(iArr, i2, iM214getpVg5ArA2);
                i++;
                i2--;
            }
        }
        return i;
    }

    @ExperimentalUnsignedTypes
    /* JADX INFO: renamed from: quickSort-oBK06Vg, reason: not valid java name */
    private static final void m521quickSortoBK06Vg(int[] iArr, int i, int i2) {
        int iM517partitionoBK06Vg = m517partitionoBK06Vg(iArr, i, i2);
        int i3 = iM517partitionoBK06Vg - 1;
        if (i < i3) {
            m521quickSortoBK06Vg(iArr, i, i3);
        }
        if (iM517partitionoBK06Vg < i2) {
            m521quickSortoBK06Vg(iArr, iM517partitionoBK06Vg, i2);
        }
    }

    @ExperimentalUnsignedTypes
    /* JADX INFO: renamed from: partition--nroSd4, reason: not valid java name */
    private static final int m514partitionnroSd4(long[] jArr, int i, int i2) {
        long jM293getsVKNKU = ULongArray.m293getsVKNKU(jArr, (i + i2) / 2);
        while (i <= i2) {
            while (Long.compareUnsigned(ULongArray.m293getsVKNKU(jArr, i), jM293getsVKNKU) < 0) {
                i++;
            }
            while (Long.compareUnsigned(ULongArray.m293getsVKNKU(jArr, i2), jM293getsVKNKU) > 0) {
                i2--;
            }
            if (i <= i2) {
                long jM293getsVKNKU2 = ULongArray.m293getsVKNKU(jArr, i);
                ULongArray.m298setk8EXiF4(jArr, i, ULongArray.m293getsVKNKU(jArr, i2));
                ULongArray.m298setk8EXiF4(jArr, i2, jM293getsVKNKU2);
                i++;
                i2--;
            }
        }
        return i;
    }

    @ExperimentalUnsignedTypes
    /* JADX INFO: renamed from: quickSort--nroSd4, reason: not valid java name */
    private static final void m518quickSortnroSd4(long[] jArr, int i, int i2) {
        int iM514partitionnroSd4 = m514partitionnroSd4(jArr, i, i2);
        int i3 = iM514partitionnroSd4 - 1;
        if (i < i3) {
            m518quickSortnroSd4(jArr, i, i3);
        }
        if (iM514partitionnroSd4 < i2) {
            m518quickSortnroSd4(jArr, iM514partitionnroSd4, i2);
        }
    }

    @ExperimentalUnsignedTypes
    /* JADX INFO: renamed from: sortArray-4UcCI2c, reason: not valid java name */
    public static final void m523sortArray4UcCI2c(@NotNull byte[] array, int i, int i2) {
        Intrinsics.checkNotNullParameter(array, "array");
        m519quickSort4UcCI2c(array, i, i2 - 1);
    }

    @ExperimentalUnsignedTypes
    /* JADX INFO: renamed from: sortArray-Aa5vz7o, reason: not valid java name */
    public static final void m524sortArrayAa5vz7o(@NotNull short[] array, int i, int i2) {
        Intrinsics.checkNotNullParameter(array, "array");
        m520quickSortAa5vz7o(array, i, i2 - 1);
    }

    @ExperimentalUnsignedTypes
    /* JADX INFO: renamed from: sortArray-oBK06Vg, reason: not valid java name */
    public static final void m525sortArrayoBK06Vg(@NotNull int[] array, int i, int i2) {
        Intrinsics.checkNotNullParameter(array, "array");
        m521quickSortoBK06Vg(array, i, i2 - 1);
    }

    @ExperimentalUnsignedTypes
    /* JADX INFO: renamed from: sortArray--nroSd4, reason: not valid java name */
    public static final void m522sortArraynroSd4(@NotNull long[] array, int i, int i2) {
        Intrinsics.checkNotNullParameter(array, "array");
        m518quickSortnroSd4(array, i, i2 - 1);
    }
}
