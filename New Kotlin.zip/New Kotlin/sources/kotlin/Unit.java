package kotlin;

import org.jetbrains.annotations.NotNull;

/* JADX INFO: compiled from: Unit.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\u0010\n\u0002\u0010\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\u0002\b\u0002J\b\u0010\u0002\u001a\u00020\u0003H\u0016¨\u0006\u0004"}, d2 = {"", "", "toString", "", "kotlin-stdlib"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class Unit {

    @NotNull
    public static final Unit INSTANCE = new Unit();

    @NotNull
    public String toString() {
        return "kotlin.Unit";
    }

    private Unit() {
    }
}
